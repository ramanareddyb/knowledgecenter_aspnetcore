﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleTonDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {

            AxSingleTon.clsecDefaults.get_ecdefaults_fromDB();
            Console.WriteLine("Hi....Welcome to SingleTonDemo");
            Console.WriteLine("Excelicare System DateFormats");
            Console.WriteLine("-------------------------------");
            Console.WriteLine(AxSingleTon.clsecDefaults.dateFormats().ToString());


            Console.WriteLine("Excelicare System Defaults");
            Console.WriteLine("-------------------------------");
            Console.WriteLine(AxSingleTon.clsecDefaults.sysDefaults().ToString());


            Console.WriteLine("Reading Individual Values");
            Console.WriteLine("---------------------------");
            Console.WriteLine("Reading specific DateFormat");
            Console.WriteLine($"1130 dateFormat value : {AxSingleTon.clsecDefaults.getDateFormat(1130)}");
            //$"Type is {str.GetType() } & value = {str}"

            Console.WriteLine("Reading specific SysDefault value");
            Console.WriteLine($"2577 sysdefault value : {AxSingleTon.clsecDefaults.getsysDefault(2577)}");

            Console.ReadLine();
        }
    }
}
