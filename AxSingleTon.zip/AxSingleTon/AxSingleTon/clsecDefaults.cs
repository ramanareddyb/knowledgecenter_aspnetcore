﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Excelicare.Framework.AppDataSupport;
using System.Configuration;
using System.Data;
using System.Text.RegularExpressions;

namespace AxSingleTon
{
    /// <summary>
    /// SingleTon class for EC Default values 
    /// Created By  :  BRR
    /// Created Date:  2023-JAN-03
    /// </summary>
    public class clsecDefaults
    {

        //single ton variable declarations

        private static string strDateFormats = string.Empty;
        private static string strSysDefaults = string.Empty;
        private static string strResults = string.Empty;
       
        private clsecDefaults()
        { }


        //property methods for singleton class
        public static string Ec_Url { get; set; }

        public static string EcService_Url { get; set; }
        public static Boolean showScriptErrors { get; set; }

        public static Boolean ShowServerErrors { get; set; }
        public static Boolean IsTraceWriteToFile { get; set; }

        public static Boolean ValidatePostCode { get; set; }


        //getting and assigning all sysdefault and dateformat values from the configure database
        public static void getecDefaults()
        {           
           
            try
            {
        
                clsDataAccess objClsDataAccess;
                objClsDataAccess = new clsDataAccess();
                string strConn = ConfigurationManager.AppSettings["ConnectionString"];
                objClsDataAccess.GetConnectionStringforUser(ref strConn, EnumDataBaseUserType.AxAppUser);
                objClsDataAccess.ConnectionString = strConn;
                //return objClsDataAccess.ExecuteDataSet("axadhocsp_getPatients", CommandType.StoredProcedure, param).Tables[0];
                strResults = @"[{'success': true,'message': 'data found','data': {  'dateFormats': {'ShowScriptErrors': 'False','1130':'dd/MM/yyyy', '1131':'MM/yyyy','1132':'dd/MM/yyyy hh:mm:ss AM/PM',	'2535':'ddMMyyyy_Hmmss',	'2536':'dddd, mmmm dd, yyyy','2537':'mmmm dd, yyyy',	'2538':'yyyy-MM-dd',	'2539':'dd-mmm-yy',	'2542':'mmmm yy',	'2543':'mmm-yy',	'2557':'dd/MM/yyyy HH:mm ddd',	'2558':'d/M/y',	'2980':'dd/MM/yyyy','2981':'dd/MM/yyyy HH:mm:ss',	'2982':'dd/MM/yyyy hh:mm:ss tt',	'2983':'dd/MM/yyyy HH:mm','2984':'MM/yyyy',	'2985':'dd/MM/yyyy hh:mm:ss AM/PM','DPDelimiter' : '/','DPDayPosition' : '1','DPMonthPosition' : '2','DPYearPosition' : '3',},'sysDefaults': {  '1032':'333','2575' : '1',	'2576' : '1',	'2577' : '/^[a-zA-Z0-9]*$/gm',	'2578' : '350'," +
                       "'1011' : '15' ,'2490' : '1','2583' : '2', '2585' : '1','2562' : '0', '2000' : '0', '1215' :'3','2000':'0','2080':'3107','2181':'1','2285':'0','2287':'1','2288':'3','2289':'5','2397':'1','2520':'JBSWY3DPEHPK3PXP','2521':'49.249.225.113,157.48.77.203,157.48.77.148','2583' : '2',	'2584' : '44444',	'2585' : '1',	'2587' : '',	'2588' : '0',	'2642' : '1',	'9525000' :'1'}} }]";
               

                strResults.Replace("2544:", "DPDelimiter:").Replace("2545:", "DPDayPosition:").Replace("2546:", "DPMonthPosition:").Replace("2547:", "DPYearPosition:");
                
            }
            catch (Exception ex) { }
        }

         /// <summary>
        /// constructing the ecdefault values like dateformats and sysdefault values by fethcing from DB
        /// </summary>
        /// <returns></returns>
        public static void get_ecdefaults_fromDB()
        {
            try
            {
                clsDataAccess objClsDataAccess;
                objClsDataAccess = new clsDataAccess();
                string strConn = ConfigurationManager.AppSettings["ConnectionString"];
                objClsDataAccess.GetConnectionStringforUser(ref strConn, EnumDataBaseUserType.AxAppUser);
                objClsDataAccess.ConnectionString = strConn;

                strResults = objClsDataAccess.ExecuteDataSet("[AxSP_GetECdefaultValue]", CommandType.StoredProcedure).Tables[0].Rows[0][0].ToString();                
                dynamic strResultJObj = JsonConvert.DeserializeObject(strResults[0].ToString());

            }
            catch (Exception ex) { strResults = ""; }
            finally { }
        }
       
        //gettting all dateFormats
        public static string dateFormats()
        {
            dynamic strResultJObj = JsonConvert.DeserializeObject(strResults);
            return strResultJObj[0].data.dateFormats.ToString().ToString();
        }

        //gettting all sysDefaults
        public static string sysDefaults()
        {
            dynamic strResultJObj = JsonConvert.DeserializeObject(strResults);
            return strResultJObj[0].data.sysDefaults.ToString().ToString();
        }

        //getting sysdefault value based on the given sysdefault id
        public static string getsysDefault(int sysdefaultid)
        {
            dynamic strResultJObj = JsonConvert.DeserializeObject(strResults);
            return (strResultJObj[0].data.sysDefaults["" + sysdefaultid + ""] != null ? strResultJObj[0].data.sysDefaults["" + sysdefaultid + ""].Value.ToString() : "");
        }

        //getting dateformat string based on the given lookup
        public static string getDateFormat(int dtformatlookup)
        {
            dynamic strResultJObj = JsonConvert.DeserializeObject(strResults);
            return (strResultJObj[0].data.dateFormats["" + dtformatlookup + ""] != null ? strResultJObj[0].data.dateFormats["" + dtformatlookup + ""].Value.ToString() : "") ;
        }
        /// <summary>
        /// get the document module related dateformats
        /// </summary>
        /// <returns></returns>
        public static string getDocumentDateFormats()
        {
            try
            {
                return "1142,1143,1144,1145,1146,1147,1148,1149,1150,1151,1152,1153,1154,1155,1137,1139,1131,3106".ToString();
            }
            catch (Exception ex) { throw ex; }
        }
        /// <summary>
        /// validate XSS security vulnerabilities
        /// </summary>
        /// <param name="strInput"></param>
        /// <returns></returns>
        public static bool validateXSS(string strInput)
        {
            string strRegExp = "";
            bool blnFound;   
            try
            {
                strInput = strInput.Replace("&lt;", "<").Replace("&gt;", ">").Replace("&amp;", "&").Replace("&apos;", "'").Replace("&quot;", "\"");
                //strRegExp =  "<[^\\w<>]*(?:[^<>""'\s]*:)?[^\w<>]*(?:\W*s\W*c\W*r\W*i\W*p\W*t|\W*s\W*t\W*y\W*l\W*e|\W*f\W*o\W*r\W*m|\W*m\W*a\W*t\W*h|\W*s\W*v\W*g|\W*m\W*a\W*r\W*q\W*u\W*e\W*e|(?:\W*l\W*i\W*n\W*k|\W*o\W*b\W*j\W*e\W*c\W*t|\W*e\W*m\W*b\W*e\W*d|\W*a\W*p\W*p\W*l\W*e\W*t|\W*p\W*a\W*r\W*a\W*m|\W*i?\W*f\W*r\W*a\W*m\W*e|\W*b\W*a\W*s\W*e|\W*b\W*o\W*d\W*y|\W*m\W*e\W*t\W*a|\W*i\W*m\W*a?\W*g\W*e?|\W*v\W*i\W*d\W*e\W*o|\W*a\W*u\W*d\W*i\W*o|\W*b\W*i\W*n\W*d\W*i\W*n\W*g\W*s|\W*s\W*e\W*t|\W*i\W*s\W*i\W*n\W*d\W*e\W*x|\W*a\W*n\W*i\W*m\W*a\W*t\W*e)[^>\w])|(?:<\w[\s\S]*[\s\0\/]|['""])(?:formaction|style|background|src|href|lowsrc|ping|on(?:d(?:e(?:vice(?:(?:orienta|mo)tion|proximity|found|light)|livery(?:success|error)|activate)|r(?:ag(?:e(?:n(?:ter|d)|xit)|(?:gestur|leav)e|start|drop|over)?|op)|i(?:s(?:c(?:hargingtimechange|onnect(?:ing|ed))|abled)|aling)|ata(?:setc(?:omplete|hanged)|(?:availabl|chang)e|error)|urationchange|ownloading|blclick)|Moz(?:M(?:agnifyGesture(?:Update|Start)?|ouse(?:PixelScroll|Hittest))|S(?:wipeGesture(?:Update|Start|End)?|crolledAreaChanged)|(?:(?:Press)?TapGestur|BeforeResiz)e|EdgeUI(?:C(?:omplet|ancel)|Start)ed|RotateGesture(?:Update|Start)?|A(?:udioAvailable|fterPaint))|c(?:o(?:m(?:p(?:osition(?:update|start|end)|lete)|mand(?:update)?)|n(?:t(?:rolselect|extmenu)|nect(?:ing|ed))|py)|a(?:(?:llschang|ch)ed|nplay(?:through)?|rdstatechange)|h(?:(?:arging(?:time)?ch)?ange|ecking)|(?:fstate|ell)change|u(?:echange|t)|l(?:ick|ose))|m(?:o(?:z(?:pointerlock(?:change|error)|(?:orientation|time)change|fullscreen(?:change|error)|network(?:down|up)load)|use(?:(?:lea|mo)ve|o(?:ver|ut)|enter|wheel|down|up)|ve(?:start|end)?)|essage|ark)|s(?:t(?:a(?:t(?:uschanged|echange)|lled|rt)|k(?:sessione|comma)nd|op)|e(?:ek(?:complete|ing|ed)|(?:lec(?:tstar)?)?t|n(?:ding|t))|u(?:ccess|spend|bmit)|peech(?:start|end)|ound(?:start|end)|croll|how)|b(?:e(?:for(?:e(?:(?:scriptexecu|activa)te|u(?:nload|pdate)|p(?:aste|rint)|c(?:opy|ut)|editfocus)|deactivate)|gin(?:Event)?)|oun(?:dary|ce)|l(?:ocked|ur)|roadcast|usy)|a(?:n(?:imation(?:iteration|start|end)|tennastatechange)|fter(?:(?:scriptexecu|upda)te|print)|udio(?:process|start|end)|d(?:apteradded|dtrack)|ctivate|lerting|bort)|DOM(?:Node(?:Inserted(?:IntoDocument)?|Removed(?:FromDocument)?)|(?:CharacterData|Subtree)Modified|A(?:ttrModified|ctivate)|Focus(?:Out|In)|MouseScroll)|r(?:e(?:s(?:u(?:m(?:ing|e)|lt)|ize|et)|adystatechange|pea(?:tEven)?t|movetrack|trieving|ceived)|ow(?:s(?:inserted|delete)|e(?:nter|xit))|atechange)|p(?:op(?:up(?:hid(?:den|ing)|show(?:ing|n))|state)|a(?:ge(?:hide|show)|(?:st|us)e|int)|ro(?:pertychange|gress)|lay(?:ing)?)|t(?:ouch(?:(?:lea|mo)ve|en(?:ter|d)|cancel|start)|ime(?:update|out)|ransitionend|ext)|u(?:s(?:erproximity|sdreceived)|p(?:gradeneeded|dateready)|n(?:derflow|load))|f(?:o(?:rm(?:change|input)|cus(?:out|in)?)|i(?:lterchange|nish)|ailed)|l(?:o(?:ad(?:e(?:d(?:meta)?data|nd)|start)?|secapture)|evelchange|y)|g(?:amepad(?:(?:dis)?connected|button(?:down|up)|axismove)|et)|e(?:n(?:d(?:Event|ed)?|abled|ter)|rror(?:update)?|mptied|xit)|i(?:cc(?:cardlockerror|infochange)|n(?:coming|valid|put))|o(?:(?:(?:ff|n)lin|bsolet)e|verflow(?:changed)?|pen)|SVG(?:(?:Unl|L)oad|Resize|Scroll|Abort|Error|Zoom)|h(?:e(?:adphoneschange|l[dp])|ashchange|olding)|v(?:o(?:lum|ic)e|ersion)change|w(?:a(?:it|rn)ing|heel)|key(?:press|down|up)|(?:AppComman|Loa)d|no(?:update|match)|Request|javascript|zoom))[\s\0]*=";
                blnFound = Regex.IsMatch(strInput, strRegExp, RegexOptions.IgnoreCase);              
                return blnFound;
            }
            catch (Exception ex){throw ex;}
            finally
            {
                blnFound = default(Boolean);
                strRegExp = null;                
            }
        }
        /// <summary>
        /// validate HTML content received from UI to avoid secuirity vulneravilities
        /// </summary>
        /// <param name="strHTML"></param>
        /// <returns></returns>
        public static bool validateHTMLContent(string strHTML)
        {
            string strRexExp;
            bool blnFound;
            try
            {
                strRexExp = "(<script|<\\/script>|alert|<math|<svg|<body|<form|<a\\sonmouseover=|<Img|script>|<iframe|<Link|<Style|<Meta|javascript|<Frameset|<htm|<html|<embed|SCRIPT+AD4)";
                blnFound = Regex.IsMatch(strHTML, strRexExp, RegexOptions.IgnorePatternWhitespace | RegexOptions.Multiline | RegexOptions.IgnoreCase);
                return blnFound;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                blnFound = default(Boolean);
                strRexExp = null;
            }
        }
        /// <summary>
        /// validate OS and SQLCommand injections to avoid security vulnerabilities
        /// </summary>
        /// <param name="strValue"></param>
        /// <returns></returns>
        public static bool validateOSandSQLCommandInjections(string strValue)
        {
            string strPattern;
            bool blnFound=false;
            RegexOptions options;
            try
            {
                if (strValue != "")
                {
                    //strValue = strValue.Replace(String.Chr(34), "").Replace("\"", "");                  
                    strPattern = "";
                    options = RegexOptions.Multiline | RegexOptions.IgnoreCase;
                    blnFound = Regex.IsMatch(strValue.ToLower(), strPattern, options);
                    if (blnFound == false)
                        blnFound =validateSqlInjection(strValue);                    
                }
                return blnFound;
            }
            catch (Exception ex) { throw ex; }
            finally { strPattern = null; }         
        }
         /// <summary>
        /// validate SQLInjections
        /// </summary>
        /// <param name="strValue"></param>
        /// <returns></returns>
        public static bool validateSqlInjection(string strValue)
        {
            string strPattern;
            bool blnFound;
            RegexOptions options;
            try
            {
                strPattern =  "";
                options = RegexOptions.Multiline | RegexOptions.IgnoreCase;
                blnFound = Regex.IsMatch(strValue, strPattern, options);                
                return blnFound;
            }
            catch (Exception ex){throw ex;}
            finally{strPattern = null;}
        }
    }
    /// <summary>
    ///  SingleTon Demo class
    /// </summary>
    public class singletondemo
    {

        private static Int32 count = 0;
        private singletondemo()
        {

        }

        public static void hit()
        {
            count++;
        }

        public static Int32 getCount()
        {
            return count;
        }

    }
}
