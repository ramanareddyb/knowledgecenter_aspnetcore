USE [ExceliDB_v751UK_DEV]
GO
/****** Object:  StoredProcedure [dbo].[AxSP_GetECdefaultValue]    Script Date: 06/01/2023 10:45:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/****      
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------      
OBJECT NAME  	: AxSP_GetECdefaultValue  
CREATED DATE  	: 05-Jan-2023
AUTHOR NAME  	: ADSR Prasad
TYPE OF OBJECT  : SP
INPUT PARAMS  	: 
OUTPUT PARAMS  	: NVARCHAR(MAX)
OBJECTS USED  	: tblSysLookUp, tblSysDefault
PURPOSE         : Get the Excelicare one time used default values.
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------      
MODIFICATION LOG: 
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------      
AUTHOR		VERSION		DATE            REASON/CHANGES      
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------      
ADSR Prasad	1.0			05-Jan-2023		Initial Implmentation
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Exec [AxSP_GetECdefaultValue] 0

*/  


ALTER   PROCEDURE [dbo].[AxSP_GetECdefaultValue]
(
	@isClient Bit = 1
)
AS
BEGIN
	SET NOCOUNT ON     
BEGIN TRY   

		DECLARE @strSysDefaultInfo AS NVARCHAR(MAX) = '',				 
				@strSysLookupInfo AS NVARCHAR(MAX)	= ''

		IF @isClient = 1
		BEGIN
		SELECT @strSysDefaultInfo =  
		 ( SELECT   ID, VALUE  
			FROM tblSysDefault WITH(NOLOCK) 
			WHERE   ID IN(	1215, 2081, 2000, 2178, 2179, 
							2180, 2181, 2288, 2289, 2287, 
							2285, 2397, 2520, 2521, 2583, 
							2115, 2324, 2321, 2327, 2325, 
							2326, 2585, 2583, 2490, 2562,
							1011, 2000) 
			AND  IsActive = 1 FOR JSON PATH,INCLUDE_NULL_VALUES --, WITHOUT_ARRAY_WRAPPER
		)	 
	 	 
		SELECT @strSysLookupInfo = (SELECT ID , LookupValue FROM tblSysLookUp WITH(NOLOCK) 
		  WHERE id in (1130,1131,1132,1133,1134,1135,1136,1137,1138,1139,1140,1141,1142,1143,1144,1145,1146,1145,1146,1147,1148,
		1149,1150,1151,1152,1153,1155,2531,2532,2533,2534,2535,2536,2537,2538,2539,2540,2541,2542,2543,2544,2545,2546,2547,2557,2558,2980,2984,2985,2981,2986,2983,2987,2988,2989,2990,2982,2991,2992,2993,2994,2995,3106,3126)
		and isactive = 1  FOR JSON PATH,INCLUDE_NULL_VALUES --, WITHOUT_ARRAY_WRAPPER 
		) 

 
		-- Prepared the Json for default values
		SELECT @strSysDefaultInfo as sysDefaults, @strSysLookupInfo AS dateFormats
	END
	ELSE
		BEGIN
		SET @strSysLookupInfo = '';
		SELECT @strSysLookupInfo = @strSysLookupInfo + 'this._' + CAST(ID AS VARCHAR(4)) + '=""" & "' + LookupValue + '" & """;' FROM tblSysLookUp 
			WHERE ID in ( 1130, 1131, 1132, 1133,
               1134, 1135, 1136, 1137,
               1138, 1139, 1140, 1141,
               1142, 1143, 1144, 1145,
               1146, 1147, 1148, 1149,
               1150, 1151, 1152, 1153,
               1154, 1155, 2531, 2532,
               2533, 2534, 2535, 2536,
               2537, 2538, 2539, 2540,
               2541, 2542, 2543, 2557,
               2558, 2980, 2984, 2985,
               2981, 2986, 2983, 2987,
               2988, 2989, 2990, 2982,
               2991, 2992, 2993, 2994, 2995 );
			   SELECT @strSysLookupInfo
		END
END TRY  
BEGIN CATCH  
END CATCH  
END
