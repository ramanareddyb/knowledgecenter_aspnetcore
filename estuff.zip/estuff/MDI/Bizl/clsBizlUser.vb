Option Explicit On 

Imports Excelicare.Dal.MDI    ' To access data access functionalty from DAL
Imports System.Net
Imports Newtonsoft.Json.Linq
Imports System.Text.RegularExpressions
Namespace Excelicare.Bizl.MDI
    '*******************************************************************************************
    'Class Name : clsBizlUser
    'PURPOSE    : Exposes User information to Presentation layer
    '
    'MODIFICATION LOG  :
    '
    'AUTHOR                      Ver#       Date        Reason/Changes
    '-------------------------------------------------------------------------------------------
    'Nagodaya Bhaskar KR.      1.0.000    25/05/2004    First version.
    '*******************************************************************************************
    Public Class clsBizlUser
        Implements IDisposable
        Dim JSONString As JObject
        Public Overloads Sub Dispose() Implements IDisposable.Dispose                      'Added by mani pratap to destroy the unused objects 
            GC.SuppressFinalize(Me)
        End Sub
        '****************************************************************************************
        'Sub/Function/Property Name : GetUserDetails
        'Parameters   : int64USR_ID,strCommaDelimitedColumns
        'Return Values: DataSet
        'Purpose      : This function is used to get user details
        '
        'Other relevant sources: 
        '     
        'Author            : Nagodaya Bhaskar KR
        'Created Date      : 25/05/2004
        'Last Modified Date: None
        'Modification Log  :
        'Author                 Date           Reason
        '----------------------------------------------------------------------------------------
        '****************************************************************************************
        ' -----------------------------------------------------------------------------
        ' <summary>
        '      This function is used to get user details
        ' </summary>
        ' <param name="int64USR_ID"> Pass the  UserId for particular user </param>
        ' <param name="strCommaDelimitedColumns"> Pass the CommaDelimitedColumns </param>
        ' <returns> Data set Object Containing UserDetails </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Nagodaya Bhaskar KR]    25/05/2004   Created
        ' 	   [Srinivas K]	            15/06/2005	 Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function GetUserDetails(ByVal int64USR_ID As Int64, ByVal strCommaDelimitedColumns As String) As DataSet
            Dim objClsUserDan As clsDalUserDan
            Try
                objClsUserDan = New clsDalUserDan
                Return objClsUserDan.GetUserDetails(int64USR_ID, strCommaDelimitedColumns)
            Catch ex As Exception
                Throw
            Finally
                objClsUserDan = Nothing
            End Try
        End Function

        '****************************************************************************************
        'Sub/Function/Property Name : CanMakeQueueRedForTheLoggedInUser
        'Parameters   : int64USR_ID
        'Return Values: Boolean
        'Purpose      : This function returns a boolean vale and is used to make the Queue red or white
        '
        'Other relevant sources: 
        '     
        'Author            : Suneetha B
        'Created Date      : 27.05.2005
        'Last Modified Date: None
        'Modification Log  :
        'Author                 Date           Reason
        '----------------------------------------------------------------------------------------
        '****************************************************************************************
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This function returns a boolean vale and is used to make the Queue red or white
        ' </summary>
        ' <param name="intUSR_ID"> pass the userid to get the particular user </param>
        ' <returns></returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]    27.05.2005  Created
        ' 	    [Srinivas K]	15/06/2005	Comments Added
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function CanMakeQueueRedForTheLoggedInUser(ByVal int64UsrId As Int64) As Boolean
            Dim objClsUserDan As clsDalUserDan
            Try
                objClsUserDan = New clsDalUserDan
                Return (objClsUserDan.CanMakeQueueRedForTheLoggedInUser(int64UsrId))
            Catch ex As Exception
                Throw
            Finally
                objClsUserDan = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This Function is used to get the items of MyFavorites and is used to make the myfav icon green or white
        ' </summary>
        ' <param name="intUSR_ID"> pass the userid to get the particular user </param>
        ' <returns>Integer representing the Count of the forms in My Favourites</returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Srinivas K]    13/06/2005  Created
        ' 	    [Srinivas K]	15/06/2005	Comments Added
        '       [Suneetha B]    28/06/2005  Modified to return a boolean value whether the supplied user has any favourites attached
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function HasMyFavourites(ByVal intUSR_ID As Integer) As Boolean
            Dim objClsUserDan As clsDalUserDan
            Try
                objClsUserDan = New clsDalUserDan
                HasMyFavourites = objClsUserDan.HasMyFavourites(intUSR_ID)
            Catch ex As Exception
                Throw
            Finally
                objClsUserDan = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       whether to show the Q as the start up form or not for the given user ID
        ' </summary>
        ' <param name="intUsr_Id"> user id </param>
        ' <returns>Boolean</returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]    26/08/2005  Created
        ' 	    [Suneetha B]	26/08/2005	Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function ShowQAsStartUpForm(ByVal intUsr_Id As Integer) As Boolean
            Dim objClsUserDan As clsDalUserDan
            Try
                objClsUserDan = New clsDalUserDan
                Return objClsUserDan.ShowQAsStartUpForm(intUsr_Id)
            Catch ex As Exception
                Throw
            Finally
                objClsUserDan = Nothing
            End Try
        End Function
        '************************************************************************************************
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This  function is used to find whether the logged in user is a privileged to view the Key word search button 
        ' </summary>
        ' <param name="intUser_ID"> user id </param>
        ' <returns> Boolean </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '   [Suneetha B]    30/09/2005    Created
        ' 	[Suneetha B]	30/09/2005	  Comments added
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function IsUserPrivilegedToViewKeyWordSearch(ByVal intUser_ID As Int32) As Boolean
            Dim objClsUserDan As clsDalUserDan
            Try
                objClsUserDan = New clsDalUserDan
                Return objClsUserDan.IsUserPrivilegedToViewKeyWordSearch(intUser_ID)
            Catch ex As Exception
                Throw
            Finally
                objClsUserDan = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       whether to show the Start up object  based on user preferences
        ' </summary>
        ' <param name="intUsr_Id"> user id </param>
        ' <returns>Boolean</returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]    15/11/2005  Created
        ' 	    [Suneetha B]	15/11/2005 	Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function ShowStartUpObject(ByVal intUsr_Id As Integer) As Integer
            Dim objClsUserDan As clsDalUserDan
            Try
                objClsUserDan = New clsDalUserDan
                Return objClsUserDan.ShowStartUpObject(intUsr_Id)
            Catch ex As Exception
                Throw
            Finally
                objClsUserDan = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '      This is used to delete the temporary session data of patient reg 
        ' </summary>
        ' <param name="intUsr_Id"> user id </param>
        ' <param name="strSessionID"> Session ID </param>
        ' <returns>Boolean</returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]    12/12/2005  Created
        ' 	    [Suneetha B]	12/12/2005 	Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function DeleteTempPatientRegistrationData(ByVal intUserID As Integer, ByVal strSessionID As String) As Boolean
            Dim objClsUserDan As clsDalUserDan
            Try
                objClsUserDan = New clsDalUserDan
                Return objClsUserDan.DeleteTempPatientRegistrationData(intUserID, strSessionID)
            Catch ex As Exception
                Throw
            Finally
                objClsUserDan = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This is used to get the user restriction level for the selected patient
        ' </summary>
        '<param Name="intUserID">holds user ID</param>
        '<param Name="intPAT_ID">holds Patient ID</param>
        '<param Name="IntuserRestrictionLevel">holds user restriction level on the current selected patient</param>
        '<returns>returns an integer value</returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]  14.03.2006    Created
        '       [Suneetha B]  14.03.2006	Comments Added
        ' </history>
        ' ----------------------------------------------------------------------------
        Public Function GetPatRestrictionLevel(ByVal intUserID As Integer, ByVal intPAT_ID As Integer, ByVal intRestrictionLevel As Integer) As Integer
            Dim objClsUserDan As clsDalUserDan
            Try
                objClsUserDan = New clsDalUserDan
                Return objClsUserDan.GetPatRestrictionLevel(intUserID, intPAT_ID, intRestrictionLevel)
            Catch ex As Exception
                Throw
            Finally
                objClsUserDan = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '      This is used to add the suppiled module ID , for supplied user as a My Favourite
        ' </summary>
        ' <param name="intUsr_Id"> user id </param>
        ' <param name="intModuleID"> Module ID </param>
        ' <param name="strFormName"> Form Name </param>
        ' <param name="strFormType"> Form Type </param>
        ' <returns>Integer</returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]    03/03/2006  Created
        ' 	    [Suneetha B]	03/03/2006 	Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function AddToMyFavourites(ByVal intUserID As Integer, ByVal intModuleID As Integer, ByVal strFormName As String, ByVal strFormType As String) As Integer
            Dim objClsUserDan As clsDalUserDan
            Try
                objClsUserDan = New clsDalUserDan
                Return objClsUserDan.AddToMyFavourites(intUserID, intModuleID, strFormName, strFormType)
            Catch ex As Exception
                Throw
            Finally
                objClsUserDan = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '      This is used to find the given ModuleID is added to a paticular user or not
        ' </summary>
        ' <param name="intUserID"> user id </param>
        ' <param name="intModuleID"> Module ID </param>
        ' <param name="strFormType"> Form Type </param>
        ' <param name="intFIBID"> Form Lib Item ID </param>
        ' <returns>Boolean</returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]    03/03/2006  Created
        ' 	    [Suneetha B]	03/03/2006 	Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function IsModuleAddedToMyFavourites(ByVal intUserID As Integer, ByVal intModuleID As Integer, ByVal strFormType As String, Optional ByVal intFIBID As Integer = 0) As Boolean
            Dim objClsUserDan As clsDalUserDan
            Try
                objClsUserDan = New clsDalUserDan
                Return objClsUserDan.IsModuleAddedToMyFavourites(intUserID, intModuleID, strFormType, intFIBID)
            Catch ex As Exception
                Throw
            Finally
                objClsUserDan = Nothing
            End Try
        End Function
        'To retreive User specific information. Session related changes.
        Public Function GetUserValues(ByVal intUserId As Integer) As DataSet
            Dim objClsUserDan As clsDalUserDan
            Try
                objClsUserDan = New clsDalUserDan
                Return objClsUserDan.GetUserValues(intUserId)
            Catch ex As Exception
                Throw ex
            Finally
                objClsUserDan = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       To get the Startup form of the supplied User ID
        ' </summary>
        ' <param name="intUsr_Id"> user id </param>
        ' <returns>Boolean</returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Vanisri]    28/11/2006  Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function GetPatientRecordStartUpForm(ByVal intUsr_Id As Integer) As String
            Dim objClsUserDan As clsDalUserDan
            Try
                objClsUserDan = New clsDalUserDan
                Return objClsUserDan.GetPatientRecordStartUpForm(intUsr_Id)
            Catch ex As Exception
                Throw
            Finally
                objClsUserDan = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       To get the fully qualified Url of the supplied module ID
        ' </summary>
        ' <param name="intModuleId"> Module Id </param>
        ' <returns>Boolean</returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Vanisri]    28/11/2006  Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function GetPatientRecordStartUpFormUrl(ByVal intModuleId As Integer) As String
            Dim objClsUserDan As clsDalUserDan
            Try
                objClsUserDan = New clsDalUserDan
                Return objClsUserDan.GetPatientRecordStartUpFormUrl(intModuleId)
            Catch ex As Exception
                Throw
            Finally
                objClsUserDan = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       To get the fully qualified Url of the supplied module ID
        ' </summary>
        ' <param name="lngLookupId"> Lookup Id </param>
        ' <returns>String</returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [B.N.Jagadeesh]    25/06/2007  Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function GetSysLookupValue(ByVal lngLookupId As Long) As String
            Dim objClsUserDan As clsDalUserDan
            Try
                objClsUserDan = New clsDalUserDan
                Return objClsUserDan.GetSysLookupValue(lngLookupId)
            Catch ex As Exception
                Throw
            Finally
                objClsUserDan = Nothing
            End Try
        End Function
        Public Function getPatIdentifierValue(ByVal lngPatid As Long) As String
            Dim objClsUserDan As clsDalUserDan
            Try
                objClsUserDan = New clsDalUserDan
                Return objClsUserDan.getPatIdentifierValue(lngPatid)
            Catch ex As Exception
                Throw
            Finally
                objClsUserDan = Nothing
            End Try
        End Function


        ' Added on 07-Dec-2011

        ' -----------------------------------------------------------------------------------------------
        ' <summary>
        '       This get the User Prescribing Role
        ' </summary>
        ' <remarks>
        '       First version.
        ' </remarks>
        ' <history>
        '      [Harish Lalwani]      04/05/2010  Created
        ' </history>
        ' -----------------------------------------------------------------------------------------------
        Public Function GetUserPrescribingRole(ByVal UserID As Long, ByVal intUserLocId As Integer) As String
            Dim objDAL As New clsDalUserDan
            Return objDAL.GetUserPrescribingRole(UserID, intUserLocId)
        End Function
        ' -----------------------------------------------------------------------------------------------
        ' <summary>
        '       This get the User's ACL Restriction Level
        ' </summary>
        ' <remarks>
        '       First version.
        ' </remarks>
        ' <history>
        '      [Pradeep Kumar]      09/05/2010  Created
        ' </history>
        ' -----------------------------------------------------------------------------------------------
        Public Function GetUserACLLevel(ByVal intUserID As Integer, ByVal intPatientID As Integer) As Integer
            Dim objDAL As clsDalUserDan
            Try
                objDAL = New clsDalUserDan
                Return objDAL.GetUserACLLevel(intUserID, intPatientID)
            Catch ex As Exception
                Throw ex
            Finally
                objDAL = Nothing
            End Try
        End Function
        Public Function GetSunQuestICELab(ByVal intUserID As Integer, ByVal lngPatientID As Integer, Optional ByVal blnCheckLocation As Boolean = False) As DataSet
            Dim objClsUserDan As clsDalUserDan
            Try
                objClsUserDan = New clsDalUserDan
                Return objClsUserDan.GetSunQuestICELab(intUserID, lngPatientID, blnCheckLocation)
            Catch ex As Exception
                Throw
            Finally
                objClsUserDan = Nothing
            End Try
        End Function
        Public Function fnSavePrintLogDetails(ByVal lngPatientId As Long, ByVal intItemID As Int64, ByVal lngModuleID As Long, ByVal strItemtype As String, ByVal strPrinterName As String, ByVal lngUserID As Long, ByVal strDatePrinted As DateTime, ByVal lngCustomFormID As Long, ByVal strPrintPreviewDate As DateTime, ByVal blnPrintStatus As Boolean) As Integer
            Dim objClsUserDan As clsDalUserDan
            Try
                objClsUserDan = New clsDalUserDan
                Return objClsUserDan.fnSavePrintLogDetails(lngPatientId, intItemID, lngModuleID, strItemtype, strPrinterName, lngUserID, strDatePrinted, lngCustomFormID, strPrintPreviewDate, blnPrintStatus)

            Catch ex As Exception
                Throw
            Finally
                objClsUserDan = Nothing
            End Try
        End Function
        Public Function GetExternalURLFLID(ByVal strExternalURLName As String) As Long
            Dim objClsUserDan As clsDalUserDan
            Try
                objClsUserDan = New clsDalUserDan
                Return objClsUserDan.GetExternalURLFLID(strExternalURLName)
            Catch ex As Exception
                Throw
            Finally
                objClsUserDan = Nothing
            End Try
        End Function
        Public Function getJSONSession(ByVal lngFLID As Long, ByVal SessionID As String) As JObject
            Dim objClsUserDan As clsDalUserDan
            Dim DS As DataSet
            Dim objSessiondata As Excelicare.Framework.AppSupport.clsSessionData
            Dim objSessionJSON As JObject
            Dim objRetrunValue As New JObject
            Dim intLoop As Integer = 0
            Dim strTempKey As String
            Dim objTempJSONValue As JToken
            Dim objSessionMgr As Excelicare.Framework.AppSupport.clsSessionManager = New Excelicare.Framework.AppSupport.clsSessionManager
            Dim inputLoop As Integer
            Try
                objSessiondata = objSessionMgr.GetSessionData(SessionID, "APPDATA")
                objSessionJSON = JObject.FromObject(objSessiondata)
                objClsUserDan = New clsDalUserDan
                DS = objClsUserDan.getDataSet(lngFLID)
                For inputLoop = 0 To DS.Tables(0).Rows.Count - 1
                    strTempKey = DS.Tables(0).Rows(inputLoop).Item("LookupValue")
                    objTempJSONValue = objSessionJSON.SelectToken(strTempKey.Replace("{", "").Replace("}", "").Replace("SV.", ""))
                    objRetrunValue = PrepareJSONInput(strTempKey.Replace("{", "").Replace("}", "").Replace("SV.", ""), objTempJSONValue.ToString)
                Next
                Return objRetrunValue
            Catch ex As Exception
                Throw
            Finally
                objClsUserDan = Nothing
            End Try
        End Function
        Public Function PrepareJSONInput(ByVal key As String, ByVal value As String) As JObject
            Try
                If JSONString Is Nothing Then
                    JSONString = JObject.Parse("{""SV"":{" + key + ": """ + value + """}}")
                Else
                    JSONString("SV")(key) = value
                End If
                Return JSONString
            Catch ex As Exception

            End Try
        End Function
        Public Function GetTQuestICELab(ByVal intUserID As Integer, ByVal lngPatientID As Integer, Optional ByVal blnCheckLocation As Boolean = False) As DataSet
            Dim objClsUserDan As clsDalUserDan
            Try
                objClsUserDan = New clsDalUserDan
                Return objClsUserDan.GetTQuestICELab(intUserID, lngPatientID, blnCheckLocation)
            Catch ex As Exception
                Throw
            Finally
                objClsUserDan = Nothing
            End Try
        End Function
		Public Function GetUserDisclaimerStatus(ByVal intUserID As Integer) As String
            Dim objClsUserDan As clsDalUserDan
            Dim strStatus As String
            Try
                objClsUserDan = New clsDalUserDan
                strStatus = objClsUserDan.GetUserDisclaimerStatus(intUserID)
                Return strStatus
            Catch ex As Exception
                Throw ex
            Finally
                objClsUserDan = Nothing
                strStatus = Nothing
            End Try
        End Function

        Public Function SaveUserDisclaimer(ByVal intUserID As Integer, ByVal intdisclaimerStatus As Integer, ByVal strdisclaimerLU As String)
            Dim objClsUserDan As clsDalUserDan
            Dim strStatus As String
            Try
                objClsUserDan = New clsDalUserDan
                strStatus = objClsUserDan.SaveUserDisclaimer(intUserID, intdisclaimerStatus, strdisclaimerLU)
                Return strStatus
            Catch ex As Exception
                Throw ex
            Finally
                objClsUserDan = Nothing
                strStatus = Nothing
            End Try
        End Function
        Public Sub SaveBrowserRequestLogs(sessionId As String, UserId As Integer, MachineName As String, MachineIP As String, strModule As String, Request As String, Version As String, HttpStatus As Integer, ExecuteAt As String)
            Dim objClsUserDan As clsDalUserDan
            Try
                objClsUserDan = New clsDalUserDan
                objClsUserDan.SaveBrowserRequestLogs(sessionId, UserId, MachineName, MachineIP, strModule, Request, Version, HttpStatus, ExecuteAt)
            Catch ex As Exception
                Throw
            Finally
                objClsUserDan = Nothing
            End Try
        End Sub
        Public Sub DeleteRequestLogs(sessionId As String)
            Dim objClsUserDan As clsDalUserDan
            Try
                objClsUserDan = New clsDalUserDan
                objClsUserDan.DeleteRequestLogs(sessionId)
            Catch ex As Exception
                Throw
            Finally
                objClsUserDan = Nothing
            End Try
        End Sub
        Public Function EndActiveSSOSessionsByUserID(ByVal lngUser_ID As Int64) As String
            Dim objClsUserDan As clsDalUserDan
            Try
                objClsUserDan = New clsDalUserDan

                Return objClsUserDan.EndActiveSSOSessionsByUserID(lngUser_ID)
            Catch ex As Exception
                Throw
            Finally
                objClsUserDan = Nothing
            End Try

        End Function
        ' -----------------------------------------------------------------------------------------------
        ' <summary>
        '   Deletes the cob ids from consultationobject which are not saved to patientmediafs due to erros or logoff
        ' </summary>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      Shireesha    19-Mar-2020   Created    
        ' </history>
        ' -----------------------------------------------------------------------------------------------
        Public Function DeleteFailedMediaEntries(ByVal strCobIDs As String) As Boolean
            Dim objClsUserDan As clsDalUserDan
            Try
                objClsUserDan = New clsDalUserDan

                Return objClsUserDan.DeleteFailedMediaEntries(strCobIDs)
            Catch ex As Exception
                Throw
            Finally
                objClsUserDan = Nothing
            End Try

        End Function

        ''' <summary>
        ''' To get password settings of logged in user
        ''' </summary>
        ''' <param name="lngUsrId"></param>
        ''' <returns></returns>
        Public Function fnUserPwdSettigs(ByVal lngUsrId As Long) As DataSet
            Dim objClsUserDan As clsDalUserDan
            Try
                objClsUserDan = New clsDalUserDan
                Return objClsUserDan.fnUserPwdSettigs(lngUsrId)
            Catch ex As Exception
                Throw ex
            Finally
                objClsUserDan = Nothing
            End Try
        End Function
        ''' <summary>
        ''' To check staff associated patients
        ''' </summary>
        ''' <param name="lngUsrId"></param>
        ''' <returns></returns>
        Public Function IsAssociatedPatientsExists(ByVal lngClnID As Long, ByVal lngLocID As Long) As Int16
            Dim objClsUserDan As clsDalUserDan
            Try
                objClsUserDan = New clsDalUserDan
                Return objClsUserDan.IsAssociatedPatientsExists(lngClnID, lngLocID)
            Catch ex As Exception
                Throw ex
            Finally
                objClsUserDan = Nothing
            End Try
        End Function

    End Class

End Namespace