Option Explicit On 

Imports Excelicare.Dal.MDI    ' To access data access functionalty from DAL
'Imports AxSys.AppSupport ' To access exception handling functionality

Namespace Excelicare.Bizl.MDI
    '*******************************************************************************************
    'Class Name : clsBizlPatient
    'PURPOSE    : Exposes Patient information to Presentation layer
    '
    'MODIFICATION LOG  :
    '
    'AUTHOR                      Ver#       Date        Reason/Changes
    '-------------------------------------------------------------------------------------------
    'Nagodaya Bhaskar KR.      1.0.000    25/05/2004    First version.
    '*******************************************************************************************
    Public Class clsBizlPatient
        Implements IDisposable

        Public Overloads Sub Dispose() Implements IDisposable.Dispose                           'Added by mani pratap to destroy the unused objects 
            GC.SuppressFinalize(Me)
        End Sub
        '****************************************************************************************
        'Sub/Function/Property Name : GetPatientDetails
        'Parameters   : int64PAT_ID
        'Return Values: DataSet
        'Purpose      : This function is used to get patient details
        '
        'Other relevant sources: 
        '     
        'Author            : Nagodaya Bhaskar KR
        'Created Date      : 25/05/2004
        'Last Modified Date: None
        'Modification Log  :
        'Author                 Date           Reason
        '----------------------------------------------------------------------------------------
        '****************************************************************************************

        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This function is used to get patient details
        ' </summary>
        ' <param name="int64PAT_ID"> To get the particular User </param>
        ' <returns> Dataset get the values of user </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Nagodaya Bhaskar KR]   25/05/2004  Created
        ' 	    [Srinivas K]	        15/06/2005	Commetns Added
        ' </history>
        ' -----------------------------------------------------------------------------
        'Public Function GetPatientDetails(ByVal int64PAT_ID As Int64, ByVal lngUserId As Int64) As DataSet
        '    Dim ds As New DataSet
        '    Dim objClsPatientDan As clsDalPatientDan = New clsDalPatientDan
        '    Try
        '        ds = objClsPatientDan.GetPatientDetails(int64PAT_ID, lngUserId)
        '        Return ds
        '    Catch ex As Exception
        '        Throw
        '    Finally
        '        objClsPatientDan = Nothing
        '        ds = Nothing
        '    End Try
        'End Function
        Public Function GetPatientDetails(ByVal int64PAT_ID As Int64, ByVal int64USRID As Int64, ByVal intUsrSecLevel As Int16, _
                        ByVal int64userPreferredIdentifier As Int64, ByVal int64UserPreferredIdentifierType As Int64, ByVal strAppType As String) As DataSet
            Dim objClsPatientDan As clsDalPatientDan = New clsDalPatientDan
            Try
                Return objClsPatientDan.GetPatientDetails(int64PAT_ID, int64USRID, intUsrSecLevel, int64userPreferredIdentifier, int64UserPreferredIdentifierType, strAppType)
            Catch ex As Exception
                Throw
            Finally
                objClsPatientDan = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>This function is used to check critical problems of patient. </summary>
        ' <param name="int64PAT_ID"> pass the uderid to get the particular User </param>
        ' <param name="strCriticalProblemText"> To Hold ToolTip Information </param>
        ' <returns></returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Ashok Kumar Sole]  11/05/2005 Created
        ' 	    [Srinivas K]	    15/06/2005	Commetns Added
        '       [Srinivas V]        25/04/2007  Modified Function signature and added strCriticalProblemText for Tooltip 
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function IsPatientHavingCriticalProblems(ByVal int64PAT_ID As Int64, ByRef strCriticalProblemText As String) As Boolean
            Dim objClsPatientDan As clsDalPatientDan = New clsDalPatientDan
            Try
                Return objClsPatientDan.IsPatientHavingCriticalProblems(int64PAT_ID, strCriticalProblemText)
            Catch ex As Exception
                Throw
            Finally
                objClsPatientDan = Nothing
            End Try
        End Function

        ' -----------------------------------------------------------------------------
        ' <summary>This function is used to check Allergy or ADRProblem problems of patient</summary>
        ' <param name="int64PAT_ID"> To get the particular User </param>
        ' <param name="strAllergyorADRText"> To Hold ToolTip Information </param>
        ' <returns></returns>
        ' <remarks>  remarks>

        ' <history>
        '       [Ashok Kumar Sole]  11/05/2005  Created
        ' 	    [Srinivas K]	    15/06/2005	Commetns Added
        '       [Srinivas V]        15/06/2007  Modified Function signature and added strAllergyorADRText for Tooltip 
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function IsPatientHavingAllergyorADRProblem(ByVal int64PAT_ID As Int64, ByRef strAllergyorADRText As String) As Boolean
            Dim objClsPatientDan As clsDalPatientDan = New clsDalPatientDan
            Try
                Return objClsPatientDan.IsPatientHavingAllergyorADRProblem(int64PAT_ID, strAllergyorADRText)
            Catch ex As Exception
                Throw
            Finally
                objClsPatientDan = Nothing
            End Try
        End Function

        ' -----------------------------------------------------------------------------
        ' <summary>This function is used to check Other Alert Problems of patient.</summary>
        ' <param name="int64PAT_ID"> To get the particular UserId </param>
        ' <param name="strOtherAlertText"> To Hold ToolTip Information </param>
        ' <returns></returns>
        ' <remarks></remarks>
        ' <history>
        '       [Ashok Kumar Sole]  11/05/2005 Created
        ' 	    [Srinivas K]	    15/06/2005	Commetns Added
        '       [Srinivas V]        15/06/2007  Modified Function signature and added strOtherAlertText for Tooltip 
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function IsPatientHavingOtherAlertProblems(ByVal int64PAT_ID As Int64, ByRef strOtherAlertText As String) As Boolean
            Dim objClsPatientDan As clsDalPatientDan = New clsDalPatientDan
            Try
                Return objClsPatientDan.IsPatientHavingOtherAlertProblems(int64PAT_ID, strOtherAlertText)
            Catch ex As Exception
                Throw
            Finally
                objClsPatientDan = Nothing
            End Try
        End Function

        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This function is used to get patient identifier value
        ' </summary>
        ' <param name="int64PAT_ID"> To get the particular UserId </param>
        ' <param name="int64UserPreferredIdentifierID"> UserPreferredIdentifierID </param>
        ' <param name="int64UserPreferredIdentifierType"> UserPreferredIdentifierType </param>
        ' <returns></returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Nagodaya Bhaskar KR]   02/05/2004  Created
        ' 	    [Srinivas K]	        15/06/2005	Commetns Added
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function GetPatientIdentifierValue(ByVal int64PAT_ID As Int64, ByVal int64UserPreferredIdentifierID As Int64, ByVal int64UserPreferredIdentifierType As Int64, ByVal usrId As Int64) As String()
            Dim objClsDalPatientDan As clsDalPatientDan
            Try
                objClsDalPatientDan = New clsDalPatientDan
                Return objClsDalPatientDan.GetPatientIdentifierValue(int64PAT_ID, int64UserPreferredIdentifierID, int64UserPreferredIdentifierType, usrId)
            Catch ex As Exception
                Throw
            Finally
                objClsDalPatientDan = Nothing
            End Try
        End Function



        '********************************************************************************************************
        'Purpose                :   To hold the tooltip information of ADR problem text 
        'Layer                  :   UI
        'Method Name            :   IsPatientHavingADR
        'Input Parameters       :   Int64, String
        'Return Values          :   Boolean
        '--------------------------------------------------------------------------------------------------------
        'Version            Author                      Date                Remarks
        '--------------------------------------------------------------------------------------------------------
        '1.0.0            Pradeep                   04/09/2008           Initial Implementation  
        '********************************************************************************************************
        Public Function IsPatientHavingADR(ByVal int64PAT_ID As Int64, ByRef strADRText As String) As Boolean

            Dim objClsPatientDan As clsDalPatientDan
            Try
                objClsPatientDan = New clsDalPatientDan
                Return objClsPatientDan.IsPatientHavingADR(int64PAT_ID, strADRText)
            Catch ex As Exception
                Throw
            Finally
                objClsPatientDan = Nothing
            End Try
        End Function

        Public Function IsPatientHavingPrescriptionsInQueue(ByVal int64PAT_ID As Int64, ByVal intUserID As Integer) As Boolean
            Dim objClsPatientDan As clsDalPatientDan
            Try
                objClsPatientDan = New clsDalPatientDan
                Return objClsPatientDan.IsPatientHavingPrescriptionsInQueue(int64PAT_ID, intUserID)
            Catch ex As Exception
                Throw ex
            Finally
                objClsPatientDan = Nothing
            End Try
        End Function




        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This function is used to check the whether the supplied Clinician is in MCN role of the patient or not
        ' </summary>
        ' <param name="lngPatientID">  Patient Id </param>
        ' <param name="lngClnID"> Clinician ID </param>
        ' <returns>Boolean</returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B] 25.07.2006 Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function IsClinicianInPatientMCNrole(ByVal lngPatientID As Long, ByVal lngClnID As Long) As Boolean
            Dim objClsDalPatientDan As clsDalPatientDan
            Try
                objClsDalPatientDan = New clsDalPatientDan
                Return objClsDalPatientDan.IsClinicianInPatientMCNrole(lngPatientID, lngClnID)
            Catch ex As Exception
                Throw
            Finally
                objClsDalPatientDan = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       To read Patient Notice board data
        ' </summary>
        ' <param name="lngPat_ID"> Patient Id </param>
        ' <returns>Boolean</returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [B.N.Jagadeesh]    26/07/2007  Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function IsNoticeBoardDataExists(ByVal lngPatientID As Long) As Boolean
            Dim objClsDalPatientDan As clsDalPatientDan
            Try
                objClsDalPatientDan = New clsDalPatientDan
                Return objClsDalPatientDan.IsNoticeBoardDataExists(lngPatientID)
            Catch ex As Exception
                Throw
            Finally
                objClsDalPatientDan = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        ' To log Session Action while selection patient from patient bar
        ' </summary>
        ' <param name="strModuleName"></param>
        ' <param name="strSessionID"></param>
        ' <param name="int64PatientID"></param>
        ' <param name="int64EventType_SLU"></param>
        ' <param name="strEventDetails"></param>
        ' <param name="int64ModuleId"></param>
        ' <param name="int32RecordId"></param>
        ' <returns></returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        ' 	[bhavani]	25/04/2008	Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function LogPatientChangeAction(ByVal strModuleName As String, ByVal strSessionID As String, ByVal int32PatientID As Int32, ByVal int32EventType_SLU As Int32, ByVal strEventDetails As String, Optional ByVal int32ModuleId As Int32 = -1, Optional ByVal int32RecordId As Int32 = -1) As Int32
            Dim objClsDalPatientDan As clsDalPatientDan
            Try
                objClsDalPatientDan = New clsDalPatientDan
                Return objClsDalPatientDan.LogPatientChangeAction(strModuleName, strSessionID, int32PatientID, int32EventType_SLU, strEventDetails, int32ModuleId, int32RecordId)
            Catch ex As Exception
                Throw
            Finally
                objClsDalPatientDan = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       To Define the image for the Notice Board in patient bar.
        ' </summary>
        ' <param name="lngPat_ID"> Patient Id </param>
        ' <returns>Boolean</returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Pavithraraj]    17/09/2008  Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function UpdateNoticeBoardIcon(ByVal lngPat_ID As Long) As Boolean
            Dim objClsDalPatientDan As clsDalPatientDan
            Try
                objClsDalPatientDan = New clsDalPatientDan
                Return objClsDalPatientDan.UpdateNoticeBoardIcon(lngPat_ID)
            Catch ex As Exception
                Throw
            Finally
                objClsDalPatientDan = Nothing
            End Try
        End Function
        Public Sub GetUserValues(ByVal intUserId As Integer, ByRef strACLGroups As String, ByRef intRestrictionLevelID As Int16)
            Dim objClsDalPatDetailsDan As clsDalPatientDan
            Try
                objClsDalPatDetailsDan = New clsDalPatientDan
                objClsDalPatDetailsDan.GetUserValues(intUserId, strACLGroups, intRestrictionLevelID)
            Catch ex As Exception
                Throw ex
            Finally
                objClsDalPatDetailsDan = Nothing
            End Try
        End Sub
        ' -----------------------------------------------------------------------------
        ' <summary>
        ' To Maintian 'Patient Selection History' while Selecting the Patient
        ' </summary>
        ' <param name="int32PatientID"></param>
        ' <param name="int32Usr_Id"></param>
        ' <param name="strSessionID"></param>
        ' <remarks>
        ' </remarks>
        ' <history>
        ' 	[Posubabu]	06/02/2012	Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Sub InsLastViewPatDetails(ByVal lngPAT_ID As Long, ByVal intUsr_ID As Int32, ByVal strLogg_SessionId As String)
            Dim objClsPatientDan As clsDalPatientDan
            Try
                objClsPatientDan = New clsDalPatientDan
                objClsPatientDan.InsLastViewPatDetails(lngPAT_ID, intUsr_ID, strLogg_SessionId)
            Catch ex As Exception
                Throw
            Finally
                objClsPatientDan = Nothing
            End Try
        End Sub

        Public Function GetUserIdentifierDetails(lngIserId As Long, lngPatientId As Long) As DataSet
            Dim objClsPatientDan As clsDalPatientDan
            Try
                objClsPatientDan = New clsDalPatientDan
                Return objClsPatientDan.GetUserIdentifierDetails(lngIserId, lngPatientId)
            Catch ex As Exception
                Throw ex
            Finally
                objClsPatientDan = Nothing
            End Try
        End Function


        Public Function GetPatientZone1AlertIconInfo(ByVal int64PAT_ID As Int64, ByVal int64UsrID As Int64, ByVal intUsrSecurityLevel As Int16, ByVal strAppType As String, ByVal intIsACLPatient As Integer) As DataSet

            Dim objClsPatientDan As clsDalPatientDan = New clsDalPatientDan
            Try
                Return objClsPatientDan.GetPatientZone1AlertIconInfo(int64PAT_ID, int64UsrID, intUsrSecurityLevel, strAppType, intIsACLPatient)
            Catch ex As Exception
                Throw
            Finally
                objClsPatientDan = Nothing
            End Try
        End Function
        Public Function fnSaveMessageTrayItems(ByVal objMsgItems As Object, ByVal lngPatientID As Long, ByVal lngUserId As Long) As String
            Dim objClsPatientDan As clsDalPatientDan = New clsDalPatientDan
            Dim intCount As Integer = 0
            Dim intModuleID As Integer
            Dim lngBaseFormID As Long
            Dim lngRecordId As Long
            Dim lngFormID As Long
            Dim lngMasterID As Long
            Dim lngMasterDataID As Long
            Dim lngGrandParentID As Long
            Dim lngGrandParentDataID As Long
            Dim strItemName As String = String.Empty
            Dim lngLastModifiedUserID As Long
            Dim LastModifiedDateTime As String
            Dim intIsSourceActive As Integer
            Dim intIsActive As Integer
            Dim arrResult As ArrayList
            Dim intRecordExistsCnt As Integer = 0
            Dim strResult As String = String.Empty
            Dim strCriteria As String = String.Empty
            Try
                For intCount = 0 To objMsgItems.count - 1
                    lngRecordId = objMsgItems.item(intCount).item("RecordID")
                    intModuleID = objMsgItems.item(intCount).item("ModuleID")
                    lngBaseFormID = objMsgItems.item(intCount).item("BaseFormID")
                    lngFormID = objMsgItems.item(intCount).item("FormID")
                    lngMasterID = objMsgItems.item(intCount).item("MasterID")
                    lngMasterDataID = objMsgItems.item(intCount).item("MasterDataID")
                    lngGrandParentID = objMsgItems.item(intCount).item("GrandParentID")
                    lngGrandParentDataID = objMsgItems.item(intCount).item("GrandParentDataID")
                    strItemName = objMsgItems.item(intCount).item("ItemName")
                    lngLastModifiedUserID = objMsgItems.item(intCount).item("LastModifiedByUserID")
                    LastModifiedDateTime = objMsgItems.item(intCount).item("LastModifiedDate")
                    intIsSourceActive = objMsgItems.item(intCount).item("SourceIsActive")
                    intIsActive = objMsgItems.item(intCount).item("Status")
                    strCriteria = objMsgItems.item(intCount).item("Criteria")
                    arrResult = objClsPatientDan.fnSaveMessageTrayItems(lngPatientID, intModuleID, lngBaseFormID, lngRecordId, lngFormID, lngMasterID, lngMasterDataID, lngGrandParentID, lngGrandParentDataID, strItemName, LastModifiedDateTime, lngLastModifiedUserID, intIsSourceActive, intIsActive, lngUserId, strCriteria)
                    If arrResult.Count > 0 AndAlso arrResult.Item(0) > 0 Then
                        intRecordExistsCnt = intRecordExistsCnt + 1
                    End If
                Next
                If intCount <> 0 Then
                    If intRecordExistsCnt = intCount Then
                        strResult = "1:" & arrResult.Item(1)
                    Else
                        strResult = "0:" & arrResult.Item(1)
                    End If
                End If
                Return strResult
            Catch ex As Exception
                Throw
            Finally
                objClsPatientDan = Nothing
            End Try
        End Function
        Public Function GetMessageTrayCount(ByVal lngPatientID As Long, ByVal lngUserID As Long) As Integer
            Dim objClsPatientDan As clsDalPatientDan = New clsDalPatientDan
            Try
                Return objClsPatientDan.GetMessageTrayCount(lngPatientID, lngUserID)
            Catch ex As Exception
                Throw
            Finally
                objClsPatientDan = Nothing
            End Try
        End Function

        Public Function fnDeleteMessageTrayItems(ByVal strUniqueID As String, ByVal intMsgType_LU As Integer) As Integer
            Dim objClsPatientDan As clsDalPatientDan = New clsDalPatientDan
            Try
                Return objClsPatientDan.fnDeleteMessageTrayItems(strUniqueID, intMsgType_LU)
            Catch ex As Exception
                Throw
            Finally
                objClsPatientDan = Nothing
            End Try
        End Function
	 Public Function fnSaveRioAlerts(ByVal intPATID As Integer, ByVal intMode As Integer) As Integer

            Dim objClsPatientDan As clsDalPatientDan = New clsDalPatientDan
            Try
                Return objClsPatientDan.fnSaveRioAlerts(intPATID, intMode)
            Catch ex As Exception
                Throw
            Finally
                objClsPatientDan = Nothing
            End Try
        End Function
    End Class
End Namespace