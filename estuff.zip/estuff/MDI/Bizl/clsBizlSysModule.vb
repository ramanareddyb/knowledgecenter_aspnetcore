Option Explicit On 
Imports Excelicare.Dal.MDI    ' To access data access functionalty from DAL
Namespace Excelicare.Bizl.MDI
    '*******************************************************************************************
    'Class Name : clsBizlSysModule
    'PURPOSE    : Exposes EC system modules to the presentation layer
    '
    'MODIFICATION LOG  :
    '
    'AUTHOR                      Ver#       Date        Reason/Changes
    '-------------------------------------------------------------------------------------------
    'Nagodaya Bhaskar KR.      1.0.000    05/03/2004    First version.
    '*******************************************************************************************
    Public Class clsBizlSysModule
        Implements IDisposable

        Public Overloads Sub Dispose() Implements IDisposable.Dispose                          'Added by mani pratap to destroy the unused objects 
            GC.SuppressFinalize(Me)
        End Sub

        Public Shared Function GetMDIQueueCount(lngUserId As Long, lngPatientId As Long) As String
            Dim objClsDalSysModuleDan As clsDalSysModuleDan
            Try
                objClsDalSysModuleDan = New clsDalSysModuleDan
                Return objClsDalSysModuleDan.GetMDIQueueCount(lngUserId, lngPatientId)
            Catch ex As Exception
                Throw ex
            Finally
                objClsDalSysModuleDan = Nothing
            End Try
        End Function


        Public Shared Function GetMDIMenuItems(ByVal intUserSecurityLevel As Integer, ByVal strAppType As String, ByVal strModuleType As String, ByVal blnGUIDExists As Boolean, ByVal blnIsOfflineDBAdmin As Boolean, ByVal intUserId As Integer, ByVal intUserRole As Integer) As String
            Dim objClsDalSysModuleDan As clsDalSysModuleDan
            Dim strMenuXML As String = ""
            Try
                objClsDalSysModuleDan = New clsDalSysModuleDan
                strMenuXML = objClsDalSysModuleDan.GetMDIMenuItems(intUserSecurityLevel, strAppType, strModuleType, blnGUIDExists, blnIsOfflineDBAdmin, intUserId, intUserRole)
                Return strMenuXML
            Catch ex As Exception
                Throw ex
            Finally
                objClsDalSysModuleDan = Nothing
            End Try
        End Function

        Public Shared Function SaveUserNavigationHistory(lngUserId As Long, lngSysModuleId As Long, ByVal lngCustomFormId As Long, ByVal lngPatientId As Long, strECSessionId As String, strURL As String, strComments As String, dtNavigationDate As Date) As Boolean
            Dim objClsDalSysModuleDan As clsDalSysModuleDan
            Try
                objClsDalSysModuleDan = New clsDalSysModuleDan
                Return objClsDalSysModuleDan.SaveUserNavigationHistory(lngUserId, lngSysModuleId, lngCustomFormId, lngPatientId, strECSessionId, strURL, strComments, dtNavigationDate)
            Catch ex As Exception
                Throw ex
            Finally
                objClsDalSysModuleDan = Nothing
            End Try
        End Function

        '****************************************************************************************
        'Sub/Function/Property Name : GetListBarGroups
        'Parameters   : None
        'Return Values: ArrayList
        'Purpose      : This is a function to get list of groups
        '
        'Other relevant sources: 
        '     
        'Author            : Nagodaya Bhaskar KR
        'Created Date      : 05/03/2004
        'Last Modified Date: None
        'Modification Log  :
        'Author                 Date           Reason
        '----------------------------------------------------------------------------------------
        'Nagodaya Bhaskar KR    26/03/2004     Added exception handling
        '****************************************************************************************
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This function is used to get list of groups
        ' </summary>
        ' <param name="iSecurityLevel_ID"> pass the SecurityLevel_ID </param>
        ' <returns> return Array list of groups </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '   [Nagodaya Bhaskar KR]     05/03/2004   Created
        ' 	[Srinivas K]	          15/06/2005   Comments Added	
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Function GetListBarGroups(ByVal iSecurityLevel_ID As Int32, ByVal strApplicationType As String) As ArrayList
            Dim ds As New DataSet
            Dim objClsDalSysModuleDan As clsDalSysModuleDan
            Try
                objClsDalSysModuleDan = New clsDalSysModuleDan
                ds = objClsDalSysModuleDan.GetListBarGroups(iSecurityLevel_ID, strApplicationType)
                Dim objALListBarGroups As New ArrayList
                ' Separate Data into array collection 
                Dim dr As DataRow
                For Each dr In ds.Tables(0).Rows
                    Dim ListBarGroup As New clsBizlListBarGroup
                    ListBarGroup.ID = Convert.ToInt64(dr("ID"))
                    ListBarGroup.Name = dr("Name")
                    ListBarGroup.Caption = dr("Caption")
                    ListBarGroup.Type = Convert.ToInt16(dr("Type"))
                    ListBarGroup.DisplayOrder = Convert.ToInt64(dr("DisplayOrder"))
                    ListBarGroup.ParentModule_ID = Convert.ToInt64(dr("ParentModule_ID"))
                    ListBarGroup.ImageName = String.Concat(dr("ImageName"), "")
                    If dr("Type") = 1 Or dr("Type") = 3 Then
                        ListBarGroup.TargetUrl = String.Concat(dr("TargetUrl"), "")
                    End If
                    ListBarGroup.DomainName = String.Concat(dr("DomainName"), "")
                    objALListBarGroups.Add(ListBarGroup)
                Next dr
                Return objALListBarGroups
            Catch ex As Exception
                Throw
            Finally
                objClsDalSysModuleDan = Nothing
                'ds = Nothing
                If Not ds Is Nothing Then
                    ds.Dispose()
                End If
            End Try
        End Function 'GetListBarGroups
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This function is used to get list of groups
        ' </summary>
        ' <param name="iSecurityLevel_ID"> pass the SecurityLevel_ID </param>
        ' <param name="StrDomainIDList"> Domain ID list as string  </param>
        ' <param name="dtDomain"> Data Table contains the list of the domains</param>
        ' <param name="intDefID"> an optional sys default ID  </param>
        ' <param name="strDefValue"> an optional sys default value </param>
        ' <returns> return Array list of groups </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '  
        ' 	[Srinivas K]	  15/06/2005   Comments Added	
        '   [Suneetha B]      22/10/2005   Modified to get the requested DomainList as datatable , default values , sysmodules 
        ' </history>
        ' ----------------------------------------------------------------------------
        '''Public Shared Function GetSecuritySysModule(ByVal iSecurityLevel_ID As Int32, ByVal sModuleTypes As String, ByVal StrDomainIDList As String, ByRef dtDomain As DataTable, ByVal strApplicationType As String, ByVal blnGUIDExists As Boolean, ByVal blnIsOfflineDBAdmin As Boolean, Optional ByVal intDefID As Integer = 0, Optional ByRef strDefValue As String = "") As ArrayList
        '''    Dim ds As DataSet
        '''    Dim objClsDalSysModuleDan As clsDalSysModuleDan
        '''    Try
        '''        objClsDalSysModuleDan = New clsDalSysModuleDan
        '''        ds = objClsDalSysModuleDan.GetSecuritySysModule(iSecurityLevel_ID, sModuleTypes, StrDomainIDList, strApplicationType, blnGUIDExists, blnIsOfflineDBAdmin, intDefID, strDefValue)
        '''        Dim objALListBarGroups As New ArrayList
        '''        ' Separate Data into array collection 
        '''        Dim dr As DataRow
        '''        If ds.Tables.Count > 0 And ds.Tables.Count >= 2 Then
        '''            dtDomain = ds.Tables(0)
        '''            For Each dr In ds.Tables(1).Rows
        '''                Dim ListBarGroup As New clsBizlListBarGroup
        '''                ListBarGroup.ID = Convert.ToInt64(dr("ID"))
        '''                ListBarGroup.Name = dr("Name")
        '''                ListBarGroup.Caption = dr("Caption")
        '''                ListBarGroup.Type = Convert.ToInt16(dr("Type"))
        '''                ListBarGroup.DisplayOrder = Convert.ToInt64(dr("DisplayOrder"))
        '''                ListBarGroup.ParentModule_ID = Convert.ToInt64(dr("ParentModule_ID"))
        '''                ListBarGroup.ImageName = String.Concat(dr("ImageName"), "")
        '''                ListBarGroup.TargetUrl = String.Concat(dr("TargetUrl"), "")
        '''                ListBarGroup.DomainName = String.Concat(dr("DomainName"), "")
        '''                objALListBarGroups.Add(ListBarGroup)
        '''            Next dr
        '''        End If
        '''        Return objALListBarGroups
        '''    Catch ex As Exception
        '''        Throw
        '''    Finally
        '''        objClsDalSysModuleDan = Nothing
        '''        ds = Nothing
        '''    End Try
        '''End Function 'GetSecuritySysModule
        Public Shared Function GetSecuritySysModule(ByVal int64Usr_ID As Int64, ByVal intSecurityLevel_ID As Int32, ByVal sModuleTypes As String, ByVal strApplicationType As String, ByVal blnGUIDExists As Boolean, ByVal blnIsOfflineDBAdmin As Boolean, ByVal strproducttype As String, ByVal intUserLocationID As Integer) As DataSet
            Dim objClsDalSysModuleDan As clsDalSysModuleDan
            Try
                objClsDalSysModuleDan = New clsDalSysModuleDan
                Return objClsDalSysModuleDan.GetSecuritySysModule(int64Usr_ID, intSecurityLevel_ID, sModuleTypes, strApplicationType, blnGUIDExists, blnIsOfflineDBAdmin, strproducttype, intUserLocationID)
            Catch ex As Exception
                Throw
            Finally
                objClsDalSysModuleDan = Nothing
            End Try
        End Function

        '' Function : GetSecuritySysModuleForECFORMS
        '' Author : suneetha
        '' 24th March 2005  
        '' Purpose : to get the system modules when logged in from ECFORMS
        '' return value : ArrayList
        ''------------------------------------------------------------------------
        ' -----------------------------------------------------------------------------
        ' <summary>
        '      To get the system modules when logged in from ECFORMS
        ' </summary>
        ' <param name="iSecurityLevel_ID"> SecurityLevel Id </param>
        ' <param name="sModuleTypes"> ModuleType </param>
        ' <returns> ArrayList containing System Modules </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Suneetha]       24/03/2005  Created
        '      [Srinivas k]	    15/06/2005	Comments Added
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Function GetSecuritySysModuleForECFORMS(ByVal iSecurityLevel_ID As Int32, ByVal sModuleTypes As String, ByVal StrDomainIDList As String, ByRef dtDomain As DataTable, Optional ByVal intDefID As Integer = 0, Optional ByRef strDefValue As String = "") As ArrayList
            Dim dsModule As New DataSet
            Dim objClsDalSysModuleDan As clsDalSysModuleDan
            Dim objListBarGroup As clsBizlListBarGroup
            Dim objALListBarGroups As ArrayList
            Try
                objClsDalSysModuleDan = New clsDalSysModuleDan
                dsModule = objClsDalSysModuleDan.GetSecuritySysModuleForECFORMS(iSecurityLevel_ID, sModuleTypes, StrDomainIDList, intDefID)
                objALListBarGroups = New ArrayList
                dtDomain = Nothing

                ' Separate Data into array collection 
                If Not dsModule Is Nothing Then
                    If dsModule.Tables.Count > 0 And dsModule.Tables(0).Rows.Count = 2 Then
                        If dsModule.Tables(0).Rows.Count > 0 Then
                            dtDomain = dsModule.Tables(0)
                        End If

                        For Each dr As DataRow In dsModule.Tables(1).Rows
                            objListBarGroup = New clsBizlListBarGroup
                            objListBarGroup.ID = Convert.ToInt64(dr("ID"))
                            objListBarGroup.Name = dr("Name")
                            objListBarGroup.Caption = dr("Caption")
                            objListBarGroup.Type = Convert.ToInt16(dr("Type"))
                            objListBarGroup.DisplayOrder = Convert.ToInt64(dr("DisplayOrder"))
                            objListBarGroup.ParentModule_ID = Convert.ToInt64(dr("ParentModule_ID"))
                            objListBarGroup.ImageName = String.Concat(dr("ImageName"), "")
                            objListBarGroup.TargetUrl = String.Concat(dr("TargetUrl"), "")
                            objListBarGroup.DomainName = String.Concat(dr("DomainName"), "")
                            objALListBarGroups.Add(objListBarGroup)
                        Next dr
                    End If
                End If

                Return objALListBarGroups
            Catch ex As Exception
                Throw
            Finally
                objClsDalSysModuleDan = Nothing
                'dsModule = Nothing
                objALListBarGroups = Nothing
                If Not dsModule Is Nothing Then
                    dsModule.Dispose()
                End If
            End Try
        End Function
        '****************************************************************************************
        'Sub/Function/Property Name : GetSubFormsForModule
        'Parameters   : None
        'Return Values: 
        'Purpose      : This function is used to list bar sub group items
        '
        'Other relevant sources: 
        '     
        'Author            : Nagodaya Bhaskar KR
        'Created Date      : 19/05/2004
        'Last Modified Date: None
        'Modification Log  :
        'Author                 Date           Reason
        '----------------------------------------------------------------------------------------
        '****************************************************************************************
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This function is used to list bar sub group items
        ' </summary>
        ' <param name="int32SecurityLevel_ID"> SecurityLevel Id </param>
        ' <param name="sModuleTypes"> ModuleType </param>
        ' <param name="int64ParentForm_Id"> ParentForm Id </param>
        ' <returns> Array List Containing list bar group names/group items </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Nagodaya Bhaskar KR]   19/05/2004  Created
        ' 	    [Srinivas k]	        15/06/2005	Comments Added
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Function GetSubFormsForModule(ByVal int32SecurityLevel_ID As Int32, ByVal sModuleTypes As String, ByVal int64ParentForm_Id As Int64, ByVal strApplicationType As String) As ArrayList
            Dim ds As New DataSet
            Dim objClsDalSysModuleDan As clsDalSysModuleDan
            Try
                objClsDalSysModuleDan = New clsDalSysModuleDan
                ds = objClsDalSysModuleDan.GetSubFormsForModule(int32SecurityLevel_ID, sModuleTypes, int64ParentForm_Id, strApplicationType)
                Dim objALListBarGroups As New ArrayList

                ' Separate Data into array collection 
                Dim dr As DataRow
                For Each dr In ds.Tables(0).Rows
                    Dim ListBarGroup As New clsBizlListBarGroup
                    ListBarGroup.ID = Convert.ToInt64(dr("ID"))
                    ListBarGroup.Name = dr("Name")
                    ListBarGroup.Caption = dr("Caption")
                    ListBarGroup.Type = Convert.ToInt16(dr("Type"))
                    ListBarGroup.DisplayOrder = Convert.ToInt64(dr("DisplayOrder"))
                    ListBarGroup.ParentModule_ID = Convert.ToInt64(dr("ParentModule_ID"))
                    ListBarGroup.ParentForm_ID = Convert.ToInt64(dr("ParentForm_ID"))
                    ListBarGroup.ImageName = String.Concat(dr("ImageName"), "")
                    ListBarGroup.TargetUrl = String.Concat(dr("TargetUrl"), "").Trim()
                    ListBarGroup.DomainName = String.Concat(dr("DomainName"), "").Trim()
                    objALListBarGroups.Add(ListBarGroup)
                Next dr
                Return objALListBarGroups
            Catch ex As Exception
                Throw
            Finally
                objClsDalSysModuleDan = Nothing
                'ds = Nothing
                If Not ds Is Nothing Then
                    ds.Dispose()
                End If
            End Try
        End Function
        Public Shared Function GetDomains(ByVal strIDList As String) As DataTable
            Dim objClsDalSysModuleDan As clsDalSysModuleDan
            Try
                objClsDalSysModuleDan = New clsDalSysModuleDan
                GetDomains = objClsDalSysModuleDan.GetDomains(strIDList)
            Catch ex As Exception
                Throw
            Finally
                objClsDalSysModuleDan = Nothing
            End Try
        End Function

        Public Function IsFormAccessible(ByVal intSysModuleId As Integer, ByVal strAppType As String, ByVal intUserSecLevel As Integer) As Boolean
            Dim objClsDalSysModuleDan As clsDalSysModuleDan
            Dim blnAccess As Boolean = False
            Try
                objClsDalSysModuleDan = New clsDalSysModuleDan
                blnAccess = objClsDalSysModuleDan.IsFormAccessible(intSysModuleId, strAppType, intUserSecLevel)
            Catch ex As Exception
                Throw
            Finally
                objClsDalSysModuleDan = Nothing
            End Try
            Return blnAccess
        End Function

        Public Function IsAdhocUser(ByVal lngUserID As Int64) As Boolean
            Dim objClsDalSysModuleDan As clsDalSysModuleDan
            Dim blnAccess As Boolean = False
            Try
                objClsDalSysModuleDan = New clsDalSysModuleDan
                Return objClsDalSysModuleDan.IsAdhocUser(lngUserID)
            Catch ex As Exception
                Throw
            Finally
                objClsDalSysModuleDan = Nothing
            End Try
            Return blnAccess
        End Function
        Public Function GetAdhocPath(ByVal strSession_ID As String) As String
            Dim objClsDalSysModuleDan As clsDalSysModuleDan
            Dim blnAccess As Boolean = False
            Try
                objClsDalSysModuleDan = New clsDalSysModuleDan
                Return objClsDalSysModuleDan.GetAdhocPath(strSession_ID)
            Catch ex As Exception
                Throw
            Finally
                objClsDalSysModuleDan = Nothing
            End Try
            Return blnAccess
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This function is used to get the Database version
        ' </summary>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]    02.03.2006  Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Function GetDBVersion() As DataSet
            Try
                Return clsDalSysModuleDan.GetDBVersion()
            Catch ex As Exception
                Throw
            End Try
        End Function

        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This function is used to get the helpUrl for the supplied form Name
        ' </summary>
        '<param Name="strFormName">form Name</param>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]    09.05.2006  Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function GetHelpTagetUrl(ByVal strFormName As String) As String
            Dim objClsDalSysModuleDan As clsDalSysModuleDan
            Try
                objClsDalSysModuleDan = New clsDalSysModuleDan
                Return objClsDalSysModuleDan.GetHelpTargetUrl(strFormName)
            Catch ex As Exception
                Throw
            Finally
                objClsDalSysModuleDan = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This function is used to get the values for Network Monitor Test
        ' </summary>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [K Srinivas Reddy]    26.02.2009  Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function GetNMTLimits() As String
            Dim objClsDalSysModuleDan As clsDalSysModuleDan
            Try
                objClsDalSysModuleDan = New clsDalSysModuleDan
                Return objClsDalSysModuleDan.GetNMTLimits()
            Catch ex As Exception
                Throw
            Finally
                objClsDalSysModuleDan = Nothing
            End Try
        End Function

        Public Function GetExternalURL(ByVal lngFormItemItemID As Long) As String
            Dim objClsDalSysModuleDan As clsDalSysModuleDan
            Try
                objClsDalSysModuleDan = New clsDalSysModuleDan
                Return objClsDalSysModuleDan.GetExternalUrl(lngFormItemItemID)
            Catch ex As Exception
                Throw
            Finally
                objClsDalSysModuleDan = Nothing
            End Try
        End Function
        Public Function GetSysActionMenuItems(ByVal strMenuGroupItemName As String, ByVal strActionName As String) As DataSet
            Dim objClsDalSysModuleDan As clsDalSysModuleDan
            Try
                objClsDalSysModuleDan = New clsDalSysModuleDan
                Return objClsDalSysModuleDan.GetSysActionMenuItems(strMenuGroupItemName, strActionName)
            Catch ex As Exception
                Throw
            Finally
                objClsDalSysModuleDan = Nothing
            End Try
        End Function

        '***********************************************************************************************************************
        'Purpose            :   To get DropDown items
        'Method Name        :   GetItemsforUserDropDown
        'Input Parameters   :   lngUserID, intUserRole
        'Return Values      :   Lookupvalues JSON string
        '-----------------------------------------------------------------------------------------------------------------------
        'Version        Author                              Date                            Remarks
        '-----------------------------------------------------------------------------------------------------------------------
        '7.5            RK                              25/04/2022                    Initial Implementation       
        '***********************************************************************************************************************
        Public Function GetItemsforUserDropDown(ByVal lngUserID As Long, ByVal intUserRole As Integer) As String
            Dim objClsDalSysModuleDan As clsDalSysModuleDan
            Dim dsValues As DataSet
            Try
                objClsDalSysModuleDan = New clsDalSysModuleDan
                dsValues = objClsDalSysModuleDan.GetItemsforUserDropDown(lngUserID, intUserRole)
                Return Newtonsoft.Json.JsonConvert.SerializeObject(dsValues.Tables(0))
            Catch ex As Exception
                Throw ex
            Finally
                dsValues = Nothing
                objClsDalSysModuleDan = Nothing
            End Try
        End Function

    End Class
    '*******************************************************************************************
    'Class Name : clsBizlListBarGroup
    'PURPOSE    : This class has has members/properties of list bar groups
    '
    'MODIFICATION LOG  :
    '
    'AUTHOR                      Ver#       Date        Reason/Changes
    '-------------------------------------------------------------------------------------------
    'Nagodaya Bhaskar KR.      1.0.000    05/03/2004    First version.
    '*******************************************************************************************
    Public Class clsBizlListBarGroup
        Private _ID As Int64
        Private _Name As String
        Private _Caption As String
        Private _Type As Int16
        Private _DisplayOrder As Int64
        Private _ParentModule_ID As Int64
        Private _ParentForm_ID As Int64
        Private _ImageName As String
        Private _TargetUrl As String
        Private _DomainName As String
#Region "Properties"
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       Get the Domain Name
        ' </summary>
        ' <value> DomainName </value>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Nagodaya Bhaskar KR]   05/03/2004  Created
        ' 	    [Srinivas k]	        15/06/2005	Comments Added
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Property DomainName() As String
            Get
                Return _DomainName
            End Get
            Set(ByVal Value As String)
                _DomainName = Value
            End Set
        End Property
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This Property is used to Get the ID
        ' </summary>
        ' <value> ID </value>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Nagodaya Bhaskar KR]   05/03/2004  Created
        ' 	    [Srinivas k]	        15/06/2005	Comments Added
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Property ID() As Int64
            Get
                Return _ID
            End Get
            Set(ByVal Value As Int64)
                _ID = Value
            End Set
        End Property
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       Get the  Name
        ' </summary>
        ' <value> Name </value>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Nagodaya Bhaskar KR]   05/03/2004  Created
        ' 	    [Srinivas k]	        15/06/2005	Comments Added
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Property Name() As String
            Get
                Return _Name
            End Get
            Set(ByVal Value As String)
                _Name = Value
            End Set
        End Property
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       Get the Caption
        ' </summary>
        ' <value> Caption </value>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Nagodaya Bhaskar KR]   05/03/2004  Created
        ' 	    [Srinivas k]	        15/06/2005	Comments Added
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Property Caption() As String
            Get
                Return _Caption
            End Get
            Set(ByVal Value As String)
                _Caption = Value
            End Set
        End Property
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       Get the Type
        ' </summary>
        ' <value> Type </value>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Nagodaya Bhaskar KR]   05/03/2004  Created
        ' 	    [Srinivas k]	        15/06/2005	Comments Added
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Property Type() As Int16
            Get
                Return _Type
            End Get
            Set(ByVal Value As Int16)
                _Type = Value
            End Set
        End Property
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       Get the DisplayOrder
        ' </summary>
        ' <value> DisplayOrder </value>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Nagodaya Bhaskar KR]   05/03/2004  Created
        ' 	    [Srinivas k]	        15/06/2005	Comments Added
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Property DisplayOrder() As Int64
            Get
                Return _DisplayOrder
            End Get
            Set(ByVal Value As Int64)
                _DisplayOrder = Value
            End Set
        End Property
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       Get the ParentModule_ID
        ' </summary>
        ' <value> ParentModule_ID </value>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Nagodaya Bhaskar KR]   05/03/2004  Created
        ' 	    [Srinivas k]	        15/06/2005	Comments Added
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Property ParentModule_ID() As Int64
            Get
                Return _ParentModule_ID
            End Get
            Set(ByVal Value As Int64)
                _ParentModule_ID = Value

            End Set
        End Property
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       Get the ParentForm_ID
        ' </summary>
        ' <value> ParentForm_ID </value>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Nagodaya Bhaskar KR]   05/03/2004  Created
        ' 	    [Srinivas k]	        15/06/2005	Comments Added
        ' </history>
        ' -----------------------------------------------------------------------------

        Public Property ParentForm_ID() As Int64
            Get
                Return _ParentForm_ID
            End Get
            Set(ByVal Value As Int64)
                _ParentForm_ID = Value

            End Set
        End Property
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       ImageName
        ' </summary>
        ' <value> ImageName </value>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Nagodaya Bhaskar KR]   05/03/2004  Created
        ' 	    [Srinivas k]	        15/06/2005	Comments Added
        ' </history>
        ' -----------------------------------------------------------------------------

        Public Property ImageName() As String
            Get
                Return _ImageName
            End Get
            Set(ByVal Value As String)
                _ImageName = Value
            End Set
        End Property
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       Get the TargetURL
        ' </summary>
        ' <value> Target Url </value>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Nagodaya Bhaskar KR]   05/03/2004  Created
        ' 	    [Srinivas k]	        15/06/2005	Comments Added
        ' </history>
        ' -----------------------------------------------------------------------------

        Public Property TargetUrl() As String
            Get
                Return _TargetUrl
            End Get
            Set(ByVal Value As String)
                _TargetUrl = Value
            End Set
        End Property
#End Region
    End Class
End Namespace