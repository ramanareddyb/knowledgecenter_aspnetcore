Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("AxLibBizlMDI")>
<Assembly: AssemblyDescription("EC v6.4000.0095.0000")> 
<Assembly: AssemblyCompany("AxSys Technology Ltd.")>
<Assembly: AssemblyProduct("AxLibBizlMDI")>
<Assembly: AssemblyCopyright("Copyright 1998 - 2017 AxSys Technology Ltd. All rights reserved.")>
<Assembly: AssemblyTrademark("Excelicare")> 
<Assembly: CLSCompliant(True)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("108D9105-7B4B-46D7-BC42-CC48FBABFC6C")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("6.5000.0001.0000")> 
<Assembly: AssemblyFileVersion("6.5000.0001.0000")> 
