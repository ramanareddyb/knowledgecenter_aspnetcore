Imports Ajax
Imports Excelicare.Bizl.MDI
Imports Excelicare.Framework.AppSupport
Imports System
Imports System.Text
Imports System.Collections.Generic
Imports System.Linq
Imports System.IO
Imports System.Net
Imports System.Web.Services
Imports System.Collections.Specialized

''----------------------------
'' use of Configuration key values used in this module

'' ConfigurationSettings.AppSettings("PreSelectedPatId") -- is used to get the PatientID of the patient to be shown when Ecforms is loaded 
'' ConfigurationSettings.AppSettings("StartUpForm")      -- is used to know which module to be loaded in MDI container when ECFORMS is loaded
'' ConfigurationSettings.AppSettings("RecordID")         -- Gives the form ID which is used to show the form to be displayed when Special forms is loaded
'' ConfigurationSettings.AppSettings("ShowPatLabels")    -- Gives a boolean value which indicates whether the patient bar has to be shown for ECFORMS or not
''---------------------------

Namespace Excelicare.UI.Web.MDI
    Partial Class frmPatientBar
        Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        ''<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        ''End Sub
        'Removed by Srinivas V on 25-07-2007 to Use HTML Buttons
        'Protected WithEvents imgBCritical As System.Web.UI.WebControls.Image
        'Protected WithEvents ImgBAllergy As System.Web.UI.WebControls.Image
        'Protected WithEvents imgBOtherAlerts As System.Web.UI.WebControls.Image

        Protected WithEvents lblCritical As System.Web.UI.WebControls.Label
        Protected WithEvents lblAllergy As System.Web.UI.WebControls.Label

        Protected WithEvents hdnPatientSelectFromMyPatient As System.Web.UI.HtmlControls.HtmlInputHidden
        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            '  InitializeComponent()
        End Sub

#End Region
        'Dim strQS As String = String.Empty
        'Dim objAxSession As clsAxSession
        'Dim objClsUser As clsUser
        'Dim objClsApplication As clsApplication
        Public strSpecialFormURL As String
        Public strCalledFrom As String ''added by Suneetha to resolve between in ecweb and ecforms on 30th April 2005 
        Public strDomainName As String = "../"
        Public strMDIDomainName As String = "../"

        Public strSecIdentName As String = ""
        Public strSecIdentValue As String = ""
        Public strPriIdentName As String = ""
        Public strPriIdentValue As String = ""
        Public strUsrIdenvalue As String()
        Public lngUserId As Long
        Public m_strDOD As String = ""

        Private lngPatId As Long
        Dim intStartUpModuleId As Integer
        Private intUsrSecLevel As Int16
        Public strDialogDomainName As String = "../"
        Public strCriticalProblemText As String = "" 'Added by Srinivas V on 15-June-2007 17:26 to Complete CriticalProblem ToolTip
        Public strAllergyorADRText As String = "" 'Added by Srinivas V on 15-June-2007 17:26 to Complete AllergyorADR ToolTip
        Public strOtherAlertText As String = "" 'Added by Srinivas V on 15-June-2007 17:26 to Complete OtherProblem ToolTip
        Public blnIsTraining As Boolean
        Public isActivePatient As Integer
        Public intSLogPatId As Int64
        Public M_blnValidPatient As Boolean
        Public intACLPatient As Int16 = 0
        Public strADRText As String = "" 'Added by Pradeep on 1-Sep-2008 For ADR ToolTip
        Public blnIsPrescriptionInQueue As Boolean
        Public GetPatRestrictionLevel As Integer
        Public m_blnDeadPatient As Boolean = False
        Protected strPatJSON As String = "{" & Chr(180) & "}}"
        Public strBannerAllergy As String = String.Empty
        Public m_strSex As String = "Sex"
        Public m_strDOB As String
        Public m_strAge As String
        Public m_strClinicianInfo As String = ""
        Public m_strConnectedSystemInfo As String = ""
        Protected strVerNo As String = ""
        Public m_IsACLPatient As Integer = 0
        Public m_usrRstLevel As Integer = 0
        Public m_strAppType As String = ""
        Private m_strFacName As String = String.Empty
        Private m_strFactIdent As String
        Public strActionValue As String = ""
        Public strActionCaption As String = ""
        Public strhideActionItem As String = ""
        Public intVersionNumber As String = "0"
        Public inthidetracingstatus As String = "0"
        Public intShowPatientKeySummary As Integer = 0
        Public strGenderIdentity As String = String.Empty
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       Using for Patient Bar(Patient Name,Age,DOB,Cleftsis No..)
        ' </summary>
        ' <remarks>
        ' </remarks>
        ' <history>
        ' 	    [Srinivas K]	16/06/2005	Comments Added
        ' </history>
        ' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Response.Expires = -1
            Response.Cache.SetNoServerCaching()
            Response.Cache.SetAllowResponseInBrowserHistory(False)
            Response.CacheControl = "no-cache"
            Response.Cache.SetNoStore()
            'Response.Expires = 0 ''Added by Suneetha 
            'Dim objClsSessionManager As clsSessionManager
            Response.Cache.SetNoStore() ''Added by Samatha 01/05/2008
            Ajax.Utility.RegisterTypeForAjax(GetType(frmPatientBar))
            Dim objClsBizlPatient As clsBizlPatient
            '''Dim objClsAppSettings As clsAppSettings
            '''Dim objBizUser As AxSys.Bizl.MDI.clsBizlUser
            Dim Session_ID As String
            Dim dsPatient As DataSet
            Dim strDateFormat As String
            'Dim int64Patient_ID As Int64
            Dim dtDOB, dtDOD As Date
            Dim LibID As String = ""
            Dim strUrl As String

            Dim blnPAT_DOD As Boolean
            Dim strApproxDODFlag As String
            Dim blnApproxDODFlag As Boolean
            Dim objClsPatient As clsPatient
            '''Dim dtDomain As DataTable
            Dim strPreferredIdentifierValue As String = String.Empty
            Dim strSecondaryIdentifierValue As String = String.Empty
            Dim strPrimayIdentifierValue As String = String.Empty
            Dim intAgeMonthCount As Int16
            Dim objSessionData As clsSessionData
            Dim intSlPatID As Int64
            Dim objClsSessionmanager As clsSessionManager
            Dim strAppType As String

            Dim strEventDesc As String
            Dim objBizUser As clsBizlUser
            Dim strEmptyString As String = ""
            Dim objGetVersionNo As clsAppSettings
            Dim objclsSecurity As clsSecurity
            Dim objQueryParams As New NameValueCollection
            Try
                GetSessionData()

                objClsSessionmanager = New clsSessionManager
                objSessionData = objClsSessionmanager.GetSessionData(Me.Session.SessionID, "APPDATA")
                If objSessionData Is Nothing Then
                    Exit Sub
                End If

                If SiteExcelicare.URLValidationCheck(Request.Url.ToString.Replace(Chr(34), "").Replace("""", "")) = False Then
                    'Ajax_LogSessionAction(lngPatId, 2729, "Response ended due to URL is altered.")
                    Response.End()
                    Exit Sub
                End If

                fnValidateHiddenFieldsData(Me.Page)
                If System.Configuration.ConfigurationSettings.GetConfig("system.web/globalization").uiCulture() = "en-US" Then
                    m_strSex = "Gender"
                End If
                objGetVersionNo = New clsAppSettings
                strVerNo = objGetVersionNo.GetModuleVersion("1031")
                WriteToTrace("Page_Load", "frmPatientBar.aspx.vb", "Page Load started at-" + System.DateTime.Now.ToString)
                objclsSecurity = New clsSecurity
                If Not Request.QueryString("strQPData") Is Nothing Then
                    objQueryParams = objclsSecurity.fnGetQueryParamData(Request.QueryString("strQPData"))
                Else
                    objQueryParams = Request.QueryString
                End If

                If Page.IsPostBack = False AndAlso IsNothing(objQueryParams.Item("pid")) = False AndAlso IsNumeric(objQueryParams.Item("pid")) = True Then
                    hdnChangePatID.Value = objQueryParams.Item("pid")
                    hdnCurrentPatID.Value = objQueryParams.Item("pid")

                End If

                m_usrRstLevel = intUsrSecLevel
                LogwebsessionAction("Patient bar", lngPatId, 2042, "Checking hdnChangePatID :" & hdnChangePatID.Value & " in Page Load-BEGIN", 1031)

                objClsPatient = New clsPatient
                objBizUser = New clsBizlUser
                If (objQueryParams.Count > 0 AndAlso objQueryParams.Item("sid") <> "") Then
                    Session_ID = objQueryParams.Item("sid")
                Else
                    Session_ID = Session.SessionID  ''clsNavigation.GetSession_ID(Session)
                End If
                If (objQueryParams.Item("PatientContext") = "True") Then
                    hdnChangeContext.Value = objQueryParams.Item("PatientContext")
                End If
                If Application("ApplicationInstallType") <> "" Then
                    strAppType = Application("ApplicationInstallType")
                Else
                    strAppType = "3,5,7"
                End If

                m_strAppType = strAppType
                If Not IsNothing(Session("CALLEDFROM")) Then
                    strCalledFrom = Session("CALLEDFROM") 'objClsSessionManager.GetSessionData(Session_ID, "Session_CalledFrom")
                End If
                '' Added by PVP Mohan on 23.07.2007 to change the Title of the Application when connected to Training DB
                Dim StrDBDetails As String = ""
                StrDBDetails = System.Configuration.ConfigurationSettings.AppSettings.Item("ConnectionString")
                If (StrDBDetails.ToLower.IndexOf("initial catalog") <> -1) Then
                    If (StrDBDetails.ToLower.IndexOf("_training") <> -1) Then
                        blnIsTraining = True
                    Else
                        blnIsTraining = False
                    End If
                End If
                If Not strCalledFrom Is Nothing Then
                    If Not IsNumeric(strCalledFrom) Then
                        strCalledFrom = 0
                    End If
                    If CInt(strCalledFrom) = 1031 Then
                        strSpecialFormURL = "../AxWebUIDisplaySpecialform/frmDisplayform.aspx"  'clsNavigation.GetURL(56, "btnSelect") ''Addedby Bhavani on 13/07/2005

                        '' Added by Suneetha on 03.08.2005 to set the defauly patID Begin
                        If Not ConfigurationSettings.AppSettings("PreSelectedPatId") Is Nothing Then
                            If ConfigurationSettings.AppSettings("PreSelectedPatId").ToString <> "" Then
                                If hdnChangePatID.Value = "" Then
                                    hdnChangePatID.Value = ConfigurationSettings.AppSettings("PreSelectedPatId").ToString
                                End If
                            End If
                        End If
                    Else
                        strCalledFrom = "1"
                    End If
                Else
                    strCalledFrom = "1"
                End If
                strhideActionItem = clsSysDefault.GetSysDefaultValue(2268)
                inthidetracingstatus = clsSysDefault.GetSysDefaultValue(2322)
                hdnBannerAllergy.Value = ""
                hdnPatientSelected.Value = ""
                hdnEntityType.Value = ""
                '\\Start\Added by Ashok to retrieve the Patient Details URL for Showing Pat. Details when Dead Image Icon is clicked
                hdPatDet.Value = "../AxWebUIPatientRegistration/framPatientRegistration.aspx?AppMode=PatDet"

                '\\End\Added by Ashok to retrieve the Patient Details URL for Showing Pat. Details when Dead Image Icon is clicked

                'Added by Jagadeesh on 19 Jun 2007 to check whether cam modules enabled or not
                '''If objBizUser.GetSysLookupValue(2264) = "1" Then
                '''    hdNoticeBoard.Value = objBizUser.GetPatientRecordStartUpFormUrl(1101)
                '''    'Adding attribue to call fnShowNoticeBoard on notice board image button click
                '''    'code changed to java script by sravanthi on 09/05/2008 to fix the issue 13418
                '''    imgBNoticeBoard.Attributes.Add("OnClick", "javascript:return fnShowNoticeBoard();")
                '''    imgBNoticeBoard.Visible = True
                '''Else
                '''    imgBNoticeBoard.Visible = False
                '''End If
                'If Not IsPostBack Then
                '''UpdateStartUpFormDetails() '' for updating the user start form url 
                ' End If
                If hdnChangePatID.Value <> "" Then
                    If hdnChangePatID.Value = "-100" Then 'For Load Testing - Temp Change
                        If Not Session("APPDATA") Is Nothing Then
                            LogwebsessionAction("Patient bar", lngPatId, 2042, "Checking hdnChangePatID :" & hdnChangePatID.Value & " in Page Load-Middle", 1031)
                            lngPatId = objSessionData.PatientID 'CType(Session("APPDATA"), clsSessionData).PatientID
                            hdnChangePatID.Value = ""
                        End If
                    Else
                        ''Added by K.Bhavani on 25/04/2008 to store the SessionLogDBPatientId,Current Selected PatientId -- START
                        If Not Session("APPDATA") Is Nothing Then
                            objSessionData.PatientID = hdnChangePatID.Value   ''Setting the Session PatId
                            objSessionData.CurrentPatientID = hdnChangePatID.Value
                            lngPatId = hdnChangePatID.Value
                        End If
                        ''Added by K.Bhavani on 25/04/2008 to store the SessionLogDBPatientId,Current Selected PatientId -- END
                    End If
                End If
                objClsBizlPatient = New clsBizlPatient
                'Added on 27-JUN-2008 to check for empty identifiers --- START
                If Not IsNothing(Session("USR_IDENTIFIER_LU")) Then
                    If Session("USR_IDENTIFIER_LU") = "" Then
                        Session("USR_IDENTIFIER_LU") = "-1"
                    End If
                End If
                If Not IsNothing(Session("USR_IDENTIFIER")) Then
                    If Session("USR_IDENTIFIER") = "" Then
                        Session("USR_IDENTIFIER") = "-1"
                    End If
                End If
                'Added on 27-JUN-2008 to check for empty identifiers --- END
                dsPatient = objClsBizlPatient.GetPatientDetails(lngPatId, lngUserId, intUsrSecLevel, Session("USR_IDENTIFIER_LU"), Session("USR_IDENTIFIER"), strAppType)
                If Not dsPatient.Tables("SummaryPinnedstate") Is Nothing AndAlso dsPatient.Tables("SummaryPinnedstate").Rows.Count > 0 Then
                    intShowPatientKeySummary = dsPatient.Tables("SummaryPinnedstate").Rows(0)("PatientSummaryState")
                End If
                UpdateStartUpFormDetails(dsPatient.Tables("OtherInfo").Rows(0)) '' for updating the user start form url 
                If IsNothing(Session("CurrentLoadedModule")) Then 'code added for patient navigation in patient registration by p.s.kiran on 24/07/07.
                    If Not IsNothing(Session("PatientStack")) Then
                        Session("PatientStack") = ""
                    End If
                ElseIf CType(Session("CurrentLoadedModule"), Long) <> 104 Then
                    If Not IsNothing(Session("PatientStack")) Then
                        Session("PatientStack") = ""
                    End If
                End If
                ''Code changes done by Narendra on 30/04/2008

                hdnCurrentPatID.Value = lngPatId
                If hdnChangePatID.Value = "" Then
                    hdnChangePatID.Value = 0
                End If
                Try
                    objClsBizlPatient = New clsBizlPatient
                    If Not Session("APPDATA") Is Nothing Then
                        objSessionData.PatientID = hdnChangePatID.Value   ''Setting the Session PatId
                        objSessionData.CurrentPatientID = hdnChangePatID.Value
                        ' WriteToTrace("SetSessionData", "frmPatientBar.aspx.vb", "Patient Id: " & lngPatId & "| Session Patient ID :" & hdnChangePatID.Value & "| Session Current Patient ID: " & hdnChangePatID.Value & "| User Id :" & lngUserId & "| Session ID: " & Session.SessionID & "|Date and Time :" + System.DateTime.Now.ToString)
                        LogwebsessionAction("Patient bar", hdnChangePatID.Value, 2042, "SetSessionData", 1031)
                        objClsSessionmanager.SetSessionData(Me.Session.SessionID, "APPDATA", objSessionData)
                    End If
                    If lngPatId > 0 Then
                        intSlPatID = objClsBizlPatient.LogPatientChangeAction("Patient Bar", Session.SessionID, hdnChangePatID.Value, 2398, "Patient Selected", 1031) ''To Log SessionAction when PatientId is set
                        'Added By Posubabu CR To Show Last Visted Patient By Logged in User ''06/02/2012 
                        objClsBizlPatient.InsLastViewPatDetails(lngPatId, lngUserId, Me.Session.SessionID)
                    Else
                        intSlPatID = objClsBizlPatient.LogPatientChangeAction("Patient Bar", Session.SessionID, hdnChangePatID.Value, 2399, "Patient Deselected", 1031) ''To Log SessionAction when PatientId is set
                    End If
                    If intSlPatID <> -15000 Then
                        If intSlPatID <> lngPatId OrElse intSlPatID <> objSessionData.PatientID Then
                            strEventDesc = "Patient Bar| Patient Id:" & lngPatId & "| Session Patient ID : " & objSessionData.PatientID & "| Session Current Patient ID:" & intSlPatID & "|Valid Patient Status: False"
                            LogwebsessionAction("Patient bar", hdnChangePatID.Value, 2401, strEventDesc, 1031)
                            M_blnValidPatient = False
                            hdnChangePatID.Value = 0
                        Else
                            strEventDesc = "Patient Bar| Patient Id:" & lngPatId & "| Session Patient ID : " & objSessionData.PatientID & "| Session Current Patient ID:" & intSlPatID & "|Valid Patient Status: True"
                            LogwebsessionAction("Patient bar", hdnChangePatID.Value, 2042, strEventDesc, 1031)
                            M_blnValidPatient = True
                            intSLogPatId = intSlPatID
                        End If
                    Else
                        strEventDesc = "Patient Bar| Patient Id:" & lngPatId & "| Session Patient ID : " & objSessionData.PatientID & "| Session Current Patient ID:" & intSlPatID & "|Valid Patient Status: True"
                        LogwebsessionAction("Patient bar", hdnChangePatID.Value, 2401, strEventDesc, 1031)
                        M_blnValidPatient = False
                        hdnChangePatID.Value = 0
                    End If
                Catch ex As Exception
                    strEventDesc = "Patient Bar|Catch Exception: " & ex.Message & "| Patient Id:" & lngPatId & "| Session Patient ID : " & objSessionData.PatientID & "| Session Current Patient ID:" & intSlPatID & "|Valid Patient Status: False"
                    LogwebsessionAction("Patient bar", hdnChangePatID.Value, 2401, strEventDesc, 1031)
                    M_blnValidPatient = False
                    hdnChangePatID.Value = 0
                End Try
                If lngPatId > 0 Then
                    '''objClsPatient.GetPatientDetails(lngPatId)
                    '''dsPatient = objClsBizlPatient.GetPatientDetails(lngPatId, lngUserId)
                    '  dsPatient = objClsBizlPatient.GetPatientDetails(lngPatId, lngUserId, intUsrSecLevel, Session("USR_IDENTIFIER_LU"), Session("USR_IDENTIFIER"), strAppType)
                    '' Added by Suneetha on 03.08.2005 to show special forms Begin
                    If dsPatient.Tables("PatActionItem") IsNot Nothing AndAlso strhideActionItem = "1" Then
                        If dsPatient.Tables("PatActionItem").Rows.Count > 0 Then
                            strActionCaption = dsPatient.Tables("PatActionItem").Rows(0)(0)
                            strActionValue = strActionCaption.Split(Chr(13))(0)
                            spnAction.InnerText = strActionValue
                            spnAction.Attributes.Add("title", strActionCaption)
                        End If
                    End If

                    If Not IsPostBack Then
                        If Not strCalledFrom Is Nothing Then
                            If CInt(strCalledFrom) = 1031 Then
                                If Not ConfigurationSettings.AppSettings("PreSelectedPatId") Is Nothing Then ''
                                    If ConfigurationSettings.AppSettings("PreSelectedPatId").ToString <> "" Then
                                        If Not ConfigurationSettings.AppSettings("StartUpForm") Is Nothing Then
                                            If ConfigurationSettings.AppSettings("StartUpForm").ToString = "SpecialForms" Then
                                                LibID = ""
                                                If Not ConfigurationSettings.AppSettings("RecordID") Is Nothing Then ''
                                                    If ConfigurationSettings.AppSettings("RecordID").ToString <> "" Then
                                                        LibID = ConfigurationSettings.AppSettings("RecordID").ToString.Trim
                                                    End If
                                                End If
                                                strUrl = "../AxWebUIDisplaySpecialform/frmDisplayform.aspx?CalledFrom=MyFavourites&ShowTreeFrame=false&FormID=" & LibID
                                                RegisterClientScriptBlock("LoadSpecialForms", "<script language=javascript> parent.frames[3].location.href = '" & strUrl & "';</script>")
                                            End If
                                        End If
                                    End If
                                End If
                            End If
                        End If
                    End If

                    hdnPatientSelected.Value = 1
                    If (dsPatient.Tables(0).Rows.Count > 0) Then
                        '' Added by Suneetha to show or hide patient label bar for ECFORMS based on config key : ShowPatLabels -- Begin

                        'Patient Name
                        ''Added by Suneetha on 27.06.2005 to display the patname like ... when the length is > 17 Begin


                        objSessionData.Pat_ForeName = dsPatient.Tables(0).Rows.Item(0)("PAT_Forename1")
                        objSessionData.Pat_SurName = dsPatient.Tables(0).Rows.Item(0)("PAT_Surname")
                        objSessionData.Pat_Gender = dsPatient.Tables(0).Rows.Item(0)("Sex")
                        If Not dsPatient.Tables(0).Rows.Item(0)("EntityType_SLU") Is Nothing Then
                            objSessionData.EntityType = IIf(IsDBNull(dsPatient.Tables(0).Rows.Item(0)("EntityType_SLU")), -1, dsPatient.Tables(0).Rows.Item(0)("EntityType_SLU"))
                        End If
                        If Not dsPatient.Tables(0).Rows.Item(0)("FacilityPrimaryIdentifier") Is Nothing Then
                            m_strFactIdent = IIf(IsDBNull(dsPatient.Tables(0).Rows.Item(0)("FacilityPrimaryIdentifier")), "", dsPatient.Tables(0).Rows.Item(0)("FacilityPrimaryIdentifier"))
                        End If
                        If Not dsPatient.Tables(0).Rows.Item(0)("FacilityName") Is Nothing Then
                            m_strFacName = IIf(IsDBNull(dsPatient.Tables(0).Rows.Item(0)("FacilityName")), "", dsPatient.Tables(0).Rows.Item(0)("FacilityName"))
                        End If
                        ' strPatJSON = "{'Surname':'" & dsPatient.Tables(0).Rows(0)("PAt_Surname") & "','Forename1':'" & dsPatient.Tables(0).Rows(0)("PAT_Forename1") & "','MiddleName':'" & dsPatient.Tables(0).Rows(0)("PAT_Forename1") & "'}"


                        If Not dsPatient.Tables(0).Rows.Item(0)("IsACLPatient") Is Nothing Then
                            intACLPatient = dsPatient.Tables(0).Rows.Item(0)("IsACLPatient")
                            m_IsACLPatient = intACLPatient
                        End If
                        ''Added by Suneetha on 27.06.2005 to display the patname in with ... when the length is > 17 End


                        'Added by Pradeep P on 01-09-2008 to Display ADR Text 
                        'Check for display of ADRicon on Patient Bar
                        strADRText = ""
                        GetPatRestrictionLevel = objBizUser.GetPatRestrictionLevel(lngUserId, lngPatId, CType(Session("RESTRICTIONLEVEL"), Int16))
                        Session("PatRestrictionLevel") = GetPatRestrictionLevel
                        'If GetPatRestrictionLevel = 0 Then
                        '    If objClsBizlPatient.IsPatientHavingADR(lngPatId, strADRText) Then
                        '        '' ImgBAllergy.Visible = True
                        '        'Added by Srinivas V on 15-June-2007 18:39 for ToolTipDisplay
                        '        strADRText = strADRText.Substring(0, strADRText.Length - 1)
                        '        strADRText = strADRText.Replace(ChrW(182) & ChrW(181), ChrW(181))
                        '        'strAllergyorADRText = "Allergy/ADR(s) - " & strAllergyorADRText.Split(ChrW(182)).Length & ":\n *" & strAllergyorADRText.Replace(ChrW(182), "\n *").Replace("'", "&#39;")
                        '        strADRText = "ADR(s) - " & strADRText.Split(ChrW(182)).Length & ":\n *" & strADRText.Replace(ChrW(182), "\n *").Replace("'", "\'")
                        '        ' strAllergyorADRText = strAllergyorADRText
                        '        '' Else
                        '        ''  ImgBAllergy.Visible = False
                        '    End If
                        'End If
                        '   blnIsPrescriptionInQueue = objClsBizlPatient.IsPatientHavingPrescriptionsInQueue(lngPatId, objSessionData.UserID)
                        ''If dsPatient.Tables("OtherInfo").Rows(0).Item("AllergyProblems") <> "" Then
                        ''    strAllergyorADRText = dsPatient.Tables("OtherInfo").Rows(0).Item("AllergyProblems") 'strAllergyorADRText.Replace(ChrW(182) & ChrW(181), ChrW(181))
                        ''    strAllergyorADRText = "Allergy/ADR(s):" & strEmptyString & "\n *" & strAllergyorADRText.Replace(ChrW(182), "\n *").Replace("'", "&#39;") '"Allergy/ADR(s) - " & strAllergyorADRText.Split(ChrW(182)).Length & ":\n *" & strAllergyorADRText.Replace(ChrW(182), "\n *").Replace("'", "\'")
                        ''End If
                        'Check for display of Other Alert Problems on Patient Bar- Added by ashok
                        '''If objClsBizlPatient.IsPatientHavingOtherAlertProblems(lngPatId, strOtherAlertText) Then
                        '''    strOtherAlertText = strOtherAlertText.Replace(ChrW(182) & ChrW(181), ChrW(181))
                        '''    strOtherAlertText = "Other Alert(s) - " & strOtherAlertText.Split(ChrW(182)).Length & ":\n *" & strOtherAlertText.Replace(ChrW(182), "\n *").Replace("'", "\'")
                        '''End If
                        ''If dsPatient.Tables("OtherInfo").Rows(0).Item("OthersProblems") <> "" Then
                        ''    strOtherAlertText = dsPatient.Tables("OtherInfo").Rows(0).Item("OthersProblems")
                        ''    strOtherAlertText = "Other Alert(s):" & strEmptyString & "\n *" & strOtherAlertText.Replace(ChrW(182), "\n *").Replace("'", "&#39;") 'strOtherAlertText = strOtherAlertText
                        ''End If

                        'Check for display of Critical Problems on Patient Bar- Added by ashok
                        '''If objClsBizlPatient.IsPatientHavingCriticalProblems(lngPatId, strCriticalProblemText) Then
                        '''    strCriticalProblemText = strCriticalProblemText.Replace(ChrW(182) & ChrW(181), ChrW(181))
                        '''    strCriticalProblemText = "Critical Problem(s) - " & strCriticalProblemText.Split(ChrW(182)).Length & ":\n *" & strCriticalProblemText.Replace(ChrW(182), "\n *").Replace("'", "\'")
                        '''End If
                        ''If dsPatient.Tables("OtherInfo").Rows(0).Item("CriticalProblems") <> "" Then
                        ''    strCriticalProblemText = dsPatient.Tables("OtherInfo").Rows(0).Item("CriticalProblems")
                        ''    strCriticalProblemText = "Critical Problem(s):" & strEmptyString & "\n *" & strCriticalProblemText.Replace(ChrW(182), "\n *").Replace("'", "&#39;")
                        ''End If
                        If dsPatient.Tables("AllergyInfo").Rows.Count > 0 Then
                            If IsNothing(dsPatient.Tables("AllergyInfo").Rows(0).Item(0)) = False AndAlso Not IsDBNull(dsPatient.Tables("AllergyInfo").Rows(0).Item(0)) AndAlso dsPatient.Tables("AllergyInfo").Rows.Count > 0 Then
                                hdnBannerAllergy.Value = dsPatient.Tables(2).Rows(0).Item(0)
                            Else
                                hdnBannerAllergy.Value = ""
                            End If
                        Else
                            hdnBannerAllergy.Value = ""
                        End If


                        ''strDateFormat = objClsAppSettings.GetAppDateFormat(eDateFormats.dftYMD)
                        '''objClsAppSettings = Nothing
                        strDateFormat = dsPatient.Tables("OtherInfo").Rows(0).Item("DFTYMD")
                        If IsNothing(Session("SignOn")) = False AndAlso Session("SignOn") = "1" Then
                            strDateFormat = "dd-MMM-yyyy"
                        Else
                            strDateFormat = dsPatient.Tables("OtherInfo").Rows(0).Item("DFTYMD")
                        End If

                        strApproxDODFlag = ""
                        If IsDBNull(dsPatient.Tables(0).Rows.Item(0)("PAT_DOD")) Then
                            If Not IsDBNull(dsPatient.Tables(0).Rows.Item(0)("IsDeceased")) Then
                                If dsPatient.Tables(0).Rows.Item(0)("IsDeceased") = True Then
                                    If IsDBNull(dsPatient.Tables(0).Rows.Item(0)("DeceasedRecordDate")) Then
                                        strApproxDODFlag = ""
                                    Else
                                        strApproxDODFlag = "*"
                                        blnApproxDODFlag = True
                                    End If
                                End If
                            End If
                        End If

                        If dsPatient.Tables(0).Rows.Item(0)("PAT_DOBKnown") = True Then
                            'DOB
                            m_strDOB = Format(dsPatient.Tables(0).Rows.Item(0)("PAT_DOB"), strDateFormat)
                            'Patient Age


                            If IsDBNull(dsPatient.Tables(0).Rows.Item(0)("PAT_DOB")) Then
                                dtDOB = DateTime.MinValue
                            Else
                                dtDOB = dsPatient.Tables(0).Rows.Item(0)("PAT_DOB")
                            End If

                            objSessionData.Pat_DateOfBirth = dtDOB
                            Session("DOB") = objSessionData.Pat_DateOfBirth

                            If IsDBNull(dsPatient.Tables(0).Rows.Item(0)("PAT_DOD")) Then
                                dtDOD = DateTime.MinValue
                                If Not IsDBNull(dsPatient.Tables(0).Rows.Item(0)("IsDeceased")) Then
                                    If dsPatient.Tables(0).Rows.Item(0)("IsDeceased") = "True" Then
                                        If Not IsDBNull(dsPatient.Tables(0).Rows.Item(0)("DeceasedRecordDate")) Then
                                            dtDOD = dsPatient.Tables(0).Rows.Item(0)("DeceasedRecordDate")
                                        End If
                                    End If
                                End If
                                blnPAT_DOD = False
                            Else
                                dtDOD = dsPatient.Tables(0).Rows.Item(0)("PAT_DOD")
                                blnPAT_DOD = True
                            End If

                        Else 'Approximate Age, where DOB is not Known
                            'DOB

                            'Age
                            If Not IsDBNull(dsPatient.Tables(0).Rows.Item(0)("PAT_DOB")) Then
                                m_strDOB = Format(dsPatient.Tables(0).Rows.Item(0)("PAT_DOB"), strDateFormat)
                                objSessionData.Pat_DateOfBirth = dsPatient.Tables(0).Rows.Item(0)("PAT_DOB")
                                Session("DOB") = objSessionData.Pat_DateOfBirth
                            End If

                            If IsDBNull(dsPatient.Tables(0).Rows.Item(0)("PAT_DOD")) Then
                                dtDOD = DateTime.MinValue
                                blnPAT_DOD = False
                            Else
                                dtDOD = dsPatient.Tables(0).Rows.Item(0)("PAT_DOD")
                                blnPAT_DOD = True
                            End If

                            If Not IsDBNull(dsPatient.Tables(0).Rows.Item(0)("IsDeceased")) Then
                                If CBool(dsPatient.Tables(0).Rows.Item(0)("IsDeceased")) = True Then
                                    m_blnDeadPatient = True
                                End If
                            End If
                        End If

                    End If
                    If Not IsDBNull(dsPatient.Tables(0).Rows.Item(0)("IsDeceased")) Then
                        If CBool(dsPatient.Tables(0).Rows.Item(0)("IsDeceased")) = True Then

                            m_blnDeadPatient = True
                            If IsDBNull(dsPatient.Tables(0).Rows.Item(0)("PAT_DOD")) Then
                                m_strDOD ="DoD Not Recorded"'Format(dsPatient.Tables(0).Rows.Item(0)("DeceasedRecordDate"), strDateFormat)
                            Else
                                m_strDOD = Format(dsPatient.Tables(0).Rows.Item(0)("PAT_DOD"), strDateFormat)
                            End If

                        End If

                    End If


                    'Added to know the
                    If Not IsDBNull(dsPatient.Tables(0).Rows.Item(0)("IsActive")) Then
                        If dsPatient.Tables(0).Rows.Item(0)("IsActive") = "1" Then
                            isActivePatient = 1
                        Else
                            isActivePatient = 0
                        End If
                    Else
                        isActivePatient = -1
                    End If
                    strSecondaryIdentifierValue = dsPatient.Tables(0).Rows.Item(0)("sec")
                    strPreferredIdentifierValue = dsPatient.Tables(0).Rows.Item(0)("prime")
                    strPrimayIdentifierValue = dsPatient.Tables(0).Rows.Item(0)("prime")
                    If Not Session("USR_IDENTIFIER") Is Nothing And Session("USR_IDENTIFIER") <> "" Then
                        If CType(Session("USR_IDENTIFIER"), Long) <> -1 Then
                            If Session("USR_IDENTIFIER_LU") = "" Then
                                Session("USR_IDENTIFIER_LU") = "-1"
                            End If
                            '''strUsrIdenvalue = objClsBizlPatient.GetPatientIdentifierValue(lngPatId, Session("USR_IDENTIFIER_LU"), CType(Session("USR_IDENTIFIER"), Long), lngUserId)
                            '''strPreferredIdentifierValue = strUsrIdenvalue(0)
                            '''Session("USR_PREFIDENCAPTION") = strUsrIdenvalue(1)
                            If dsPatient.Tables("OtherInfo").Rows(0).Item("PriIdentValue") = "0" Then
                                strPreferredIdentifierValue = ""
                            Else
                                strPreferredIdentifierValue = dsPatient.Tables("OtherInfo").Rows(0).Item("PriIdentValue")
                            End If
                            Session("USR_PREFIDENCAPTION") = dsPatient.Tables("OtherInfo").Rows(0).Item("PriIdent")
                        End If
                    End If

                    'change the caption for pi and si if any changes
                    If Session("MAINDISPLAYIDENTIFIERID") & "" = Session("SECONDARYIDENTIFIERID") Then
                        'PI 
                        If Not Session("SECONDARYIDENTIFIERCAPTION") Is Nothing AndAlso Session("SECONDARYIDENTIFIERCAPTION").Length > 0 Then

                            strPriIdentName = Session("SECONDARYIDENTIFIERCAPTION").Trim & ": "
                        End If
                        'SI
                        If Not Session("PRIMAYIDENTIFIERCAPTION") Is Nothing AndAlso Session("PRIMAYIDENTIFIERCAPTION").Length > 0 Then

                            strSecIdentName = Session("PRIMAYIDENTIFIERCAPTION").Trim & ": "
                        End If
                    Else
                        'PI

                        If Not Session("PRIMAYIDENTIFIERCAPTION") Is Nothing AndAlso Session("PRIMAYIDENTIFIERCAPTION").Length > 0 Then
                            strPriIdentName = Session("PRIMAYIDENTIFIERCAPTION").Trim & ": "
                        End If
                        'SI
                        If Not Session("SECONDARYIDENTIFIERCAPTION") Is Nothing AndAlso Session("SECONDARYIDENTIFIERCAPTION").Length > 0 Then

                            strSecIdentName = Session("SECONDARYIDENTIFIERCAPTION").Trim & ": "
                        Else

                            strSecIdentName = ""
                        End If
                    End If




                    If IsDBNull(dsPatient.Tables(0).Rows(0).Item("PAT_DOB")) Then
                        m_strAge = ""
                    Else
                        If dsPatient.Tables(0).Rows(0).Item("PAT_DOB").ToString() <> "" Then
                            m_strAge = CalcAge(dsPatient.Tables(0).Rows(0).Item("PAT_DOB"), dtDOD)
                        End If
                    End If
                    If Not m_strAge Is Nothing Then
                        If m_strAge <> "" Then

                            If dtDOB <> DateTime.MinValue Then
                                If dtDOD <> DateTime.MinValue Then
                                    intAgeMonthCount = GetMonthCount(dtDOB, dtDOD)  ''DateDiff(DateInterval.Month, dtDOB, dtDOD)
                                Else
                                    intAgeMonthCount = GetMonthCount(dtDOB, DateTime.Now)  ''DateDiff(DateInterval.Month, dtDOB, DateTime.Now)
                                End If
                            End If
                            If CInt(m_strAge) = 0 Then

                                If intAgeMonthCount = 0 Or intAgeMonthCount = 1 Then
                                    m_strAge = intAgeMonthCount & " mth" & strApproxDODFlag
                                ElseIf intAgeMonthCount > 1 Then
                                    m_strAge = intAgeMonthCount & " mths" & strApproxDODFlag
                                End If

                            ElseIf CInt(m_strAge) > 0 Then
                                If CInt(m_strAge) = 1 Then
                                    m_strAge = m_strAge & " yr" & strApproxDODFlag
                                ElseIf CInt(m_strAge) > 1 Then


                                    If IsNothing(Session("SignOn")) = False AndAlso Session("SignOn") = "1" Then
                                        m_strAge = m_strAge & "y" & strApproxDODFlag

                                    End If

                                End If
                            End If
                        End If
                    End If
                    ''Code Added by Vijaykumar on 01/12/2008 to show address details as tooltip...Begin
                    ''If (dsPatient.Tables("PatAddressDetails").Rows.Count > 0) Then
                    Dim strPatAddress As String = ""
                    ''    strPatAddress = "Address: " & strEmptyString & vbCrLf
                    ''    With dsPatient.Tables("PatAddressDetails").Rows(0)
                    ''        If Not IsDBNull(.Item("PatAddr1")) AndAlso .Item("PatAddr1") <> "" Then
                    ''            strPatAddress &= .Item("PatAddr1") & vbCrLf
                    ''        End If
                    ''        If Not IsDBNull(.Item("PatAddr2")) AndAlso .Item("PatAddr2") <> "" Then
                    ''            strPatAddress &= .Item("PatAddr2") & vbCrLf
                    ''        End If
                    ''        If Not IsDBNull(.Item("Pat_addr3")) AndAlso .Item("Pat_addr3") <> "" Then
                    ''            strPatAddress &= .Item("Pat_addr3") & vbCrLf
                    ''        End If
                    ''        If Not IsDBNull(.Item("PatCity")) AndAlso .Item("PatCity") <> "" Then
                    ''            strPatAddress &= .Item("PatCity") & vbCrLf
                    ''        End If
                    ''        If Not IsDBNull(.Item("PatCounty")) AndAlso .Item("PatCounty") <> "" Then
                    ''            strPatAddress &= .Item("PatCounty") & vbCrLf
                    ''        End If
                    ''        If Not IsDBNull(.Item("PatCountry")) AndAlso .Item("PatCountry") <> "" Then
                    ''            strPatAddress &= .Item("PatCountry") & vbCrLf
                    ''        End If
                    ''        strPatAddress &= vbCrLf
                    ''        strPatAddress &= "Phone: " & strEmptyString & vbCrLf
                    ''        If Not IsDBNull(.Item("HomePhone")) AndAlso .Item("HomePhone") <> "" Then
                    ''            strPatAddress &= .Item("HomePhone") & vbCrLf
                    ''        End If
                    ''        If Not IsDBNull(.Item("WorkPhone")) AndAlso .Item("WorkPhone") <> "" Then
                    ''            strPatAddress &= .Item("WorkPhone") & vbCrLf
                    ''        End If
                    ''        If Not IsDBNull(.Item("Mobile")) AndAlso .Item("Mobile") <> "" Then
                    ''            strPatAddress &= .Item("Mobile") & vbCrLf
                    ''        End If
                    ''        If Not IsDBNull(.Item("Fax")) AndAlso .Item("Fax") <> "" Then
                    ''            strPatAddress &= .Item("Fax") & vbCrLf
                    ''        End If
                    ''        If Not IsDBNull(.Item("Other")) AndAlso .Item("Other") <> "" Then
                    ''            strPatAddress &= .Item("Other") & vbCrLf
                    ''        End If
                    ''        strPatAddress &= vbCrLf
                    ''        strPatAddress &= "Catchment: " & strEmptyString & vbCrLf
                    ''        If Not IsDBNull(.Item("pat_optional1")) AndAlso .Item("pat_optional1") <> "" Then
                    ''            strPatAddress &= .Item("pat_optional1")
                    ''        End If
                    ''    End With
                    hdnPatAddress.Value = strPatAddress
                    'If IsNothing(dsPatient.Tables("PatAddressDetails").Rows(0).Item("ZIP")) = False AndAlso dsPatient.Tables("PatAddressDetails").Rows(0).Item("ZIP").length = 6 Then
                    '    dsPatient.Tables("PatAddressDetails").Rows(0).Item("ZIP") = dsPatient.Tables("PatAddressDetails").Rows(0).Item("ZIP").ToString.Substring(0, 3) & " " & dsPatient.Tables("PatAddressDetails").Rows(0).Item("ZIP").ToString.Substring(3, 3)
                    'End If

                    '    Dim tempBanner As IEnumerable(Of String)
                    '    Try
                    '        'tempBanner = From ele As String In New String() {"PatAddr1", "PatAddr2", "Pat_addr3", "PatCity", "PatCounty", "PatCountry", "ZIP"} _
                    '        '             Where Not IsDBNull(dsPatient.Tables("PatAddressDetails").Rows(0).Item(ele)) AndAlso Not String.IsNullOrEmpty(dsPatient.Tables("PatAddressDetails").Rows(0).Item(ele)) _
                    '        '             Select Convert.ToString(dsPatient.Tables("PatAddressDetails").Rows(0).Item(ele))
                    '        'hdnBannerAddress.Value = HttpUtility.HtmlEncode(String.Join("<br/>", tempBanner.ToArray()))
                    '        Dim strPhoneFormat As String = ""
                    '        Dim objSysDefault As clsSysDefault
                    '        objSysDefault = New clsSysDefault

                    '        strPhoneFormat = objSysDefault.GetSysDefaultValue(2115)
                    '        'tempBanner = From ele As String In New String() {"HomePhone", "WorkPhone", "Mobile", "Fax", "Other", "Email"} _
                    '        '             Where Not IsDBNull(dsPatient.Tables("PatAddressDetails").Rows(0).Item(ele)) AndAlso Not String.IsNullOrEmpty(dsPatient.Tables("PatAddressDetails").Rows(0).Item(ele)) _
                    '        '             Select status = If(((dsPatient.Tables("PatAddressDetails").Rows(0).Item(ele).ToString.IndexOf("(") = -1 AndAlso Len(dsPatient.Tables("PatAddressDetails").Rows(0).Item(ele).ToString) = 10) _
                    '        '                                 Or dsPatient.Tables("PatAddressDetails").Rows(0).Item(ele).ToString.IndexOf("(") = 10) AndAlso IsNumeric(dsPatient.Tables("PatAddressDetails").Rows(0).Item(ele).ToString.Substring(0, 10)) = True, If(ele = "HomePhone", CLng(dsPatient.Tables("PatAddressDetails").Rows(0).Item(ele)).ToString(strPhoneFormat), CLng(dsPatient.Tables("PatAddressDetails").Rows(0).Item(ele).ToString.Substring(0, dsPatient.Tables("PatAddressDetails").Rows(0).Item(ele).ToString.IndexOf("("))).ToString(strPhoneFormat) & " " & dsPatient.Tables("PatAddressDetails").Rows(0).Item(ele).ToString.Substring(dsPatient.Tables("PatAddressDetails").Rows(0).Item(ele).ToString.IndexOf("("))), dsPatient.Tables("PatAddressDetails").Rows(0).Item(ele).ToString)
                    '        ''Select strTemp = IIf(dsPatient.Tables("PatAddressDetails").Rows(0).Item(ele).ToString.Length = 10, CInt(dsPatient.Tables("PatAddressDetails").Rows(0).Item(ele)).ToString("(000) 000-0000"), dsPatient.Tables("PatAddressDetails").Rows(0).Item(ele))


                    '        'hdnBannerMobile.Value = HttpUtility.HtmlEncode(String.Join("<br/>", tempBanner.ToArray()))
                    '    Catch ex As Exception
                    '    Finally
                    '        tempBanner = Nothing
                    '    End Try
                    'End If
                    '   m_strClinicianInfo = fnGetRecentlypatientViewdByClinicianDetails()
                    '  m_strConnectedSystemInfo = fnGetConnectedSystemInfo()
                Else
                    'Code Added by Vijaykumar on 01/12/2008 to show address details as tooltip...End                Else

                    hdnPatientSelected.Value = ""
                    isActivePatient = -1
                End If
                Dim dsIdentifier As DataSet
                dsIdentifier = objClsBizlPatient.GetUserIdentifierDetails(lngUserId, lngPatId)
                strPriIdentName = dsPatient.Tables("OtherInfo").Rows.Item(0)("PriIdent")
                strPriIdentValue = dsPatient.Tables("OtherInfo").Rows(0).Item("PriIdentValue")
                strSecIdentName = dsPatient.Tables("OtherInfo").Rows(0).Item("SecIdent")
                strSecIdentValue = dsPatient.Tables("OtherInfo").Rows(0).Item("SecIdentValue")
                intVersionNumber = dsPatient.Tables("OtherInfo").Rows(0).Item("TracingStatus") '1
                If strPriIdentName = "NHS" AndAlso Len(strPriIdentValue) = 10 Then
                    strPriIdentValue = strPriIdentValue.Substring(0, 3) & "-" & strPriIdentValue.Substring(3, 3) & "-" & strPriIdentValue.Substring(6)
                ElseIf strSecIdentName = "NHS" AndAlso Len(strSecIdentValue) = 10 Then
                    strSecIdentValue = strSecIdentValue.Substring(0, 3) & "-" & strSecIdentValue.Substring(3, 3) & "-" & strSecIdentValue.Substring(6)
                End If

                Dim sbPatJSON As New StringBuilder
                If lngPatId > 0 Then
                    If dsPatient.Tables.Contains("GenderIdentity") Then
                        strGenderIdentity = Newtonsoft.Json.JsonConvert.SerializeObject(dsPatient.Tables("GenderIdentity"))
                    End If


                    If objSessionData.EntityType <> 2936 Then
                        'sbPatJSON.AppendFormat(Chr(183) & "name" & Chr(183) & Chr(181) & Chr(183) & "surname" & Chr(183) & ":" & Chr(183) & "{2}" & Chr(183) & "," & Chr(183) & "forename" & Chr(183) & ":" & Chr(183) & "{0}" & Chr(183) & "," & Chr(183) & "middlename" & Chr(183) & ":" & Chr(183) & "{1}" & Chr(183) & "," & Chr(183) & "title" & Chr(183) & ":" & Chr(183) & "{11}" & Chr(183) & Chr(182) & Chr(183) & "dob" & Chr(183) & ":" & Chr(183) & "{4}" & Chr(183) & "," & Chr(183) & "dod" & Chr(183) & ":" & Chr(183) & "{10}" & Chr(183) & "," & Chr(183) & "sex" & Chr(183) & ":" & Chr(183) & "{12}" & Chr(183) & "," & Chr(183) & "identifier" & Chr(183) & Chr(181) & Chr(183) & "caption" & Chr(183) & Chr(181) & Chr(183) & "primary" & Chr(183) & ":" & Chr(183) & strPriIdentName & Chr(183) & "," & Chr(183) & "secondary" & Chr(183) & ":" & Chr(183) & strSecIdentName & Chr(183) & Chr(182) & Chr(183) & "value" & Chr(183) & Chr(181) & Chr(183) & "primary" & Chr(183) & ":" & Chr(183) & strPriIdentValue & Chr(183) & "," & Chr(183) & "secondary" & Chr(183) & ":" & Chr(183) & strSecIdentValue & Chr(183) & "}}", dsPatient.Tables(0).Rows(0).ItemArray)
                        sbPatJSON.AppendFormat(Chr(183) & "name" & Chr(183) & Chr(181) & Chr(183) & "surname" & Chr(183) & ":" & Chr(183) & "{2}" & Chr(183) & "," & Chr(183) & "forename" & Chr(183) & ":" & Chr(183) & "{0}" & Chr(183) & "," & Chr(183) & "middlename" & Chr(183) & ":" & Chr(183) & "{1}" & Chr(183) & "," & Chr(183) & "knownas" & Chr(183) & ":" & Chr(183) & "{24}" & Chr(183) & "," & Chr(183) & "title" & Chr(183) & ":" & Chr(183) & "{11}" & Chr(183) & Chr(182) & Chr(183) & "MCPUserId" & Chr(183) & ":" & Chr(183) & dsPatient.Tables(0).Rows(0)("MCP_USRID") & Chr(183) & "," & Chr(183) & "isMCPUser" & Chr(183) & ":" & Chr(183) & dsPatient.Tables(0).Rows(0)("isMCPUser") & Chr(183) & "," & Chr(183) & "dob" & Chr(183) & ":" & Chr(183) & "{4}" & Chr(183) & "," & Chr(183) & "dod" & Chr(183) & ":" & Chr(183) & "{10}" & Chr(183) & "," & Chr(183) & "sex" & Chr(183) & ":" & Chr(183) & "{12}" & Chr(183) & "," & Chr(183) & "sexcode" & Chr(183) & ":" & Chr(183) & "{25}" & Chr(183) & "," & Chr(183) & "identifier" & Chr(183) & Chr(181) & Chr(183) & "caption" & Chr(183) & Chr(181) & Chr(183) & "primary" & Chr(183) & ":" & Chr(183) & strPriIdentName & Chr(183) & "," & Chr(183) & "secondary" & Chr(183) & ":" & Chr(183) & strSecIdentName & Chr(183) & Chr(182) & Chr(183) & "value" & Chr(183) & Chr(181) & Chr(183) & "primary" & Chr(183) & ":" & Chr(183) & strPriIdentValue & Chr(183) & "," & Chr(183) & "secondary" & Chr(183) & ":" & Chr(183) & strSecIdentValue & Chr(183) & "}}", dsPatient.Tables(0).Rows(0).ItemArray)
                        strPatJSON = strPatJSON.Replace(Chr(180), sbPatJSON.ToString().Replace(Chr(182), "},").Replace(Chr(181), ":{"))
                        strPatJSON = strPatJSON.Replace("""", "''").Replace(Chr(183), """")
                        Session("EntityType") = objSessionData.EntityType
                    Else
                        hdnEntityType.Value = objSessionData.EntityType
                        sbPatJSON.AppendFormat(Chr(183) & "FacName" & Chr(183) & ":" & Chr(183) & "{19}" & Chr(183) & "," & Chr(183) & "Facident" & Chr(183) & ":" & Chr(183) & "{18}" & Chr(183) & "," & Chr(183) & "Phone" & Chr(183) & ":" & Chr(183) & "{20} " & Chr(183) & "," & Chr(183) & "Address" & Chr(183) & ":" & Chr(183) & "{21} " & Chr(183) & "}}", dsPatient.Tables(0).Rows(0).ItemArray)
                        strPatJSON = strPatJSON.Replace(Chr(180), sbPatJSON.ToString().Replace("""", "''").Replace(Chr(183), """").Replace("}}}}", "}"))
                        strPatJSON = strPatJSON.Replace("}}}", "}")
                    End If

                    objSessionData.Pat_Title = If(IsDBNull(dsPatient.Tables(0).Rows(0).Item(11)), "", dsPatient.Tables(0).Rows(0).Item(11))
                    objSessionData.Pat_MiddleName = If(IsDBNull(dsPatient.Tables(0).Rows(0).Item("PAT_Forename2")), "", dsPatient.Tables(0).Rows(0).Item("PAT_Forename2"))
                    objSessionData.Pat_PrimaryIdentifierCaption = strPriIdentName
                    objSessionData.Pat_PrimaryIdentifierValue = strPriIdentValue
                    objSessionData.Pat_SecondaryIdentifierCaption = strSecIdentName
                    objSessionData.Pat_SecondaryIdentifierValue = strSecIdentValue
                    objSessionData.Pat_DOBINMSCUI = Format(dsPatient.Tables(0).Rows.Item(0)("PAT_DOB"), strDateFormat) & " (" & m_strAge & ")"
                    If objSessionData.Pat_Title <> "" Then
                        objSessionData.Pat_FullName = objSessionData.Pat_SurName.ToUpper & ", " & If(objSessionData.Pat_ForeName.Length > 0, objSessionData.Pat_ForeName.Substring(0, 1).ToUpper, "") & If(objSessionData.Pat_ForeName.Length > 1, objSessionData.Pat_ForeName.Substring(1).ToLower, "") & " " & If(objSessionData.Pat_MiddleName.Length > 0, objSessionData.Pat_MiddleName.Substring(0, 1).ToUpper, "") & If(objSessionData.Pat_MiddleName.Length > 1, objSessionData.Pat_MiddleName.Substring(1).ToLower, "") & " (" & objSessionData.Pat_Title & ")"
                    Else
                        objSessionData.Pat_FullName = objSessionData.Pat_SurName.ToUpper & ", " & If(objSessionData.Pat_ForeName.Length > 0, objSessionData.Pat_ForeName.Substring(0, 1).ToUpper, "") & If(objSessionData.Pat_ForeName.Length > 1, objSessionData.Pat_ForeName.Substring(1).ToLower, "") & " " & If(objSessionData.Pat_MiddleName.Length > 0, objSessionData.Pat_MiddleName.Substring(0, 1).ToUpper, "") & If(objSessionData.Pat_MiddleName.Length > 1, objSessionData.Pat_MiddleName.Substring(1).ToLower, "")
                    End If
                Else
                    If objSessionData.EntityType <> 2936 Then
                        sbPatJSON.AppendFormat("""name"":~""surname"":"""",""forename"":"""",""middlename"":"""",""title"":""""~,""dob"":"""",""dod"":"""",""sex"":"""",""identifier"":~""caption"":~""primary"":""" & strPriIdentName & """,""secondary"":""" & strSecIdentName & """~,""value"":~""primary"":""" & strPriIdentValue & """,""secondary"":""" & strSecIdentValue & """}}", "")
                        strPatJSON = strPatJSON.Replace(Chr(180), sbPatJSON.ToString().Replace("~,", "},").Replace(":~", ":{"))
                    Else
                        hdnEntityType.Value = objSessionData.EntityType
                        sbPatJSON.AppendFormat(Chr(183) & "FacName" & Chr(183) & ":" & Chr(183) & """" & Chr(183) & "," & Chr(183) & "Facident" & Chr(183) & ":" & Chr(183) & """" & Chr(183) & "," & Chr(183) & "Phone" & Chr(183) & ":" & Chr(183) & """" & Chr(183) & "," & Chr(183) & "Address" & Chr(183) & ":" & Chr(183) & """" & Chr(183) & "}}", "")
                        strPatJSON = strPatJSON.Replace(Chr(180), sbPatJSON.ToString().Replace("""", "''").Replace(Chr(183), """").Replace("}}}}", "}"))
                        strPatJSON = strPatJSON.Replace("}}}", "}")
                    End If
                End If
                Session("Pat_SecondaryIdentifierValue") = strSecondaryIdentifierValue
                LogwebsessionAction("Patient bar", lngPatId, 2042, "Checking hdnChangePatID :" & hdnChangePatID.Value & " in Page Load-END", 1031)
                WriteToTrace("Page_Load", "frmPatientBar.aspx.vb", "Page Load Ended at-" + System.DateTime.Now.ToString)
            Catch ex As Exception
                LogException(ex)
            Finally
                objClsBizlPatient = Nothing
                objclsSecurity = Nothing
                objQueryParams = Nothing
                'dsPatient = Nothing
                If Not dsPatient Is Nothing Then
                    dsPatient.Dispose()
                End If
                '''objClsAppSettings = Nothing
                objClsPatient = Nothing
                '''objBizUser = Nothing
                objSessionData = Nothing
                objClsSessionmanager = Nothing
                strEventDesc = Nothing
            End Try
        End Sub


        'Public Function fnGetRecentlypatientViewdByClinicianDetails()
        '    Dim strRetHtml As String = String.Empty
        '    Dim objCCDManagerProxy As Excelicare.ServiceProxy.RSPatientSummary.AxRSPatientSummaryClient
        '    Try
        '        objCCDManagerProxy = New Excelicare.ServiceProxy.RSPatientSummary.AxRSPatientSummaryClient
        '        strRetHtml = objCCDManagerProxy.fetchHTML(lngUserId, lngPatId, "", 115, "", "", "", False, "AxCCDTemplate.xsl")
        '        objCCDManagerProxy.Close()
        '        strRetHtml = strRetHtml.Substring(strRetHtml.IndexOf("</style>") + 8)
        '        Return strRetHtml

        '        ' Return HttpUtility.HtmlEncode(strRetHtml)
        '    Catch ex As Exception
        '    Finally
        '        If objCCDManagerProxy.State <> ServiceModel.CommunicationState.Closed Then
        '            objCCDManagerProxy.Abort()
        '        End If
        '    End Try
        'End Function

        'Public Function fnGetConnectedSystemInfo()
        '    Dim strRetHtml As String = String.Empty
        '    Dim objCCDManagerProxy As Excelicare.ServiceProxy.RSPatientSummary.AxRSPatientSummaryClient
        '    Try
        '        objCCDManagerProxy = New Excelicare.ServiceProxy.RSPatientSummary.AxRSPatientSummaryClient
        '        strRetHtml = objCCDManagerProxy.fetchHTML(lngUserId, lngPatId, "", 116, "", "", "", False, "AxCCDTemplate.xsl")
        '        objCCDManagerProxy.Close()
        '        strRetHtml = strRetHtml.Substring(strRetHtml.IndexOf("</style>") + 8)
        '        Return strRetHtml
        '    Catch ex As Exception
        '    Finally
        '        If objCCDManagerProxy.State <> ServiceModel.CommunicationState.Closed Then
        '            objCCDManagerProxy.Abort()
        '        End If
        '    End Try
        'End Function


        Private Function CalcAge(ByVal strDOB As String, ByVal strDoD As String) As String
            Try
                Dim dtDod As Date
                Dim dtDob As Date
                '' Dim strDob As String
                Dim strAge As String = ""
                If strDoD <> "" Then
                    dtDod = System.Convert.ToDateTime(strDoD)
                Else
                    dtDod = System.DateTime.Now.Date
                End If
                dtDob = System.Convert.ToDateTime(strDOB)

                strAge = dtDod.Year - dtDob.Year
                If Year(dtDob) > Year(dtDod) Then
                    strAge = ""

                ElseIf (Year(dtDob) = Year(dtDod) And (Month(dtDob) = Month(dtDod)) And Day(dtDob) > Day(dtDod)) Or (Year(dtDob) = Year(dtDod) And (Month(dtDob) > Month(dtDod))) Then
                    strAge = vbNullString

                ElseIf Year(dtDob) < Year(dtDod) Then
                    If (Month(dtDob) > Month(dtDod)) Or (Month(dtDob) = Month(dtDod) And Day(dtDob) > Day(dtDod)) Then
                        strAge = strAge - 1
                    End If
                End If
                Return strAge

            Catch ex As Exception
                Throw
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        ' This used to calculate patient Age in months when Age is  less than a year
        ' </summary>
        '<param Name="dtdob">Date of Birth</param>
        '<param Name="dtdod">Date of Death</param>
        ' <remarks>
        ' </remarks>
        ' <history>
        ' 	[Suneetha B]	02/02/2006	Created
        ' </history>
        ' -----------------------------------------------------------------------------

        Private Function GetMonthCount(ByVal dtdob As Date, ByVal dtDOD As Date) As Integer
            Dim intMonthCount As Integer = 0
            'Dim tDate As Date
            Try
                intMonthCount = DateDiff(DateInterval.Month, dtdob, dtDOD)
                intMonthCount = intMonthCount Mod 12
                If dtdob.Day > dtDOD.Day Then
                    intMonthCount = intMonthCount - 1
                End If
            Catch ex As Exception
                LogException(ex)
            Finally
            End Try
            GetMonthCount = intMonthCount
        End Function
        Private Sub GetSessionData()
            Dim objClsSessionData As clsSessionData
            Dim objClsSessionManager As clsSessionManager
            Try
                '  objClsSessionData = CType(Session("APPDATA"), clsSessionData)
                objClsSessionManager = New clsSessionManager
                If Not objClsSessionManager.IsSessionExists(Session.SessionID) Then
                    Response.Redirect(clsNavigation.GetURL(1031, "Page_Load"), False)
                End If
                objClsSessionData = objClsSessionManager.GetSessionData(Session.SessionID, "APPDATA")
                If Not objClsSessionData Is Nothing Then
                    lngUserId = objClsSessionData.UserID
                    intUsrSecLevel = objClsSessionData.UserSecurityLevel

                    If objClsSessionData.PatientID > 0 Then
                        lngPatId = objClsSessionData.PatientID
                    End If
                    If objClsSessionData.TypeOfUser = 2 Then
                        lngPatId = objClsSessionData.CLN_ID
                        hdnChangePatID.Value = objClsSessionData.PatientID
                        hdnCurrentPatID.Value = objClsSessionData.PatientID
                    End If
                    'LogwebsessionAction("Patient bar", lngPatId, 2042, "objClsSessionData.TypeOfUser :" & objClsSessionData.TypeOfUser & " ;patient id:" & objClsSessionData.CLN_ID, 1031)
                End If
            Finally
                objClsSessionData = Nothing
                objClsSessionManager = Nothing
            End Try
        End Sub

        ' -----------------------------------------------------------------------------
        ' <summary>
        '       To get the Startupform , Startup form url for the supplied Use ID
        ' </summary>
        ' <param name="intUserID"> User Id </param>
        ' <returns>Boolean</returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Vanisri]    28/11/2006  Created
        ' </history>
        ' -----------------------------------------------------------------------------

        '''Private Sub UpdateStartUpFormDetails()
        '''    Dim objBizUser As New AxSys.Bizl.MDI.clsBizlUser
        '''    Dim objSysModuleDan As New AxSys.Bizl.MDI.clsBizlSysModule
        '''    Dim objClsSessionData As clsSessionData
        '''    Try
        '''        objClsSessionData = Session("APPDATA")
        '''        If Not objClsSessionData Is Nothing Then
        '''            hdnUserStartupForm.Value = objBizUser.GetPatientRecordStartUpForm(objClsSessionData.UserID)
        '''            hdnUserStartupForm.Value = hdnUserStartupForm.Value.Trim
        '''        End If

        '''        If hdnUserStartupForm.Value <> "" Then
        '''            If hdnUserStartupForm.Value.IndexOf(Chr(17)) <> -1 Then
        '''                intStartUpModuleId = hdnUserStartupForm.Value.Split(Chr(17))(0)
        '''            Else
        '''                intStartUpModuleId = hdnUserStartupForm.Value
        '''            End If
        '''        End If

        '''        If IsNumeric(intStartUpModuleId) Then
        '''            If intStartUpModuleId > 0 Then
        '''                hdnIsStartupFormAccessible.Value = objSysModuleDan.IsFormAccessible(intStartUpModuleId, Application("ApplicationInstallType"), Session("USR_SECURITY_LEVEL"))
        '''                If hdnIsStartupFormAccessible.Value.Trim.ToUpper = "true".ToUpper Then
        '''                    hdnStartUpUrl.Value = objBizUser.GetPatientRecordStartUpFormUrl(intStartUpModuleId).Trim
        '''                    If intStartUpModuleId.ToString.Trim = "129" Then
        '''                        If hdnStartUpUrl.Value.IndexOf("?") = -1 Then
        '''                            hdnStartUpUrl.Value = hdnStartUpUrl.Value & "?ShowStartupForm=True"
        '''                        Else
        '''                            hdnStartUpUrl.Value = hdnStartUpUrl.Value & "&ShowStartupForm=True"
        '''                        End If
        '''                    End If
        '''                End If
        '''            Else    'Added by Mallika   on 25/05/2007
        '''                hdnStartUpUrl.Value = ""
        '''            End If
        '''        End If

        '''    Catch ex As Exception
        '''        LogException(ex)
        '''    Finally
        '''        objBizUser = Nothing
        '''        objSysModuleDan = Nothing
        '''    End Try
        '''End Sub
        Private Sub UpdateStartUpFormDetails(ByVal dRow As DataRow)
            Try
                If Not dRow Is Nothing Then
                    intStartUpModuleId = IIf(IsDBNull(dRow.Item("StartUpMID")), 0, dRow.Item("StartUpMID"))
                    hdnUserStartupForm.Value = intStartUpModuleId
                    If IsNumeric(intStartUpModuleId) Then
                        If intStartUpModuleId > 0 Then
                            'hdnIsStartupFormAccessible.Value = objSysModuleDan.IsFormAccessible(intStartUpModuleId, Application("ApplicationInstallType"), Session("USR_SECURITY_LEVEL"))
                            hdnIsStartupFormAccessible.Value = dRow.Item("StartUpAccess")
                            If dRow.Item("StartUpAccess") = True Then
                                hdnStartUpUrl.Value = IIf(IsDBNull(dRow.Item("StartUPURL")), 0, dRow.Item("StartUPURL"))
                                If intStartUpModuleId.ToString.Trim = "129" Then
                                    If hdnStartUpUrl.Value.IndexOf("?") = -1 Then
                                        hdnStartUpUrl.Value = hdnStartUpUrl.Value & "?ShowStartupForm=True"
                                    Else
                                        hdnStartUpUrl.Value = hdnStartUpUrl.Value & "&ShowStartupForm=True"
                                    End If
                                End If
                            End If
                        Else
                            hdnStartUpUrl.Value = ""
                        End If
                    End If
                End If
            Catch ex As Exception
                LogException(ex)
            Finally
            End Try
        End Sub



        ' -----------------------------------------------------------------------------
        ' <summary>
        '       To Change the Notice Board Icon whenever the some fields available in Noticeboard.
        ' </summary>
        ' <param name="lngPat_ID"> Patient ID </param>
        ' <returns>Integer</returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Pavithraraj]    28/11/2008  Created
        ' </history>
        ' -----------------------------------------------------------------------------
        <Ajax.AjaxMethod()> _
        Public Function UpdateNoticeBoardIcon(ByVal lngPat_ID As Long) As Integer
            Dim objClsBizlPatient As clsBizlPatient
            Try
                objClsBizlPatient = New clsBizlPatient
                If objClsBizlPatient.IsNoticeBoardDataExists(lngPat_ID) Then
                    Return "1"
                Else
                    Return "0"
                End If
            Catch ex As Exception
                LogException(ex)
            Finally
                objClsBizlPatient = Nothing
            End Try
        End Function
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)> _
        Public Function WriteToTrace(ByVal strProcName As String, ByVal strPageName As String, ByVal strMessage As String)
            Dim strTraceFile As String
            Dim strCanWrite As String
            Dim objTraceFile As System.IO.StreamWriter
            Dim strMessageFooter As String
            Try
                strCanWrite = System.Configuration.ConfigurationSettings.AppSettings.Get("IsTraceWriteToFile")

                If Not strMessage Is Nothing Then
                    If strCanWrite.ToUpper = "TRUE" And strMessage <> "" Then
                        strTraceFile = HttpContext.Current.Request.PhysicalApplicationPath & System.Configuration.ConfigurationSettings.AppSettings.Get("TraceFileName")
                        objTraceFile = New System.IO.StreamWriter(strTraceFile, True)

                        strMessageFooter = vbCrLf
                        objTraceFile.Write("Form Name:" & strPageName & " | Method Name: " & strProcName & " | " & strMessage)
                        objTraceFile.Write(strMessageFooter)
                    End If
                End If
            Catch ex As Exception
            Finally
                If Not objTraceFile Is Nothing Then
                    objTraceFile.Flush()
                    objTraceFile.Close()
                End If
                strTraceFile = Nothing
                strCanWrite = Nothing
                strMessageFooter = Nothing
            End Try
        End Function
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Sub fnLogwebsessionAction(ByVal strData As String)
            Dim jsonResult As Object
            Dim strModuleName As String
            Dim intPatientID As Integer
            Dim intActionID As Integer
            Dim strDecription As String
            Dim intModuleID As Integer
            Try
                jsonResult = SiteExcelicare.DecryptJsonData(strData)
                strModuleName = jsonResult("strModuleName")
                intPatientID = jsonResult("intPatientID")
                intActionID = jsonResult("intActionID")
                strDecription = jsonResult("strDecription")
                intModuleID = jsonResult("intModuleID")

                LogwebsessionAction(strModuleName, intPatientID, intActionID, strDecription, intModuleID)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.Read)>
        Public Sub LogwebsessionAction(ByVal strModuleName As String, ByVal intPatientID As Integer, ByVal intActionID As Integer, ByVal strDecription As String, ByVal intModuleID As Integer)
            Try
                clsECSession.LogWebSessionAction(strModuleName, Session.SessionID, intPatientID, intActionID, strDecription, intModuleID)
            Catch ex As Exception
                LogException(ex)
            End Try
        End Sub
        <Ajax.AjaxMethod()> _
        Public Function IsModuleAvailableInProduct(ByVal lngModId As Integer) As Boolean
            Dim objClsSecurity As clsSecurity
            Try
                objClsSecurity = New clsSecurity
                Return objClsSecurity.IsModuleAvailableInProduct(lngModId)
            Catch ex As Exception
                LogException(ex)
            Finally
                objClsSecurity = Nothing
            End Try
        End Function

        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.Read)>
        Public Function GetPatientZone1AlertIconInfo(ByVal strData As String) As String
            Dim objClsBizlPatient As clsBizlPatient
            Dim dsAlertInfo As DataSet
            Dim pat_id As Integer
            Dim usr_id As Long
            Dim intusrSec As Integer
            Dim strAppType As String
            Dim intIsACLPatient As Integer
            Dim jsonResult As Object
            Dim objSessionMgr As clsSessionManager
            Dim objClsSessionData As clsSessionData
            Dim objclsSecurity As clsSecurity
            Try
                jsonResult = SiteExcelicare.DecryptJsonData(strData)
                objSessionMgr = New clsSessionManager
                objClsSessionData = New clsSessionData
                objclsSecurity = New clsSecurity
                objClsSessionData = objSessionMgr.GetSessionData(Me.Session.SessionID, "APPDATA")
                If Not objClsSessionData Is Nothing Then
                    pat_id = objClsSessionData.PatientID
                    usr_id = objClsSessionData.UserID
                End If
                intusrSec = jsonResult("usl")
                strAppType = jsonResult("sat")
                intIsACLPatient = jsonResult("acl")
                objClsBizlPatient = New clsBizlPatient
                dsAlertInfo = objClsBizlPatient.GetPatientZone1AlertIconInfo(pat_id, usr_id, intusrSec, strAppType, intIsACLPatient)
                If dsAlertInfo.Tables(0).Rows.Count > 0 Then

                    Return objclsSecurity.ECEncode(dsAlertInfo.Tables(0).Rows(0).Item(0))
                Else
                    Return ""
                End If

            Catch ex As Exception
                LogException(ex)
                Throw ex
            Finally
                objClsBizlPatient = Nothing
                objSessionMgr = Nothing
                objClsSessionData = Nothing
                jsonResult = Nothing
            End Try
        End Function

        <WebMethod(EnableSession:=True)>
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Function fnGetTquestURL(ByVal strData As String) As String
            Dim request As HttpWebRequest
            Dim response As HttpWebResponse
            Dim jsonResponse As String = ""
            Dim paramURL As String
            Dim objBizUser As clsBizlUser
            Dim dsResult As DataSet
            Dim intUserId As Integer
            Dim PatientID As String
            Dim blnCheckLocation As Boolean
            Dim jsonResult As Object
            Try
                intUserId = SiteExcelicare.GetUSRID()
                jsonResult = SiteExcelicare.DecryptJsonData(strData)
                PatientID = jsonResult("spd")
                blnCheckLocation = jsonResult("bcl")
                objBizUser = New clsBizlUser
                dsResult = objBizUser.GetTQuestICELab(intUserId, PatientID, blnCheckLocation)
                If Not dsResult Is Nothing And dsResult.Tables.Count > 0 Then
                    If dsResult.Tables(0).Rows.Count > 0 Then
                        If dsResult.Tables(0).Rows(0)("PAT_DOB").ToString <> "" And dsResult.Tables(0).Rows(0)("PAT_Forename1").ToString <> "" And dsResult.Tables(0).Rows(0)("PPA_PCode").ToString <> "" And dsResult.Tables(0).Rows(0)("PAT_Primary_Identifier").ToString <> "" Then
                            paramURL = ConfigurationManager.AppSettings("ExcelicareWebServiceURL") & "/ParamURL.svc/getURL?LibID=9250001&Token=" + Me.Session.SessionID + "&UserID=" + lngUserId.ToString() + "&lngPatID=" + PatientID
                            WebRequest.DefaultWebProxy = Nothing
                            request = HttpWebRequest.Create(paramURL)
                            request.Method = WebRequestMethods.Http.Get
                            response = request.GetResponse()
                            jsonResponse = New StreamReader(response.GetResponseStream()).ReadToEnd()
                            response.Close()
                            Return jsonResponse
                        Else
                            Return "NoIdentifiers"
                        End If

                    End If

                Else
                    Return ""
                End If

            Catch ex As Exception
                Throw ex
            Finally
                request = Nothing
                response = Nothing
                jsonResponse = Nothing
                jsonResult = Nothing
            End Try
        End Function
        Public Sub fnValidateHiddenFieldsData(ByVal page As Page)
            Dim objSecurity As clsSecurity
            Dim blnResult As Boolean
            Try
                objSecurity = New clsSecurity
                For Each ctrl As Control In From C In page.Controls(0).Controls.OfType(Of HtmlInputHidden)()
                    LogwebsessionAction("Patient bar", lngPatId, 2042, "PB hidden ctrl:" & ctrl.ClientID & " PB hidden Ctrl Value:" & System.Xml.XmlConvert.DecodeName(DirectCast(ctrl, HtmlInputControl).Value.ToString.Replace(Chr(34), "").Replace("""", "")), 1031)
                    blnResult = objSecurity.ValidateOSandSQLCommandInjections(System.Xml.XmlConvert.DecodeName(DirectCast(ctrl, HtmlInputControl).Value.ToString.Replace(Chr(34), "").Replace("""", "")))
                    If blnResult Then
                        Response.End()
                    End If
                Next
            Catch ex As Exception
                Throw ex
            Finally
                objSecurity = Nothing
                blnResult = Nothing
            End Try
        End Sub
#Region "Exception Handling Methods"


        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This function is used to log the exception
        ' </summary>
        ' <Returns>Dataset</Returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        ' 	    [Suneetha]	08/11/2005	Comments added
        ' 	    [Suneetha]	08/11/2005	Created
        ' </history>
        ' -----------------------------------------------------------------------------


        Private Function LogException(ByVal objExcep As Exception)
            Dim objClsExceptionHandler As clsExceptionHandler
            Try
                objClsExceptionHandler = New clsExceptionHandler(objExcep)
                If Not IsNothing(Page) Then
                    objClsExceptionHandler.LogException(Page)
                Else
                    objClsExceptionHandler.LogException()
                End If
            Catch ex As Exception
                objClsExceptionHandler = New clsExceptionHandler(ex)
                If Not IsNothing(Page) Then
                    objClsExceptionHandler.LogException(Page)
                Else
                    objClsExceptionHandler.LogException()
                End If
            Finally
                objClsExceptionHandler = Nothing
            End Try

        End Function


#End Region
    End Class
End Namespace