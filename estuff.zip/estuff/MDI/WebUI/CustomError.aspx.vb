﻿Imports System.Web.SessionState
Imports Excelicare.Framework.AppSupport
Imports Excelicare.Bizl.MDI
Imports System.Collections.Specialized

Partial Public Class CustomError
    Inherits System.Web.UI.Page
    Public strCustomErrorMsg As String = String.Empty
    Public strSSoLogin As String = String.Empty
    Public lngUserId As String = String.Empty
    Protected strVerNo As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Response.Expires = -1
        Response.Cache.SetNoServerCaching()
        Response.Cache.SetAllowResponseInBrowserHistory(False)
        Response.CacheControl = "no-cache"
        Response.Cache.SetNoStore()
        Ajax.Utility.RegisterTypeForAjax(GetType(CustomError))
        Dim objGetVersionNo As clsAppSettings
        Dim objclsSecurity As New clsSecurity
        Dim objQueryParams As New NameValueCollection
        Try
            fnlogECWebSessionAction(2039, -1, "CustomError page Load")													   
            objGetVersionNo = New clsAppSettings
            strVerNo = objGetVersionNo.GetModuleVersion("1031")
            If URLValidationCheck(Request.Url.ToString) = False Then
                Response.End()
                Exit Sub
            End If
            If Not Request.QueryString("strQPData") Is Nothing Then
                objQueryParams = objclsSecurity.fnGetQueryParamData(Request.QueryString("strQPData"))
            Else
                objQueryParams = Request.QueryString
            End If
            strCustomErrorMsg = ""
            If Not objQueryParams.Item("ErrorCode") Is Nothing AndAlso objQueryParams.Item("ErrorCode") <> "" Then
                If objQueryParams.Item("ErrorCode").ToString() = "0" Then 'SessionNotExisted
                    strCustomErrorMsg = "Session not existed."
                ElseIf objQueryParams.Item("ErrorCode").ToString() = "1" Then 'NoModuleLevelSecurity
                    strCustomErrorMsg = "Unable to access the module."
                ElseIf objQueryParams.Item("ErrorCode").ToString() = "2" Then 'PatientNotSelected
                    strCustomErrorMsg = "Currently there is no patient selected."
                ElseIf objQueryParams.Item("ErrorCode").ToString() = "3" Then 'No module is defined in security group
                    strCustomErrorMsg = "No module is defined in security group."
                ElseIf objQueryParams.Item("ErrorCode").ToString() = "4" Then 'No User privileges.
                    strCustomErrorMsg = "Your user privileges do not permit you to view this Chart."
                ElseIf objQueryParams.Item("ErrorCode").ToString() = "5" Then 'No User privileges.
                    strCustomErrorMsg = "Invalid URL Supply."
                ElseIf objQueryParams.Item("ErrorCode").ToString() <> "" Then
                    strCustomErrorMsg = objQueryParams.Item("ErrorCode").ToString()
                End If
            Else
                strCustomErrorMsg = IIf(Not ConfigurationSettings.AppSettings("CustomErrorMesssage") Is Nothing, ConfigurationSettings.AppSettings("CustomErrorMesssage").ToString & "", "")
            End If
            strCustomErrorMsg = HttpUtility.HtmlEncode(strCustomErrorMsg) 'System.Uri.EscapeDataString(strCustomErrorMsg) 'HttpUtility.UrlEncode(strCustomErrorMsg)  
            If Not Session("SSOCalledFrom") Is Nothing Then
                strSSoLogin = 1
            End If
			
        Catch ex As Exception
        Finally
            objclsSecurity = Nothing
            objQueryParams = Nothing
        End Try
    End Sub
    Public Function URLValidationCheck(ByVal strURL As String) As Boolean
        Dim strParams() As String
        Dim intLoop, result As Integer
        Try
            Dim strCausedHackHTMLTags() As String = {"<applet>", "<body>", "<embed>", "<frame>", "<script>", "<frameset>", "<html>", "<iframe>", "<img>", "<style>", "<layer>", "<link>", "<ilayer>", "<meta>", "<object>", "alert", "alert(", "<title>", "=", "</", "<=", ">=", "<>", "<iframe", "<script", "<img", "<style", "style", "http", "phishing", "trim"}
            strParams = strURL.Split("?")
            If strParams.Length > 1 Then
                strURL = strParams(1)
                If strURL <> "" AndAlso strURL.Split("&").Length >= 1 Then
                    For intLoop = 0 To strURL.Split("&").Length - 1
                        If strURL.Split("&")(intLoop) <> "" AndAlso strURL.Split("&")(intLoop).Split("=").Length > 1 Then
                            Select Case UCase(strURL.Split("&")(intLoop).Split("=")(0))
                                Case "ERRORCODE"
                                    For intIndex As Integer = 0 To strCausedHackHTMLTags.Length - 1
                                        If UCase(strURL.Split("&")(intLoop).Split("=")(1)).IndexOf(UCase(strCausedHackHTMLTags(intIndex).ToString())) > -1 Then
                                            result = intIndex
                                            Exit For
                                        End If
                                    Next
                                    If result > 0 Then Return False
                            End Select
                        End If
                    Next
                End If
            End If
            Return True
        Catch ex As Exception
            Throw ex
        Finally
            strParams = Nothing
        End Try
    End Function
	<Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.Read)>
    Public Sub fnlogECWebSessionAction(ByVal lngEventId As Long, ByVal lngPatId As Long, ByVal strEventDet As String)
        Try
            clsECSession.LogWebSessionAction("CustomError", Session.SessionID, lngPatId, lngEventId, strEventDet, 1031, 0)
        Catch ex As Exception
            clsECSession.LogWebSessionAction("CustomError", HttpContext.Current.Session.SessionID, lngPatId, lngEventId, strEventDet, 1031, 0)
        End Try
    End Sub
    <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.Read)>
    Public Function EndActiveSSOSessionsByUserID() As String
        Dim objClsBizlUser As clsBizlUser
        Dim objClsECSession As clsECSession
        Dim objClsSessionData As clsSessionData
        Dim objClsSessionManager As clsSessionManager
        Dim Manager As SessionIDManager
        Dim NewID As String
        Dim strTempDirectorypath As String
        'Dim OldID As String
        Dim redirected As Boolean = False
        Dim IsAdded As Boolean = False
        ' Try
        objClsECSession = New clsECSession

        objClsSessionManager = New clsSessionManager
        Try

            lngUserId = Session("TempUserID")
            objClsBizlUser = New clsBizlUser
            If lngUserId > 0 Then
                objClsBizlUser.EndActiveSSOSessionsByUserID(lngUserId)

            End If
            Try
                strTempDirectorypath = ConfigurationSettings.AppSettings("AxServerTempFolder") & HttpContext.Current.Session.SessionID
                If IO.Directory.Exists(strTempDirectorypath) Then
                    IO.Directory.Delete(strTempDirectorypath, True)
                End If
            Catch ex As Exception

            End Try
            objClsSessionData = objClsSessionManager.GetSessionData(HttpContext.Current.Session.SessionID, "APPDATA")

            ' logECWebSessionAction(2038, -1, "Browser Closed")
            objClsECSession.EndSession(HttpContext.Current.Session.SessionID, objClsSessionData.UserID)

            '  If objClsSessionManager.IsSessionExists(HttpContext.Current.Session.SessionID) = False Then

            HttpContext.Current.Session.Clear()
            HttpContext.Current.Session.RemoveAll()
            HttpContext.Current.Session.Abandon()
            'DeleteOtherStoreFiles()
            Manager = New SessionIDManager
            NewID = Manager.CreateSessionID(Context)
            ' OldID = HttpContext.Current.Session.SessionID
            Manager.SaveSessionID(Context, NewID, redirected, IsAdded)


            Return "SSO"
        Catch ex As Exception
            Throw
        Finally
            objClsBizlUser = Nothing
            strTempDirectorypath = Nothing
        End Try

    End Function
End Class