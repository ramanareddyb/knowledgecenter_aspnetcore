Imports Excelicare.Framework.AppSupport
Imports System.IO
Imports System.Collections.Specialized

Namespace AxSys.UI.Web.MDI
    Partial Class frmEndSession
        Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            'Put user code to initialize the page here
            Dim objClsECSession As clsECSession
            Dim objSession As clsSessionData
            Dim objSessionMgr As clsSessionManager
            Dim lngUserId As Long
            Dim objclsSecurity As New clsSecurity
            Dim objQueryParams As New NameValueCollection
            Try
                Response.Expires = -1
                Response.Cache.SetNoServerCaching()
                Response.Cache.SetAllowResponseInBrowserHistory(False)
                Response.CacheControl = "no-cache"
                Response.Cache.SetNoStore()
                '' Code added to end the current session by Suneetha -- Begin 

                objClsECSession = New clsECSession
                clsECSession.LogWebSessionAction("MDI", Session.SessionID, -1, 2038, "Browser is closed", 1032)
                objSessionMgr = New clsSessionManager
                objSession = objSessionMgr.GetSessionData(Me.Session.SessionID, "APPDATA")
                If Not Request.QueryString("strQPData") Is Nothing Then
                    objQueryParams = objclsSecurity.fnGetQueryParamData(Request.QueryString("strQPData"))
                Else
                    objQueryParams = Request.QueryString
                End If
                If Not objSession Is Nothing Then
                    lngUserId = objSession.UserID
                Else
                    lngUserId = objQueryParams.Item("UserID")
                End If

                objSession = Nothing
                objSessionMgr = Nothing

                Session.Clear()
                Session.RemoveAll()
                Session.Abandon()
                DeleteSessionDataAndFilesInBrowserClose()
                DeleteSessionDataInLeadImage()
                objClsECSession.EndSession(Session.SessionID, lngUserId)
                '''objClsECSession.DecrementConcurrentUserCount()

                '' Code added to end the current session by Suneetha -- End
            Catch ex As Exception
                LogException(ex)
            Finally
                objClsECSession = Nothing
                objSession = Nothing
                objSessionMgr = Nothing
                objclsSecurity = Nothing
                objQueryParams = Nothing
            End Try
        End Sub

        ' -----------------------------------------------------------------------------
        ' <summary>
        '      This is used to delete the temporary session data or files of the current user session in browser close
        ' </summary>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]    12/12/2005  Created
        ' 	    [Suneetha B]	12/12/2005 	Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------

        Private Function DeleteSessionDataAndFilesInBrowserClose()
            Try
                DeleteOtherStoreFiles() '' to delete the XML files created for other store search if any in this session 
                ' DeleteTempPatientRegData() '' to delete the temporary session data of patient registration for the curent session
                DeleteLabImages() '' to delete lab grapg images
            Catch ex As Exception
                LogException(ex)
            Finally
            End Try
        End Function

        ' -----------------------------------------------------------------------------
        ' <summary>
        '      This is used to delete the other store XML file created in the curent user session 
        ' </summary>
        ' <returns></returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]    12/12/2005  Created
        ' 	    [Suneetha B]	12/12/2005 	Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------


        Private Sub DeleteOtherStoreFiles()
            Try
                If Not ConfigurationSettings.AppSettings("OSPatientFilePath") Is Nothing Then
                    If ConfigurationSettings.AppSettings("OSPatientFilePath").ToString <> "" Then
                        Dim strOSPath As String = ConfigurationSettings.AppSettings("OSPatientFilePath").ToString
                        If strOSPath <> "" Then
                            If strOSPath.Substring(strOSPath.Length - 1) <> "/" Or strOSPath.Substring(strOSPath.Length - 1) <> "\" Then
                                strOSPath = strOSPath & "\" & "OSPatientData_" & Session.SessionID & ".XML"
                            End If
                            If File.Exists(strOSPath) Then
                                File.Delete(strOSPath)
                            End If
                        End If
                    End If
                End If
            Catch ex As Exception
                LogException(ex)
            Finally
            End Try
        End Sub

        ' -----------------------------------------------------------------------------
        ' <summary>
        '      This is used to delete the Images created for LAbs module in the current session 
        ' </summary>
        ' <returns></returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]    21/12/2005  Created
        ' 	    [Suneetha B]	21/12/2005 	Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Private Sub DeleteLabImages()
            Try
                If Not ConfigurationSettings.AppSettings("LabResultsGraph") Is Nothing Then
                    If ConfigurationSettings.AppSettings("LabResultsGraph").ToString <> "" Then
                        Dim strLabImagePath As String = ConfigurationSettings.AppSettings("LabResultsGraph").ToString
                        If strLabImagePath <> "" Then
                            If strLabImagePath.Substring(strLabImagePath.Length - 1) <> "/" And strLabImagePath.Substring(strLabImagePath.Length - 1) <> "\" Then
                                strLabImagePath = strLabImagePath & "\" & Session.SessionID
                            Else
                                strLabImagePath = strLabImagePath & Session.SessionID
                            End If
                            If Directory.Exists(strLabImagePath) Then
                                Directory.Delete(strLabImagePath, True)
                            End If
                        End If
                    End If
                End If
            Catch ex As Exception
                LogException(ex)
            End Try
        End Sub

        Private Sub LogException(ByVal objex As Exception)
            Dim objClsExceptionHandler As clsExceptionHandler
            Try
                objClsExceptionHandler = New clsExceptionHandler(objex)
                objClsExceptionHandler.LogException()
            Catch ex As Exception
                objClsExceptionHandler = New clsExceptionHandler(ex)
                objClsExceptionHandler.LogException()
            Finally
                objClsExceptionHandler = Nothing
            End Try
        End Sub

        ' -----------------------------------------------------------------------------
        ' <summary>
        '      This is used to delete the temporary session data of patient reg 
        ' </summary>
        ' <returns></returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]    12/12/2005  Created
        ' 	    [Suneetha B]	12/12/2005 	Added Comments
        '       [Madhavi]       11/06/2008  Commented this function as this functionality is 
        '                                   executed in the SP called in EndSession()
        ' </history>
        ' -----------------------------------------------------------------------------

        '''Private Sub DeleteTempPatientRegData()
        '''    Dim objbizUser As AxSys.Bizl.MDI.clsBizlUser
        '''    Try
        '''        objbizUser = New AxSys.Bizl.MDI.clsBizlUser
        '''        If Not Request.QueryString("UserID") Is Nothing Then
        '''            objbizUser.DeleteTempPatientRegistrationData(CInt(Request.QueryString("UserID")), Session.SessionID)
        '''        End If

        '''    Catch ex As Exception
        '''        LogException(ex)
        '''    Finally
        '''        objbizUser = Nothing
        '''    End Try
        '''End Sub
        ' -----------------------------------------------------------------------------
        ' <summary>
        '      This is used to delete the temporary session data of all the modules generated on the server for the current session
        ' </summary>
        ' <returns></returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]    17/03/2006  Created
        ' 	    [Suneetha B]	17/03/2006 	Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Function DeleteSessionDataInLeadImage()
            Dim strPath As String = ""
            Try
                If Not ConfigurationSettings.AppSettings("AxServerTempFolder") Is Nothing Then
                    strPath = ConfigurationSettings.AppSettings("AxServerTempFolder").ToString.Trim
                    If Directory.Exists(strPath) Then
                        If (strPath.EndsWith("/") = True Or strPath.EndsWith("\") = True) Then
                            If Directory.Exists(strPath & Session.SessionID) Then
                                Directory.Delete(strPath & Session.SessionID, True)
                            End If
                        Else
                            If Directory.Exists(strPath & "/" & Session.SessionID) Then
                                Directory.Delete(strPath & "/" & Session.SessionID, True)
                            End If
                        End If
                    End If
                End If
            Catch ex As Exception
                LogException(ex)
            Finally
                strPath = Nothing
            End Try
        End Function
        Protected Overrides Sub Finalize()
            MyBase.Finalize()
        End Sub
    End Class
End Namespace
