Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("AxWebUIMDI|LOCAL-BUILD")>
<Assembly: AssemblyDescription("Excelicare v7")>
<Assembly: AssemblyCompany("Practive Health Inc. dba Excelicare")>
<Assembly: AssemblyProduct("Excelicare")>
<Assembly: AssemblyCopyright("Copyright 2023 Practive Health Inc. dba Excelicare. All rights reserved.")>
<Assembly: AssemblyTrademark("Excelicare")>

<Assembly: ComVisible(False)>
<Assembly: CLSCompliant(True)>

<Assembly: AssemblyVersion("0.0.0.0")>
<Assembly: AssemblyFileVersion("0.0.0.0")>
