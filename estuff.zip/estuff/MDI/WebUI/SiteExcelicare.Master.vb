﻿Imports System.Web
Imports System.Xml.Linq
Imports System.Xml.Xsl
Imports System.Web.Services
Imports Excelicare.Bizl.MDI
Imports Excelicare.Framework.AppSupport
Imports System.Xml
Imports System.IO
Imports System.Linq
Imports System.Collections.Generic
Imports System.Configuration.ConfigurationManager
Imports System.Web.SessionState
Imports Ajax
Imports Excelicare.ServiceProxy
Imports Excelicare.ServiceProxy.AxRSOrderCommunicationsManager

Imports System.Net
Imports Newtonsoft.Json.Linq
Imports System.Diagnostics
Imports System.Threading
Imports Newtonsoft.Json
Imports System.Data
Imports System.Web.Script.Serialization
Imports Excelicare
Imports System.Text.RegularExpressions
Imports System.Dynamic
Imports RestSharp				 
'Imports AxSys.Biz.AxWSLibBizOrderComms

Namespace Excelicare.UI.Web.MDI
    Public Class SiteExcelicare
        Inherits System.Web.UI.MasterPage
        Protected strVerNo As String = "v6"
        Protected strMenuItems As String = "" '"{dataSource:[$]}"
        Protected UserName As String = ""
        Protected strSecureModuleIds As String = ""
        Protected m_strUserStartupForm As String = ""
        Protected m_strSysBroadcastDetails As String = ""
        Protected m_strServerDate As String = ""
        Protected m_inteRxLocationId As Integer
        Protected m_intUserId As Integer
        Protected m_intPrescriberRole As Integer
        Protected m_strQueCount As String = ""
        Dim oMenuDOM As XDocument
        Protected m_intAutoLogOffTime, m_intCountDownTime As Integer
        Protected m_isHtmlDialog As String = "false"
        Protected m_strSSOCalledFrom As String = ""
        Public m_lngPatientID As Long
        Public intShowClientLog As Integer = 0
        Public intUserRole As Integer = 0
        Public m_lngRefreshTime As Long = 0
        Public m_strSessionID As String
        Public m_strTempURL As String = ""
        Public m_IsShowDisclaimer As String = ""
        Protected m_strLauncherURL As String = ""
        Protected m_bitADUser As Int16 = 0
        Protected m_strUserLoginName As String = ""
        Protected m_strUserDomainName As String = ""
        Protected m_strClinicalNotesURL As String = ""
        Public m_strSunQuestURL As String = ""
        Public strPatRecordModuleIds As String = ""
        Protected m_RIOServiceURL As String = ""
        Dim m_objWSePrescribing As WSPrescriptionManager.AxWSePrescriptionManagerClient
        Public m_blnShowPrintConfirmationMessage As Integer = 0
        Public m_strSessionValidate As String = ""
        Public strSaltKey As String = ""
        Public objClsSecurity As clsSecurity
        Public strWelcomePackageFilePath As String
        Public m_blnIsWelcomePackageEnabled As String = "0"
        Public showPatientKeySummary As Int16 = 0
        Public AuthenUser As String = ""
        Public Authenpd As String = ""
        Public strUserDropDown_Lookup As String = String.Empty
        Public AutoLogoffAction As Integer
        Public m_blnIsSuperUser As Boolean = False
        Public UserSettings As String = String.Empty
		Public UserStatus As String = "Appear_offline"
        Public intShowUserStatus As Integer = 0
        Public m_strUserCapabilityModuleIds As String = ""
        Public strFormattedName As String = ""
        Public IsPrintAPI As String = "0"
        Public m_TypeOfUser As Int64
        ' Protected m_strSecuremodules As String = ""
        Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
            Dim oSessionManager As clsSessionManager
            Dim oSessionData As clsSessionData
            Dim objGetVersionNo As clsAppSettings
            '  Dim objSysDefault As clsSysDefault
            Dim strResult() As String
            Dim objJSONObject As JObject
            Dim jtReturnValue As JToken
            Dim oMDIUserBiz As clsBizlUser
            Dim UserPreferences = New ExpandoObject()

            Try
                Response.Expires = -1
                Response.Cache.SetNoServerCaching()
                Response.Cache.SetAllowResponseInBrowserHistory(False)
                Response.CacheControl = "no-cache"
                Response.Cache.SetNoStore()
                'If Session("APPDATA") Is Nothing Then
                '   Response.Redirect("~/AxWebUILogin/frmSignon.aspx", False)
                '    Exit Sub
                ' End If
                If IsNothing(Session("UserLoginName")) = False Then
                    m_strUserLoginName = Session("UserLoginName")
                End If
                If IsNothing(Session("UserDomainName")) = False Then
                    m_strUserDomainName = Session("UserDomainName")
                End If

                If IsNothing(Session("ADUser")) = False AndAlso Session("ADUser") = True Then
                    m_bitADUser = 1
                End If
                If Not String.IsNullOrEmpty(ConfigurationSettings.AppSettings("AuthPd")) Then
                    AuthenUser = ConfigurationSettings.AppSettings("AuthId")
                End If
                If Not String.IsNullOrEmpty(ConfigurationSettings.AppSettings("AuthPd")) Then
                    Authenpd = ConfigurationSettings.AppSettings("AuthPd")
                End If
                strSaltKey = Session("SK")
                m_strTempURL = ConfigurationSettings.AppSettings("AxServerTempURL") & Session.SessionID
                objGetVersionNo = New clsAppSettings
                '   objSysDefault = New clsSysDefault
                strVerNo = objGetVersionNo.GetModuleVersion("1031")
                m_lngRefreshTime = clsSysDefault.GetSysDefaultValue(1011) * (1000 * 60)
                m_blnShowPrintConfirmationMessage = clsSysDefault.GetSysDefaultValue(2490)
                Dim arrResult As Hashtable = clsSysDefault.GetSysDefaultValues({2583, 2115, 2324, 2321, 2327, 2325, 2326, 2585, 2590})
                If Not arrResult Is Nothing AndAlso Not arrResult(2583) Is Nothing Then
                    AutoLogoffAction = arrResult(2583).value
                End If
                If Not clsSysDefault.GetSysDefaultValue(2000) Is Nothing AndAlso clsSysDefault.GetSysDefaultValue(2000) <> "" Then
                    intShowClientLog = clsSysDefault.GetSysDefaultValue(2000)
                End If
                If Not arrResult Is Nothing AndAlso Not arrResult(2585) Is Nothing Then
                    intShowUserStatus = arrResult(2585).value
                End If
                If IsNothing(Session("LauncherURL")) = False Then
                    m_strLauncherURL = Session("LauncherURL")
                End If
                If Not arrResult Is Nothing AndAlso Not arrResult(2590) Is Nothing Then
                    IsPrintAPI = arrResult(2590).value
                End If

                m_strSysBroadcastDetails = Server.UrlEncode(Session("SysBroadcastDetails"))
                Ajax.Utility.RegisterTypeForAjax(GetType(SiteExcelicare))
                oSessionManager = New clsSessionManager
                oSessionData = oSessionManager.GetSessionData(Session.SessionID, "APPDATA")


                UserPreferences.IsSuperUser = If(oSessionData IsNot Nothing, oSessionData.IsSuperUser, False)
                UserPreferences.ShowSaveConfirmation = Convert.ToInt16(Session("SHOWSAVEDIALOG"))
                UserPreferences.PhoneNumberFormat = arrResult(2115).value
                UserPreferences.MFA = ConfigurationSettings.AppSettings("MFAE")
                UserPreferences.ProductType = ConfigurationSettings.AppSettings("ProductType")
                UserPreferences.Culture = ConfigurationSettings.GetConfig("system.web/globalization").UICulture()
                UserPreferences.IsOtherStoreAccesible = ConfigurationSettings.AppSettings("Other store Accesible")
                UserPreferences.ShowInActiveRecords = If(oSessionData IsNot Nothing, oSessionData.ShowInActiveRecords, False)
                UserSettings = JObject.FromObject(UserPreferences).ToString()

                If Not oSessionData Is Nothing Then
                    UserName = oSessionData.UserRole & " " & oSessionData.UserForeName & " " & oSessionData.UserSurName
                    strFormattedName = oSessionData.UserSurName.ToUpper & ", " & StrConv(oSessionData.UserForeName, VbStrConv.ProperCase) '' For SURNAME(LAST NAME), Forename(First Name)
                    m_intUserId = oSessionData.UserID
                    m_lngPatientID = oSessionData.PatientID
                    m_strSessionID = HttpContext.Current.Session.SessionID
                    m_blnIsSuperUser = oSessionData.IsSuperUser
					m_TypeOfUser = oSessionData.TypeOfUser
                    If Request.QueryString("CalledFrom") = "SSOEP" Then
                        intUserRole = 2968
                    Else
                        intUserRole = 2967
                    End If

                    oMDIUserBiz = New clsBizlUser
                    m_IsShowDisclaimer = oMDIUserBiz.GetUserDisclaimerStatus(m_intUserId)
                    Using oMDIBiz As New clsBizlSysModule
                        strResult = clsBizlSysModule.GetMDIMenuItems(oSessionData.UserSecurityLevel, "1,2,3", Application("ApplicationInstallType"), False, True, oSessionData.UserID, intUserRole).Split(Chr(186))
                        ' oMenuDOM = XDocument.Parse(clsBizlSysModule.GetMDIMenuItems(oSessionData.UserSecurityLevel, "1,2,3", Application("ApplicationInstallType"), False, True))
                    End Using
                    strPatRecordModuleIds = strResult(8)
                    oMenuDOM = XDocument.Parse(strResult(0))
                    strSecureModuleIds = strResult(1)
                    If IsNothing(strResult(2)) = False Then
                        Session("ISOPTGROUP") = strResult(2)
                    End If
                    If IsNothing(strResult(3)) = False Then
                        m_strUserStartupForm = strResult(3)
                    End If
                    If IsNothing(strResult(4)) = False Then
                        m_strServerDate = strResult(4)
                    End If
                    If strResult.Length > 5 Then
                        m_inteRxLocationId = strResult(5)
                        Session("eRxAccountLocationID") = m_inteRxLocationId
                    End If
                    If strResult.Length > 6 Then
                        m_intPrescriberRole = strResult(6)
                    End If
                    If strResult.Length > 7 Then
                        m_strQueCount = HttpUtility.HtmlEncode(strResult(7))
                    End If
                    If strResult.Length > 9 Then
                        showPatientKeySummary = CInt(strResult(9))
                    End If
                    If strResult.Length > 10 Then
                        m_strUserCapabilityModuleIds = strResult(10)
                    End If
                    m_intAutoLogOffTime = oSessionData.AutoLogOffTime * 60 * 1000
                    m_intCountDownTime = AppSettings("AutoLogOffReminderTimeInSecs")

                If Not AppSettings("ShowHTMLDialoge") Is Nothing AndAlso AppSettings("ShowHTMLDialoge") <> "" Then
                    m_isHtmlDialog = AppSettings("ShowHTMLDialoge")
                End If
				If Not AppSettings("RIOServiceURL") Is Nothing AndAlso AppSettings("RIOServiceURL") <> "" Then
                    m_RIOServiceURL = AppSettings("RIOServiceURL")
                End If
                If Not AppSettings("SessionValidate") Is Nothing AndAlso AppSettings("SessionValidate") <> "" Then 
                    m_strSessionValidate = AppSettings("SessionValidate")
                End If
                If Not ConfigurationSettings.AppSettings("IsDevice") Is Nothing AndAlso ConfigurationSettings.AppSettings("IsDevice").ToString() <> "0" Then
                    If Not ConfigurationSettings.AppSettings("RestServiceURL") Is Nothing AndAlso ConfigurationSettings.AppSettings("RestServiceURL").ToString() <> "" Then
                        Dim strMenuDetials As String = ""
                        strMenuDetials = fnGetMenuItemdeatails()
                        objJSONObject = JsonConvert.DeserializeObject(strMenuDetials)
                        jtReturnValue = objJSONObject.SelectToken("MenuItem")
                        If Not jtReturnValue Is Nothing Then
                            strMenuItems = jtReturnValue.ToString()
                        End If
                    End If
                Else
                    Dim oMenuItems As IEnumerable(Of XElement)
                    oMenuItems = From Item In oMenuDOM.Root.<groups>.Elements Where CInt(Item.@parentid) = 0 Order By CInt(Item.@displayorder) Select Item
                    Dim strMenuItem As String = ""
                    Dim oMenuSubItems As IEnumerable(Of XElement)
                    Dim oTempDom As XDocument
                    For intCnt As Integer = 0 To oMenuItems.Count - 1
                        oTempDom = XDocument.Parse("<root/>")
                        oTempDom.Root.Add(From Item In oMenuDOM.Root.<list>.Elements Where Item.@groupid = oMenuItems(intCnt).@id Order By CInt(Item.@displayorder) Select Item)
                        oTempDom.Root.Add(From Item In oMenuDOM.Root.<groups>.Elements Where Not Item.@parentid Is Nothing AndAlso CInt(Item.@parentid) = oMenuItems(intCnt).@id Order By CInt(Item.@displayorder) Select Item)
                        oMenuSubItems = From Item In oTempDom.Root.Elements Order By CInt(Item.@displayorder) Select Item
                        'If IsNothing(oTempDom.Elements.<item>(intCnt)) = False Then
                        '    m_strSecuremodules = m_strSecuremodules & "," & oTempDom.Elements.<item>(intCnt).@id & ","
                        'End If


                        '    strMenuItem += GetMenuGroupItems(oMenuItems(intCnt).@id, oMenuItems(intCnt).<name>.Value, oMenuItems(intCnt).<icon>.Value, oMenuItems(intCnt).<url>.Value, oMenuSubItems)
                        strMenuItem += GetMenuGroupItems(New String() {oMenuItems(intCnt).@id, oMenuItems(intCnt).<name>.Value, oMenuItems(intCnt).<icon>.Value, oMenuItems(intCnt).<url>.Value, oMenuItems(intCnt).<PSM>.Value, oMenuItems(intCnt).<smod_ID>.Value}, oMenuSubItems)
                    Next
                    strMenuItems = "<ul>" & strMenuItem & "</ul>" 'strMenuItems.Replace("$", strMenuItem.TrimEnd(",", ""))




                    End If
                End If
                If Not Session("SSOCalledFrom") Is Nothing Then
                    m_strSSOCalledFrom = Session("SSOCalledFrom")
                End If

                m_blnIsWelcomePackageEnabled = clsSysDefault.GetSysDefaultValue(2562)
                GetItemsforUserDropDown()

            Catch ex As Exception
                LogException(ex)
            Finally
                '  objSysDefault = Nothing
                objGetVersionNo = Nothing
		UserPreferences = Nothing
            End Try
        End Sub
        Private Function GetMenuGroupItems(ByVal aMenuItem() As String, ByVal Items As IEnumerable(Of XElement), Optional ByVal strPosition As String = "") As String
            '    Dim strMenuItem As String = "'text':'{0}','spriteCssClass':'{1}','url':'{2}'"
            Dim strMenuItem As String = "'name':'TB{0}','text':'{1}','imageUrl1':'{2}','url':'{3}','encoded': false"
            'Dim strListItems As String=""
            Dim oMenuSubItems As IEnumerable(Of XElement)
            Try                                                            '
                ' MenuItem
                '0 - Name
                '1 - text
                '2 - imageUrl
                '3 - navigation url
                If aMenuItem(2).Trim <> "" Then aMenuItem(2) = "./Images/MainToolBar/" + aMenuItem(2) + ".gif"
                'aMenuItem(1) = "<span id=""" & aMenuItem(0) & """ PD=""" & aMenuItem(4) & """>" & aMenuItem(1) & "</span>"
                ' strMenuItem = "{" + String.Format(strMenuItem, aMenuItem) + "},"

                strMenuItem = "<li id=""" & aMenuItem(0) & """ class=""" & strPosition & """ PD=""" & aMenuItem(4) & """><a onclick=""Javascript:return MenuItemOnClick('" & aMenuItem(3) & "','" & aMenuItem(4) & "','" & aMenuItem(1) & "','" & aMenuItem(5) & "' );"" href=""#"">" & aMenuItem(1) & "</a>"
                If aMenuItem(0) = 111 Then
                    m_strClinicalNotesURL = aMenuItem(3)
                End If
                If Not Items Is Nothing AndAlso Items.Count <> 0 Then
                    '          Dim strSubMenu As String = "$"
                    Dim strSubMenuItem As String = ""
                    Dim oTempDom As XDocument
                    For intCnt As Integer = 0 To Items.Count - 1
                        If Not Items(intCnt).@parentid Is Nothing Then
                            oTempDom = XDocument.Parse("<root/>")
                            oTempDom.Root.Add(From Item In oMenuDOM.Root.<list>.Elements Where Item.@groupid = Items(intCnt).@id Order By CInt(Item.@displayorder) Select Item)
                            oTempDom.Root.Add(From Item In oMenuDOM.Root.<groups>.Elements Where Not Item.@parentid Is Nothing AndAlso CInt(Item.@parentid) = Items(intCnt).@id Order By CInt(Item.@displayorder) Select Item)
                            oMenuSubItems = From Item In oTempDom.Root.Elements Order By CInt(Item.@displayorder) Select Item
                        End If
                        If intCnt = Items.Count - 1 Then
                            strSubMenuItem += GetMenuGroupItems(New String() {Items(intCnt).@id, Items(intCnt).<name>.Value, Items(intCnt).<icon>.Value, Items(intCnt).<url>.Value, Items(intCnt).<PSM>.Value, Items(intCnt).<smod_ID>.Value}, oMenuSubItems, "last")
                        ElseIf intCnt = 0 Then
                            strSubMenuItem += GetMenuGroupItems(New String() {Items(intCnt).@id, Items(intCnt).<name>.Value, Items(intCnt).<icon>.Value, Items(intCnt).<url>.Value, Items(intCnt).<PSM>.Value, Items(intCnt).<smod_ID>.Value}, oMenuSubItems, "first")
                        Else
                            strSubMenuItem += GetMenuGroupItems(New String() {Items(intCnt).@id, Items(intCnt).<name>.Value, Items(intCnt).<icon>.Value, Items(intCnt).<url>.Value, Items(intCnt).<PSM>.Value, Items(intCnt).<smod_ID>.Value}, oMenuSubItems)
                        End If

                    Next
                    strMenuItem = strMenuItem & "<ul>$</ul></li>"
                    'strSubMenu = strSubMenu.Replace("$", strSubMenuItem.TrimEnd(",", ""))
                    strMenuItem = strMenuItem.Replace("$", strSubMenuItem) 'strMenuItem.Replace("},", ",items:" + strSubMenu + "},")
                Else
                    strMenuItem += "</li>"
                End If
            Catch ex As Exception
                strMenuItem = ""
            End Try
            Return strMenuItem
        End Function

        <WebMethod(EnableSession:=True)>
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Function fnAppLogOff(strData As String) As String
            Dim intLogOff As Int16
            Dim jsonResult As Object
            Try
                jsonResult = DecryptJsonData(strData)
                intLogOff = jsonResult("intLogOff")
                'If intLogOff <> "" Then
                If intLogOff = 1 Or intLogOff = 0 Then  
                    LogOff(intLogOff)
                End If
            Catch ex As Exception
                Throw ex
            Finally
                jsonResult = Nothing
            End Try
        End Function

        <WebMethod(EnableSession:=True)>
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Function LogOff(intLogOff As Int16) As String
            Dim objClsECSession As clsECSession
            Dim objClsSessionData As clsSessionData
            Dim objClsSessionManager As clsSessionManager
            Dim intSessionExpired As Int16 = 0
            Dim Manager As SessionIDManager
            Dim NewID As String
            Dim strTempDirectorypath As String
            'Dim OldID As String
            Dim redirected As Boolean = False
            Dim IsAdded As Boolean = False
            Dim CookieObj As System.Web.HttpCookie
            Try
                objClsECSession = New clsECSession
                objClsSessionManager = New clsSessionManager
                If intLogOff = 0 Then
                    If IsNothing(HttpContext.Current.Session("APPDATA")) = True Then
                        intSessionExpired = 1
                    Else
                        intSessionExpired = 0
                    End If
                    ' If intSessionExpired = 0 Then
                    objClsSessionData = objClsSessionManager.GetSessionData(HttpContext.Current.Session.SessionID, "APPDATA")

                    logECWebSessionAction(2038, -1, "Browser Closed")
                    objClsECSession.EndSession(HttpContext.Current.Session.SessionID, objClsSessionData.UserID)

                    '  If objClsSessionManager.IsSessionExists(HttpContext.Current.Session.SessionID) = False Then
            
                    intSessionExpired = 1
                    HttpContext.Current.Session.Clear()
                    HttpContext.Current.Session.RemoveAll()
                    HttpContext.Current.Session.Abandon()
                    DeleteOtherStoreFiles()
                    'Moved from down to here to remove  media by Shireesha
                    Try
                        strTempDirectorypath = AppSettings("AxServerTempFolder") & HttpContext.Current.Session.SessionID
                        removeAxServerTempData(strTempDirectorypath, True)

                    Catch ex As Exception

                    End Try

                    ' Added by BRR
                    Manager = New SessionIDManager
                    NewID = Manager.CreateSessionID(Context)
                    ' OldID = HttpContext.Current.Session.SessionID
                    Manager.SaveSessionID(Context, NewID, redirected, IsAdded)
                    Return intSessionExpired
                End If


                Try
                    strTempDirectorypath = AppSettings("AxServerTempFolder") & HttpContext.Current.Session.SessionID
                    removeAxServerTempData(strTempDirectorypath, True)

                Catch ex As Exception

                End Try
                '' To delete Saved external documents viewed from special forms -- start
                Dim strExternalDocumentPath As String = AppSettings("ExcelicareInternalDocumentsFolder") & "ExternalDocuments\" & HttpContext.Current.Session.SessionID
                WriteToTrace("External Document path: " & strExternalDocumentPath, "SiteExcelicareMaster.vb", "")
                removeAxServerTempData(strExternalDocumentPath, True)

                '' To delete Saved external documents viewed from special forms -- End
                objClsSessionData = objClsSessionManager.GetSessionData(HttpContext.Current.Session.SessionID, "APPDATA")
                If objClsSessionData Is Nothing Then
                    logECWebSessionAction(2038, -1, "Log Off Excelicare")
                Else
                    logECWebSessionAction(2038, objClsSessionData.PatientID, "Log Off Excelicare")
                End If

                objClsECSession.EndSession(HttpContext.Current.Session.SessionID, objClsSessionData.UserID)

                HttpContext.Current.Session.Clear()
                HttpContext.Current.Session.RemoveAll()
                HttpContext.Current.Session.Abandon()
                DeleteOtherStoreFiles()
                Manager = New SessionIDManager
                NewID = Manager.CreateSessionID(Context)
                ' OldID = HttpContext.Current.Session.SessionID
                Manager.SaveSessionID(Context, NewID, redirected, IsAdded)

                ' Added by BRR 
                '            CookieObj = Response.Cookies("ASP.NET_SessionId")
                '            If Not CookieObj Is Nothing
                '                CookieObj.Path = Request.ApplicationPath
                '            End If
                'CookieObj = Nothing
                Return "true"
            Catch ex As Exception
                Throw ex
            Finally

                ' Added by BRR
                'HttpContext.Current.Response.Cookies.Add(new HttpCookie("ASP.NET_SessionId", ""))
                'CookieObj = HttpContext.Current.Response.Cookies("ASP.NET_SessionId")
                'CookieObj.Expires = DateTime.Now.AddDays(-1)
                'CookieObj=Nothing
                'HttpContext.Current.Response.Cookies.Remove("ASP.NET_SessionId")
            End Try
        End Function

        'Purpose : To Remove the TempFilesFolder 
        'Added By: Ashok 
        Public Sub removeAxServerTempData(ByVal folderPath As String, Optional ByVal calledFrom As Boolean = False, Optional ByVal blnLogOutClicked As Boolean = True)
            Dim strTempDirectorypath As String
            Dim objClsExceptionHandler As clsExceptionHandler
            Try
                strTempDirectorypath = folderPath 'AppSettings("AxServerTempFolder") & strSessionID
                If calledFrom Then
                    logECWebSessionAction(2039, -1, "AxServerTempData Folder Deleting in LogOff Processs")
                End If
                If blnLogOutClicked = False Then
                    fnUnLockCarePlan("Logoff", m_intUserId)
                    LogOff(0)
                Else
                    If IO.Directory.Exists(strTempDirectorypath) Then
                        logECWebSessionAction(2039, -1, "AxServerTempData Folder Exist")
                        IO.Directory.Delete(strTempDirectorypath, True)
                        logECWebSessionAction(2039, -1, "AxServerTempData Folder Deleted")
                    End If
                End If
            Catch ex As Exception
                'objClsExceptionHandler = New clsExceptionHandler(ex)
                'objClsExceptionHandler.LogException()
                Throw ex
            Finally
                objClsExceptionHandler = Nothing
            End Try
        End Sub

        <WebMethod(EnableSession:=True)>
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Function fnSaveUserNavigationHistory(ByVal strData As String) As String
            Dim objClsSessionData As clsSessionData
            Dim objClsSessionManager As clsSessionManager
            Dim lngModuleId As Long
            Dim lngCustomFormId As Long
            Dim strURL As String
            Dim jsonResult As Object
            Try
                jsonResult = DecryptJsonData(strData)
                lngModuleId = jsonResult("ModuleId")
                lngCustomFormId = jsonResult("FormId")
                strURL = jsonResult("URL")
                objClsSessionManager = New clsSessionManager
                objClsSessionData = objClsSessionManager.GetSessionData(HttpContext.Current.Session.SessionID, "APPDATA")

                clsBizlSysModule.SaveUserNavigationHistory(objClsSessionData.UserID, lngModuleId, lngCustomFormId, objClsSessionData.PatientID, HttpContext.Current.Session.SessionID, strURL, "", Date.Now)
                Return True
            Catch ex As Exception
                Return False
                WriteException(ex)
                Throw ex
            Finally
                objClsSessionManager = Nothing
                objClsSessionData = Nothing
                jsonResult = Nothing
            End Try
        End Function

        <WebMethod(EnableSession:=True)>
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Function fnGetTquestURL(ByVal strData As String) As String
            Dim request As HttpWebRequest
            Dim response As HttpWebResponse
            Dim jsonResponse As String = ""
            Dim paramURL As String
            Dim objBizUser As clsBizlUser
            Dim dsResult As DataSet
            Dim intUserId As Integer
            Dim PatientID As String
            Dim blnCheckLocation As Boolean
            Dim jsonResult As Object
            Dim objClsSessionData As clsSessionData
            Dim objSessionMgr As clsSessionManager
            Try
                intUserId = SiteExcelicare.GetUSRID()
                jsonResult = SiteExcelicare.DecryptJsonData(strData)
                objClsSessionData = New clsSessionData
                objSessionMgr = New clsSessionManager
                objClsSessionData = objSessionMgr.GetSessionData(HttpContext.Current.Session.SessionID, "APPDATA")
                If Not objClsSessionData Is Nothing Then
                    PatientID = objClsSessionData.PatientID
                End If
                blnCheckLocation = jsonResult("bcl")
                objBizUser = New clsBizlUser
                dsResult = objBizUser.GetTQuestICELab(intUserId, PatientID, blnCheckLocation)
                If Not dsResult Is Nothing And dsResult.Tables.Count > 0 Then
                    If dsResult.Tables(0).Rows.Count > 0 Then
                        If dsResult.Tables(0).Rows(0)("PAT_DOB").ToString <> "" And dsResult.Tables(0).Rows(0)("PAT_Forename1").ToString <> "" And dsResult.Tables(0).Rows(0)("PPA_PCode").ToString <> "" And dsResult.Tables(0).Rows(0)("PAT_Primary_Identifier").ToString <> "" Then
                            paramURL = ConfigurationManager.AppSettings("ExcelicareWebServiceURL") & "/ParamURL.svc/getURL?LibID=9250001&Token=" + m_strSessionID + "&UserID=" + m_intUserId.ToString() + "&lngPatID=" + PatientID
                            WebRequest.DefaultWebProxy = Nothing
                            request = HttpWebRequest.Create(paramURL)
                            request.Method = WebRequestMethods.Http.Get
                            response = request.GetResponse()
                            jsonResponse = New StreamReader(response.GetResponseStream()).ReadToEnd()
                            response.Close()
                            Return jsonResponse
                        Else
                            Return "NoIdentifiers"
                        End If

                    End If

                Else
                    Return ""
                End If

            Catch ex As Exception
                WriteException(ex)
                Throw ex
            Finally
                request = Nothing
                response = Nothing
                jsonResponse = Nothing
                jsonResult = Nothing
                objClsSessionData = Nothing
                objSessionMgr = Nothing
            End Try
        End Function


        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Function UpdateDisclaimer(ByVal strData As String)
            Dim oSessionManager As clsSessionManager
            Dim objClsSessionData As clsSessionData
            Dim objBizUser As clsBizlUser
            Dim intDisclaimerID As Integer
            Dim strSessionID As String
            Dim DisclaimerType_SLU As String
            Dim disclaimervalue As String
            Dim jsonResult As Object
            Try
                jsonResult = DecryptJsonData(strData)
                disclaimervalue = jsonResult("blnShowDisclaimer")
                objBizUser = New clsBizlUser
                objClsSessionData = New clsSessionData
                oSessionManager = New clsSessionManager
                strSessionID = HttpContext.Current.Session.SessionID
                objClsSessionData = oSessionManager.GetSessionData(strSessionID, "APPDATA")
                m_intUserId = objClsSessionData.UserID
                intDisclaimerID = disclaimervalue
                'If (blndisclaimer = "2") Then
                'intDisclaimerID = 1
                'DisclaimerType_SLU = "3484,3485"
                'ElseIf (blndisclaimer = "1") Then
                'intDisclaimerID = 1
                'DisclaimerType_SLU = "3484"
                'Else
                'intDisclaimerID = 0
                DisclaimerType_SLU = "3484,3485"
                'End If
                objBizUser.SaveUserDisclaimer(m_intUserId, intDisclaimerID, DisclaimerType_SLU)

            Catch ex As Exception
                WriteException(ex)
                Throw ex
            Finally
                jsonResult = Nothing
            End Try
        End Function


        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Function frmGetLabOrderURL(ByVal strData As String) As String
            Dim objBizUser As clsBizlUser
            Dim dsResult As DataSet
            Dim strDOB As String = String.Empty
            Dim strForeName As String = String.Empty
            Dim strNashNo As String = String.Empty
            Dim strPostCode As String = String.Empty
            'Dim strPhysicalPath As String = Server.MapPath("BIN/SunqQuestWebComponent.exe").Replace("\ajax", "")
            'Dim ClientWebComponent As New System.Diagnostics.Process
            'Dim startInfo As New ProcessStartInfo(strPhysicalPath)
            ''Dim status As String = ""
            Dim objWSTPSLabOrder As AxRSOrderCommunicationsClient = Nothing
            Dim strSunQuestURL As String = ""
            Dim strGender As String = ""
            Dim strPatSurname As String = ""
            Dim strOtherPatientIDType As String = ""
			Dim strPatientAddress As String = ""
            Dim strPatSecondaryIdentifier As String = ""
            Dim intUserID As Integer
            Dim lngPatientID As Integer
            Dim strSessionID As String
            Dim blnCheckLocation As Boolean = False
            Dim jsonResult As Object
            Dim objClsSessionData As clsSessionData
            Dim objSessionMgr As clsSessionManager

            Try
                intUserID = GetUSRID()
                jsonResult = DecryptJsonData(strData)
                objClsSessionData = New clsSessionData
                objSessionMgr = New clsSessionManager
                objClsSessionData = objSessionMgr.GetSessionData(HttpContext.Current.Session.SessionID, "APPDATA")
                If Not objClsSessionData Is Nothing Then
                    lngPatientID = objClsSessionData.PatientID
                End If
                'strSessionID = jsonResult("msd")
                strSessionID = HttpContext.Current.Session.SessionID
                blnCheckLocation = jsonResult("bcl")
                objBizUser = New clsBizlUser
                dsResult = objBizUser.GetSunQuestICELab(intUserID, lngPatientID, blnCheckLocation)
                If Not dsResult Is Nothing And dsResult.Tables.Count > 0 Then
                    If dsResult.Tables(0).Rows.Count > 0 Then
                        Dim dtdate As Date
                        dtdate = dsResult.Tables(0).Rows(0)("PAT_DOB")
                        strDOB = dtdate.ToString("yyyyMMdd")
                        strForeName = dsResult.Tables(0).Rows(0)("PAT_Forename1").ToString
                        strPostCode = dsResult.Tables(0).Rows(0)("PPA_PCode").ToString
                        strNashNo = dsResult.Tables(0).Rows(0)("PAT_Primary_Identifier").ToString
                        strGender = dsResult.Tables(0).Rows(0)("PAT_Sex").ToString
						strPatSurname = dsResult.Tables(0).Rows(0)("PAT_Surname").ToString	
						m_strSunQuestURL = dsResult.Tables(0).Rows(0)("ExternalURL").ToString
						strOtherPatientIDType = dsResult.Tables(0).Rows(0)("OtherPatientIDType").ToString
						strPatSecondaryIdentifier = dsResult.Tables(0).Rows(0)("PAT_Secondary_Identifier").ToString
						strPatientAddress = dsResult.Tables(0).Rows(0)("PPA_Addr1").ToString + Chr(182) + dsResult.Tables(0).Rows(0)("PPA_Addr2").ToString + Chr(182) + dsResult.Tables(0).Rows(0)("PPA_Addr3").ToString + Chr(182) + dsResult.Tables(0).Rows(0)("PPA_County").ToString + Chr(182) + dsResult.Tables(0).Rows(0)("PPA_City").ToString
                        'If strDOB <> "" And strForeName <> "" And strPostCode <> "" And strNashNo <> "" Then
					     If strDOB <> "" And strPostCode <> "" Then
                            clsECSession.LogWebSessionAction("MDI", strSessionID, lngPatientID, 2798, "Web Service - Start", 1035)
                            objWSTPSLabOrder = New AxRSOrderCommunicationsClient
                            strSessionID = strSessionID + Chr(181) + dsResult.Tables(0).Rows(0)("ExternalLab").ToString + Chr(181) + strPatSurname + Chr(181) + strOtherPatientIDType + Chr(181) + strPatSecondaryIdentifier + Chr(181) + strPatientAddress
                            strSunQuestURL = objWSTPSLabOrder.GetLabOrderURL(intUserID, strDOB, strNashNo, strForeName, strPostCode, strSessionID, strGender)
                            'fnGetLabOrderURL(intUserID, strDOB, strNashNo, strForeName, strPostCode, strSessionID, strGender)
                            If Not String.IsNullOrEmpty(strSunQuestURL) Then

                                'objWSTPSLabOrder.Close()
                                clsECSession.LogWebSessionAction("MDI", strSessionID, lngPatientID, 2799, "Web Service - End", 1035)
                                'If strSunQuestURL.StartsWith("http:") Then
                                    'strSunQuestURL = "test"
                                    'Return strSunQuestURL & Chr(181) & m_strSunQuestURL & Chr(181) & dsResult.Tables(0).Rows(0)("ExternalLab").ToString
                                'Else
                                    'strSunQuestURL = ""
                                    'Return strSunQuestURL
                                'End If
                            'Else
                                'strSunQuestURL = ""
                                'Return strSunQuestURL
								Return strSunQuestURL
                            End If
                        Else
                            strSunQuestURL = "No Identifier"
                            Return strSunQuestURL
                        End If
                    End If
                Else
                    strSunQuestURL = "False"
                    Return strSunQuestURL
                End If
            Catch ex As Exception
                LogException(ex)
                WriteException(ex)
                Throw ex
            Finally
                jsonResult = Nothing
                objClsSessionData = Nothing
                objSessionMgr = Nothing
                If Not objWSTPSLabOrder Is Nothing Then
                    If objWSTPSLabOrder.State = ServiceModel.CommunicationState.Opened Then
                        objWSTPSLabOrder.Close()
                    End If
                    If objWSTPSLabOrder.State <> ServiceModel.CommunicationState.Closed Then
                        objWSTPSLabOrder.Abort()
                    End If
                    'ClientWebComponent = Nothing
                    'startInfo = Nothing
                    objWSTPSLabOrder = Nothing
                End If
                objBizUser = Nothing
                objClsSecurity = Nothing
            End Try
        End Function

        <WebMethod(EnableSession:=True)>
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Function GetMDIQueueCount() As String
            Dim lngUserId As Long
            Dim lngPatientId As Long
            Dim jsonResult As Object
            Dim objSessionMgr As clsSessionManager
            Dim objClsSessionData As clsSessionData
            Dim objclsSecurity As clsSecurity
            'Dim Respon As String
            Try
                lngUserId = GetUSRID()
                objSessionMgr = New clsSessionManager
                objClsSessionData = New clsSessionData
                objclsSecurity = New clsSecurity
                objClsSessionData = objSessionMgr.GetSessionData(HttpContext.Current.Session.SessionID, "APPDATA")
                If Not objClsSessionData Is Nothing Then
                    lngPatientId = objClsSessionData.PatientID
                End If
                Return objclsSecurity.ECEncode(clsBizlSysModule.GetMDIQueueCount(lngUserId, lngPatientId))
            Catch ex As Exception
                WriteException(ex)
                Throw ex
            Finally
                jsonResult = Nothing
                objSessionMgr = Nothing
                objClsSessionData = Nothing
                objclsSecurity = Nothing
            End Try
        End Function


        <Ajax.AjaxMethod(HttpSessionStateRequirement.Read)>
        Public Sub logECWebSessionAction(ByVal lngEventId As Long, ByVal lngPatId As Long, ByVal strEventDet As String)
            Try
                clsECSession.LogWebSessionAction("MDI", Session.SessionID, lngPatId, lngEventId, strEventDet, 1031, 0)
            Catch ex As Exception
                clsECSession.LogWebSessionAction("MDI", HttpContext.Current.Session.SessionID, lngPatId, lngEventId, strEventDet, 1031, 0)
            End Try
        End Sub
		
       


        <WebMethod(EnableSession:=True)>
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Function GetPresAccountStatus(ByVal strData As String) As String
            Dim objWSePrescription As New Excelicare.ServiceProxy.WSPrescriptionManager.AxWSePrescriptionManagerClient
            Dim blnServiceClose As Boolean = False
            Dim strACStatus As String = ""
            Dim intUserId As Integer
            Dim intUserLocationID As Integer
            Dim jsonResult As Object
            Try
                jsonResult = DecryptJsonData(strData)
                intUserId = jsonResult("ieu")
                intUserLocationID = jsonResult("iel")
                strACStatus = objWSePrescription.GetAccountStatus(intUserId, intUserLocationID)
                objWSePrescription.Close()
                blnServiceClose = True
                Return strACStatus
            Catch ex As Exception
                LogException(ex)
                WriteException(ex)
                Throw ex
            Finally
                jsonResult = Nothing
                If blnServiceClose <> True Then
                    objWSePrescription.Abort()
                End If
                objWSePrescription = Nothing
            End Try

        End Function

        <WebMethod(enableSession:=True)> _
<Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)> _
        Public Function GetExternalURL1(ByVal intFormLibItemId As Int64) As String
            Dim objBizUser As New clsBizlSysModule
            Try
                Return objBizUser.GetExternalURL(intFormLibItemId)
            Catch ex As Exception
                LogException(ex)
            Finally

            End Try

        End Function
        <WebMethod(EnableSession:=True)>
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Function GetExternalURLFLID(ByVal strData As String) As String
            Dim objBizUser As New clsBizlUser
            Dim strExternalURLName As String
            Dim jsonResult As Object
            Try
                jsonResult = DecryptJsonData(strData)
                strExternalURLName = jsonResult("strExternalURLName")
                Return objBizUser.GetExternalURLFLID(strExternalURLName)
            Catch ex As Exception
                LogException(ex)
                WriteException(ex)
                Throw ex
            Finally
                objBizUser = Nothing
                jsonResult = Nothing
            End Try
        End Function

        <WebMethod(EnableSession:=True)>
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Function GetExternalURL(ByVal strData As String) As String
            Dim objBizUser As New clsBizlSysModule
            Try
                Dim objWebRequest As WebRequest
                Dim objWebresponse As WebResponse
                Dim dataStream As Stream
                Dim strResponseFromServer As String
                Dim JSONString As JObject
                Dim objClsBizUser As clsBizlUser
                Dim objClsSessionData As clsSessionData
                Dim oSessionManager As clsSessionManager
                Dim strSessionID As String
                Dim intFormLibItemId As Int64
                Dim lngDataID As Long
                Dim jsonResult As Object
                Try
                    jsonResult = DecryptJsonData(strData)
                    intFormLibItemId = jsonResult("intFormLibItemID")
                    lngDataID = jsonResult("lngDataID")
                    objClsBizUser = New clsBizlUser
                    objClsSessionData = New clsSessionData
                    oSessionManager = New clsSessionManager
                    strSessionID = HttpContext.Current.Session.SessionID
                    objClsSessionData = oSessionManager.GetSessionData(strSessionID, "APPDATA")
                    'JSONString = objClsBizUser.getJSONSession(intFormLibItemId, strSessionID)
                    JSONString = JObject.Parse("{}")
                    logECWebSessionAction(1, objClsSessionData.PatientID, "Calling Parameterised Service -  Begin For FormLibItem: " & intFormLibItemId & ",lngPatientID:" & objClsSessionData.PatientID & " ServiceURL: " & "" & System.Configuration.ConfigurationSettings.AppSettings.Get("ExcelicareWebServiceURL") & "/ParamURL.svc/getURL?LibID=" & intFormLibItemId & "&sessionJSON=" & JSONString.ToString & "&TransactionID=" & strSessionID & "&UserID=" & objClsSessionData.UserID & "&PatID=" & objClsSessionData.PatientID & "&DataID=" & lngDataID)
                    WriteToTrace("Calling Parameterised Service for LibID" & intFormLibItemId & ", ServiceURL: " & "" & System.Configuration.ConfigurationSettings.AppSettings.Get("ExcelicareWebServiceURL") & "/ParamURL.svc/getURL?LibID=" & intFormLibItemId & "&sessionJSON=" & JSONString.ToString & "&TransactionID=" & strSessionID & "&UserID=" & objClsSessionData.UserID & "&PatID=" & objClsSessionData.PatientID & "&DataID=" & lngDataID, "frmExcelicareMDI.aspx.vb", "started at-" + System.DateTime.Now.ToString)
                    objWebRequest = WebRequest.Create("" & System.Configuration.ConfigurationSettings.AppSettings.Get("ExcelicareWebServiceURL") & "/ParamURL.svc/getURL?LibID=" & intFormLibItemId & "&sessionJSON=" & JSONString.ToString & "&TransactionID=" & strSessionID & "&UserID=" & objClsSessionData.UserID & "&PatID=" & objClsSessionData.PatientID & "&DataID=" & lngDataID)
                    objWebresponse = objWebRequest.GetResponse()
                    dataStream = objWebresponse.GetResponseStream()
                    Dim reader As New StreamReader(dataStream)
                    strResponseFromServer = reader.ReadToEnd()
                    strResponseFromServer = strResponseFromServer.Replace("\/", "/").Replace("""", "")
                    Return strResponseFromServer
                Catch ex As WebException
                    WriteException(ex)
                    Return JObject.Parse("{""Exception"":""Exception occured during execution of Service. please contact system administrator""}")
                Catch ex As Exception
                    WriteException(ex)

                Finally
                    logECWebSessionAction(1, 0, "Calling Parameterised Service - End For FormLibItem " & intFormLibItemId & " :lngUserID:" & 0 & " - lngPatientID:" & 0)
                    WriteToTrace("Calling Parameterised Service", "frmExcelicareMDI.aspx.vb", "Ended at-" + System.DateTime.Now.ToString)
                End Try
            Catch ex As Exception
                LogException(ex)
            Finally

            End Try

        End Function
        Private Function LogException(ByVal objExcep As Exception)
            Dim objClsExceptionHandler As clsExceptionHandler
            Try
                objClsExceptionHandler = New clsExceptionHandler(objExcep)
                If Not IsNothing(Page) Then
                    objClsExceptionHandler.LogException(Page)
                Else
                    objClsExceptionHandler.LogException()
                End If
            Catch ex As Exception
                objClsExceptionHandler = New clsExceptionHandler(ex)
                If Not IsNothing(Page) Then
                    objClsExceptionHandler.LogException(Page)
                Else
                    objClsExceptionHandler.LogException()
                End If
            Finally
                objClsExceptionHandler = Nothing
            End Try
        End Function

        '<Ajax.AjaxMethod(HttpSessionStateRequirement.Read)> _
        'Public Function fnSaveArtifactDetails(ByVal lngUserID As Long, ByVal lngPatientID As Long, ByVal lngModuleID As Long) As String
        '    Dim objSSOProxy As Axsys_SSOClient
        '    '   Dim strArtifactDetails As String = ""
        '    Dim strPartnerToken As String = ""
        '    Dim strArtifactID As String = ""
        '    '  Dim strAxsysArtifacts As String = ""
        '    Dim strPartnerArtifactID As String
        '    Dim strInputMessage As String
        '    '   Dim strOutputMessage As String = String.Empty
        '    Dim strPartnerServiceURL As String = String.Empty
        '    Dim strAxsysToken As String
        '    Dim strMessageTransactionID As String
        '    Dim sessionStateSection As System.Web.Configuration.SessionStateSection = _
        '    CType(System.Configuration.ConfigurationManager.GetSection("system.web/sessionState"),  _
        '      System.Web.Configuration.SessionStateSection)
        '    Dim intSessionTimeout As Integer
        '    Dim blnServiceClose As Boolean = False
        '    Dim intUserLocationID As Integer
        '    Dim cbMedicationHistory As New AsyncCallback(AddressOf WSMedicationHistoryCallback)
        '    Dim objClsExceptionHandler As clsExceptionHandler
        '    Try
        '        logECWebSessionAction(1, lngPatientID, "SSO -  fnSaveArtifactDetails Begin:lngUserID:" & lngUserID & " - lngPatientID:" & lngPatientID)
        '        If Not HttpContext.Current.Session("PartnerToken") Is Nothing AndAlso HttpContext.Current.Session("PartnerToken") <> "" Then
        '            strPartnerToken = HttpContext.Current.Session("PartnerToken")
        '            strAxsysToken = HttpContext.Current.Session("AxsysTokenID")
        '            strPartnerArtifactID = IIf(HttpContext.Current.Session("PartnerArtifactID") Is Nothing, "", HttpContext.Current.Session("PartnerArtifactID"))
        '            objSSOProxy = New Axsys_SSOClient
        '            strArtifactID = objSSOProxy.SaveArtifactDetails(strAxsysToken, lngPatientID.ToString, HttpContext.Current.Session.SessionID, lngUserID, lngModuleID, HttpContext.Current.Session("eRxMessageTransactionID"))
        '            objSSOProxy.Close()

        '            strMessageTransactionID = HttpContext.Current.Session("eRxMessageTransactionID")
        '            intSessionTimeout = sessionStateSection.Timeout.TotalMinutes
        '            intUserLocationID = HttpContext.Current.Session("eRxAccountLocationID")
        '            m_objWSePrescribing = New WSPrescriptionManager.AxWSePrescriptionManagerClient
        '            strInputMessage = "<SendPartnerArtifact>" & _
        '                                  "<Token>" & strPartnerToken & "</Token>" & _
        '                                  "<ArtifactID>" & strArtifactID & "</ArtifactID>" & _
        '                                  "<PartnerArtifactID>" & strPartnerArtifactID & "</PartnerArtifactID>" & _
        '                              "</SendPartnerArtifact>"
        '            strPartnerServiceURL = HttpContext.Current.Session("PartnerServiceURL")
        '            m_objWSePrescribing.BeginGetPatientFullMedicationHistory(lngPatientID.ToString, lngUserID, intSessionTimeout, strMessageTransactionID, intUserLocationID, True, strInputMessage, strPartnerServiceURL, cbMedicationHistory, New Object) 'strNotArchived, strCompletedPrescription)

        '            blnServiceClose = True

        '        End If
        '        logECWebSessionAction(1, lngPatientID, "SSO -  fnSaveArtifactDetails End: strArtifactID:" & strArtifactID)
        '    Catch ex As Exception
        '        logECWebSessionAction(1, lngPatientID, "SSO -  fnSaveArtifactDetails Catch: Exception:" & ex.Message)
        '        objClsExceptionHandler = New clsExceptionHandler(ex)
        '        objClsExceptionHandler.LogException()
        '    Finally
        '        objSSOProxy = Nothing
        '        If blnServiceClose = False Then
        '            m_objWSePrescribing.Abort()
        '        End If
        '    End Try
        '    Return ""
        'End Function
        '*************************************************************************************************************
        'Purpose            :   This method is used to get the Lab order URL
        'Layer	            :   Service
        'Method Name        :	GetLabOrderURL
        'Input Parameters   :   UserID,ECSessionID,PatientDetailsXml
        'Return Values      :   strReturnMsg
        '---------------------------------------------------------------------------------------
        'Version    Author                  Date                             Remarks      
        '---------------------------------------------------------------------------------------
        '1.0.0.1	SwethaK         04-JUN-2013                Initial Implementation.                                    
        '************************************************************************************************************
        'Public Function fnGetLabOrderURL(ByVal UserID As Int64, ByVal DOB As String, _
        '                                 ByVal NashNo As String, ByVal Forename As String, _
        '                                 ByVal Postcode As String, ByVal ECSessionID As String, ByVal strGender As String) As String

        '    Dim strReturnMsg As String = String.Empty
        '    Dim strMethodName As String = String.Empty
        '    Dim objOrderData As clsOrderData
        '    'Dim objEPAck As clsEPAcknowledgment = Nothing
        '    Dim objProperties As clsLabOrderProperties = Nothing
        '    Dim LogMsgId As Int64 = -1
        '    Dim intIsMsgStatusSuccess As Int16 = 1
        '    Dim strtemp() As String = Nothing
        '    Dim strDesc As String = String.Empty

        '    Try

        '        objProperties = New clsLabOrderProperties

        '        If UserID > 0 OrElse DOB <> "" OrElse NashNo <> "" OrElse Forename <> "" OrElse Postcode <> "" OrElse ECSessionID.Trim <> "" Then

        '            objProperties.ECUserId = UserID
        '            objProperties.DOB = DOB
        '            objProperties.NashNo = NashNo
        '            objProperties.Forename = Forename
        '            objProperties.PostCode = Postcode
        '            objProperties.ECSessionID = ECSessionID
        '            objProperties.Sex = strGender
        '            objOrderData = New clsOrderData
        '            strReturnMsg = objOrderData.GetLabOrderURL(objProperties)

        '            'strReturnMsg = "<Acknowledgement><Status>" + Convert.ToString(objEPAck.Status) + "</Status>" _
        '            '      & "<Code>" + Convert.ToString(objEPAck.Code) + "</Code>" _
        '            '      & "<Description>" + objEPAck.Description + "</Description>" _
        '            '      & "<NotifySeverity>" + Convert.ToString(objEPAck.NotifySeverity) + "</NotifySeverity>" _
        '            '      & "<ReturnValue>" + objEPAck.ReturnValue + "</ReturnValue></Acknowledgement>"

        '            Return strReturnMsg

        '        Else
        '            Throw New Exception("Expected input parameter are not received, please recheck the input parameter.")
        '        End If

        '    Catch ex As Exception
        '        LogException(ex)

        '    Finally

        '        If Not objProperties Is Nothing Then
        '            objProperties.Dispose()
        '            objProperties = Nothing
        '        End If
        '    End Try
        'End Function
        ''----------------------------------------------------------------------------------------
        '' <summary>To close the service connection </summary>
        '' <history>
        '' Version           Author                Date           Remarks
        '' 4.0               K Pradeep             23.12.2009
        '' </history>
        '' ---------------------------------------------------------------------------------------
        Sub WSMedicationHistoryCallback()
            Dim objClsExceptionHandler As clsExceptionHandler
            Try
                If IsNothing(m_objWSePrescribing) = False Then
                    m_objWSePrescribing.Close() ' closing the service connection after saving is completed
                End If
                LogOff(1)
            Catch ex As Exception
                objClsExceptionHandler = New clsExceptionHandler(ex)
                objClsExceptionHandler.LogException()   ' Writing log for Exception occured
            End Try
        End Sub
        Public Sub WriteException(ByVal ex As Exception)
            Dim objClsExceptionHandler As New clsExceptionHandler(ex)
            objClsExceptionHandler.LogException(Page)
            objClsExceptionHandler = Nothing
        End Sub
        Public Function WriteToTrace(ByVal strProcName As String, ByVal strPageName As String, ByVal strMessage As String)
            Dim strTraceFile As String
            Dim strCanWrite As String
            Dim objTraceFile As System.IO.StreamWriter
            Dim strMessageFooter As String
            Try
                strCanWrite = System.Configuration.ConfigurationSettings.AppSettings.Get("IsTraceWriteToFile")

                If Not strMessage Is Nothing Then
                    If strCanWrite.ToUpper = "TRUE" And strMessage <> "" Then
                        strTraceFile = HttpContext.Current.Request.PhysicalApplicationPath & System.Configuration.ConfigurationSettings.AppSettings.Get("TraceFileName")
                        objTraceFile = New System.IO.StreamWriter(strTraceFile, True)
                        strMessageFooter = vbCrLf
                        objTraceFile.Write("Form Name:" & strPageName & " | Method Name: " & strProcName & " | " & strMessage)
                        objTraceFile.Write(strMessageFooter)
                    End If
                End If
            Catch ex As Exception
            Finally
                If Not objTraceFile Is Nothing Then
                    objTraceFile.Flush()
                    objTraceFile.Close()
                End If
                strTraceFile = Nothing
                strCanWrite = Nothing
                strMessageFooter = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '      This is used to delete the other store XML file created in the curent user session 
        ' </summary>
        ' <returns></returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Krishna Prasad S]    25/03/2015  Created
        ' </history>
       ' -----------------------------------------------------------------------------
        Private Sub DeleteOtherStoreFiles()
            Try
                If Not ConfigurationManager.AppSettings("OSPatientFilePath") Is Nothing Then
                    If ConfigurationManager.AppSettings("OSPatientFilePath").ToString <> "" Then
                        Dim strOSPath As String = ConfigurationManager.AppSettings("OSPatientFilePath").ToString
                        If strOSPath <> "" Then
                            If strOSPath.Substring(strOSPath.Length - 1) <> "/" Or strOSPath.Substring(strOSPath.Length - 1) <> "\" Then
                                strOSPath = strOSPath & "\" & "OSPatientData_" & HttpContext.Current.Session.SessionID & ".XML"
                            End If
                            If File.Exists(strOSPath) Then
                                File.Delete(strOSPath)
                            End If
                        End If
                    End If
                End If
            Catch ex As Exception
                LogException(ex)
            Finally
            End Try
        End Sub

        Public Function fnGetMenuItemdeatails() As String
            Dim request As HttpWebRequest
            Dim response As HttpWebResponse
            Dim jsonResponse As String = ""
            Try
                If Not ConfigurationSettings.AppSettings("RestServiceURL") Is Nothing AndAlso ConfigurationSettings.AppSettings("RestServiceURL").ToString() <> "" Then
                    WebRequest.DefaultWebProxy = Nothing
                    request = HttpWebRequest.Create(ConfigurationSettings.AppSettings("RestServiceURL") + "GetAppMenuList?TokenNo=Access&ActionText=AppMenu&ActionColumn=FreeText")
                    request.Method = WebRequestMethods.Http.Get
                    response = request.GetResponse()
                    jsonResponse = New StreamReader(response.GetResponseStream()).ReadToEnd()
                    response.Close()
                End If
                Return jsonResponse
            Catch ex As Exception
                Throw ex
            Finally
                request = Nothing
                response = Nothing
                jsonResponse = Nothing
            End Try

        End Function

        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Function GetSysActionMenuItems(ByVal strData As String) As String
            Dim objBizUser As clsBizlSysModule
            Dim strMenuString As String = "{"
            Dim dsMenuItemDataset As DataSet = New DataSet
            Dim intIndex As Integer = 0
            Dim strMenuGroupItemName As String
            Dim strActionName As String
            Dim jsonResult As Object
            Dim objclssecurity As clsSecurity
            Try
                objclssecurity = New clsSecurity
                jsonResult = DecryptJsonData(strData)
                strMenuGroupItemName = jsonResult("strMenuGroupItemName")
                strActionName = jsonResult("strActionName")
                objBizUser = New clsBizlSysModule
                dsMenuItemDataset = objBizUser.GetSysActionMenuItems(strMenuGroupItemName, strActionName)
                If Not dsMenuItemDataset Is Nothing Then
                    For intIndex = 0 To dsMenuItemDataset.Tables(0).Rows.Count - 1
                        If intIndex > 0 Then
                            strMenuString = strMenuString & ","
                        End If
                        strMenuString = strMenuString & """" & intIndex.ToString & """" & ":{ ""name"": """ & dsMenuItemDataset.Tables(0).Rows(intIndex).Item("Caption") & """,""callback"": """ & dsMenuItemDataset.Tables(0).Rows(intIndex).Item("Action") & """}"
                    Next
                    strMenuString = strMenuString & "}"
                    Return objclssecurity.ECEncode(strMenuString)
                Else
                    Return ""
                End If
            Catch ex As Exception
                WriteException(ex)
                Throw ex
            Finally
                objBizUser = Nothing
                jsonResult = Nothing
            End Try

        End Function

        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Function fnSaveMessageTrayItems(ByVal strData As String) As String
            Dim objBizPatient As clsBizlPatient
            Dim intIndex As Integer = 0
            Dim objjsonMsgItem As Object
            Dim strResultValue As String = ""
            Dim lngPatientID As Long
            Dim lngUserID As Long
            Dim objSessionData As clsSessionData
            Dim objclsSecurity As clsSecurity
            Dim objClsSessionManager As clsSessionManager
            Dim arrMsgItems As String
            Try
                objclsSecurity = New clsSecurity
                arrMsgItems = objclsSecurity.DecryptData(strData)
                objClsSessionManager = New clsSessionManager
                objSessionData = New clsSessionData
                objSessionData = objClsSessionManager.GetSessionData(HttpContext.Current.Session.SessionID, "APPDATA")
                If Not objSessionData Is Nothing Then
                    lngUserID = objSessionData.UserID
                    lngPatientID = objSessionData.PatientID
                End If
                objBizPatient = New clsBizlPatient
                objjsonMsgItem = JsonConvert.DeserializeObject(arrMsgItems)
                If objjsonMsgItem.count > 0 Then
                    strResultValue = objBizPatient.fnSaveMessageTrayItems(objjsonMsgItem, lngPatientID, lngUserID)
                End If
                Return strResultValue
            Catch ex As Exception
                WriteException(ex)
                Throw ex
            Finally
                objBizPatient = Nothing
                objClsSessionManager = Nothing
                objclsSecurity = Nothing
                objSessionData = Nothing
            End Try
        End Function

        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Function GetMessageTrayCount() As Integer
            Dim objBizPatient As clsBizlPatient
            Dim intMsgTrayCount As Integer = 0
            Dim lngPatientID As Long
            Dim lngUserID As Long
            Dim objClsSessionManager As clsSessionManager
            Dim objSessionData As clsSessionData
            Try
                objClsSessionManager = New clsSessionManager
                objSessionData = New clsSessionData
                objSessionData = objClsSessionManager.GetSessionData(HttpContext.Current.Session.SessionID, "APPDATA")
                If Not objSessionData Is Nothing Then
                    lngUserID = objSessionData.UserID
                    lngPatientID = objSessionData.PatientID
                End If
                objBizPatient = New clsBizlPatient
                intMsgTrayCount = objBizPatient.GetMessageTrayCount(lngPatientID, lngUserID)
                Return intMsgTrayCount
            Catch ex As Exception
                WriteException(ex)
                Throw ex
            Finally
                objBizPatient = Nothing
                objClsSessionManager = Nothing
                objSessionData = Nothing
            End Try
        End Function

        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Function fnDeleteMessageTrayItems(ByVal strData As String) As Integer
            Dim objBizPatient As clsBizlPatient
            Dim intMsgCount As Integer = 0
            Dim strUniqueID As String
            Dim intMsgType_LU As Integer
            Dim jsonResult As Object
            Try
                jsonResult = DecryptJsonData(strData)
                strUniqueID = jsonResult("strUniqueID")
                intMsgType_LU = jsonResult("intMsgType")
                objBizPatient = New clsBizlPatient
                If strUniqueID <> "" Then
                    intMsgCount = objBizPatient.fnDeleteMessageTrayItems(strUniqueID, intMsgType_LU)
                End If
                Return intMsgCount
            Catch ex As Exception
                WriteException(ex)
                Throw ex
            Finally
                objBizPatient = Nothing
                jsonResult = Nothing
            End Try
        End Function

        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Function fnAppUnLockCarePlan(ByVal strData As String) As String
            Dim jsonResult As Object
            Dim strname As String = ""
            Dim intUserId As Integer
            Try
                jsonResult = DecryptJsonData(strData)
                strname = jsonResult("strname")
                intUserId = GetUSRID()
                fnUnLockCarePlan(strname, intUserId)
            Catch ex As Exception
                Throw ex
            Finally
                jsonResult = Nothing
            End Try
        End Function
        '***********************************************************************************************************************
        'Purpose            :   To Clear the Session in Care Plan Module   termination is in abnormal 
        'Method Name        :   fnUnLockCarePlan
        'Input Parameters   :   strname
        'Return Values      :   
        '-----------------------------------------------------------------------------------------------------------------------
        'Version        Author                              Date                            Remarks
        '-----------------------------------------------------------------------------------------------------------------------
        '6.5.0002        seshukumar                           21/02/2017
        '***********************************************************************************************************************

        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Function fnUnLockCarePlan(ByVal strname As String, ByVal intUserId As Integer) As String
            Dim objClsSessionData As clsSessionData
            Dim objClsSessionManager As clsSessionManager
            Dim objCarePlanService As New AxRSCarePlanTemplate.AxRSCarePlanTemplateClient
            Try
                objClsSessionManager = New clsSessionManager
                objClsSessionData = objClsSessionManager.GetSessionData(HttpContext.Current.Session.SessionID, "APPDATA")
                If Not objClsSessionData Is Nothing Then
                    objCarePlanService.fnUnLockTemplate(-1, objClsSessionData.UserID, HttpContext.Current.Session.SessionID, strname, objClsSessionData.PatientID)
                Else
                    objCarePlanService.fnUnLockTemplate(-1, intUserId, HttpContext.Current.Session.SessionID, strname, -1)
                End If
            Catch ex As Exception
                WriteException(ex)
                Throw ex
            Finally
                'HttpContext.Current.Session.Clear()
                'HttpContext.Current.Session.RemoveAll()
                'HttpContext.Current.Session.Abandon()
                objClsSessionManager = Nothing
                objClsSessionData = Nothing
                objCarePlanService = Nothing
            End Try
        End Function

<Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)> _
        Public Function fnSaveBrowserRequestLogs(userId As Integer, strModule As String, strRequest As String, strVersion As String, intHttpStatus As Integer, strExecutedAt As String) As Integer

            Dim objBizUser As clsBizlUser
            Try
                objBizUser = New clsBizlUser
                objBizUser.SaveBrowserRequestLogs(HttpContext.Current.Session.SessionID, userId, HttpContext.Current.Request.UserHostName, HttpContext.Current.Request.UserHostAddress, strModule, strRequest, strVersion, intHttpStatus, strExecutedAt)
                Return 1
            Catch ex As Exception
                Return 0
            Finally
                objBizUser = Nothing
            End Try
        End Function
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Sub fnDeleteRequestLog()
            Dim objBizUser As clsBizlUser
            Dim jss As New JavaScriptSerializer
            Try
                objBizUser = New clsBizlUser
                objBizUser.DeleteRequestLogs(HttpContext.Current.Session.SessionID)
            Catch ex As Exception
                Throw ex
            Finally
                objBizUser = Nothing
            End Try
        End Sub
        ' -----------------------------------------------------------------------------------------------
        ' <summary>
        '   Deletes the cob ids from consultationobject which are not saved to patientmediafs due to erros or logoff
        ' </summary>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      Shireesha    19-Mar-2020   Created    
        ' </history>
        ' -----------------------------------------------------------------------------------------------
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Function DeleteFailedMediaEntries(ByVal strData As String) As Boolean
            Dim objBizUser As clsBizlUser
            Dim jss As New JavaScriptSerializer
            Dim strCobIDs As String
            Dim jsonResult As Object
            Try
                jsonResult = DecryptJsonData(strData)
                strCobIDs = jsonResult("strCobIds")
                objBizUser = New clsBizlUser
                objBizUser.DeleteFailedMediaEntries(strCobIDs)
            Catch ex As Exception
                'WriteException(ex)
                Throw ex
            Finally
                objBizUser = Nothing
                jsonResult = Nothing
            End Try
        End Function
        '************************************************************************************************************
        ' -----------------------------------------------------------------------------------------------
        ' <summary>
        '   this will write trace to large media trace.
        ' </summary>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      Shireesha    19-Mar-2020   Created    
        ' </history>
        ' -----------------------------------------------------------------------------------------------
        '************************************************************************************************************
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Sub LogLargeMediaTrace(ByVal strData As String)
            Dim strTraceFile As String
            Dim strCanWrite As String
            Dim objTraceFile As System.IO.StreamWriter = Nothing
            Dim strMessage As String
            Dim jsonResult As Object

            Try
                jsonResult = DecryptJsonData(strData)
                strMessage = jsonResult("strMessage")
                strCanWrite = System.Configuration.ConfigurationSettings.AppSettings.Get("IsTraceWriteToFile")

                If Not strMessage Is Nothing AndAlso Not strCanWrite Is Nothing Then
                    If strCanWrite.ToUpper = "TRUE" And strMessage <> "" Then
                        strTraceFile = AppDomain.CurrentDomain.BaseDirectory & "\" & System.Configuration.ConfigurationSettings.AppSettings.Get("TraceFileName")
                        objTraceFile = New System.IO.StreamWriter(strTraceFile, True)
                        objTraceFile.Write(strMessage & Date.Now.TimeOfDay.ToString() & vbCrLf)
                    End If
                End If
            Catch ex As Exception
                LogException(ex)
                WriteException(ex)
                Throw ex
            Finally
                If Not objTraceFile Is Nothing Then
                    objTraceFile.Flush()
                    objTraceFile.Close()
                End If
                strTraceFile = Nothing
                strCanWrite = Nothing
                jsonResult = Nothing

            End Try
        End Sub
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.Read)>
        Public Function AxSysF_fnShowRioSummary(ByVal strData As String) As String
            Dim strHtmlFileName As String = ""
            Dim strAxServerTempFolder As String = ""
            Dim strRioHTML As String = ""
            Dim jsonResult As Object
            Try
                jsonResult = DecryptJsonData(strData)
                strRioHTML = jsonResult("rht").ToString
                '   strRioHTML = HttpUtility.UrlDecode(strRioHTML)
                strHtmlFileName = HttpContext.Current.Session.SessionID & "_RIOSummary.html"
                strAxServerTempFolder = ConfigurationSettings.AppSettings("AxServerTempFolder") & HttpContext.Current.Session.SessionID & "\MDI\"
                If Not IO.Directory.Exists(strAxServerTempFolder) Then
                    IO.Directory.CreateDirectory(strAxServerTempFolder)
                End If
                If IO.File.Exists(strAxServerTempFolder & strHtmlFileName) Then
                    IO.File.Delete(strAxServerTempFolder & strHtmlFileName)
                End If
                Dim sw As New System.IO.StreamWriter(strAxServerTempFolder & strHtmlFileName, True)
                sw.WriteLine(strRioHTML)
                sw.Close()
                Return ConfigurationSettings.AppSettings("AxServerTempURL") & HttpContext.Current.Session.SessionID & "/MDI/" & strHtmlFileName
            Catch ex As Exception
                WriteException(ex)
                Throw ex
            Finally
                jsonResult = Nothing
            End Try
        End Function
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.Read)>
        Public Function AxSysF_fnSaveRioAlerts(ByVal strData As String) As String
            Dim objClsBizlPatient As clsBizlPatient
            Dim objClsSecurity As New clsSecurity
            Dim intPatID As Integer
            Dim intMode As Integer
            Dim jsonResult As Object
            Try
                jsonResult = DecryptJsonData(strData)
                intPatID = jsonResult("spi")
                intMode = jsonResult("imd")
                objClsBizlPatient = New clsBizlPatient
                objClsBizlPatient.fnSaveRioAlerts(intPatID, intMode)
                Return "Success"
            Catch ex As Exception
                WriteException(ex)
                LogException(ex)
                Throw ex
            Finally
                objClsBizlPatient = Nothing
                jsonResult = Nothing
            End Try
        End Function
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Function GetPdlCount(ByVal strData As String) As Integer
            Dim intModuleId As Integer
            Dim intRecordId As Integer
            Dim intPatientId As Integer
            Dim intCustomFormId As Integer
            Dim intUserId As Integer
            Dim jsonResult As Object
            Dim objSessionMgr As clsSessionManager
            Dim objClsSessionData As clsSessionData
            Try
                jsonResult = DecryptJsonData(strData)
                objSessionMgr = New clsSessionManager
                objClsSessionData = New clsSessionData
                objClsSessionData = objSessionMgr.GetSessionData(HttpContext.Current.Session.SessionID, "APPDATA")
                If Not objClsSessionData Is Nothing Then
                    intPatientId = objClsSessionData.PatientID
                End If
                intModuleId = jsonResult("mid")
                intRecordId = jsonResult("rid")
                intCustomFormId = jsonResult("cid")
                intUserId = GetUSRID()
                Return clsCommon.GetPdlCount(intModuleId, intRecordId, intPatientId, intCustomFormId, intUserId)
            Catch ex As Exception
                LogException(ex)
            Finally
                objSessionMgr = Nothing
                objClsSessionData = Nothing
                jsonResult = Nothing
            End Try
        End Function

        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Function IsSessionActive(ByVal strData As String) As Boolean
            Dim strSession As String
            Dim jsonResult As Object
            Try
                jsonResult = DecryptJsonData(strData)
                strSession = jsonResult("ssi")
                If (HttpContext.Current.Session.SessionID <> strSession) OrElse Not fnSessionExist(strSession) Then
                    HttpContext.Current.Session("LoginForced") = 1
                    Return "true"
                Else
                    Return "false"
                End If
            Catch ex As Exception
                'LogException(ex)
                'WriteException(ex)
                Throw ex
            Finally
                jsonResult = Nothing
            End Try
        End Function

        Private Function fnSessionExist(ByVal strSession As String) As Boolean
            Dim objClsSessionManager As clsSessionManager
            Try
                objClsSessionManager = New clsSessionManager
                If objClsSessionManager.IsSessionExists(strSession) Then
                    Return True
                Else
                    Return False
                End If
            Catch ex As Exception
                LogException(ex)
            Finally
                objClsSessionManager = Nothing
            End Try
        End Function

        Public Shared Function GetUSRID() As String
            Dim objClsSessionManager As clsSessionManager
            Dim objSessionData As clsSessionData
            Dim lngUsrid As Long = 0
            Try
                objClsSessionManager = New clsSessionManager
                objSessionData = New clsSessionData
                objSessionData = objClsSessionManager.GetSessionData(HttpContext.Current.Session.SessionID, "APPDATA")
                If Not objSessionData Is Nothing Then
                    lngUsrid = objSessionData.UserID
                End If
            Catch ex As Exception
                lngUsrid = -1
            Finally
                objClsSessionManager = Nothing
                objSessionData = Nothing
            End Try
            Return lngUsrid
        End Function

        Public Shared Function DecryptJsonData(ByVal strData As String) As Object
            Dim strEncData As String
            Dim objSecurity As clsSecurity
            Try
                objSecurity = New clsSecurity
                strEncData = objSecurity.DecryptData(strData)
                Return JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(strEncData)
            Catch ex As Exception
                Throw ex
            Finally
                objSecurity = Nothing
            End Try
        End Function

        ''' <summary>
        ''' Method to validate the data before sending Welcome package to patient
        ''' </summary>
        ''' <returns></returns>
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Function fnValidateBeforeSendingWelcomePackage() As String
            Dim lngPatientID As Long
            Dim objClsSessionManager As clsSessionManager
            Dim objSessionData As clsSessionData
            Dim objClsPatient As clsPatient
            Try
                objClsSessionManager = New clsSessionManager
                objSessionData = New clsSessionData
                objSessionData = objClsSessionManager.GetSessionData(HttpContext.Current.Session.SessionID, "APPDATA")
                If Not objSessionData Is Nothing Then
                    lngPatientID = objSessionData.PatientID
                End If
                objClsPatient = New clsPatient()
                Return objClsPatient.fnValidateBeforeSendingWelcomePackage(lngPatientID)
            Catch ex As Exception
                LogException(ex)
            Finally
                objClsSessionManager = Nothing
                objSessionData = Nothing
                objClsPatient = Nothing
            End Try
        End Function
	
        ''' <summary>
        ''' To get WelcomePackageTemplate from DB
        ''' </summary>
        ''' <returns></returns>
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Function GetWelcomePackage() As String
            Dim objClsPatient As clsPatient
            Dim strMaliTemplate As String
            Dim strImageFilePath As String
            Dim sWriter As StreamWriter
            Try
                objClsPatient = New clsPatient
                logECWebSessionAction(2729, -1, "Getting patient welcome package - start")
                strImageFilePath = AppSettings("AxServerTempFolder") & HttpContext.Current.Session.SessionID & "\" & "Template" & "\"
                strWelcomePackageFilePath = strImageFilePath & "PatientWelcomePackage.html"
                If Not File.Exists(strWelcomePackageFilePath) Then
                    strMaliTemplate = objClsPatient.GetWelcomePackage()
                    If strMaliTemplate = "" Then
                        Return strMaliTemplate
                    End If
                    If Not Directory.Exists(strImageFilePath) Then
                        Directory.CreateDirectory(strImageFilePath)
                    End If
                    If Not File.Exists(strWelcomePackageFilePath) Then
                        sWriter = New StreamWriter(strWelcomePackageFilePath, True)
                        sWriter.WriteLine(strMaliTemplate)
                        sWriter.Close()
                    End If
                End If
                logECWebSessionAction(2730, -1, "Getting patient welcome package - successfully")
                Return (AppSettings("AxServerTempURL") & HttpContext.Current.Session.SessionID & "/" & "Template" & "/" & "PatientWelcomePackage.html")
            Catch ex As Exception
                LogException(ex)
                Return "Exception"
            Finally
                objClsPatient = Nothing
                strMaliTemplate = Nothing
                strImageFilePath = Nothing
                sWriter = Nothing
            End Try
        End Function
	
        ''' <summary>
        ''' To Send WelcomePackageTemplate to Patient
        ''' </summary>
        ''' <param name="strHTML"></param>
        ''' <returns>"1" or "0"</returns>
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Function SendWelcomePackage(ByVal strHTML As String) As String
            Dim strImageFilePath As String = String.Empty
            Dim objPDFCreator As New Excelicare.AxPDFCreator.clsPDFCreator
            Dim baseURL As String = String.Empty
            Dim bytWelcomePackage As Byte()
            Dim objClsCommon As clsCommon
            Dim lngPatientID As Long
            Dim lngUsrID As Long
            Dim objClsSessionManager As clsSessionManager
            Dim objSessionData As clsSessionData
            Dim objClsPatient As clsPatient
            Try
                objClsCommon = New clsCommon
                objClsPatient = New clsPatient
                objClsSessionManager = New clsSessionManager
                objSessionData = New clsSessionData
                objSessionData = objClsSessionManager.GetSessionData(HttpContext.Current.Session.SessionID, "APPDATA")
                logECWebSessionAction(2731, -1, "Send welcome package - start")
                strImageFilePath = AppSettings("AxServerTempFolder") & HttpContext.Current.Session.SessionID & "\" & "Template" & "\"
                If Not Directory.Exists(strImageFilePath) Then
                    Directory.CreateDirectory(strImageFilePath)
                End If
                If Not AppSettings("InternalURL") Is Nothing Then
                    baseURL = AppSettings("InternalURL")
                End If
                objPDFCreator.PDFFilePath = strImageFilePath & "PatientWelcomePackage.pdf"
                objPDFCreator.CertificatePath = System.IO.Path.Combine(HttpContext.Current.Server.MapPath("../AxCommon/Certificates/"), "Axsys.pfx")
                objPDFCreator.IgnoreHeader = True
                objPDFCreator.GetPrintFromHTMLText(strHTML, baseURL)
                bytWelcomePackage = objClsCommon.ConvertFiletoStream(strImageFilePath & "PatientWelcomePackage.pdf")
                If Not objSessionData Is Nothing Then
                    lngPatientID = objSessionData.PatientID
                    lngUsrID = objSessionData.UserID
                End If
                logECWebSessionAction(2732, -1, "Welcome package sent")
                Return objClsPatient.SendWelcomePackage(lngUsrID, lngPatientID, bytWelcomePackage)
            Catch ex As Exception
                LogException(ex)
                logECWebSessionAction(2732, -1, "exception while sending")
                Return "0"
            Finally
                strImageFilePath = baseURL = Nothing
                objPDFCreator = Nothing
                baseURL = Nothing
                bytWelcomePackage = Nothing
                objClsCommon = Nothing
                lngPatientID = lngUsrID = Nothing
                objClsSessionManager = Nothing
                objSessionData = Nothing
                objClsPatient = Nothing
            End Try
        End Function

        '***********************************************************************************************************************
        'Purpose            :   To get DropDown items
        'Method Name        :   GetItemsforUserDropDown
        'Input Parameters   :   
        'Return Values      :   
        '-----------------------------------------------------------------------------------------------------------------------
        'Version        Author                              Date                            Remarks
        '-----------------------------------------------------------------------------------------------------------------------
        '7.5            RK                              25/04/2022                    Initial Implementation       
        '***********************************************************************************************************************
        Public Sub GetItemsforUserDropDown()
            Dim objBizUser As clsBizlSysModule
            Dim lngUserID As Long
            Try
                objBizUser = New clsBizlSysModule
                lngUserID = GetUSRID()
                strUserDropDown_Lookup = objBizUser.GetItemsforUserDropDown(lngUserID, intUserRole)
                strUserDropDown_Lookup = strUserDropDown_Lookup.Replace("'", "\'\")
            Catch ex As Exception
                LogException(ex)
            Finally
                lngUserID = Nothing
                objBizUser = Nothing
            End Try
        End Sub

        ''' <summary>
        ''' To validate password with password settings
        ''' </summary>
        ''' <param name="strpassword"></param>
        ''' <returns></returns>
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Function fnValidatePwdSetting(ByVal strpassword As String) As String
            Dim objBizUser As clsBizlUser
            Dim dsPasswordSettings As DataSet
            Dim strLAlphaCharsPattern As String = "[a-z]+"
            Dim strUAlphaCharsPattern As String = "[A-Z]+"
            Dim strNumCharsPattern As String = "[0-9]+"
            Dim strNonAlphaNumericpattern As String = "[^a-zA-Z0-9]+"
            Dim intTotalUpperCaseLetters As Int64 = 0
            Dim intTotalLowerCaseLetters As Int64 = 0
            Dim intTotalNumericCharacters As Int64 = 0
            Dim intTotalNonAlphaNumericCharacters As Int64 = 0
            Dim strLAlphaChars As MatchCollection = Nothing
            Dim strUAlphaChars As MatchCollection = Nothing
            Dim strNumChars As MatchCollection = Nothing
            Dim strTotalNonAlphaNumericCharacters As MatchCollection = Nothing
            Dim intTotalAlphaChars As Int64 = 0
            Dim lngUserID As Long

            Try
                lngUserID = GetUSRID()
                objBizUser = New clsBizlUser
                dsPasswordSettings = objBizUser.fnUserPwdSettigs(lngUserID)
                If strpassword.Length < dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("MinimumCharacters") Then
                    Return "The Password length must be greater than or equal to " & dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("MinimumCharacters") & "."
                ElseIf strpassword.Length > dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("MaximumCharacters") Then
                    Return "The Password length must be less than or equal to " & dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("MaximumCharacters") & "."
                End If
                strLAlphaChars = Regex.Matches(strpassword, strLAlphaCharsPattern)
                If strLAlphaChars IsNot Nothing AndAlso strLAlphaChars.Count > 0 Then
                    For Each ItemMatch As Match In strLAlphaChars
                        intTotalLowerCaseLetters = intTotalLowerCaseLetters + ItemMatch.ToString.Length
                    Next
                End If
                strUAlphaChars = Regex.Matches(strpassword, strUAlphaCharsPattern)
                If strUAlphaChars IsNot Nothing AndAlso strUAlphaChars.Count > 0 Then
                    For Each ItemMatch As Match In strUAlphaChars
                        intTotalUpperCaseLetters = intTotalUpperCaseLetters + ItemMatch.ToString.Length
                    Next
                End If
                intTotalAlphaChars = intTotalLowerCaseLetters + intTotalUpperCaseLetters
                If dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("IsAlphaOnly") <> False Then
                    If intTotalAlphaChars < dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("MinAlphaChars") Then
                        Return "The Password entered should contain at least " & dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("MinAlphaChars") & " Alpha Characters."
                    End If
                End If
                If dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("IsNumeric") <> False Then
                    strNumChars = Regex.Matches(strpassword, strNumCharsPattern)
                    If strNumChars IsNot Nothing AndAlso strNumChars.Count > 0 Then
                        For Each ItemMatch As Match In strNumChars
                            intTotalNumericCharacters = intTotalNumericCharacters + ItemMatch.ToString.Length
                        Next
                    End If
                    If intTotalNumericCharacters < dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("MinNumChars") Then
                        Return "The Password entered should contain at least " & dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("MinNumChars") & " Numeric Characters."
                    End If
                End If
                If dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("IsNonAlphanumeric") <> False Then
                    strTotalNonAlphaNumericCharacters = Regex.Matches(strpassword, strNonAlphaNumericpattern)
                    If strTotalNonAlphaNumericCharacters IsNot Nothing AndAlso strTotalNonAlphaNumericCharacters.Count > 0 Then
                        For Each ItemMatch As Match In strTotalNonAlphaNumericCharacters
                            intTotalNonAlphaNumericCharacters = intTotalNonAlphaNumericCharacters + ItemMatch.ToString.Length
                        Next
                    End If
                    If intTotalNonAlphaNumericCharacters < dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("MinNonAlphaChars") Then
                        Return "The Password entered should contain at least " & dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("MinNonAlphaChars") & " Non-alphanumeric Characters."
                    End If
                End If
                If dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("IsUCaseCharMandatory") <> False Then
                    If intTotalUpperCaseLetters < dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("MinUCaseChars") Then
                        Return "The Password entered should contain at least " & dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("MinUCaseChars") & " Upper Case Character."
                    End If
                End If
                If dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("IsLCaseCharMandatory") <> False Then
                    If intTotalLowerCaseLetters < dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("MinLCaseChars") Then
                        Return "The Password entered should contain at least " & dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("MinLCaseChars") & " Lower Case Characters."
                    End If
                End If
                If dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("IsConsAlphaCharAllowed") <> False Then
                    Dim strRestrictConsAlphaCharPattern As String = "[a-zA-Z]{" & (dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("MaxConsecutiveAlphaChars") + 1) & "}"
                    If Regex.Matches(strpassword, strRestrictConsAlphaCharPattern).Count > 0 Then
                        Return "The Password entered should not contain more than " & dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("MaxConsecutiveAlphaChars") & " consecutive Alpha Characters."
                    End If
                End If
                If dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("IsConsNumCharAllowed") <> False Then
                    Dim strRestrictConsNumCharPattern As String = "\d{" & (dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("MaxConsecutiveNumChars") + 1) & "}"
                    If Regex.Matches(strpassword, strRestrictConsNumCharPattern).Count > 0 Then
                        Return "The Password entered should not contain more than " & dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("MaxConsecutiveNumChars") & " consecutive Numeric Characters."
                    End If
                End If
                If dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("IsConsNonAlphaCharAllowed") <> False Then
                    Dim strRestrictConsAlpaCharsPattern As String = "[^a-zA-Z0-9]{" & (dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("MaxConsecutiveNonalphaChars") + 1) & "}"
                    If Regex.Matches(strpassword, strRestrictConsAlpaCharsPattern).Count > 0 Then
                        Return "The Password entered should not contain more than " & dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("MaxConsecutiveNonalphaChars") & " consecutive Non-alphanumeric Characters."
                    End If
                End If
                If dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("RestrictedCharacterSet") <> "" Then
                    Dim strRestrictedChars As String = String.Empty
                    Dim arrRestrictedChars As Array = {}
                    arrRestrictedChars = dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("RestrictedCharacterSet").ToString.Split(Chr(182))
                    For Each item As Char In arrRestrictedChars
                        If strpassword.Contains(item) Then
                            Return "The Password entered should not contain " & dsPasswordSettings.Tables("PwdSettings").Rows(0).Item("RestrictedCharacterSet").ToString.Replace(Chr(182), ", ") & " character(s)."
                        End If
                    Next
                End If
                Return "Success"
            Catch ex As Exception
                Throw ex
            Finally
                objBizUser = Nothing
            End Try
        End Function

        ''' <summary>
        ''' To check staff associated patients
        ''' </summary>
        ''' <param name="lngClnID"></param>
        ''' <param name="lngLocID"></param>
        ''' <returns></returns>
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Function IsAssociatedPatientsExists(ByVal strData As String) As Int16
            Dim objBizUser As clsBizlUser
            Dim lngClnID As Long = 0
            Dim lngLocID As Long = 0
            Dim jsonResult As Object
            Try
                jsonResult = DecryptJsonData(strData)
                lngClnID = jsonResult("lngStaffID")
                lngLocID = jsonResult("lngLocationID")
                objBizUser = New clsBizlUser
                Return objBizUser.IsAssociatedPatientsExists(lngClnID, lngLocID)
            Catch ex As Exception
                Throw ex
            Finally
                objBizUser = Nothing
                jsonResult = Nothing
            End Try
        End Function
	
	
        '*********************************************************************************************
        'Purpose        :  To Get User  Availabiity Status Lookups
        'Layer	        :   UI
        'Name		    :	GetUserStatusLookup
        'Parameters     :   
        'Return Values  :   
        '-------------------------------------------------------------------------------------
        'Version        Author :           Date:              Remarks      
        '---------------------------------------------------------------------------------------
        '7.5          Seshukumar           17/10/2022          Initial development          
        '*********************************************************************************************
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.Read)>
        Public Function GetUserStatusLookup(ByVal strData As String) As String
            Dim strURL As String
            Dim client As RestClient
            Dim objResponse As Object
            Dim jsonResult As Object
            Dim rawresp As String
            Dim objSecurity As clsSecurity
            Dim LookCategoryId As String
            Dim serviceURL As String
            Try
                objSecurity = New clsSecurity
                strData = objSecurity.DecryptData(strData)
                jsonResult = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(strData)
                LookCategoryId = jsonResult.Item("lcId").ToString
                If System.Configuration.ConfigurationSettings.AppSettings("ExcelicareWebServiceURL") IsNot Nothing Then
                    serviceURL = System.Configuration.ConfigurationSettings.AppSettings("ExcelicareWebServiceURL")
                End If

                strURL = serviceURL & "/api/LookupValues"
                client = New RestClient(strURL)
                Dim request As New RestRequest(strURL, RestSharp.Method.Get)

                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12
                request.AddHeader("content-type", "application/json")
                request.AddHeader("values", LookCategoryId)
                request.AddParameter("application/json", ParameterType.RequestBody)
                Dim response As RestResponse = client.Execute(request)
                objResponse = JsonConvert.DeserializeObject(Of Object)(response.Content)

                rawresp = response.Content
                Return rawresp
            Catch ex As Exception
                WriteException(ex)
                Throw ex
            Finally
                strURL = Nothing
                client = Nothing
                objResponse = Nothing
                jsonResult = Nothing
                rawresp = Nothing
                objSecurity = Nothing
                LookCategoryId = Nothing
                serviceURL = Nothing
            End Try
        End Function
		'*********************************************************************************************
        'Purpose        :  To update the status
        'Layer	        :   UI
        'Name		    :	UpdateUserStatus
        'Parameters     :   
        'Return Values  :   
        '-------------------------------------------------------------------------------------
        'Version        Author :           Date:              Remarks      
        '---------------------------------------------------------------------------------------
        '7.5          Seshukumar           17/10/2022          Initial development          
        '*********************************************************************************************
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.Read)>
        Public Function UpdateUserStatus(ByVal strData As String) As String
            Dim strURL As String
            Dim client As RestClient
            Dim objResponse As Object
            Dim jsonResult As Object
            Dim rawresp As String
            Dim objSecurity As clsSecurity
            Dim lnguserId As Long
            Dim serviceURL As String
            Dim payload As String = ""
            Dim strStatus As String = ""
            Dim objClsSessionData As clsSessionData
            Dim objClsSessionManager As clsSessionManager
            Try
                objSecurity = New clsSecurity
                objClsSessionData = New clsSessionData
                objClsSessionManager = New clsSessionManager
                strData = objSecurity.DecryptData(strData)
                jsonResult = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(strData)

                strStatus = jsonResult.Item("lus").ToString
                If System.Configuration.ConfigurationSettings.AppSettings("ExcelicareWebServiceURL") IsNot Nothing Then
                    serviceURL = System.Configuration.ConfigurationSettings.AppSettings("ExcelicareWebServiceURL")
                End If
                objClsSessionData = objClsSessionManager.GetSessionData(HttpContext.Current.Session.SessionID, "APPDATA")
                lnguserId = objClsSessionData.UserID
                payload = "{'userId': " & lnguserId & ",'status':'" & strStatus & "'}"
                strURL = serviceURL & "/api/userstatus"
                client = New RestClient(strURL)
                Dim request As New RestRequest(strURL, Method.Post)

                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12
                request.AddHeader("content-type", "application/json")
                request.AddParameter("application/json", payload, ParameterType.RequestBody)
                Dim response As RestResponse = client.Execute(request)
                objResponse = JsonConvert.DeserializeObject(Of Object)(response.Content)

                rawresp = response.Content
                Return rawresp
            Catch ex As Exception
                WriteException(ex)
                Throw ex
            Finally
                strURL = Nothing
                client = Nothing
                objResponse = Nothing
                jsonResult = Nothing
                rawresp = Nothing
                objSecurity = Nothing
                lngUserId = Nothing
                serviceURL = Nothing
                payload = Nothing
                strStatus = Nothing
                objClsSessionData = Nothing
                objClsSessionManager = Nothing
            End Try
        End Function
		'*********************************************************************************************
        'Purpose        :  To get user availabiity status
        'Layer	        :   UI
        'Name		    :	GetUserAvailiabilityStatus
        'Parameters     :   
        'Return Values  :   
        '-------------------------------------------------------------------------------------
        'Version        Author :           Date:              Remarks      
        '---------------------------------------------------------------------------------------
        '7.5          Seshukumar           17/10/2022          Initial development          
        '*********************************************************************************************
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.Read)>
        Public Function GetUserAvailiabilityStatus() As String
            Dim strURL As String
            Dim client As RestClient
            Dim objResponse As Object
            Dim jsonResult As Object
            Dim rawresp As String
            Dim lnguserId As Long
            Dim serviceURL As String
            Dim objClsSessionData As clsSessionData
            Dim objClsSessionManager As clsSessionManager
            Try
                objClsSessionData = New clsSessionData
                objClsSessionManager = New clsSessionManager
                If System.Configuration.ConfigurationSettings.AppSettings("ExcelicareWebServiceURL") IsNot Nothing Then
                    serviceURL = System.Configuration.ConfigurationSettings.AppSettings("ExcelicareWebServiceURL")
                End If
                objClsSessionData = objClsSessionManager.GetSessionData(HttpContext.Current.Session.SessionID, "APPDATA")
                lnguserId = objClsSessionData.UserID
                strURL = serviceURL & "/api/userstatus/" & lnguserId
                client = New RestClient(strURL)
                Dim request As New RestRequest(strURL, RestSharp.Method.Get)
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12
                request.AddHeader("content-type", "application/json")
                request.AddParameter("application/json", ParameterType.RequestBody)
                Dim response As RestResponse = client.Execute(request)
                objResponse = JsonConvert.DeserializeObject(Of Object)(response.Content)

                rawresp = response.Content
                Return rawresp
            Catch ex As Exception
                WriteException(ex)
                Throw ex
            Finally
                strURL = Nothing
                client = Nothing
                objResponse = Nothing
                jsonResult = Nothing
                rawresp = Nothing
                serviceURL = Nothing
                objClsSessionData = Nothing
                objClsSessionManager = Nothing
                lnguserId = Nothing
            End Try
        End Function
		'*********************************************************************************************
        'Purpose        :  To delete user photo
        'Layer	        :   UI
        'Name		    :	DeleteUserPhoto
        'Parameters     :   
        'Return Values  :   
        '-------------------------------------------------------------------------------------
        'Version        Author :           Date:              Remarks      
        '---------------------------------------------------------------------------------------
        '7.5          Seshukumar           17/10/2022          Initial development          
        '*********************************************************************************************
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.Read)>
        Public Function DeleteUserPhoto() As String
            Dim strURL As String
            Dim client As RestClient
            Dim objResponse As Object
            Dim jsonResult As Object
            Dim rawresp As String
            Dim lnguserId As Long
            Dim serviceURL As String
            Dim objClsSessionData As clsSessionData
            Dim objClsSessionManager As clsSessionManager
            Try
                objClsSessionData = New clsSessionData
                objClsSessionManager = New clsSessionManager
                If System.Configuration.ConfigurationSettings.AppSettings("ExcelicareWebServiceURL") IsNot Nothing Then
                    serviceURL = System.Configuration.ConfigurationSettings.AppSettings("ExcelicareWebServiceURL")
                End If
                objClsSessionData = objClsSessionManager.GetSessionData(HttpContext.Current.Session.SessionID, "APPDATA")
                lnguserId = objClsSessionData.UserID
                strURL = serviceURL & "/AxRSPatientDetails.svc/DeleteUserPhoto?Token=" & "@" & HttpContext.Current.Session.SessionID & "&PatientID=" & lnguserId & ""
                client = New RestClient(strURL)
                Dim request As New RestRequest(strURL, RestSharp.Method.Get)
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12
                request.AddHeader("content-type", "application/json")
                request.AddParameter("application/json", ParameterType.RequestBody)
                Dim response As RestResponse = client.Execute(request)
                objResponse = JsonConvert.DeserializeObject(Of Object)(response.Content)

                rawresp = response.Content
                Return rawresp
            Catch ex As Exception
                WriteException(ex)
                Throw ex
            Finally
                strURL = Nothing
                client = Nothing
                objResponse = Nothing
                jsonResult = Nothing
                rawresp = Nothing
                serviceURL = Nothing
                objClsSessionData = Nothing
                objClsSessionManager = Nothing
                lnguserId = Nothing
            End Try
        End Function
		'*********************************************************************************************
        'Purpose        :  To get user photo
        'Layer	        :   UI
        'Name		    :	GetUserPhoto
        'Parameters     :   
        'Return Values  :   
        '-------------------------------------------------------------------------------------
        'Version        Author :           Date:              Remarks      
        '---------------------------------------------------------------------------------------
        '7.5          Seshukumar           17/10/2022          Initial development          
        '*********************************************************************************************
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.Read)>
        Public Function GetUserPhoto() As String
            Dim strURL As String
            Dim client As RestClient
            Dim objResponse As Object
            Dim jsonResult As Object
            Dim rawresp As String
            Dim lnguserId As Long
            Dim serviceURL As String
            Dim objClsSessionData As clsSessionData
            Dim objClsSessionManager As clsSessionManager
            Try
                objClsSessionData = New clsSessionData
                objClsSessionManager = New clsSessionManager
                If System.Configuration.ConfigurationSettings.AppSettings("ExcelicareWebServiceURL") IsNot Nothing Then
                    serviceURL = System.Configuration.ConfigurationSettings.AppSettings("ExcelicareWebServiceURL")
                End If
                objClsSessionData = objClsSessionManager.GetSessionData(HttpContext.Current.Session.SessionID, "APPDATA")
                lnguserId = objClsSessionData.UserID
                strURL = serviceURL & "/AxRSPatientDetails.svc/GetUserPhoto?Token=" & "@" & HttpContext.Current.Session.SessionID & "&PatientID=" & lnguserId & ""
                client = New RestClient(strURL)
                Dim request As New RestRequest(strURL, RestSharp.Method.Get)
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12
                request.AddHeader("content-type", "application/json")
                request.AddParameter("application/json", ParameterType.RequestBody)
                Dim response As RestResponse = client.Execute(request)
                objResponse = JsonConvert.DeserializeObject(Of Object)(response.Content)

                rawresp = response.Content
                Return rawresp
            Catch ex As Exception
                WriteException(ex)
                Throw ex
            Finally
                strURL = Nothing
                client = Nothing
                objResponse = Nothing
                jsonResult = Nothing
                rawresp = Nothing
                serviceURL = Nothing
                objClsSessionData = Nothing
                objClsSessionManager = Nothing
                lnguserId = Nothing
            End Try
        End Function

        Public Shared Function URLValidationCheck(ByVal strURL As String) As Boolean
            Dim strCausedHackHTMLTags() As String = {"<applet>", "<body>", "<embed>", "<frame>", "<script>", "<frameset>", "<html>", "<iframe>", "<img>", "<style>", "<layer>", "<link>", "<ilayer>", "<meta>", "<object>", "alert(", "<title>", "=", "</", "<=", ">=", "<>", "<iframe", "<script", "<img", "<style", "style", "http", "phishing", "trim", "+and+", "+alert+", "eval"}
            Dim intLoop As Integer
            Dim blnResult As Boolean
            Dim Index As Integer
            Try
                If Not strURL.Contains("?") Then
                    Return True
                End If
                strURL = strURL.Split("?")(1).ToString
                If strURL <> "" AndAlso strURL.Split("&").Length > 1 OrElse strURL <> "" AndAlso strURL.Split("&").Length = 1 Then
                    For intLoop = 0 To strURL.Split("&").Length - 1
                        If strURL.Split("&")(intLoop) <> "" Then
                            Select Case UCase(strURL.Split("&")(intLoop).Split("=")(0))
                                Case "STRQPDATA", "CALLEDFROM"
                                    For Index = 0 To strCausedHackHTMLTags.Length - 1
                                        If UCase(strURL.Split("&")(intLoop).Split("=")(1).IndexOf(UCase(strCausedHackHTMLTags(Index).ToString()))) > -1 Then
                                            Return False
                                        End If
                                    Next
                                    Dim objSecurity As clsSecurity
                                    objSecurity = New clsSecurity
                                    blnResult = objSecurity.ValidateOSandSQLCommandInjections(strURL.Split("&")(intLoop).Split("=")(1).ToString())
                                    If blnResult Then
                                        Return False
                                    End If
                                    objSecurity = Nothing
                            End Select
                        End If
                    Next
                End If
                Return True
            Catch ex As Exception
                Throw ex
            Finally
                strCausedHackHTMLTags = Nothing
                intLoop = Index = Nothing
                blnResult = Nothing
            End Try
        End Function

        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Function fnUpdatePDLInEditMode(ByVal strParam As String) As String
            Dim objclsSplForm As New clsSplForm
            Dim lngPatID, lngDataID As Long
            Dim strPDLEditModeIDs, strAction As String
            Dim objInputJSON As Object
            Dim lngModuleID As Long
            Try
                lngPatID = GetDataFromSession("PatID")
                objInputJSON = DecryptJsonData(strParam)
                strPDLEditModeIDs = objInputJSON.Item("strPDLReturnIDInEdit").ToString
                strAction = objInputJSON.Item("strAction").ToString
                lngDataID = objInputJSON.Item("lngDataID")
                lngModuleID = objInputJSON.Item("lngModuleID")
                Return objclsSplForm.fnUpdatePDLInEditMode(strPDLEditModeIDs, lngPatID, strAction, lngDataID, lngModuleID)
            Catch ex As Exception
                WriteException(ex)
            Finally
                objclsSplForm = Nothing
                lngPatID = Nothing
            End Try
        End Function

        Public Function GetDataFromSession(StrSessionVariable As String) As String
            Dim objClsSessionManager As clsSessionManager
            Dim objSessionData As clsSessionData
            Dim strSessionID As String = ""
            Dim strResult As String = ""
            Try
                strSessionID = HttpContext.Current.Session.SessionID
                objClsSessionManager = New clsSessionManager
                objSessionData = objClsSessionManager.GetSessionData(strSessionID, "APPDATA")
                If Not objSessionData Is Nothing Then
                    Select Case StrSessionVariable.ToUpper()
                        Case "PATID"
                            strResult = objSessionData.PatientID
                        Case "USERID"
                            strResult = objSessionData.UserID
                    End Select
                End If
                Return strResult
            Catch ex As Exception
                Throw
            Finally
                objClsSessionManager = Nothing
                objSessionData = Nothing
                strSessionID = Nothing
                strResult = Nothing
            End Try
            Return strResult
        End Function
    End Class
End Namespace