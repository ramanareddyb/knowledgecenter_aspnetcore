Imports System.Collections.Specialized
Imports Excelicare.Framework.AppSupport
Partial Class frmBlankPage
    Inherits System.Web.UI.Page
#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub
#End Region
    ' -----------------------------------------------------------------------------
    Public m_blnShowCriticalMessage As Boolean = False
    Public m_intModuleId As Int32
    Protected strVerNo As String
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim objGetVersionNo As clsAppSettings
        Dim objclsSecurity As clsSecurity
        Dim objQueryParams As New NameValueCollection
        Try
			Response.Expires = -1
            Response.Cache.SetNoServerCaching()
            Response.Cache.SetAllowResponseInBrowserHistory(False)
            Response.CacheControl = "no-cache"
            Response.Cache.SetNoStore()
            objGetVersionNo = New clsAppSettings
            strVerNo = objGetVersionNo.GetModuleVersion("1031")
            If URLValidationCheck(Request.Url.ToString) = False Then
                Response.End()
                Exit Sub
            End If
            If Not Request.QueryString("strQPData") Is Nothing Then
                objQueryParams = objclsSecurity.fnGetQueryParamData(Request.QueryString("strQPData"))
            Else
                objQueryParams = Request.QueryString
            End If
            If Not objQueryParams.Item("ShowCriticalMessage") Is Nothing Then
                m_blnShowCriticalMessage = True
            End If
            If Not objQueryParams.Item("ModID") Is Nothing Then
                m_intModuleId = objQueryParams.Item("ModID")
            End If
        Catch ex As Exception
            LogException(ex)
        Finally
            objclsSecurity = Nothing
            objQueryParams = Nothing
        End Try
    End Sub
    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub
    '''Added by BRR- to check the security check before processing the response and giving to client browser.2015-OCT-08
    Public Function URLValidationCheck(ByVal strURL As String) As Boolean
        Dim strParams() As String
        Dim intLoop, result As Integer
        Try
            Dim strCausedHackHTMLTags() As String = {"<applet>", "<body>", "<embed>", "<frame>", "<script>", "<frameset>", "<html>", "<iframe>", "<img>", "<style>", "<layer>", "<link>", "<ilayer>", "<meta>", "<object>", "alert(", "<title>", "=", "</", "<=", ">=", "<>", "<iframe", "<script", "<img", "<style", "style", "http", "phishing", "trim"}
            strParams = strURL.Split("?")
            If strParams.Length > 1 Then
                strURL = strParams(1)
                If strURL <> "" AndAlso strURL.Split("&").Length >= 1 Then
                    For intLoop = 0 To strURL.Split("&").Length - 1
                        If strURL.Split("&")(intLoop) <> "" AndAlso strURL.Split("&")(intLoop).Split("=").Length > 1 Then
                            Select Case UCase(strURL.Split("&")(intLoop).Split("=")(0))
                                Case "MESSAGE"
                                    For intIndex As Integer = 0 To strCausedHackHTMLTags.Length - 1
                                        If UCase(strURL.Split("&")(intLoop).Split("=")(1)).IndexOf(UCase(strCausedHackHTMLTags(intIndex).ToString())) > -1 Then
                                            result = intIndex
                                            Exit For
                                        End If
                                    Next
                                    If result > 0 Then Return False
                                Case "MODULENAME"
                                    For intIndex As Integer = 0 To strCausedHackHTMLTags.Length - 1
                                        If UCase(strURL.Split("&")(intLoop).Split("=")(1)).IndexOf(UCase(strCausedHackHTMLTags(intIndex).ToString())) > -1 Then
                                            result = intIndex
                                            Exit For
                                        End If
                                    Next
                                    If result > 0 Then Return False
                                Case "ICONSTYLE"
                                    If strURL.Split("&")(intLoop).Split("=")(1) <> "" AndAlso Not (IsNumeric(strURL.Split("&")(intLoop).Split("=")(1))) Then
                                        Return False
                                    End If
                                Case "BOXSTYLE"
                                    If strURL.Split("&")(intLoop).Split("=")(1) <> "" AndAlso Not (IsNumeric(strURL.Split("&")(intLoop).Split("=")(1))) Then
                                        Return False
                                    End If

                            End Select
                        End If
                    Next
                End If
            End If
            Return True
        Catch ex As Exception
            LogException(ex)
        Finally
            strParams = Nothing
        End Try
    End Function
    Private Sub LogException(ByVal objExcep As Exception)
        Dim objClsExceptionHandler As clsExceptionHandler
        Try
            objClsExceptionHandler = New clsExceptionHandler(objExcep)
            If Not IsNothing(Page) Then
                objClsExceptionHandler.LogException(Page)
            Else
                objClsExceptionHandler.LogException()
            End If
        Catch ex As Exception
            objClsExceptionHandler = New clsExceptionHandler(ex)
            If Not IsNothing(Page) Then
                objClsExceptionHandler.LogException(Page)
            Else
                objClsExceptionHandler.LogException()
            End If
        Finally
            objClsExceptionHandler = Nothing
        End Try
    End Sub
End Class
