Imports Excelicare.Framework.AppSupport
Imports System.Xml
Imports Ajax
Imports Excelicare.Bizl.MDI
Imports Excelicare.ServiceProxy
Imports Excelicare.Bizl.Login
Imports System.Configuration.ConfigurationManager
Imports Newtonsoft.Json.Linq
Imports Newtonsoft.Json
Imports System.Collections.Generic
Imports System.Collections.Specialized

Namespace Excelicare.UI.Web.MDI
    Partial Class frmExcelicareMDI
        Inherits System.Web.UI.Page

        'Public CalledFrom As Int32
        Public strModuleName As String = String.Empty
        Public strSessionID As String = String.Empty
        'Public intUserID As Integer = 0
        Public lngUserID As Long
        Public blnPWDpromptRequired As String = ""
        Public blnPwdExpired As Boolean = False
        Public blnIsTraining As Boolean
        Public strAxStreamReaderProgID As String
        Protected strVerNo As String = ""
        Protected lngAutoLogOffTime As Int32            'Added for AutoLogOff on 14-Dec-2011
        Protected m_intUserSecurityLevel As Integer = 0
        Protected UserSecureModule As String = String.Empty
        Public m_intPrescriberRole As Integer
        Public m_streRxAccountLocationID As String = ""
        Public strPrescDetails As String = ""
        Public m_strAccountName As String = String.Empty
        Public m_strLocationName As String = String.Empty
        Public m_strProviderName As String = String.Empty
        Public m_inteRxUsr_Id As Integer
        Public m_inteRxCln_Id As Integer
        Public blnCheckRestriction As Boolean = False
        Dim m_objWSePrescribing As WSPrescriptionManager.AxWSePrescriptionManagerClient
        Public m_lngPatientID As Long
        Public m_strCalledFrom As String
        Public serviceURL As String = String.Empty

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This is used to open the excelicare window when login
        ' </summary>
        ' <remarks>
        ' </remarks>
        ' <history>
        ' 	    [Srinivas K]	16/06/2005	Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            ''   Dim objProxy As clsBizlUser = Nothing 'added on 14-Dec-2011
            Dim objClsExceptionHandler As clsExceptionHandler
            Dim objGetVersionNo As clsAppSettings
            Dim objBizEcsession As New clsSessionManager
            Dim strTempDirectorypath As String
            Dim objExcelicareMasterPage As SiteExcelicare
            Dim objQueryParams As New NameValueCollection
            Dim objClsSecurity As New clsSecurity
            Try
				Response.Expires = -1
				Response.Cache.SetNoServerCaching()
				Response.Cache.SetAllowResponseInBrowserHistory(False)
				Response.CacheControl = "no-cache"
				Response.Cache.SetNoStore()
                If Not IsPostBack AndAlso Not Request.Form("data") Is Nothing Then
                    Dim json As JObject = JObject.Parse(Request.Form("data"))
                    If json.SelectToken("IsSessionLog") IsNot Nothing AndAlso json.SelectToken("IsSessionLog").ToString = True Then
                        fnLogWebSessionAction(json.SelectToken("ModuleName").ToString, json.SelectToken("SessionID").ToString, json.SelectToken("PatientId"), json.SelectToken("EventID"), json.SelectToken("EventDetails").ToString, json.SelectToken("ModuleID"), json.SelectToken("RecordID"), json.SelectToken("RequestID"))
                    Else
                        logECWebSessionAction(2039, -1, "removeAxServerTempData Start")
                        strTempDirectorypath = AppSettings("AxServerTempFolder") & Session.SessionID
                        objExcelicareMasterPage = CType(Page.Master, SiteExcelicare)
                        If objExcelicareMasterPage IsNot Nothing Then
                            If Not json.SelectToken("CobIds").ToString Is Nothing AndAlso json.SelectToken("CobIds").ToString <> "0" Then
                                'objExcelicareMasterPage.removeAxServerTempData(strTempDirectorypath, json.SelectToken("CobIds").ToString)
                                DeleteFailedMediaEntries(json.SelectToken("CobIds").ToString)
                                'removeAxServerTempData(Session.SessionID, json.SelectToken("CobIds").ToString)
                            End If
                            If json.SelectToken("method").ToString = "removeAxServerTempData" Then
                                objExcelicareMasterPage.removeAxServerTempData(strTempDirectorypath, True, json.SelectToken("LogoutClicked"))
                            End If
                            logECWebSessionAction(2039, -1, "removeAxServerTempData End")
                        End If
                    End If
                    Exit Sub
                End If

                Response.Expires = -1
                Response.Cache.SetNoServerCaching()
                Response.Cache.SetAllowResponseInBrowserHistory(False)
                Response.CacheControl = "no-cache"
                Response.Cache.SetNoStore()
                GetSessionData()
                objGetVersionNo = New clsAppSettings
                strVerNo = objGetVersionNo.GetModuleVersion("1031")
                serviceURL = System.Configuration.ConfigurationManager.AppSettings("ExcelicareWebServiceURL")
                Ajax.Utility.RegisterTypeForAjax(GetType(frmExcelicareMDI))

                If SiteExcelicare.URLValidationCheck(Request.Url.ToString.Replace(Chr(34), "").Replace("""", "")) = False Then
                    'Ajax_LogSessionAction(lngPatId, 2729, "Response ended due to URL is altered.")
                    Response.End()
                    Exit Sub
                End If
                If Not Request.QueryString("strQPData") Is Nothing Then
                    objQueryParams = objClsSecurity.fnGetQueryParamData(Request.QueryString("strQPData"))
                Else
                    objQueryParams = Request.QueryString
                End If
                If Not objQueryParams.Item("CalledFrom") Is Nothing Then
                    m_strCalledFrom = objQueryParams.Item("CalledFrom")
                End If
                If Not Session("APPDATA") Is Nothing AndAlso Not Session("mdiloaded") = Nothing AndAlso Session("mdiloaded") = 1 Then
                    If objBizEcsession.IsSessionExists(Session.SessionID) = True Then
                        logECWebSessionAction(2039, -1, "Duplicate ASP Session, Logged from MDI.")
                        Response.Redirect("~/AxWebUIMDI/CustomError.Aspx?ErrorCode=User session is active in this machine, please close the active session or open the URL in different browser.", False)
                        Exit Sub
                    End If
                End If
                If Not Session("APPDATA") Is Nothing AndAlso Not Session("mdiloaded") = Nothing AndAlso Session("mdiloaded") = 1 AndAlso m_strCalledFrom = "SSO" Then
                    logECWebSessionAction(2039, -1, "Duplicate ASP Session, Logged from SSO.")
                    Response.Redirect("~/AxWebUIMDI/CustomError.Aspx?ErrorCode=User session is active in this machine, please close the active session.&CalledFrom=SSO&CalledFrom=SSO", False)
                    Exit Sub
                End If

                If Session("APPDATA") Is Nothing AndAlso m_strCalledFrom = "SSO" Then
                    logECWebSessionAction(2039, -1, "Login from Shortcut.")
                    Response.Redirect("~/AxWebUILogin/default.Aspx", False)
                    Exit Sub

                End If
                If Not IsPostBack() Then
                    GetUserPrescribingRole() 'Retrieve values only for the first time as data is stored in session.
                End If

                If Not IsPostBack() Then
                    GetUserValues() 'Retrieve values only for the first time as data is stored in session.
                End If

                'If Not objClsSessionManager.IsSessionExists(clsNavigation.GetSession_ID(Page.Session)) Then
                '    Response.Redirect(clsNavigation.GetURL(1031, "Page_Load"), False)
                'End If

                If Not Session("IsPWDpromptRequired") Is Nothing Then
                    blnPWDpromptRequired = Session("IsPWDpromptRequired")
                End If

                If Not objQueryParams.Item("IsPwdExpired") Is Nothing Then
                    blnPwdExpired = objQueryParams.Item("IsPwdExpired")
                End If

                strModuleName = "MDI"
                strSessionID = Session.SessionID  ''clsNavigation.GetSession_ID(Page.Session) '' Added by Suneetha on 24.10.2005 to to reduce trip to the clsNavigation

                'objClsUser = objClsSessionManager.GetSessionData(Session.SessionID, "Session_User")

                'If Not objClsUser Is Nothing Then
                '    intUserID = objClsUser.User_Id
                'End If
                If Not ConfigurationSettings.AppSettings("AxStreamReaderProgID") Is Nothing AndAlso ConfigurationSettings.AppSettings("AxStreamReaderProgID").ToString() <> "" Then
                    strAxStreamReaderProgID = ConfigurationSettings.AppSettings("AxStreamReaderProgID")
                End If

                If Not IsPostBack Then
                    ''   objProxy = New clsBizlUser
                    ''clsECSession.LogWebSessionAction(strModuleName, strSessionID, -1, 2039, "Loading MDI", 1031)
                    If Not objQueryParams.Item("CalledFrom") Is Nothing Then
                        'm_strCalledFrom = Request.QueryString("CalledFrom")
                        If objQueryParams.Item("CalledFrom").GetType Is GetType(Integer) AndAlso objQueryParams.Item("CalledFrom") = 1031 Then
                            'objClsSessionManager.SetSessionData(strSessionID, "Session_CalledFrom", Request.QueryString("CalledFrom"))
                            'objClsSessionManager.OnStop()
                            Session("CALLEDFROM") = objQueryParams.Item("CalledFrom")
                        End If
                    End If
                End If
                '''added by suneetha on 24 march 05 to track from page the request has come in BEGINS
                '' Added by PVP Mohan on 23.07.2007 to change the Title of the Application when connected to Training DB
                Dim StrDBDetails As String = ""
                StrDBDetails = System.Configuration.ConfigurationSettings.AppSettings.Item("ConnectionString")
                ''  lblDBName.InnerText = "hi"
                If (StrDBDetails.ToLower.IndexOf("initial catalog") <> -1) Then
                    If (StrDBDetails.ToLower.IndexOf("_training") <> -1) Then
                        blnIsTraining = True
                    Else
                        blnIsTraining = False
                    End If
                End If
                If IsNothing(Session("mdiloaded")) AndAlso Not Session("APPDATA") Is Nothing Then
                    Session("mdiloaded") = 1
                End If
            Catch ex As Exception
                objClsExceptionHandler = New clsExceptionHandler(ex)
                objClsExceptionHandler.LogException()
            Finally
                objClsExceptionHandler = Nothing
                ''  objProxy = Nothing
                objGetVersionNo = Nothing
                objExcelicareMasterPage = Nothing
                strTempDirectorypath = Nothing
                objClsSecurity = Nothing
                objQueryParams = Nothing
            End Try
        End Sub


        Public Function DeleteFailedMediaEntries(ByVal strCobIDs As String) As Boolean

            Dim objBizUser As clsBizlUser

            Try
                objBizUser = New clsBizlUser
                objBizUser.DeleteFailedMediaEntries(strCobIDs)
            Catch ex As Exception
                Throw ex
            Finally
                objBizUser = Nothing
            End Try
        End Function

        Private Sub GetSessionData()
            Dim objClsSessionData As clsSessionData
            Dim objSessionMgr As clsSessionManager
            Try
                objSessionMgr = New clsSessionManager
                If Not objSessionMgr.IsSessionExists(Me.Session.SessionID) Then
                    Response.Redirect(clsNavigation.GetURL(1031, "Page_Load"), False)
                End If
                objClsSessionData = objSessionMgr.GetSessionData(Me.Session.SessionID, "APPDATA") 'Session("APPDATA")
                If Not objClsSessionData Is Nothing Then
                    lngUserID = objClsSessionData.UserID
                    m_lngPatientID = objClsSessionData.PatientID            'Added by SSuresh to select patient when called from SSO
                    lngAutoLogOffTime = objClsSessionData.AutoLogOffTime
                    m_intUserSecurityLevel = objClsSessionData.UserSecurityLevel
                End If
            Finally
                objClsSessionData = Nothing
                objSessionMgr = Nothing
            End Try
        End Sub
        Private Sub GetUserValues()
            Dim objClsBizlUser As Excelicare.Bizl.MDI.clsBizlUser
            Dim dsUserValues As DataSet
            Dim strShowSaveDialog As String
            Try
                'Initialize session variables
                Session("USR_SECURITY_LEVEL") = -1
                Session("USR_IDENTIFIER_LU") = -1
                Session("USR_IDENTIFIER") = -1
                '''Session("USR_PREFIDENCAPTION") = ""
                Session("RESTRICTIONLEVEL") = -1
                Session("ACLSUPERUSER") = 0 'Have to check for appropriate default here
                Session("ISACLMANAGER") = 0 'Have to check for appropriate default here
                'Code written to initialize variable if it is not available
                'This can be removed is Session("ApplicationInstallType") is initialize properly
                Session("CanUserPrint") = False
                If IsNothing(Application("ApplicationInstallType")) Then
                    Application("ApplicationInstallType") = "3,5,7"
                End If
                objClsBizlUser = New Excelicare.Bizl.MDI.clsBizlUser
                dsUserValues = objClsBizlUser.GetUserValues(lngUserID)
                If Not IsNothing(dsUserValues) Then
                    If dsUserValues.Tables.Count > 0 AndAlso dsUserValues.Tables(0).Rows.Count > 0 Then
                        Session("USR_SECURITY_LEVEL") = IIf(IsDBNull(dsUserValues.Tables(0).Rows(0).Item("USR_SECURITY_LEVEL").ToString), "-1", dsUserValues.Tables(0).Rows(0).Item("USR_SECURITY_LEVEL").ToString)
                        Session("USR_IDENTIFIER_LU") = IIf(IsDBNull(dsUserValues.Tables(0).Rows(0).Item("USR_IDENTIFIER_LU").ToString), "-1", dsUserValues.Tables(0).Rows(0).Item("USR_IDENTIFIER_LU").ToString)
                        Session("USR_IDENTIFIER") = IIf(IsDBNull(dsUserValues.Tables(0).Rows(0).Item("USR_IDENTIFIER").ToString), "-1", dsUserValues.Tables(0).Rows(0).Item("USR_IDENTIFIER").ToString)
                        '''Session("USR_PREFIDENCAPTION") = dsUserValues.Tables(0).Rows(0).Item("USR_PREFIDENCAPTION").ToString
                        Session("RESTRICTIONLEVEL") = IIf(IsDBNull(dsUserValues.Tables(0).Rows(0).Item("RESTRICTIONLEVEL").ToString), "-1", dsUserValues.Tables(0).Rows(0).Item("RESTRICTIONLEVEL").ToString)
                        Session("SHOWINACTIVERECORDS") = dsUserValues.Tables(0).Rows(0).Item("SHOWINACTIVERECORDS")
                        If Not IsDBNull(dsUserValues.Tables(0).Rows(0).Item("ACLSUPERUSER")) Then
                            Session("ACLSUPERUSER") = dsUserValues.Tables(0).Rows(0).Item("ACLSUPERUSER").ToString
                        Else
                            Session("ACLSUPERUSER") = 0
                        End If

                        Session("ISACLMANAGER") = dsUserValues.Tables(0).Rows(0).Item("ISACLMANAGER").ToString
                        If Not IsDBNull(dsUserValues.Tables(0).Rows(0).Item("PrivilegedForms")) Then
                            strShowSaveDialog = dsUserValues.Tables(0).Rows(0).Item("PrivilegedForms").ToString
                            If strShowSaveDialog.Length > 23 Then
                                Session("SHOWSAVEDIALOG") = strShowSaveDialog.Substring(23, 1)
                            Else
                                Session("SHOWSAVEDIALOG") = "1"
                            End If
                        Else
                            Session("SHOWSAVEDIALOG") = "1"
                        End If


                        If Not IsNothing(dsUserValues.Tables(1)) AndAlso dsUserValues.Tables(1).Rows.Count = 3 Then
                            Dim intIndex As Integer
                            For intIndex = 0 To dsUserValues.Tables(1).Rows.Count - 1
                                If dsUserValues.Tables(1).Rows(intIndex).Item("ID") = "30" Then 'Primary
                                    Session("PRIMARYIDENTIFIERID") = dsUserValues.Tables(1).Rows(intIndex).Item("IDENTIFIER_LU").ToString
                                    Session("PRIMAYIDENTIFIERCAPTION") = dsUserValues.Tables(1).Rows(intIndex).Item("IDENTIFIERCAPTION").ToString
                                ElseIf dsUserValues.Tables(1).Rows(intIndex).Item("ID") = "41" Then 'Secondary
                                    Session("SECONDARYIDENTIFIERID") = dsUserValues.Tables(1).Rows(intIndex).Item("IDENTIFIER_LU").ToString
                                    Session("SECONDARYIDENTIFIERCAPTION") = dsUserValues.Tables(1).Rows(intIndex).Item("IDENTIFIERCAPTION").ToString
                                ElseIf dsUserValues.Tables(1).Rows(intIndex).Item("ID") = "46" Then 'Main Display
                                    Session("MAINDISPLAYIDENTIFIERID") = dsUserValues.Tables(1).Rows(intIndex).Item("IDENTIFIER_LU").ToString
                                End If
                            Next
                        End If
                        If Not IsNothing(dsUserValues.Tables(2)) AndAlso dsUserValues.Tables(2).Rows.Count > 0 Then
                            If Not IsDBNull(dsUserValues.Tables(2).Rows(0).Item("CanPrint")) Then
                                If dsUserValues.Tables(2).Rows(0).Item("CanPrint") > 0 Then
                                    Session("CanUserPrint") = True
                                Else
                                    Session("CanUserPrint") = False
                                End If
                            End If

                        End If
                    End If
                End If
                If CType(Session("ISACLMANAGER"), Boolean) = False And (CType(Session("RESTRICTIONLEVEL"), Int16) > 0 Or CType(Session("ACLSUPERUSER"), Boolean) = False) Then
                    blnCheckRestriction = True
                End If
            Finally
                objClsBizlUser = Nothing
                If Not IsNothing(dsUserValues) Then
                    dsUserValues.Dispose()
                    dsUserValues = Nothing
                End If
            End Try
        End Sub

        Protected Overrides Sub Finalize()
            MyBase.Finalize()
        End Sub

        Private Sub GetUserPrescribingRole()
            Dim objePrescXmlDoc As New XmlDocument
            Dim objClsBizlUser As Excelicare.Bizl.MDI.clsBizlUser
            Try
                objClsBizlUser = New Excelicare.Bizl.MDI.clsBizlUser
                strPrescDetails = objClsBizlUser.GetUserPrescribingRole(lngUserID, 0)

                If strPrescDetails <> "" Then
                    objePrescXmlDoc = New XmlDocument
                    objePrescXmlDoc.LoadXml(strPrescDetails)
                    m_intPrescriberRole = CInt(Trim(objePrescXmlDoc.ChildNodes(0).Item("Role").InnerText))
                    m_streRxAccountLocationID = Trim(objePrescXmlDoc.ChildNodes(0).Item("eRxAccountLocationID").InnerText)
                    m_inteRxCln_Id = Trim(objePrescXmlDoc.ChildNodes(0).Item("eRxClnID").InnerText)
                    'm_streRxAccountLocationID = Session("UserLocationID")
                    m_strAccountName = Trim(objePrescXmlDoc.ChildNodes(0).Item("AccountName").InnerText)
                    m_strLocationName = Trim(objePrescXmlDoc.ChildNodes(0).Item("LocationName").InnerText)
                    m_strProviderName = Trim(objePrescXmlDoc.ChildNodes(0).Item("ProviderName").InnerText)
                    m_inteRxUsr_Id = Trim(objePrescXmlDoc.ChildNodes(0).Item("eRxUsrId").InnerText)
                End If
                Session("eRxAccountName") = m_strAccountName
                Session("eRxlocationName") = m_strLocationName
                Session("eRxProviderName") = m_strProviderName
                Session("eRxAccountLocationID") = m_streRxAccountLocationID
                Session("eRxUserID") = m_inteRxCln_Id
                Session("eRxUsrId") = m_inteRxUsr_Id
                Session("eRxPrescriberRole") = m_intPrescriberRole
            Catch ex As Exception
            Finally
                objClsBizlUser = Nothing
            End Try

        End Sub

        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This is used to send eRx data to EMR partner
        ' </summary>
        ' <remarks>
        ' </remarks>
        ' <history>
        ' 	    [SSuresh]	26/06/2013	Created
        ' </history>
        ' -----------------------------------------------------------------------------
        '<Ajax.AjaxMethod(HttpSessionStateRequirement.Read)> _
        'Public Function fnSaveArtifactDetails(ByVal lngUserID As Long, ByVal lngPatientID As Long, ByVal lngModuleID As Long) As String
        '    Dim objSSOProxy As Axsys_SSOClient
        '    ' Dim strArtifactDetails As String = ""
        '    Dim strPartnerToken As String = ""
        '    Dim strArtifactID As String = ""
        '    '   Dim strAxsysArtifacts As String = ""
        '    Dim strPartnerArtifactID As String
        '    Dim strInputMessage As String
        '    '     Dim strOutputMessage As String = String.Empty
        '    Dim strPartnerServiceURL As String = String.Empty
        '    Dim strAxsysToken As String
        '    Dim strMessageTransactionID As String
        '    Dim sessionStateSection As System.Web.Configuration.SessionStateSection = _
        '    CType(System.Configuration.ConfigurationManager.GetSection("system.web/sessionState"),  _
        '      System.Web.Configuration.SessionStateSection)
        '    Dim intSessionTimeout As Integer
        '    Dim blnServiceClose As Boolean = False
        '    Dim intUserLocationID As Integer
        '    Dim cbMedicationHistory As New AsyncCallback(AddressOf WSMedicationHistoryCallback)
        '    Dim objClsExceptionHandler As clsExceptionHandler
        '    Try
        '        logECWebSessionAction(1, lngPatientID, "SSO -  fnSaveArtifactDetails Begin:lngUserID:" & lngUserID & " - lngPatientID:" & lngPatientID)
        '        If Not Session("PartnerToken") Is Nothing AndAlso Session("PartnerToken") <> "" Then
        '            strPartnerToken = Session("PartnerToken")
        '            strAxsysToken = Session("AxsysTokenID")
        '            strPartnerArtifactID = IIf(Session("PartnerArtifactID") Is Nothing, "", Session("PartnerArtifactID"))
        '            objSSOProxy = New Axsys_SSOClient
        '            strArtifactID = objSSOProxy.SaveArtifactDetails(strAxsysToken, lngPatientID.ToString, Session.SessionID, lngUserID, lngModuleID, Session("eRxMessageTransactionID"))
        '            objSSOProxy.Close()

        '            strMessageTransactionID = Session("eRxMessageTransactionID")
        '            intSessionTimeout = sessionStateSection.Timeout.TotalMinutes
        '            intUserLocationID = Session("eRxAccountLocationID")
        '            m_objWSePrescribing = New WSPrescriptionManager.AxWSePrescriptionManagerClient
        '            strInputMessage = "<SendPartnerArtifact>" & _
        '                                  "<Token>" & strPartnerToken & "</Token>" & _
        '                                  "<ArtifactID>" & strArtifactID & "</ArtifactID>" & _
        '                                  "<PartnerArtifactID>" & strPartnerArtifactID & "</PartnerArtifactID>" & _
        '                              "</SendPartnerArtifact>"
        '            strPartnerServiceURL = Session("PartnerServiceURL")
        '            m_objWSePrescribing.BeginGetPatientFullMedicationHistory(lngPatientID.ToString, lngUserID, intSessionTimeout, strMessageTransactionID, intUserLocationID, True, strInputMessage, strPartnerServiceURL, cbMedicationHistory, New Object) 'strNotArchived, strCompletedPrescription)

        '            blnServiceClose = True

        '        End If
        '        logECWebSessionAction(1, lngPatientID, "SSO -  fnSaveArtifactDetails End: strArtifactID:" & strArtifactID)
        '    Catch ex As Exception
        '        logECWebSessionAction(1, lngPatientID, "SSO -  fnSaveArtifactDetails Catch: Exception:" & ex.Message)
        '        objClsExceptionHandler = New clsExceptionHandler(ex)
        '        objClsExceptionHandler.LogException()
        '    Finally
        '        objSSOProxy = Nothing
        '        If blnServiceClose = False Then
        '            m_objWSePrescribing.Abort()
        '        End If
        '    End Try
        '    Return ""
        'End Function
        '''----------------------------------------------------------------------------------------
        ''' <summary>To close the service connection </summary>
        ''' <history>
        ''' Version           Author                Date           Remarks
        ''' 4.0               K Pradeep             23.12.2009
        ''' </history>
        ''' ---------------------------------------------------------------------------------------
        Sub WSMedicationHistoryCallback()
            Dim objClsExceptionHandler As clsExceptionHandler
            Try
                If IsNothing(m_objWSePrescribing) = False Then
                    m_objWSePrescribing.Close() ' closing the service connection after saving is completed
                End If
            Catch ex As Exception
                objClsExceptionHandler = New clsExceptionHandler(ex)
                objClsExceptionHandler.LogException()   ' Writing log for Exception occured
            End Try
        End Sub
        Public Sub WriteException(ByVal ex As Exception)
            Dim objClsExceptionHandler As New clsExceptionHandler(ex)
            objClsExceptionHandler.LogException(Page)
            objClsExceptionHandler = Nothing
        End Sub
        <Ajax.AjaxMethod(HttpSessionStateRequirement.Read)>
        Public Sub fnlogECWebSessionAction(ByVal strData As String)
            Dim lngEventId As Long
            Dim lngPatId As Long
            Dim strEventDet As String
            Dim jsonResult As Object
            Try
                jsonResult = SiteExcelicare.DecryptJsonData(strData)
                lngEventId = jsonResult("lngEventId")
                lngPatId = jsonResult("lngPatId")
                strEventDet = jsonResult("strEventDet")
                logECWebSessionAction(lngEventId, lngPatId, strEventDet)
            Catch ex As Exception
                WriteException(ex)
                Throw ex
            End Try
        End Sub
        <Ajax.AjaxMethod(HttpSessionStateRequirement.Read)>
        Public Sub logECWebSessionAction(ByVal lngEventId As Long, ByVal lngPatId As Long, ByVal strEventDet As String)
            Try
                clsECSession.LogWebSessionAction("MDI", Session.SessionID, lngPatId, lngEventId, strEventDet, 1031, 0)
            Catch ex As Exception
            End Try
        End Sub
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.Read)>
        Public Function SavePrintLogDetails(ByVal strData As String) As String
            Dim objClsBizlUser As Excelicare.Bizl.MDI.clsBizlUser
            Dim objClsSessionData As clsSessionData
            Dim objSessionMgr As clsSessionManager
            Dim intTemp As Integer
            Dim strDatePrinted As DateTime
            Dim strPreviewDate As DateTime
            Dim lngPatID As Long
            Dim intItemID As Int64
            Dim lngModuleID As Long
            Dim strItemType As String
            Dim strPrinterName As String
            Dim lngUserID As Long
            Dim lngDataId As Long
            Dim lngCustomFormID As Long
            Dim strPrintPreviewDate As String
            Dim blnPrintStatus As Boolean
            Dim jsonResult As Object

            Try
                objSessionMgr = New clsSessionManager
                objClsSessionData = New clsSessionData
                objClsSessionData = objSessionMgr.GetSessionData(Me.Session.SessionID, "APPDATA") 'Session("APPDATA")
                If Not objClsSessionData Is Nothing Then
                    lngPatID = objClsSessionData.PatientID
                End If
                lngUserID = SiteExcelicare.GetUSRID()
                jsonResult = SiteExcelicare.DecryptJsonData(strData)
                intItemID = jsonResult("iti")
                lngModuleID = jsonResult("imi")
                strItemType = jsonResult("sit")
                strPrinterName = jsonResult("spn")
                lngDataId = jsonResult("ldi")
                lngCustomFormID = jsonResult("lbd")
                strPrintPreviewDate = jsonResult("spd")
                blnPrintStatus = jsonResult("bps")
                objClsBizlUser = New Excelicare.Bizl.MDI.clsBizlUser
                strItemType = HttpUtility.UrlDecode(strItemType)
                strPrinterName = HttpUtility.UrlDecode(strPrinterName)
                strDatePrinted = DateTime.Now()
                If strPrintPreviewDate = "" Then
                    strPreviewDate = DateTime.Now
                Else
                    strPreviewDate = System.Convert.ToDateTime(strPrintPreviewDate).ToString(System.Configuration.ConfigurationSettings.AppSettings.Item("2981"))
                End If
                intTemp = objClsBizlUser.fnSavePrintLogDetails(lngPatID, intItemID, lngModuleID, strItemType, strPrinterName, lngUserID, strDatePrinted, lngCustomFormID, strPreviewDate, blnPrintStatus)
                If intTemp = 1 Then
                    Return "1"
                Else
                    Return "0"
                End If
            Catch ex As Exception
                Throw ex
            Finally
                intTemp = 0
                objClsBizlUser = Nothing
                objClsSessionData = Nothing
                objSessionMgr = Nothing
                jsonResult = Nothing
            End Try
        End Function
        '''----------------------------------------------------------------------------------------
        ''' <summary>To save the session log data</summary>
        ''' <history>
        ''' Version           Author                Date           Remarks
        ''' 1.0               Sagar               12.06.2020
        ''' </history>
        ''' ---------------------------------------------------------------------------------------
        Public Function fnLogWebSessionAction(strModuleName As String, strSessionID As String, lngPatId As Integer, lngEventId As Integer, strEventDetails As String, Optional int32ModuleId As Integer = -1, Optional int32RecordId As Integer = -1, Optional strRequestID As String = "")
            Try
                If strSessionID = "" Then
                    strSessionID = Session.SessionID
                End If
                clsECSession.LogWebSessionAction(strModuleName, strSessionID, lngPatId, lngEventId, strEventDetails, int32ModuleId, int32RecordId, strRequestID)
            Catch ex As Exception
            End Try
        End Function
    End Class
End Namespace