Imports System.Web
Imports System.Web.SessionState
Imports System.IO
Imports Excelicare.Framework.AppSupport
Imports System
Imports System.Diagnostics
Imports System.Reflection
Imports System.Configuration
Namespace Excelicare.UI.Web.MDI
    Public Class [Global]
        Inherits System.Web.HttpApplication

#Region " Component Designer Generated Code "
        Public Sub New()
            MyBase.New()
            'This call is required by the Component Designer.
            InitializeComponent()
            'Add any initialization after the InitializeComponent() call
        End Sub

        'Required by the Component Designer
        Private components As System.ComponentModel.IContainer

        'NOTE: The following procedure is required by the Component Designer
        'It can be modified using the Component Designer.
        'Do not modify it using the code editor.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
            components = New System.ComponentModel.Container
        End Sub

#End Region
        Sub Application_Start(ByVal sender As Object, ByVal e As EventArgs)
            Application("ApplicationInstallType") = "3,5,7"          ''Code rolled from 4.6 branch
            ' Fires when the application is started
        End Sub
         Sub Session_Start(ByVal sender As Object, ByVal e As EventArgs)
            ' Fires when the session is started
            Try
                '' Added by BRR
                Dim Cookie As HttpCookie
                Cookie = Response.Cookies("ASP.NET_SessionId")
                If Not Cookie Is Nothing
                    cookie.Path = Request.ApplicationPath
                End If
                If Request.IsSecureConnection Then Response.Cookies("ASP.NET_SessionId").Secure = True
            Catch ex As Exception
            End Try
        End Sub
        Sub Application_BeginRequest(ByVal sender As Object, ByVal e As EventArgs)
            ' Fires at the beginning of each request
        End Sub
        Sub Application_AuthenticateRequest(ByVal sender As Object, ByVal e As EventArgs)
            ' Fires upon attempting to authenticate the use
        End Sub
        Sub Application_Error(ByVal sender As Object, ByVal e As EventArgs)            ' Fires when an error occurs

            'Dim objAxException As New clsExceptionHandler(Server.GetLastError, Session, Request)
            'objAxException.LogException()
            Response.Redirect("frmCustomMessage.aspx", False)

        End Sub
        Sub Session_End(ByVal sender As Object, ByVal e As EventArgs)   ''Code rolled E19917
            ' Fires when the session ends
            Dim objECSession As clsECSession
            Dim strPath As String = ""
            Try
                
                objECSession = New clsECSession
                clsECSession.LogWebSessionAction("Excelicare MDI", Session.SessionID, 0, 2038, "Session END from Global.asax", 1032, 0)
                objECSession.EndSession(Session.SessionID, 0)
                DeleteOtherStoreFiles()         
                If Not ConfigurationManager.AppSettings("AxServerTempFolder") Is Nothing Then
                    strPath = ConfigurationManager.AppSettings("AxServerTempFolder").ToString.Trim
                    If Directory.Exists(strPath) Then
                        If (strPath.EndsWith("/") = True Or strPath.EndsWith("\") = True) Then
                            If Directory.Exists(strPath & Session.SessionID) Then
                                Directory.Delete(strPath & Session.SessionID, True)
                            End If
                        Else
                            If Directory.Exists(strPath & "/" & Session.SessionID) Then
                                Directory.Delete(strPath & "/" & Session.SessionID, True)
                            End If
                        End If
                    End If
                End If
            Catch ex As Exception
                Dim objExceptionHandler As New clsExceptionHandler(ex)
                objExceptionHandler.LogException()
            End Try
        End Sub
        Sub Application_End(ByVal sender As Object, ByVal e As EventArgs)            ''Code rolled E19917
            ' Fires when the application ends
            Dim _shutDownMessage As String = ""
            Try
                Dim oRuntime As HttpRuntime
                oRuntime = GetType(System.Web.HttpRuntime).InvokeMember("_theRuntime", BindingFlags.NonPublic Or BindingFlags.Static Or BindingFlags.GetField, Nothing, Nothing, Nothing)
                If Not oRuntime Is Nothing Then
                    _shutDownMessage = oRuntime.GetType().InvokeMember("_shutDownMessage", BindingFlags.NonPublic Or BindingFlags.Instance Or BindingFlags.GetField, Nothing, oRuntime, Nothing)
                End If
            Catch ex As Exception
                Dim objExceptionHandler As New clsExceptionHandler(ex)
                objExceptionHandler.LogException()
            End Try
            Try
                clsECSession.LogWebSessionAction("Excelicare MDI", "Ax " & DateTime.Now.ToString, 0, 2038, "Application END from Global.asax _shutDownMessage: " & vbCrLf & _shutDownMessage, 1032, 0)
            Catch ex As Exception
                Dim objExceptionHandler As New clsExceptionHandler(ex)
                objExceptionHandler.LogException()
            End Try
        End Sub
        Private Sub Global_AuthenticateRequest(sender As Object, e As System.EventArgs) Handles Me.AuthenticateRequest
        End Sub
        Private Sub Global_asax_BeginRequest(sender As Object, e As System.EventArgs) Handles Me.BeginRequest
            ''Dim objECSession As clsECSession
            ''Dim strCausedHackHTMLTags() As String = {"<applet>", "<body>", "<embed>", "<frame>", "<script>", "<frameset>", "<html>", "<iframe>", "<img>", "<style>", "<layer>", "<link>", "<ilayer>", "<meta>", "<object>", "alert(", "<title>", "<iframe", "<script", "<img", "<style", "style", "http", "phishing", "trim"}
            ''Try
            ''    If sender.Request.Headers.item("User-Agent").ToString().IndexOf("<script>") > 0 Or sender.Request.Headers.item("User-Agent").ToString().IndexOf("alert") > 0 Then
            ''        objECSession = New clsECSession
            ''        clsECSession.LogWebSessionAction("Excelicare MDI", Session.SessionID, 0, 2038, "Session END due to http request header change", 1032, 0)
            ''        objECSession.EndSession(Session.SessionID, 0)
            ''        Response.End()
            ''    ElseIf sender.Request.Headers.item("Cookie").ToString().IndexOf("<script>") > 0 Or sender.Request.Headers.item("Cookie").ToString().IndexOf("alert") > 0 Then
            ''        objECSession = New clsECSession
            ''        clsECSession.LogWebSessionAction("Excelicare MDI", Session.SessionID, 0, 2038, "Session END due to http request header change", 1032, 0)
            ''        objECSession.EndSession(Session.SessionID, 0)
            ''        Response.End()
            ''    ElseIf sender.Request.Headers.item("Accept-Language").ToString().IndexOf("<script>") > 0 Or sender.Request.Headers.item("Accept-Language").ToString().IndexOf("alert") > 0 Then
            ''        objECSession = New clsECSession
            ''        clsECSession.LogWebSessionAction("Excelicare MDI", Session.SessionID, 0, 2038, "Session END due to http request header change", 1032, 0)
            ''        objECSession.EndSession(Session.SessionID, 0)
            ''        Response.End()
            ''    End If
            'Catch ex As Exception
            '    Finally
            '        '' objECSession = Nothing
            '    End Try

        End Sub

        Private Sub Global_PreRequestHandlerExecute(sender As Object, e As System.EventArgs) Handles Me.PreRequestHandlerExecute
            Dim objECSession As clsECSession
            Dim strConfigReferer As String = ""
            Dim strOriginalReferer As String = ""
            Try
                If IsNothing(System.Configuration.ConfigurationManager.AppSettings("Referrer")) = False AndAlso IsNothing(sender.Request.Headers.Item("Referer")) = False Then
                    strConfigReferer = "," & System.Configuration.ConfigurationManager.AppSettings("Referrer") & ","
                    strOriginalReferer = sender.Request.Headers.Item("Referer").Split("/")(2)
                End If

                If IsNothing(sender.Request.Headers.Item("Referer")) = False AndAlso sender.Request.Headers.Item("Referer").IndexOf(sender.Request.ApplicationPath, StringComparison.OrdinalIgnoreCase) = -1 AndAlso strConfigReferer.IndexOf("," & strOriginalReferer & ",", StringComparison.OrdinalIgnoreCase) = -1 Then
                    objECSession = New clsECSession
                    clsECSession.LogWebSessionAction("Excelicare MDI", Session.SessionID, 0, 2038, "Session END from wrong referer -" & sender.Request.Headers.Item("Referer") & ";application:" & sender.Request.ApplicationPath, 1032, 0)
                    objECSession.EndSession(Session.SessionID, 0)
                    Response.End()
                End If
                If sender.Request.Browser.Browser = "IE" AndAlso sender.Request.Browser.Version = "8.0" Then
                    If IsNothing(sender.Request.Headers.Item("Referer")) = True AndAlso IsNothing(HttpContext.Current.Session) = False AndAlso IsNothing(Session("APPDATA")) = False AndAlso Request.Path.ToLower.IndexOf("axwebuiappointmentscheduler") = -1 AndAlso Request.Path.ToLower.IndexOf("frmexcelicaremdi.aspx") = -1 AndAlso Request.Path.ToLower.IndexOf("customerror.aspx") = -1 AndAlso Request.Path.ToLower.IndexOf("index.aspx") = -1 AndAlso Request.Path.ToLower.IndexOf("axwebuilogin") = -1 AndAlso Request.Path.ToLower.IndexOf("default.") = -1 AndAlso Request.Params("un") Is Nothing AndAlso Request.Params("pwd") Is Nothing AndAlso Request.Params("popup") <> "window"  Then
                        Response.Redirect("~/AxWebUIMDI/CustomError.Aspx?ErrorCode=User session is active in this machine, please close the active session or open the URL in different browser.", False)
                    End If
                ElseIf IsNothing(sender.Request.Headers.Item("Referer")) = True AndAlso IsNothing(HttpContext.Current.Session) = False AndAlso IsNothing(Session("APPDATA")) = False AndAlso Request.Path.ToLower.IndexOf("axwebuiappointmentscheduler") = -1 AndAlso Request.Path.ToLower.IndexOf("default.") = -1 AndAlso Request.Path.ToLower.IndexOf("index.aspx") = -1 AndAlso Request.Path.ToLower.IndexOf("axwebuilogin") = -1 AndAlso Request.Path.ToLower.IndexOf("customerror.aspx") = -1 AndAlso Request.Params("un") Is Nothing AndAlso Request.Params("pwd") Is Nothing  AndAlso Request.Params("popup") <> "window" AndAlso Request.Path.ToLower.IndexOf("sso_generic_inbound.aspx") > 0 Then
                    Response.Redirect("~/AxWebUIMDI/CustomError.Aspx?ErrorCode=User session is active in this machine, please close the active session or open the URL in different browser.", False)
                End If
            Catch ex As Exception
                Dim objExceptionHandler As New clsExceptionHandler(ex)
                objExceptionHandler.LogException()
            Finally
                objECSession = Nothing
            End Try
        End Sub
        ' -----------------------------------------------------------------------------
        ' <summary>
        '      This is used to delete the other store XML file created in the curent user session 
        ' </summary>
        ' <returns></returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Krishna Prasad S]    25/03/2015  Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Private Sub DeleteOtherStoreFiles()
            ''Try
            ''    If Not ConfigurationManager.AppSettings("OSPatientFilePath") Is Nothing Then
            ''        If ConfigurationManager.AppSettings("OSPatientFilePath").ToString <> "" Then
            ''            Dim strOSPath As String = ConfigurationManager.AppSettings("OSPatientFilePath").ToString
            ''            If strOSPath <> "" Then
            ''                If strOSPath.Substring(strOSPath.Length - 1) <> "/" Or strOSPath.Substring(strOSPath.Length - 1) <> "\" Then
            ''                    strOSPath = strOSPath & "\" & "OSPatientData_" & HttpContext.Current.Session.SessionID & ".XML"
            ''                End If
            ''                If File.Exists(strOSPath) Then
            ''                    File.Delete(strOSPath)
            ''                End If
            ''            End If
            ''        End If
            ''    End If
            ''Catch ex As Exception
            ''    Dim objExceptionHandler As New clsExceptionHandler(ex)
            ''    objExceptionHandler.LogException()
            ''Finally
            ''End Try
        End Sub
    End Class
End Namespace
