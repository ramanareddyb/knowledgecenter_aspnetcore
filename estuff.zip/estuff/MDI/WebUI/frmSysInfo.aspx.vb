'Imports System.IO
Imports Excelicare.VersionInfo
Imports Excelicare.Framework.AppSupport
Imports Excelicare.Bizl.MDI

Namespace AxSys.UI.Web.MDI
    Partial Class frmSysInfo
        Inherits System.Web.UI.Page
        Public m_strLogoIcons As String = String.Empty
        Protected strVerNo As String = ""
#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub
        Public IEVersion As String = String.Empty
        Public CookiesStatus As String = String.Empty
        Public ScreenHW As String = String.Empty
        Public Os As String = String.Empty
        Public ActiveX As String = String.Empty
        Public strPageTitle As String = "ExcelicareWeb"
        Protected WithEvents btnShow As System.Web.UI.HtmlControls.HtmlInputButton
        Protected WithEvents btnHealthCheck As System.Web.UI.HtmlControls.HtmlInputButton
        Protected WithEvents tblCompVersion As System.Web.UI.HtmlControls.HtmlTable


        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            'Put user code to initialize the page here
            Dim objSysDefault As clsSysDefault
            Dim objGetVersionNo As clsAppSettings
            Try
                Response.Expires = -1
                Response.Cache.SetNoServerCaching()
                Response.Cache.SetAllowResponseInBrowserHistory(False)
                Response.CacheControl = "no-cache"
                Response.Cache.SetNoStore()
                objSysDefault = New clsSysDefault
                objGetVersionNo = New clsAppSettings
                strVerNo = objGetVersionNo.GetModuleVersion("1031")
                m_strLogoIcons = Server.UrlEncode(objSysDefault.GetSysDefaultValue(2081))
                m_strLogoIcons = m_strLogoIcons.Replace("+", " ")
                If Not ConfigurationSettings.AppSettings("SysInfoTitle") Is Nothing Then
                    If ConfigurationSettings.AppSettings("SysInfoTitle").ToString <> "" Then
                        strPageTitle = ConfigurationSettings.AppSettings("SysInfoTitle").ToString
                    End If
                End If
                If Not IsPostBack Then
                    GetReleaseInfo()
                End If
                hdnVersion.Value = Request.Browser.MajorVersion 'Added By Chandra to get the BrowserVersion Number
            Catch ex As Exception
                LogException(ex)
            Finally
                objGetVersionNo = Nothing
                objSysDefault = Nothing
            End Try
        End Sub

        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This function is used to fill the release information
        ' </summary>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]    16.02.2006  Created
        ' </history>
        ' -----------------------------------------------------------------------------

        Public Sub GetReleaseInfo()
            Dim strReleaseSummary As String = ""
            Dim objclsVersionInfo As New clsVersionInfo
            Dim strReleaseInfo As String = ""
            Dim strReleaseInfoarray() As String
            Dim strDBName As String = ""
            Dim strConnString As String = ""
            Dim objclsSecurity As New clsSecurity
            Dim dsDBDetails As DataSet
            Dim objGetVersionNo As clsAppSettings
            Try
                strReleaseInfo = objclsVersionInfo.GetReleaseInfo()
                If strReleaseInfo <> "" Then
                    strReleaseInfoarray = strReleaseInfo.Split(Chr(22))
                End If
                If strReleaseInfoarray.Length > 0 And strReleaseInfoarray.Length = 4 Then
                    lblECversion.Text = strReleaseInfoarray(0)
                    txtReleaseSummary.Text = "  " & strReleaseInfoarray(1)
                    lblReleaseDate.Text = strReleaseInfoarray(2)
                End If
                objGetVersionNo = New clsAppSettings
                dsDBDetails = clsBizlSysModule.GetDBVersion()
                lblDBversion.Text = dsDBDetails.Tables(0).Rows(0)(1).ToString()
                If Not ConfigurationSettings.AppSettings("ConnectionString") Is Nothing Then
                    strConnString = ConfigurationSettings.AppSettings("ConnectionString").ToString
                    If strConnString <> "" Then
                        If strConnString.ToUpper.IndexOf("Initial Catalog".ToUpper) <> -1 Then
                            strConnString = strConnString.Substring(strConnString.ToUpper.IndexOf("Initial Catalog".ToUpper) + "Initial Catalog".Length)
                            If strConnString.IndexOf("=") <> -1 Then
                                strConnString = strConnString.Split("=")(1)
                            End If
                            If strConnString.IndexOf(";") <> -1 Then
                                strDBName = strConnString.Split(";")(0)
                            End If
                        End If
                    End If
                End If
                Dim strDBServer As String = ""
                If Not ConfigurationSettings.AppSettings("ConnectionString") Is Nothing Then
                    strConnString = ConfigurationSettings.AppSettings("ConnectionString").ToString
                    If strConnString <> "" Then
                        If strConnString.ToUpper.IndexOf("Data Source".ToUpper) <> -1 Then
                            strConnString = strConnString.Substring(strConnString.ToUpper.IndexOf("Data Source".ToUpper) + "Data Source".Length)
                            If strConnString.IndexOf("=") <> -1 Then
                                strConnString = strConnString.Split("=")(1)
                            End If
                            If strConnString.IndexOf(";") <> -1 Then
                                strDBServer = strConnString.Split(";")(0)
                            End If
                        End If
                    End If
                End If
                If lblDBversion.Text.Length > 35 Then
                    lblDBversion.ToolTip = lblDBversion.Text
                    lblDBversion.Text = lblDBversion.Text.Substring(0, 35) + "..."
                End If
                If strDBServer <> "" Then
                    txtDBServer.Value = objclsSecurity.SHA256(strDBServer)
                End If
            Catch ex As Exception
                LogException(ex)
            Finally
                objclsSecurity = Nothing
                objclsVersionInfo = Nothing
                strReleaseSummary = Nothing
                strReleaseInfo = Nothing
                strReleaseInfoarray = Nothing
                strDBName = Nothing
                strConnString = Nothing
                objGetVersionNo = Nothing
                dsDBDetails = Nothing
            End Try
        End Sub

#Region "Exception Handling Methods"

        ' -----------------------------------------------------------------------------
        ' <summary>
        '   This function is used to log the exceptions
        ' </summary>
        ' <remarks>
        ' </remarks>
        ' <history>
        ' 	    [Suneetha B]	13/02/2006	Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Private Sub LogException(ByVal objExcep As Exception)
            Dim objClsExceptionHandler As clsExceptionHandler
            Try
                objClsExceptionHandler = New clsExceptionHandler(objExcep)
                If Not IsNothing(Page) Then
                    objClsExceptionHandler.LogException(Page)
                Else
                    objClsExceptionHandler.LogException()
                End If
            Catch ex As Exception
                objClsExceptionHandler = New clsExceptionHandler(ex)
                If Not IsNothing(Page) Then
                    objClsExceptionHandler.LogException(Page)
                Else
                    objClsExceptionHandler.LogException()
                End If
            Finally
                objClsExceptionHandler = Nothing
            End Try

        End Sub

#End Region

        Protected Overrides Sub Finalize()
            MyBase.Finalize()
        End Sub
    End Class

End Namespace
