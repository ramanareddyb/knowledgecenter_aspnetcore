var m_mdiWindow = getRootNode(window);
m_mdiWindow = parentWindow;
var DialogStack = new Array();
var DialogStackModuleID = new Array();
        var objVariables = [];
        function setValue(key, value) {
            objVariables[key] = value;
        }
        function getValue(key) {
            return objVariables[key];
        }

        function addToStack(strURL){
			DialogStack.push(strURL);
			return false;
		}
		
		function addModuleIDToStack(ModuleID){
			DialogStackModuleID.push(ModuleID);
			return false;
		}
		
		function removeFromStack(){
			DialogStack.pop();
			DialogStackModuleID.pop();
			return false;
		}
		
		function getFromStack(){
			DialogStack.pop();
			return DialogStack.pop();
		}
		
		function getModuleIDFromStack(){
			DialogStackModuleID.pop();
			return DialogStackModuleID.pop();
		}
		
		function removeAllFromStack(){
			DialogStack = new Array();
			DialogStackModuleID = new Array();
			return true;
		}
		function getStackCount(){
			return DialogStack.length;
		}
		function getStackURL(index){
			return DialogStack[index];			
		}
		function updateStackURL(index,strURL){
			DialogStack[index] = strURL;
			return false;
		}
		function GetSysActionMenuItems(strMenuGroupItemName,strActionName){
			var SysActionMenuItem = ""
			if(strMenuGroupItemName != "" && strMenuGroupItemName != undefined && strMenuGroupItemName != null){
				if ($ec.fn.getValue(strMenuGroupItemName) == undefined ||$ec.fn.getValue(strMenuGroupItemName)== null || $ec.fn.getValue(strMenuGroupItemName) == ""){
					SysActionMenuItem = SiteExcelicare.GetSysActionMenuItems(fnGetSysActionMenuItems(strMenuGroupItemName,strActionName));
					SysActionMenuItem.value = $ec.fn.ecDecode(SysActionMenuItem.value)
					$ec.fn.setValue(strMenuGroupItemName, SysActionMenuItem.value);
				}
				return $ec.fn.getValue(strMenuGroupItemName);
			}
			else  return ""
		}
		function fnSaveMessageTrayItems(objArrMsgData,lngPatientID){
			try{
				if(objArrMsgData != null && objArrMsgData != undefined && objArrMsgData.length > 0 ){
					objJsonData = $ec.fn.et(JSON.stringify(objArrMsgData))
					return SiteExcelicare.fnSaveMessageTrayItems(objJsonData);
				}
				else
					return "";
			}
			catch(ex){ }
		}		
		function GetMessageTrayCount(lngPatientID){
			try{
				if(lngPatientID != null && lngPatientID != undefined && lngPatientID> 0 ){
					 return SiteExcelicare.GetMessageTrayCount();
				}
				else
					return 0;
			}
			catch(ex){ }
		}
		function GetPdlCount(moduleId, recordId, patientId, customFormId,userId) {
		    try {
		        if (patientId != null && patientId != undefined && patientId > 0) {
		            return SiteExcelicare.GetPdlCount(fnGetPdlCount(moduleId, recordId, customFormId));
		        }
		        else
		            return 0;
		    }
		    catch (ex) { }
		}
		function fnDeleteMessageTrayItems(strUniqueID,intMsgType){
			try{
				if(strUniqueID != null && strUniqueID != undefined && strUniqueID != "" ){
					if(intMsgType==undefined)intMsgType=-1
					 strJsonData = JSON.stringify({"strUniqueID": strUniqueID, "intMsgType": intMsgType})
					 return  SiteExcelicare.fnDeleteMessageTrayItems($ec.fn.et(strJsonData));
				}
			}
			catch(ex){ }
		} 
        //script used to capture browser close button Added by Suneetha B on 03.06.2005

        $(window).bind('beforeunload1', function (e) {
            if (m_strCalledFrom.toLowerCase() == "ssoep" || m_strCalledFrom.toLowerCase() == "ssoer") {
            
                var strReturnValue = frmExcelicareMDI.fnSaveArtifactDetails(intUserID, m_lngPatientID, 1136)
                window.open("", "_self", "");
                window.opener = m_mdiWindow;
                window.close();
            }
            
            //}
            
        })
        
        
		function fnPrintLog(blnPrintStatus){
		  var oRetValue;
		  var intItemID=-1;
		  var strItemType=''
		  var strPreviewDate=''
		  var intBaseFormID=0,intModuleId,intPatientId;
		  try{				 
				for(var i=0;i<JSON.parse($ec.fn.getValue('PrintDetails')).PrintRecord.length;i++){
					intItemID=JSON.parse($ec.fn.getValue('PrintDetails')).PrintRecord[i].ItemID
					strItemType=JSON.parse($ec.fn.getValue('PrintDetails')).PrintRecord[i].ItemName	
					if(typeof(JSON.parse($ec.fn.getValue('PrintDetails')).PrintRecord[i].CustomFormID)!= "undefined")
						intBaseFormID=JSON.parse($ec.fn.getValue('PrintDetails')).PrintRecord[i].CustomFormID
					if(typeof(JSON.parse($ec.fn.getValue('PrintDetails')).PrintRecord[i].PrintPreviewedDT)!= "undefined")
						strPreviewDate=JSON.parse($ec.fn.getValue('PrintDetails')).PrintRecord[i].PrintPreviewedDT 
					if(typeof(JSON.parse($ec.fn.getValue('PrintDetails')).PrintRecord[i].ModuleId)!= "undefined")
						intModuleId=JSON.parse($ec.fn.getValue('PrintDetails')).PrintRecord[i].ModuleId 
					else 
						intModuleId =$ec.fn.getValue("ModuleId")
					if(typeof(JSON.parse($ec.fn.getValue('PrintDetails')).PrintRecord[i].PatId)!= "undefined")
						intPatientId=JSON.parse($ec.fn.getValue('PrintDetails')).PrintRecord[i].PatId 
					else 
						intPatientId =$ec.fn.getPatient()
						var lngUserID = $ec.fn.getValue("UserId")
						var strPrinterName = ''
						var lngDataId = -1
					oRetValue=frmExcelicareMDI.SavePrintLogDetails(fnSavePrintLogDetails(intItemID,intModuleId,strItemType,strPrinterName,lngDataId,intBaseFormID,strPreviewDate,blnPrintStatus));
				}
					with (oRetValue) {
					if (error != null) return "error";
					return "success";
				}			
		  }
		  catch(ex){}
		  finally{oRetValue=intItemID=strItemType=null;}
		}


		
// To end the session when browser is closed added by Suneetha B
        function fnDeleteTempFiles() {
            try {
                objXMLHTTPreq = new ActiveXObject("Msxml2.XMLHTTP");
            }
            catch (e) {
                try {
                    objXMLHTTPreq = new ActiveXObject("Microsoft.XMLHTTP");
                }
                catch (oc) {
                    objXMLHTTPreq = null;
                }
            }

            if (!objXMLHTTPreq && typeof XMLHttpRequest != "undefined") {
                objXMLHTTPreq = new XMLHttpRequest();
            }
			var url = "frmEndSession.aspx?strQPData=" + $ec.fn.ecEncode("UserID=" + intUserID);

            if (objXMLHTTPreq != null) {

                objXMLHTTPreq.open("POST", url, false);
                objXMLHTTPreq.send();
            }

        }


        $(document).ready(function () {
			var strEveData = "Loading MDI- "+ strInfo
			strJsonData = JSON.stringify({"lngEventId": 2039, "lngPatId": -1, "strEventDet": strEveData })
			strJsonData = $ec.fn.et(strJsonData)
			frmExcelicareMDI.fnlogECWebSessionAction(strJsonData)
            PatientBanner.Hide();
            $("#bannerContainer a[url]").click(function () {
                PatientBanner.Navigate($(this))
            });

            if (blnPwdPromptRequired == '1' || blnPwdPromptRequired == '2' || blnPwdExpired == 'True') {
                var intDijit = setInterval(function() {
                if (typeof(dijit) != "undefined" && m_mdiWindow.document.readyState == "complete") {
                    clearInterval(intDijit);
                   m_mdiWindow.drpUserName_onChange(true);
                }
            }, 200
	        );
                $("#fraContent").prop("src", "../frmBlankPage.htm");
            }
        });

        /*Patient Banner Object - Start*/
        PatientBanner = {
            Toggle: function () {
                if ($("#bannerContainer").is(":visible")) {
                    PatientBanner.Hide();
                } else {
                     $("#bannerContainer").show("slide");
					 $ec.fn.mask('Loading...');
					$("#fraPatient").prop("src", "../AxFXWebUISummaryPanel/frmLinkedForm.aspx?linkedFormId=128&LO=1");
                    $("#zone2", m_mdiWindow.frames.fraPatientBar.document).addClass("zone2_Toggle").prop("title", "Hide Patient Banner");
                    $("#zone_Facility", m_mdiWindow.frames.fraPatientBar.document).addClass("zone_Facility_Toggle").prop("title", "Hide Facility Banner"); 
                }
            },
            Hide: function () {
                $("#bannerContainer").hide("slide");
				$("#frames1").attr("src","")
                $("#zone2", m_mdiWindow.frames.fraPatientBar.document).removeClass("zone2_Toggle").prop("title", "Show Patient Banner");
                $("#zone_Facility", m_mdiWindow.frames.fraPatientBar.document).removeClass("zone_Facility_Toggle").prop("title", "Show Facility Banner");  
            },
            Display: function (address, phone, allergy, clinicianinfo, systeminfo) {
                PatientBanner.Hide();
                $("#bannerContainer td[address]").html(address);
                $("#bannerContainer td[mobile]").html(phone);
                $("#bannerContainer td[allergies]").html(allergy);
                //$("#bannerContainer td[clinicianinfo]").html(clinicianinfo);

                //$("#bannerContainer td[systeminfo]").html(systeminfo);
            },
            Navigate: function (obj) {
                PatientBanner.Hide();
                if ($(obj).attr('url') != '') {
                    if (typeof (m_mdiWindow.frames.fraContent.frames.fraLayoutContent.isFormDirty) === "function" && m_mdiWindow.frames.fraContent.frames.fraLayoutContent.isFormDirty(function () { m_mdiWindow.frames.fraContent.frames.fraLayoutContent.window.location.href = $(obj).attr('url'); }, "m_mdiWindow.frames.fraContent.frames.fraLayoutContent.window.location.href = $(obj).attr('url');"))
                        return false;
                    else
                        m_mdiWindow.frames.fraContent.frames.fraLayoutContent.window.location.href = $(obj).attr('url');
                }
            }
        };	
		//Added by BRR to get the clientinformation of OS,Browser,Mobile,Flash,Offset,Screenresolution
		(function (window) {
			{
			var unknown = '-';
			// screen
			var screenSize = '';
			if (screen.width) {
				width = (screen.width) ? screen.width : '';
				height = (screen.height) ? screen.height : '';
				screenSize += '' + width + " x " + height;
			}
			//browser
			var nVer = navigator.appVersion;
			var nAgt = navigator.userAgent;
			var browser = navigator.appName;
			var version = '' + parseFloat(navigator.appVersion);
			var majorVersion = parseInt(navigator.appVersion, 10);
			var nameOffset, verOffset, ix;

			// Opera
			if ((verOffset = nAgt.indexOf('Opera')) != -1) {
				browser = 'Opera';
				version = nAgt.substring(verOffset + 6);
				if ((verOffset = nAgt.indexOf('Version')) != -1) {
				version = nAgt.substring(verOffset + 8);
				}
			}
			// MSIE
			else if ((verOffset = nAgt.indexOf('MSIE')) != -1) {
				browser = 'Microsoft Internet Explorer';
				version = nAgt.substring(verOffset + 5);
			}
			// Chrome
			else if ((verOffset = nAgt.indexOf('Chrome')) != -1) {
				browser = 'Chrome';
				version = nAgt.substring(verOffset + 7);
			}
			// Safari
			else if ((verOffset = nAgt.indexOf('Safari')) != -1) {
				browser = 'Safari';
				version = nAgt.substring(verOffset + 7);
				if ((verOffset = nAgt.indexOf('Version')) != -1) {
				version = nAgt.substring(verOffset + 8);
				}
			}
			// Firefox
			else if ((verOffset = nAgt.indexOf('Firefox')) != -1) {
				browser = 'Firefox';
				version = nAgt.substring(verOffset + 8);
			}
			// MSIE 11+
			else if (nAgt.indexOf('Trident/') != -1) {
				browser = 'Microsoft Internet Explorer';
				version = nAgt.substring(nAgt.indexOf('rv:') + 3);
			}
			// Other browsers
			else if ((nameOffset = nAgt.lastIndexOf(' ') + 1) < (verOffset = nAgt.lastIndexOf('/'))) {
				browser = nAgt.substring(nameOffset, verOffset);
				version = nAgt.substring(verOffset + 1);
				if (browser.toLowerCase() == browser.toUpperCase()) {
				browser = navigator.appName;
				}
			}
			// trim the version string
			if ((ix = version.indexOf(';')) != -1) version = version.substring(0, ix);
			if ((ix = version.indexOf(' ')) != -1) version = version.substring(0, ix);
			if ((ix = version.indexOf(')')) != -1) version = version.substring(0, ix);

			majorVersion = parseInt('' + version, 10);
			if (isNaN(majorVersion)) {
				version = '' + parseFloat(navigator.appVersion);
				majorVersion = parseInt(navigator.appVersion, 10);
			}

			// mobile version
			var mobile = /Mobile|mini|Fennec|Android|iP(ad|od|hone)/.test(nVer);
			
			// cookie
			var cookieEnabled = (navigator.cookieEnabled) ? true : false;

			if (typeof navigator.cookieEnabled == 'undefined' && !cookieEnabled) {
				document.cookie = 'testcookie';
				cookieEnabled = (document.cookie.indexOf('testcookie') != -1) ? true : false;
			}

			// system
			var os = unknown;
			var clientStrings = [
				{s:'Windows 10', r:/(Windows 10.0|Windows NT 10.0)/},
				{s:'Windows 8.1', r:/(Windows 8.1|Windows NT 6.3)/},
				{s:'Windows 8', r:/(Windows 8|Windows NT 6.2)/},
				{s:'Windows 7', r:/(Windows 7|Windows NT 6.1)/},
				{s:'Windows Vista', r:/Windows NT 6.0/},
				{s:'Windows Server 2003', r:/Windows NT 5.2/},
				{s:'Windows XP', r:/(Windows NT 5.1|Windows XP)/},
				{s:'Windows 2000', r:/(Windows NT 5.0|Windows 2000)/},
				{s:'Windows ME', r:/(Win 9x 4.90|Windows ME)/},
				{s:'Windows 98', r:/(Windows 98|Win98)/},
				{s:'Windows 95', r:/(Windows 95|Win95|Windows_95)/},
				{s:'Windows NT 4.0', r:/(Windows NT 4.0|WinNT4.0|WinNT|Windows NT)/},
				{s:'Windows CE', r:/Windows CE/},
				{s:'Windows 3.11', r:/Win16/},
				{s:'Android', r:/Android/},
				{s:'Open BSD', r:/OpenBSD/},
				{s:'Sun OS', r:/SunOS/},
				{s:'Linux', r:/(Linux|X11)/},
				{s:'iOS', r:/(iPhone|iPad|iPod)/},
				{s:'Mac OS X', r:/Mac OS X/},
				{s:'Mac OS', r:/(MacPPC|MacIntel|Mac_PowerPC|Macintosh)/},
				{s:'QNX', r:/QNX/},
				{s:'UNIX', r:/UNIX/},
				{s:'BeOS', r:/BeOS/},
				{s:'OS/2', r:/OS\/2/},
				{s:'Search Bot', r:/(nuhk|Googlebot|Yammybot|Openbot|Slurp|MSNBot|Ask Jeeves\/Teoma|ia_archiver)/}
			];
			for (var id in clientStrings) {
				var cs = clientStrings[id];
				if (cs.r.test(nAgt)) {
				os = cs.s;
				break;
				}
			}

			var osVersion = unknown;

			if (/Windows/.test(os)) {
				osVersion = /Windows (.*)/.exec(os)[1];
				os = 'Windows';
			}

			switch (os) {
				case 'Mac OS X':
				osVersion = /Mac OS X (10[\.\_\d]+)/.exec(nAgt)[1];
				break;

				case 'Android':
				osVersion = /Android ([\.\_\d]+)/.exec(nAgt)[1];
				break;

				case 'iOS':
				osVersion = /OS (\d+)_(\d+)_?(\d+)?/.exec(nVer);
				osVersion = osVersion[1] + '.' + osVersion[2] + '.' + (osVersion[3] | 0);
				break;
			}

			var flashVersion = 'no check', d, fv = [];
			if (typeof navigator.plugins !== 'undefined' && typeof navigator.plugins["Shockwave Flash"] === "object") {
				d = navigator.plugins["Shockwave Flash"].description;
				if (d && !(typeof navigator.mimeTypes !== 'undefined' && navigator.mimeTypes["application/x-shockwave-flash"] && !navigator.mimeTypes["application/x-shockwave-flash"].enabledPlugin)) { // navigator.mimeTypes["application/x-shockwave-flash"].enabledPlugin indicates whether plug-ins are enabled or disabled in Safari 3+
				d = d.replace(/^.*\s+(\S+\s+\S+$)/, "$1");
				fv[0] = parseInt(d.replace(/^(.*)\..*$/, "$1"), 10);
				fv[1] = parseInt(d.replace(/^.*\.(.*)\s.*$/, "$1"), 10);
				fv[2] = /[a-zA-Z]/.test(d) ? parseInt(d.replace(/^.*[a-zA-Z]+(.*)$/, "$1"), 10) : 0;
				}
			} else if (typeof window.ActiveXObject !== 'undefined') {
				try {
				var a = new ActiveXObject("ShockwaveFlash.ShockwaveFlash");
				if (a) { // a will return null when ActiveX is disabled
					d = a.GetVariable("$version");
					if (d) {
					d = d.split(" ")[1].split(",");
					fv = [parseInt(d[0], 10), parseInt(d[1], 10), parseInt(d[2], 10)];
					}
				}
				}
				catch(e) {}
			}
			if (fv.length) {
				flashVersion = fv[0] + '.' + fv[1] + ' r' + fv[2];
			}    
			}
			var offset =new Date();	
			window.ClientInfo = {
			screen: screenSize,
			browser: browser,
			browserVersion: version,
			mobile: mobile,
			os: os,
			osVersion: osVersion,
			cookies: cookieEnabled,
			flashVersion: flashVersion,
			timezone: offset.getTimezoneOffset()
			};
		}(this));
		var strInfo='\n' + 'OS: ' + ClientInfo.os +' '+ ClientInfo.osVersion + '\n'+
			'Browser: ' + ClientInfo.browser +' '+ ClientInfo.browserVersion + '\n' + 
			//'Mobile: ' + jscd.mobile + '\n' +
			//'Flash: ' + jscd.flashVersion + '\n' +
			//'Cookies: ' + jscd.cookies + '\n' +
			'TimeZoneOffset: ' + ClientInfo.timezone + ' mins\n' +
			'Screen Size: ' + ClientInfo.screen;
			//'Full User Agent: ' + navigator.userAgent;
			
function fnSavePrintLogDetails(intItemID,intModuleId,strItemType,strPrinterName,lngDataId,intBaseFormID,strPreviewDate,blnPrintStatus)
{
	try{
		strJsonData = JSON.stringify({"iti": intItemID, "imi": intModuleId, "sit": strItemType, "spn": strPrinterName, "ldi": lngDataId, "lbd": intBaseFormID, "spd": strPreviewDate, "bps": blnPrintStatus})
		return $ec.fn.et(strJsonData);		
	   }catch(e){}
}

function fnGetPdlCount(moduleId, recordId, customFormId)
{
	try{
		objJsonData = {"mid": moduleId, "rid": recordId, "cid": customFormId}
        return fnEncryptData(objJsonData)
	}catch(e){}
}

function fnGetSysActionMenuItems(strMenuGroupItemName,strActionName)
{
	try{
		objJsonData = {"strMenuGroupItemName": strMenuGroupItemName, "strActionName": strActionName}
        return fnEncryptData(objJsonData)
	}catch(e){}
}