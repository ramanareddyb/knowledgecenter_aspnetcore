function fnPrinthistoryCallback()
{
	var callback1 = function(retVal){
			alert(1)
			if(retVal==6){
				if (typeof (window.top.opener) != "undefined" && window.top.opener != undefined)
				{		
					window.top.opener.fnPrintLog(true);
					 
				}
				else
				{
					window.top.fnPrintLog(true);
				 
				}
			}			
			else 
			{
				if (typeof (window.top.opener) != "undefined" && window.top.opener != undefined)
				{		
					window.top.opener.fnPrintLog(false);
					 
				}
				else
				{
					window.top.fnPrintLog(false);
					 
				}
			}
		}
	 	var strDialogURL ='https://excelicareweb.axsys-healthtech.com/ECWEB_v65NASH_652/AxFXDialog/frmDialogPage.aspx?t=&p=Was%20your%20print%20out%20successful%3F&bs=4&is=1';
						AxOpenDojo(strDialogURL, 410, 150,'Print','',function(retVal) {
					callback1(retVal);
					return;
				});
					
}