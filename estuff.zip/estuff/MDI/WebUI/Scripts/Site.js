var m_mdiWindow = getRootNode(window);
m_mdiWindow = parentWindow;
var dtServerTime = new Date(m_strServerDate);
var intDiffinSeconds = (new Date(Date()) - dtServerTime) / 1000;
var m_blnLogoutClicked = false;
var isLogOff = false;
var tempURL;
var strPDLReturnID, blnShowTRBold, lngPDLModuleID, strPDLdataXML, strPDLReturnIDInEdit, strPDLDeleteIDsInEdit;
var precDataID = -1 ;
var blnUserActive = false;
var blnAppActive = false;
$ec.fn.setValue("ECWebServiceURL", ServiceURL);
$ec.fn.setValue("UserId", m_intUserId);
//	$("#divfrmExcelicareMDI").css("display","none")
$("#divfrmExcelicareMDI").css({ "height": "100%", "width": "100%" });
$("#divfrmExcelicareMDI").mask("Loading...");
$("#divfrmExcelicareMDI_mask").css("filter", "alpha(opacity=0)");
$("#divfrmExcelicareMDI_mask").attr("class", "");
// $("#divfrmExcelicareMDI_mask_msg").attr("class", "");
$("#divfrmExcelicareMDI_mask_msg").attr("class", "maskingmsg");

var strdojotitle="";
var oPopupWindow ={};
var objGuideLineDocWin = {};
var objMediaUploadStatus = [];
var m_strCurrentUploadingUUID;
var  UploadStaus = {
    InProgress: 0,
    Success: 1,
    UploadedNotSaved:2,
    Error: 3
 };
 var LoadedFormDetails = {"ModuleID": "", "BFID": "", "DataID":"", "PopUPBFID":"", "PopUPDataID":"", "InstanceShowInReadOnly":"", "LoadedLayout":""};
 $ec.fn.setValue("LoadedFormDetails", LoadedFormDetails);
function GetParameterValues(param,strUrl) {
	var url = strUrl.slice(strUrl.indexOf('?') + 1).split('&'); 
	for (var i = 0; i < url.length; i++) {  
		var urlparam = url[i].split('=');  
		if (urlparam[0] == param) {  
			return urlparam[1];  
		}  
	}  
}
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === 'visible')
		blnAppActive = true;
});

function clearData() {

    var strCobIds;
    var strbeaconData;

    try {
        if ($ec.fn.isSendBeacon()) {
             strCobIds = GetFailedCobIDs();
             strbeaconData = { method: "removeAxServerTempData", CobIds: strCobIds, LogoutClicked: m_blnLogoutClicked };
             $ec.fn.sendBeacon("", strbeaconData, 0);
            }
        else {
            strCobIds = GetFailedCobIDs();
            if (strCobIds != "0") {
                SiteExcelicare.DeleteFailedMediaEntries(fnDeleteFailedMediaEntries(strCobIds));
            }
            if (m_blnLogoutClicked == false) {
                SiteExcelicare.fnAppUnLockCarePlan(UnLockCarePlan("Logoff"));

                
            }
        }
    }
catch(ex){}
}

//to clear the session data and axserver temp folder.
$(window).unload(function () {
		SiteExcelicare.logECWebSessionAction(2039,-1,"MDI:windowUnload")				  
	   clearData(); 
		SiteExcelicare.fnAppLogOff(fnLogOff(0));									
	   /* var url = window.location.href
	    var strCobIds = GetFailedCobIDs();
		var beaconData = { method: "removeAxServerTempData",CobIds: strCobIds }
		 var fd = new FormData();
		fd.append('data', JSON.stringify(beaconData));
		navigator.sendBeacon(url, fd);*/

    
  
});


if ((strSecureModuleIds.indexOf("1136", 0) < 0) && (strSecureModuleIds.indexOf("1138", 0) < 0) && (strSecureModuleIds.indexOf("1232", 0) < 0)) {
    $("#divePresc").css("display", "none");
}

$ec.fn.setValue("ServerTimeDiffInSeconds", intDiffinSeconds);
// $ec.fn.setValue("eRxLocationId", m_inteRxLocationId);
//$ec.fn.setValue("UserId", m_intUserId);
if (m_intPrescriberRole != '0') {
    GetPresAccountStatus();
}
else {
    $("#divePresc").css("display", "none");
}
//m_mdiWindow.frames.fraContent.fnLoadLayoutContent('..axwebuiccdmanager/frmpatientsummary.aspx', '');

function AllergiesInfo() {
    if ($ec.fn.isSecureModule(1132) == false) {
        OpenCustomDialog('You do not have access privileges to this part of the record.', 0, '350px', '150px', 0);
        return false;
    }
    else if ($ec.fn.getValue("GetPatRestrictionLevel") == 1 || $ec.fn.getValue("GetPatRestrictionLevel") == 2) {
        m_mdiWindow.OpenCustomDialog('Sorry. You do not have access to this form.', 0, '300px', '120px', 0);
        return false
    }
    m_mdiWindow.frames.fraContent.fnLoadLayoutContent('../AxFXWebUISummaryPanel/frmPatientSummary.aspx#Allergies, ADR and Alerts', '');
     m_mdiWindow.PatientBanner.Toggle();
    return false;
}

function ClinicianInfo() {
    AxOpenDojo("../AxFXWebUISummaryPanel/frmLinkedForm.aspx?linkedFormId=115&LO=1", "700px", "400px", "Recently Accessed By");
    return false;
}


function SystemInfo() {
    AxOpenDojo("../AxFXWebUISummaryPanel/frmLinkedForm.aspx?linkedFormId=116&LO=1", "700px", "400px", "System Info Summary");
    return false;
}
function GetPrescriptionDisclaimer(oURL, oFrameID, oTitle){
	try{
		var retvalue='3';
		var strCalledFrom ;
		var dojoHeight=300;
		$ec.fn.unmask();
		//if(intcountDisclaimer == "0")
			//dojoHeight =100;
        var OnHideHandle =  function() {
		  blnShowDisclaimer = '0';
		  SiteExcelicare.UpdateDisclaimer(fnUpdateDisclaimer('0'));
		  m_mdiWindow.frames.fraContent.fnLoadLayoutContent('../frmBlankPage.htm', '');
		}	
		var strdisclaimerurl = "../AxWebUIPrescription/frmdisclaimer.aspx";						
			AxOpenDojo(ax_getURL(strdisclaimerurl), 700,dojoHeight, "Prescription Disclaimer",function (retvalue){
			 if(retvalue != "0"){
				 blnShowDisclaimer = retvalue;					
				 SiteExcelicare.UpdateDisclaimer(fnUpdateDisclaimer(blnShowDisclaimer));
				 m_mdiWindow.frames.fraContent.fnLoadLayoutContent(oURL, oFrameID, oTitle);
			 }
			 else{
				 blnShowDisclaimer = '0';
				 SiteExcelicare.UpdateDisclaimer(fnUpdateDisclaimer('0'));
				 strCalledFrom = GetParameterValues("CalledFrom",oURL);
				 if(strCalledFrom != 'SplForms')
					m_mdiWindow.frames.fraContent.fnLoadLayoutContent('../frmBlankPage.htm', '');
			 }			 
		 },OnHideHandle);		 
	}	
	catch(ex){ }
}

function MenuItemOnClick(URL, isPSM, ModuleName, ModuleId) {

    try {     
	    if(oPopupWindow["SunquestWindow"] != undefined)
		{
			oPopupWindow["SunquestWindow"].close();
		}
		var retValue = AxCommunicatorFx().setProperties("MDISite","ModuleID:"+ModuleId);
		if(retValue == false)
			return;
		AxCommunicatorFx()["MDISite"]["FilterConditions"]=[];
		var oldModuleId = $ec.fn.getValue('ModuleId');
        var oldPSM=$ec.fn.isPatientSpecificModule(oldModuleId);
	    $ec.fn.setValue("isPRMSelected", (isPSM == "1" ? "1": "0"));
        if (ModuleName.toLowerCase() != "messages" && ModuleName != "") {
            $ec.fn.setValue("SummaryPanelFilters", undefined);
        }
        else if (ModuleName.toLowerCase() == "messages" && URL.indexOf("LID") == -1) {
            $ec.fn.setValue("SummaryPanelFilters", undefined);
        }
		if(ModuleId==1478)
		{
			
			URL="../AxTeleHealth/frmChatHistory.html?Token=@"+m_strSessionID
		   
		}
		if(ModuleId==1477)
		{
			
			URL="../AxTeleHealth/frmCallHistory.html?Token=@"+m_strSessionID
		   
		}
        var fncallBack = function(){
			$ec.fn.setValue("ParentModuleId", ModuleId);
			$ec.fn.setValue("ParentModuleName", ModuleName);			
			if (ModuleId > 0 && $ec.fn.isSecureModule(ModuleId) == false) {
				OpenCustomDialog('You do not have access privileges to this part of the record.', 0, '350px', '150px', 0);
				return false;
			}
			else if(m_mdiWindow.frames.fraContent.frames.fraLayoutContent.isV45Framework != undefined && 
					m_mdiWindow.frames.fraContent.frames.fraLayoutContent.isV45FormDirty != undefined &&
					m_mdiWindow.frames.fraContent.frames.fraLayoutContent.isV45Framework == true && 
					m_mdiWindow.frames.fraContent.frames.fraLayoutContent.isV45FormDirty == true && ModuleId != 54 && ModuleId !=1119)
			{
				 m_mdiWindow.frames.fraContent.frames.fraLayoutContent.navigationData = 
					 {URL:URL, isPSM:isPSM, ModuleName:ModuleName, ModuleId:ModuleId};
				getConfirmation();
			}
			else if (URL != undefined && URL.toUpperCase().indexOf("POPUP") == -1 && typeof (m_mdiWindow.frames.fraContent.frames.fraLayoutContent.isFormDirty) === "function" && m_mdiWindow.frames.fraContent.frames.fraLayoutContent.isFormDirty(function () { LoadContentPage(URL, isPSM, ModuleName, ModuleId) }, "m_mdiWindow.LoadContentPage('" + URL + "','" + isPSM + "','" + ModuleName + "'," + ModuleId + ")"))
				return false;
			else if (ModuleId == 1475 &&  ($ec.fn.getPatientObject("ismcpuser")=="False" && $ec.fn.getPatientObject("mcpuserid")==0)) {
				OpenCustomDialog('Patient is not a mCp user.', 0, '250px', '150px', 0);
				return false;
			}
			else
				LoadContentPage(URL, isPSM, ModuleName, ModuleId);
		}
		var newPSM=$ec.fn.isPatientSpecificModule(ModuleId);
		if (oldPSM == true && newPSM == false && (URL.indexOf("Appointment") < 0 && URL.indexOf("PRISM") < 0 && URL.indexOf("POPUP") < 0 )){
			$ec.fn.removeAllFromStack();
		}
		if(newPSM == false && (URL.indexOf("Appointment") < 0 && URL.indexOf("PRISM") < 0 && URL.indexOf("POPUP") < 0 ))
		{
			if(oPopupWindow["popupmodule"] != undefined && Object.keys(oPopupWindow["popupmodule"]).length > 0){
				oContainerWindow = oPopupWindow["popupmodule"].frames[1]
				var _callBack = function(){
					$ec.fn.fnUpdatePopupFormDetails("Close")
					oPopupWindow["popupmodule"].close();
					fncallBack(); 
					oPopupWindow["popupmodule"] = undefined;
				}
				if(oContainerWindow != undefined && oContainerWindow.isFormDirty != undefined && typeof (oContainerWindow.isFormDirty) === "function"){
					oPopupWindow["popupmodule"].focus();
					oContainerWindow.isFormDirty(_callBack)
				} 
				else{
					fncallBack();
				}
			}
			else{
				fncallBack();
			}
		}
		else
		{
			fncallBack();
		}
        // assigning the values of clicked moduleID and clicked Module Name
        	
    } catch (e) { }
}
var objResult = new Object(); /*commented by sunil for perf changes*/
objResult.value = m_strQueCount.replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
GetMDIQueueCountCallback(objResult);
/*GetMDIQueueCount(); //commented by sunil for perf changes*/
if (m_lngRefreshTime != "" && m_lngRefreshTime > 0) setInterval(GetMDIQueueCount, m_lngRefreshTime);

function GetMDIQueueCount() {
	var lngPatientID = $ec.fn.getPatient();
	var callback = function(data){
		var objResult = new Object();
		objResult.value =  $ec.fn.ecDecode(data.value)
		GetMDIQueueCountCallback(objResult);
	}
	SiteExcelicare.GetMDIQueueCount(callback)
}

function GetMDIQueueCountCallback(objResult) {
    $("#divAlters").remove();
    if (objResult.value != null) {
        var xmlDOM = fnLoadXML('<root>' + objResult.value + '</root>');





        $("#divAlertBubble").append('<div id="divAlters" style ="width:auto; height:auto"></div>');
        for (intIndex = 0; intIndex < xmlDOM.documentElement.childNodes.length; intIndex++) {
            var count = xmlDOM.documentElement.childNodes[intIndex].getAttribute("Count");
            if (count == "0")
                count = "&nbsp;";
            $("#divAlters").append('&nbsp;<span>' + xmlDOM.documentElement.childNodes[intIndex].getAttribute("Text") + '</span><div id="tdAlleagyProblems" title="' + xmlDOM.documentElement.childNodes[intIndex].getAttribute("Tooltip") + '" class="' + xmlDOM.documentElement.childNodes[intIndex].getAttribute("cssClass") + '" onClick="' + xmlDOM.documentElement.childNodes[intIndex].getAttribute("Function") + '">' + count + '</div>')
        }
        $("#divBubbleinfo").css("width", "67%");
        //$("#divBubbleinfo").removeClass("center");
        $("#divBubbleinfo").css("text-align", "center");

    }
    //xmlDom.documentElement.childNodes(intCount).getAttribute('ApptID')
}


function GetPresAccountStatus() {
    var inteRxUserId;
    var inteRxLocationId;
    inteRxUserId = $ec.fn.getValue("UserId");
    inteRxLocationId = $ec.fn.getValue("eRxLocationId");
    if (inteRxLocationId != 0)
        SiteExcelicare.GetPresAccountStatus(fnGetPresAccountStatus(inteRxUserId, inteRxLocationId), fnGetPresAccountStatusCallback);
    else {
        $("#tdRenew").html("&nbsp;");
        $("#tdFax").html("&nbsp;");
        $("#tdPending").html("&nbsp;");
        $("#tdRenew").attr("title", "Renew : 0");
        $("#tdFax").attr("title", "Fax : 0");
        $("#tdPending").attr("title", "Pending : 0");
        $("#nav1").text("Pharm :0,Fax :0,Pending :0");
    }

}
function fnRenewTooltip() {
}
//To Update the Account Status details 
function fnGetPresAccountStatusCallback(objReturn) {
    if (objReturn != "") {
        var streRxCount = '';
        if (objReturn.value.split(String.fromCharCode(22))[0] != "") {
            $("#tdRenew").text(objReturn.value.split(String.fromCharCode(22))[0]);
            $("#tdRenew").attr("title", "Renew :" + objReturn.value.split(String.fromCharCode(22))[0]);
        }
        else {
            $("#tdRenew").html("&nbsp;");
            $("#tdRenew").attr("title", "Renew : 0");
        }
        if (objReturn.value.split(String.fromCharCode(22))[1] != "") {
            $("#tdFax").text(objReturn.value.split(String.fromCharCode(22))[1]);
            $("#tdFax").attr("title", "Fax :" + objReturn.value.split(String.fromCharCode(22))[1]);
        }
        else {
            $("#tdFax").html("&nbsp;");
            $("#tdFax").attr("title", "Fax : 0");
        }

        if (objReturn.value.split(String.fromCharCode(22))[2] != "") {
            $("#tdPending").text(objReturn.value.split(String.fromCharCode(22))[2]);
            $("#tdPending").attr("title", "Pending :" + objReturn.value.split(String.fromCharCode(22))[2]);
        }
        else {
            $("#tdPending").html("&nbsp;");
            $("#tdPending").attr("title", "Pending : 0");
        }

        //  $("#alert1").html(streRxCount);
        $("#nav1").text(streRxCount);
    }
}
function fnbeforeCloseDojoDialog(ModuleID) {
    try {
		var strDialogId = "#frmDialog"+ModuleID
		var strDialogContainer = "#divDojoDialog"+ModuleID		  
            if ( $(strDialogId, document)[0].contentWindow.isFormDirty != undefined) {              
                if ($(strDialogId, document)[0].contentWindow.isFormDirty(function () {
                    m_mdiWindow.$(strDialogId).attr("src", "../frmBlankPage.htm");
                    m_mdiWindow.$(strDialogContainer).dialog('destroy').remove();                    
                }) == false) {
                    m_mdiWindow.$(strDialogId).attr("src", "../frmBlankPage.htm");
                    m_mdiWindow.$(strDialogContainer).dialog('destroy').remove();                   
                    return true;
                }
                else {
                    return false;
                }
            }
       
    } catch (e) { }
}
function fnShowDojoDialog(URL,title,ModuleID) {
    try { 
		var strDialogId = "frmDialog"+ModuleID
		var strDialogContainer = "divDojoDialog"+ModuleID
		var width =950, height= 570,resizable=true,draggable=true,minimizable=false;
		var strDimensions = $ec.fn.GetQueryStringParams('prop',URL.toLowerCase())
					if(strDimensions !=undefined && strDimensions!=''){
						var arrDimensions = strDimensions.split('|');
							for (var i = 0; i < arrDimensions.length; i++) 
							{
								var strDimension = arrDimensions[i].split(':');
								var strProp =strDimension[0].toString().trim()
								switch(strProp) {
									case 'h':
										height =strDimension[1].toString().trim();
										break;
									case 'w':
										width =strDimension[1].toString().trim();
										break;
									case 'resizable':
										resizable =strDimension[1].toString().trim();
										break;
									case 'draggable':
										draggable =strDimension[1].toString().trim();
										break;
									case 'minimizable':
										minimizable =strDimension[1].toString().trim();
										break;
								} 								
							}							
                     }
					
        if (m_mdiWindow.$("#"+strDialogId).length > 0) {			
            m_mdiWindow.$('#'+strDialogContainer).dialog(
							{
							    "width": width,
							    "height": height,
							    "resizable": resizable,
							    "draggable": draggable,
							    beforeClose: function (event, ui) { if (fnbeforeCloseDojoDialog() == false) { return false; } }
							}
						).dialogExtend(
							{
							    "closable": true,
							    "minimizable": minimizable,
							    "minimizeLocation": "left",
							    "icons": {
							        "close": "ui-icon-closethick",
							        "minimize": "ui-icon-minus"
							    }
							}
						);
            if (m_mdiWindow.$("#"+strDialogId).attr("src").indexOf("frmBlankPage.htm") > -1) {
                m_mdiWindow.$('#'+strDialogId).attr("src", URL);
            }
            if ($('.ui-icon-newwin').length > 0) {
                m_mdiWindow.$('#'+strDialogContainer).dialogExtend("restore");
            }
            if ($(".ui-dialog-titlebar-close").length > 0) {
                $(".ui-dialog-titlebar-close").attr("title", "Close");
            }
            if ($(".ui-dialog-titlebar-minimize").length > 0) {
                $(".ui-dialog-titlebar-minimize").attr("title", "Minimize");
            }
            if ($(".ui-dialog-titlebar-restore").length > 0) {
                $(".ui-dialog-titlebar-restore").attr("title", "Restore");
            }
        } else {
			if(title==undefined)
            title = 'Excelicare'
            m_mdiWindow.$("body").append('<div id="'+strDialogContainer+'" style="overflow:hidden;width:100%;height:100%" title="'+title+'"></div>').find("#"+strDialogContainer).html('<iframe id="'+strDialogId+'" style="border:0;width:100%;height:100%" width="100%" height="100%" scrolling="none" frameborder="0"></iframe>');
            m_mdiWindow.$("#"+strDialogContainer).dialog(
							{
							    "width": width,
							    "height": height,
							    "resizable": resizable,
							    "draggable": draggable,
							    beforeClose: function (event, ui) { if (fnbeforeCloseDojoDialog() == false) { return false; } }
							}
						).dialogExtend(
							{
							    "closable": true,
							    "minimizable": true,
							    "minimizeLocation": "left",
							    "icons": {
							        "close": "ui-icon-closethick",
							        "minimize": "ui-icon-minus"
							    }
							}
						);
            m_mdiWindow.$("#"+strDialogId).attr("src", URL);
            if ($(".ui-dialog-titlebar-close").length > 0) {
                $(".ui-dialog-titlebar-close").attr("title", "Close");
            }
            if ($(".ui-dialog-titlebar-minimize").length > 0) {
                $(".ui-dialog-titlebar-minimize").attr("title", "Minimize");
            }
            if ($(".ui-dialog-titlebar-restore").length > 0) {
                $(".ui-dialog-titlebar-restore").attr("title", "Restore");
            }
        }
    } catch (e) { }
}
function LoadContentPage(URL, isPSM, ModuleName, ModuleId) {
    var responseXml="";
	var strExtUrl = "";
	var responseUrl = "";
	var strRequestXML = "";
    var strAssocLocId = ""; 	
    try {
        $("#nav").css("visibility", "hidden");
        $("#nav").css("visibility", "");		
		if ((ModuleName != undefined && ModuleName != "" && (URL.indexOf("Appointment") < 0 && URL.indexOf("PRISM") < 0  && URL.indexOf("POPUP") < 0 ))|| $ec.fn.getValue("CalledFromPatChanged") == "popupwidow"){
            $ec.fn.removeAllFromStack();
			$ec.fn.setValue("CalledFromPatChanged","");
		}
        if (URL != '') {
			URL = fnUpdateHTMLVersion(URL);
			var hdnPat_Id = 0;
			if (($ec.fn.getValue('hdnPat_Id') != 0 && $ec.fn.getValue('hdnPat_Id') != undefined && isPSM == "1")){
				hdnPat_Id = $ec.fn.getValue('hdnPat_Id');
			}
			else {
				$ec.fn.setValue('hdnPat_Id', 0);	
			}	
			if (($ec.fn.getPatient() == 0 && hdnPat_Id == 0) && isPSM == "1") {
                $ec.fn.setValue('hdnSelectedAxselBarItemUrl', URL);
                m_mdiWindow.frames.fraContent.fnLoadLayoutContent('../frmBlankPage.htm', '');
                OpenCustomDialog("No patient has been selected. Please select one of the options below.", '8192', '500px', '150px', '0', 'Select Patient',
                            function (retVal) {
                                if (retVal == 1116)
                                    m_mdiWindow.frames.fraContent.fnLoadLayoutContent('../AxWebUIPatientSearch/frmPatientSearch.aspx', '');
                                else
                                    $ec.fn.setValue('hdnSelectedAxselBarItemUrl', '');
                            });
                $ec.fn.hidePatientBar(true);
                return false;
            }
			if ($ec.fn.getPatient() == 0 && $ec.fn.getValue('PrevPRUrl') == undefined && ModuleId ==1451) {
			    strdojotitle = ModuleName;
                m_mdiWindow.frames.fraContent.fnLoadLayoutContent('../frmBlankPage.htm', '');
                OpenCustomDialog("No patient record viewed earlier.", '0', '500px', '150px', '0', 'Excelicare',''
                           );
                $ec.fn.hidePatientBar(true);
                strdojotitle =""; 
                return false;
            }
            if (isPSM == "1") {
                if (($ec.fn.getValue("GetPatRestrictionLevel") == 1 && ModuleId != 100 && ModuleId != 104) || ($ec.fn.getValue("GetPatRestrictionLevel") == 2 && ModuleId != 100 && ModuleId != 104 && ModuleId != 1008)) {
                    m_mdiWindow.OpenCustomDialog('Sorry. You do not have access to this form.', 0, '300px', '120px', 0);
                    return false;
                }
            }

            $ec.fn.setValue('hdnSelectedAxselBarItemUrl', '');
			if (URL.toUpperCase().indexOf('POPUP') == -1)
			{
				$ec.fn.setValue("ModuleId", ModuleId);
				$ec.fn.setValue("ModuleName", ModuleName);
				$ec.fn.setValue("isPSM", isPSM);
			}
            var FormId = -1

            if (URL.toLowerCase().indexOf("baseformid=") != -1) {
                FormId = URL.toLowerCase().split("baseformid=")[1].split("&")[0].split("=")[0];
            }
            if (ModuleName == "Home") {
                ModuleId = "1275";
                $ec.fn.setValue("ModuleId", ModuleId);
            }


            $("#divfrmExcelicareMDI").css("height", "100%");
            $("#divfrmExcelicareMDI").css("width", "100%");
            $("#divfrmExcelicareMDI").mask("Loading...");
            $("#divfrmExcelicareMDI_mask").css("filter", "alpha(opacity=0)");
            $("#divfrmExcelicareMDI_mask").attr("class", "");
            $("#divfrmExcelicareMDI_mask_msg").attr("class", "");
            $("#divfrmExcelicareMDI_mask_msg").attr("class", "maskingmsg");

            //	$("#divfrmExcelicareMDI").css("Z-INDEX", "5000");
            $('ul').mouseout();
            //$('ul').show();
            var IntervalId = setInterval(function () {

                if (m_mdiWindow.frames.fraContent.frames.fraLayoutContent != undefined && m_mdiWindow.frames.fraContent.frames.fraLayoutContent.document.readyState == "complete") {
                    clearInterval(IntervalId);
                    $ec.fn.unmask();
                }  
            }, 1000
                );
            if (URL.toUpperCase().indexOf('POPUP') > 0) {
				var strWindowtype = $ec.fn.GetQueryStringParams('POPUP',URL.toUpperCase())
                if (ModuleId == 54 || ModuleId==1133) { //Added Module Id To Fix Issue No:99699
                    //window.open(URL,"Window","width=1000,height=760");
					if ($ec.fn.getPatient() == 0 && $ec.fn.getPatientObject("secondarycaption") == "")
					  $ec.fn.setPatient(0)
					//fnOpenApptSchedulerScreen(URL);
					var xPosition,xWidth,xHeight,xTop;					
					xPosition = (parseInt(screen.width)/7.6);
					xWidth = (parseInt(screen.width)/7)*6 ;
					xHeight = parseInt(screen.height/8)*6.1;
					xTop = parseInt(screen.height)/7.9;
					if($ec.fn.firefox() == true && ModuleId == "54")
							xHeight += 21;
					if(oPopupWindow["apptWindow"] != undefined)
					{
						if(oPopupWindow["apptWindow"].closed)
							oPopupWindow["apptWindow"] = window.open(URL,"ApptWindow","top=" + xTop + "px,left=" + xPosition + "px,width=" + xWidth + "px,height=" + xHeight + "px");					
						else if(oPopupWindow["apptWindow"]!=undefined && oPopupWindow["apptWindow"].PageLoaded.name!=undefined)  
							oPopupWindow["apptWindow"].focus();		
					}
					else					
						oPopupWindow["apptWindow"] = window.open(URL,"ApptWindow","top=" + xTop + "px,left=" + xPosition + "px,width=" + xWidth + "px,height=" + xHeight + "px");					
					SiteExcelicare.fnSaveUserNavigationHistory(fnSaveUsrNavigationHistory(ModuleId, FormId, URL));
                }
				else if(strWindowtype=='WINDOW'){ 
					if ($ec.fn.getPatient() == 0 && $ec.fn.getPatientObject("secondarycaption") == "")
					  $ec.fn.setPatient(0)
					//fnOpenApptSchedulerScreen(URL);
					var xPosition,xWidth,xHeight,xTop;					
					xPosition = (parseInt(screen.width)/7.6);
					xWidth = (parseInt(screen.width)/7)*6 ;
					xHeight = parseInt(screen.height/8)*6.1;
					xTop = parseInt(screen.height)/7.9;	
					var strDimensions = $ec.fn.GetQueryStringParams('PROP',URL.toUpperCase())
					//URL = $ec.fn.removeQueryStringParameter(URL,'popup')					
					if(strDimensions !=undefined && strDimensions!=''){
						  URL = $ec.fn.removeQueryStringParameter(URL,'prop')
						var arrDimensions = strDimensions.split('|');
							for (var i = 0; i < arrDimensions.length; i++) 
							{
								var strDimension = arrDimensions[i].split(':');
								var strProp =strDimension[0].toString().trim()
								switch(strProp) {
									case 'H':
										xHeight =strDimension[1].toString().trim();
										break;
									case 'W':
										xWidth =strDimension[1].toString().trim();
										break;
									case 'L':
										xPosition =strDimension[1].toString().trim();
										break;
									case 'T':
										xTop =strDimension[1].toString().trim();
										break;
									case 'F':
										xPosition = 25;
										xTop = 40;
										xWidth = (parseInt(screen.width))-50;
									break;
								} 								
							}
                     }
					if(URL.toLowerCase().toLowerCase().indexOf("layoutid=popup") > 0)
					{
						var objLoadedFormDetails = $ec.fn.getValue("LoadedFormDetails")
						if(oPopupWindow["popupmodule"] !=undefined && ! oPopupWindow["popupmodule"].closed)
						{
							if(ModuleId == objLoadedFormDetails.ModuleID && objLoadedFormDetails.LoadedLayout == $ec.fn.GetQueryStringParams('layoutid',URL.toLowerCase())){
								oPopupWindow["popupmodule"].focus();	
							}
							else{
								$ec.fn.unmask();
								var promptmessage = "A pop-up form is already open.  Please close it first if you wish to open a new pop-up form.";
								OpenCustomDialog(promptmessage, '0', "520px", '150px', '3', 'Excelicare','')
								return false; 
							}
						}
						else{
							objLoadedFormDetails.LoadedLayout = $ec.fn.GetQueryStringParams('layoutid',URL.toLowerCase());
							objLoadedFormDetails.ModuleID = "129;"
							oPopupWindow["popupmodule"] = window.open(URL,'PopupWindow'+ModuleId,"top=" + xTop + "px,left=" + xPosition + "px,width=" + (xWidth-20) + "px,height=" + (xHeight-30) + "px,resizable=yes,location=no");
							$(oPopupWindow["popupmodule"]).unload(function(){$ec.fn.fnUpdatePopupFormDetails("Close", 1)});
						}
					}			
					//oPopupWindow = $ec.fn.getValue('oPopupWindow'+ModuleId)
					else if(oPopupWindow[ModuleId] !=undefined && ! oPopupWindow[ModuleId].closed)
					{	
						oPopupWindow[ModuleId].focus();					
					}
					else{					
						oPopupWindow[ModuleId] = window.open(URL,'PopupWindow'+ModuleId,"top=" + xTop + "px,left=" + xPosition + "px,width=" + xWidth + "px,height=" + xHeight + "px,resizable=yes");

					}
					SiteExcelicare.fnSaveUserNavigationHistory(fnSaveUsrNavigationHistory(ModuleId, FormId, URL));
               }
			   else if(strWindowtype=='DOJO'){				   
				   fnShowDojoDialog(URL,ModuleName,ModuleId);
				   SiteExcelicare.fnSaveUserNavigationHistory(fnSaveUsrNavigationHistory(ModuleId, FormId, URL));
			   }
                else {
                    fnShowPrismDialog(URL);
                    SiteExcelicare.fnSaveUserNavigationHistory(fnSaveUsrNavigationHistory(ModuleId, FormId, URL));
                }
            }
            else if (ModuleId == 1119) {
                fnShowPrismDialog(URL);
                SiteExcelicare.fnSaveUserNavigationHistory(fnSaveUsrNavigationHistory(ModuleId, FormId, URL));
            }
            else if (ModuleId == 1316) {
				var strPatientID = $ec.fn.getPatient()
				var blnCheckLocation = false
                var TquestURL = SiteExcelicare.fnGetTquestURL(GetTquestURL(blnCheckLocation));
                if (TquestURL.value == "") {
                    OpenCustomDialog("Unable to open TQuest url with these credentials. Please contact system administrator.", '8192', '500px', '150px', '1', 'Excelicare', '')
                    return false;
                }
                else if (TquestURL.value.toLowerCase() == "noidentifiers") {
                    OpenCustomDialog("Insufficient Patient Details. Unable to load TQuest url.", 0, '300px', '150px', 0);
                    return false;
                }
                else if (JSON.parse(TquestURL.value).Status == "Success" && JSON.parse(TquestURL.value).data != "") {
                    AxOpenDojo(JSON.parse(TquestURL.value).data, '800', '450', 'TQuest', '', '');
                }
                else {
                    OpenCustomDialog(JSON.parse(TquestURL.value).Message, 0, '300px', '150px', 0);
                }
            }
            else if (ModuleId == 1282 || ModuleId == 1444) // Added case for SunQuest Integration
            {
				var intPatID = $ec.fn.getPatient();
				var blnCheckLocation =  true;
                var strSunQuestUrl = SiteExcelicare.frmGetLabOrderURL(fnfrmGetLabOrderURL(blnCheckLocation));
                strdojotitle = ModuleName;

                with (strSunQuestUrl) {
                    if (value == null || value == undefined || value == "" || strSunQuestUrl.value == "False") {
                        OpenCustomDialog("Unable to open " + strdojotitle + " url with these credentials. Please contact system administrator.", 0, '600px', '150px', 0)
                        return false;
                    }
                    else if (strSunQuestUrl.value == "No Identifier") {
                        OpenCustomDialog("Insufficient Patient Details. Unable to load " + strdojotitle + " url.", 0, '300px', '150px', 0)
                        return false;
                    }

                    else {

                        if (strSunQuestUrl.value != "" && strSunQuestUrl.value != undefined) {
                            /*strRequestXML = strSunQuestUrl.value.split(String.fromCharCode(181))[0]
                            strExtUrl = strSunQuestUrl.value.split(String.fromCharCode(181))[1];
                            strAssocLocId = strSunQuestUrl.value.split(String.fromCharCode(181))[2];*/
                            //alert(strExtUrl + '/Login');
                            if (strSunQuestUrl.value != "" && strSunQuestUrl.value != undefined && strAssocLocId != "15321") {
                                try {
                                    /*$.ajax({
                                        type: "POST",
                                        contentType: "application/json; charset=utf-8",
                                        url: strExtUrl + '/Login',
                                        datatype: "json",
                                        data:"{'xmlRequest':'"+ strRequestXML +"'}",
                                        async:false,
                                        success: function (data) {*/
                                    var xPosition, xWidth, xHeight, xTop;
                                    xPosition = (parseInt(screen.width) / 7.6);
                                    xWidth = (parseInt(screen.width) / 7) * 6;
                                    xHeight = parseInt(screen.height / 8) * 6.1;
                                    xTop = parseInt(screen.height) / 7.9;

                                    /*if (data != undefined && typeof(data.d) != undefined)
                                    {
                                        responseXml = $.parseXML(data.d);
                                        responseUrl = $(responseXml).find('responseUrl').text();
                                    }*/
                                    if (oPopupWindow["SunquestWindow"] != undefined) {
                                        if (oPopupWindow["SunquestWindow"].closed)
                                            oPopupWindow["SunquestWindow"] = window.open(strSunQuestUrl.value, "Sunquest", "top=" + xTop + "px,left=" + xPosition + "px,width=" + xWidth + "px,height=" + xHeight + "px");
                                        else
                                            oPopupWindow["SunquestWindow"].focus();
                                    }
                                    else
                                        oPopupWindow["SunquestWindow"] = window.open(strSunQuestUrl.value, "Sunquest", "top=" + xTop + "px,left=" + xPosition + "px,width=" + xWidth + "px,height=" + xHeight + "px");
                                    SiteExcelicare.fnSaveUserNavigationHistory(fnSaveUsrNavigationHistory(ModuleId, FormId, strSunQuestUrl.value));
                                }
                                /*error: function (data) {
                                    //addParagraphs("@Failed. Got failed response from service." + data);
                                    //alert("");
                                }
                            });*/
                                catch (ex) {
                                    alert("Catch - " + ex.Message);
                                }
                            } else if (strSunQuestUrl.value != "" && strSunQuestUrl.value != undefined && strAssocLocId == "15321") {
                                oPopupWindow["SunquestWindow"] = window.open(strSunQuestUrl.value, "Cyberlabs", "top=" + xTop + "px,left=" + xPosition + "px,width=" + xWidth + "px,height=" + xHeight + "px");
                                SiteExcelicare.fnSaveUserNavigationHistory(fnSaveUsrNavigationHistory(ModuleId, FormId, strSunQuestUrl.value));
                            }

                        }
                    }
                    strdojotitle = "";
                }
            }
            else {
                $ec.fn.hidePatientBar((isPSM == "1" ? false : true));
                if (isPSM == 0 || isPSM == "") {
                    if ($ec.fn.getValue('PrevPRUrl') != "" && ModuleId == 1451) {
                        $ec.fn.setPatient($ec.fn.getValue('PrevPatID'), function () {
                            SiteExcelicare.fnSaveUserNavigationHistory(fnSaveUsrNavigationHistory($ec.fn.getValue('PrevModuleID'), FormId, $ec.fn.getValue('PrevPRUrl')));
                            parentWindow.frames.fraContent.fnLoadLayoutContent($ec.fn.getValue('PrevPRUrl'), '');
                        }, false, true, false);
                        //URL = $ec.fn.getValue('PrevPRUrl');
                    }
                    else
                        $ec.fn.setPatient(0, function () {
                            SiteExcelicare.fnSaveUserNavigationHistory(fnSaveUsrNavigationHistory(ModuleId, FormId, URL));
                            parentWindow.frames.fraContent.fnLoadLayoutContent(URL, '');
                        }, false, true, false);
                }
                else {
                    /*                          $ec.fn.setPatient(hdnPat_Id, function () { SiteExcelicare.fnSaveUserNavigationHistory(ModuleId, FormId, URL); 
						parentWindow.frames.fraContent.fnLoadLayoutContent(URL, '');
					}, false,true,false);*/
                    SiteExcelicare.fnSaveUserNavigationHistory(fnSaveUsrNavigationHistory(ModuleId, FormId, URL));
                    m_mdiWindow.frames.fraContent.fnLoadLayoutContent(URL, '', '');
                }
            }
            return false;


        }

    } catch (e) { }
}
//$ec.fn.setValue('AutoLogOffTime', m_intAutoLogOffTime);
// $ec.fn.setValue('CountDownTime', m_intCountDownTime);
var oECLayout;
function fnChangePassword() {
    AxOpenDojo("../AxWebUIUserPreferences/frmConfirmPwd.aspx", "405px", "163px", "Change Password", function (retVal) {
        if (retVal == true) {
            m_blnLoginRedirect = true;
            fnSingOff();
        }
        else {
            if (m_mdiWindow.$("#frmUserPreferenceDialog").attr("src") == undefined || m_mdiWindow.$("#frmUserPreferenceDialog").attr("src") == "../frmBlankPage.htm")
                document.getElementById('drpUserName').selectedIndex = 0;
            else
                document.getElementById('drpUserName').selectedIndex = 2;
        }
    })
}


function drpUserName_onChange(blnChnagePwdRequired) {
  var strURL=window.location.href
  var strParamValue='';
  if (strURL.indexOf("?ShowQues=True") > 0)
   {
   
    strParamValue = strURL.substring(strURL.indexOf("?ShowQues=True"))
	
   }
    if (document.getElementById('drpUserName').value == 'logoff') {
        if (typeof (m_mdiWindow.frames.fraContent.frames.fraLayoutContent.isFormDirty) === "function" && m_mdiWindow.frames.fraContent.frames.fraLayoutContent.isFormDirty(function () { fnSingOff(); }, "m_mdiWindow.fnSingOff();"))
            return false;
        else
            fnSingOff();
    }
    else if ($("#drpUserName").val() == '55') {
        if (typeof (m_mdiWindow.frames.fraContent.frames.fraLayoutContent.isFormDirty) === "function" && m_mdiWindow.frames.fraContent.frames.fraLayoutContent.isFormDirty(function () {
            fnChangePassword()
        }, "m_mdiWindow.fnChangePassword()")) {
            return false;
        }
        else {
            AxOpenDojo("../AxWebUIUserPreferences/frmConfirmPwd.aspx", "405px", "163px", "Change Password", function (retVal) {
                if (retVal == true) {
                    m_blnLoginRedirect = true;
                    fnSingOff();
                }
                else {
                    if (m_mdiWindow.$("#frmUserPreferenceDialog").attr("src") == undefined || m_mdiWindow.$("#frmUserPreferenceDialog").attr("src") == "../frmBlankPage.htm")
                        document.getElementById('drpUserName').selectedIndex = 0;
                    else
                        document.getElementById('drpUserName').selectedIndex = 2;
                }
            });
        }
    }
    else if (blnChnagePwdRequired != undefined && blnChnagePwdRequired == true) {
	if (strParamValue.length > 0)
	{
	    AxOpenDojo("../AxWebUIUserPreferences/frmConfirmPwd.aspx?ShowQues=True", "405px", "163px", "Security Questions", function (retVal) {
               m_blnLoginRedirect = true;
                fnSingOff();
         });
	}
	 else
	 {
        AxOpenDojo("../AxWebUIUserPreferences/frmConfirmPwd.aspx", "405px", "163px", "Change Password", function (retVal) {
         
                m_blnLoginRedirect = true;
                fnSingOff();
         
        });
		}
    }
    if ($("#drpUserName").val() == '171') {
        if (typeof (m_mdiWindow.frames.fraContent.frames.fraLayoutContent.isFormDirty) === "function" && m_mdiWindow.frames.fraContent.frames.fraLayoutContent.isFormDirty(function () {
            fnShowUserPreferences();
        })) {
            return false;
        }
        else {
            fnShowUserPreferences();
        }
    }
	
	if($("#drpUserName").val() == '117'){
		try{
			if (typeof (m_mdiWindow.frames.fraContent.frames.fraLayoutContent.isFormDirty) === "function" && m_mdiWindow.frames.fraContent.frames.fraLayoutContent.isFormDirty(function () {
				fnLoadMailOptions();
			})) {
				return false;
			}
			else {
				fnLoadMailOptions();
			}
		}catch(e){}
	}
}

//This method to load Mail Profiles screen
fnLoadMailOptions = () => {
	try{
		AxOpenDojo("../AxWebUIMailOptions/frmMailProfiles.aspx", "1190px", "550px", "Mail Options", "", function(){
			if (m_mdiWindow.$("#frmUserPreferenceDialog").attr("src") == undefined || m_mdiWindow.$("#frmUserPreferenceDialog").attr("src") == "../frmBlankPage.htm")
				$('#drpUserName').val('0');
			else
				$('#drpUserName').val('117');
		});
	}catch(e){}
}


$(document).ready(function ($) {
 fnShowHideUserStatus();					  
	fnGetSysBroadcastDetails();
    fnStartTimer();
	SiteExcelicare.logECWebSessionAction(2039,-1,"MDI: PageLoad")  																 
    if (intShowClientLog == 1 || m_strSSOCalledFrom != '') { $(".ecLogOff").prop("innerText", "Exit"); }

    var oLayout = {
        north: {
            resizable: false
                   , closable: false
                   , spacing_open: -1
        },
        west: {
            resizable: false
                   , closable: false
                   , spacing_open: -1
                    , initClosed: true
        },
        east: {
            resizable: false
                    , closable: false
                    , spacing_open: -1
                        , initClosed: true
        },
        south: {
            size: 25
                   , resizable: false
                   , closable: false
                   , spacing_open: -1
        }
    }
    oECLayout = $('body').layout(oLayout);
    window.frames[0] = window.frames["fraToolBar"];
    window.frames[1] = window.frames["fraPatientBar"];
    window.frames[2] = window.frames["fraListBar"];
    window.frames[3] = window.frames["fraContent"];
    window.frames[4] = window.frames["fraStatusBar"];
    $(frames["fraContent"]).on("load", function () {
        if (frames["fraContent"].$(".ui-layout-west").length > 0)
            $("#nav ul:eq(0)").prepend("<li class='flyoutleft'><a onclick='showflyout(this,1,true)'>&#8801;</a></li>").width("100%");
        if (frames["fraContent"].$(".ui-layout-east").length > 0) {
            if($ec.fn.isSecureModule("1132")) 
			{

				$("#nav ul:eq(0)").append("<li class='flyoutright'><a  onclick='setRightflyoutCloseState();showflyout(this,2,true)'>&#8801;</a></li>").width("100%");
			}
			else
				frames["fraContent"].oMainLayout.hide('east')
			
			    
		}
    });
		var dllList = JSON.parse(m_strUserDropDown_Lookup)
		var ddlHtml = "";
		$.each(dllList, function(index, lookup) {
			ddlHtml += "<option value="+ lookup.ID +">"+ lookup.Caption + "</option>";
		});
		$('#drpUserName').append(ddlHtml);
	//Reg MDISite with comm mgr.
	AxCommunicator.register("MDISite",window);
});

$(m_mdiWindow.frames.fraPatientBar.document).ready(function ($) {

    var IntervalId_SSO = setInterval(function () {

        if (m_mdiWindow.frames.fraPatientBar.document.readyState == "complete") {
            clearInterval(IntervalId_SSO);
            //Added code by SSuresh, to select patient when called from SSO
            if (m_strSSOCalledFrom != "") {
                if (m_lngPatientID != "" && m_lngPatientID != '0')
                    $ec.fn.setPatient(m_lngPatientID, true)
            }
        }
    }, 1000
	        );
});
$(m_mdiWindow.frames.fraContent.document).ready(function ($) {
    var IntervalId_content = setInterval(function () {
        var strURL = '';

        if (m_mdiWindow.frames.fraContent.frames.fraLayoutContent != undefined && m_mdiWindow.frames.fraContent.frames.fraLayoutContent != undefined && m_mdiWindow.frames.fraContent.frames.fraLayoutContent.document.readyState == "complete") {
            clearInterval(IntervalId_content);
            $ec.fn.unmask();

            if (m_strSSOCalledFrom.toLowerCase() == 'ssoep' || m_strSSOCalledFrom.toLowerCase() == 'ssoer') {
                if (m_strSSOCalledFrom.toLowerCase() == "ssoep") {
                    fnShowePresc()
                }
                else if (m_strSSOCalledFrom.toLowerCase() == "ssoer") {
                    fnShowPrescRenewal()
                }
            }
            else {
                strURL = m_strUserStartup;
                if (strURL != '') {
                    if (strURL.indexOf('../AxFXWebUILayoutContainer/frmLayoutContainer.aspx?') != -1) {
                        $ec.fn.setValue("ModuleId", "1275");
                        $ec.fn.setValue("ModuleName", "Home");

                    }
                    // if (strURL.toUpperCase().indexOf('POPUP') > 0) {
                    if (strURL.indexOf('../AxWebUIPRISM/frmPRISM.aspx') != -1) {
                        fnShowPrismDialog(strURL);
                    }					
                    else {
						if (strURL.toUpperCase().indexOf('.HTML') != -1){
							strURL = fnUpdateHTMLVersion(strURL)
						}
                        m_mdiWindow.frames.fraContent.fnLoadLayoutContent(strURL, '');
                    }
                }
            }
        }
    }, 1000
	);

});


// To show the ePrescription page
function fnShowePresc() {
    try {
        if (m_lngPatientID != "" && m_lngPatientID != '0') {
            m_mdiWindow.frames.fraContent.fnLoadLayoutContent('../AxWebUIePrescription/frmEPrescribing.aspx', '')
        }
        return false;
    }
    catch (e) {
        alert("fnShowePrescStatus" + e.message)
    }
}

// To show the ePrescription renewal request page
function fnShowPrescRenewal() {
    try {
        if (m_lngPatientID != "" && m_lngPatientID != '0') {
            m_mdiWindow.frames.fraContent.fnLoadLayoutContent('../AxWebUIePrescription/frmRenewalRequest.aspx', '')
        }
        return false;
    }
    catch (e) {
        alert("fnShowePrescStatus" + e.message)
    }
}

// To show the Status page of the ePrescription
function fnShowePrescStatus() {
    try {
        if (m_lngPatientID != "" && m_lngPatientID != '0')
            m_mdiWindow.frames.fraContent.fnLoadLayoutContent('../AxWebUIePrescription/frmEPrescribing.aspx?calledfrom=MDIPat&HideToolbar=false', '')
        else
            m_mdiWindow.frames.fraContent.fnLoadLayoutContent('../AxWebUIePrescription/frmEPrescribing.aspx?calledfrom=MDI&HideToolbar=false', '')
        return false;
    }
    catch (e) {
        alert("fnShowePrescStatus" + e.message)
    }
}

function OpenCustomDialog(Prompt, MessageBoxStyle, DialogWidth, DialogHeight, IconStyle, PageTitle, fncallback) {
    var ButtonName1 = 'Patient Selector';
    var CustomReturnValue1 = 1115;

    var ButtonName2 = 'Search';
    var CustomReturnValue2 = 1116;

    var ButtonName3 = 'Cancel';
    var CustomReturnValue3 = 1117;

    var ButtonName4 = '';
    var CustomReturnValue4 = 1118;

    // if (MessageBoxStyle == 8192) {
    var URL, btnMyPatients, btnSearch;

    btnMyPatients = '';
    btnSearch = ButtonName2 + "&cbrv2=" + CustomReturnValue2;
   if(m_mdiWindow.frames.fraContent.frames.fraLayoutContent.isFromV45==true)
	URL = "../AxFXDialog/frmDialogPage.aspx?t=" + PageTitle + "&p=" + Prompt + "&bs=" + MessageBoxStyle + "&is=" + IconStyle + "&cbn1=" + btnMyPatients + "&cbn2=" + btnSearch + "&cbn3=" + ButtonName3 + "&cbrv3=" + CustomReturnValue3 + "&cbn4=" + ButtonName4 + "&cbrv4=" + CustomReturnValue4;
	else
    URL = "../AxFXDialog/frmDialogPage.aspx?t=" + PageTitle + "&p=" + Prompt + "&bs=" + MessageBoxStyle + "&is=" + IconStyle + "&cbn1=" + btnMyPatients + "&cbn2=" + btnSearch + "&cbn3=" + ButtonName3 + "&cbrv3=" + CustomReturnValue3 + "&cbn4=" + ButtonName4 + "&cbrv4=" + CustomReturnValue4;

    //}
	var strTitle;
	if(PageTitle != undefined && PageTitle != "")
		strTitle = PageTitle;
	else
		strTitle = "Excelicare";
    if (URL.indexOf("log off") > 0) strTitle = "Log Off";
    if(URL.indexOf("session") >0) strTitle="Excelicare";
	if(strdojotitle!="" && strTitle != "Log Off") strTitle = strdojotitle;
    AxOpenDojo(URL, DialogWidth, DialogHeight, strTitle, fncallback);
}

function openWindow(RedirectUrl) {
    var xPosition, xWidth, xHeight, xTop
    if ((isNaN(xPosition) && isNaN(xWidth)) || (xPosition.length == 0 && xWidth.length == 0)) {
        xPosition = (parseInt(screen.width) / 7.6);
        xWidth = (parseInt(screen.width) / 7) * 6;
    }
    xHeight = parseInt(screen.height / 8) * 6.1;
    xTop = parseInt(screen.height) / 7.9;
    window.open(RedirectUrl, "", "top=" + xTop + "px,left=" + xPosition + "px,width=" + xWidth + "px,height=" + xHeight + "px,directories=0;location=0;menubar=0;resizable=0;scrollbars=0;status=0;toolbar =0;", true);
}
function SignOff_MDI() {
	
	if(m_mdiWindow.frames.fraContent.frames.fraLayoutContent.isV45Framework != undefined && 
				m_mdiWindow.frames.fraContent.frames.fraLayoutContent.isV45FormDirty != undefined &&
				m_mdiWindow.frames.fraContent.frames.fraLayoutContent.isV45Framework == true && 
				m_mdiWindow.frames.fraContent.frames.fraLayoutContent.isV45FormDirty == true )
	{
		isLogOff=true;
		getConfirmation();
	}
    else if (typeof (m_mdiWindow.frames.fraContent.frames.fraLayoutContent.isFormDirty) === "function" && m_mdiWindow.frames.fraContent.frames.fraLayoutContent.isFormDirty(function () { fnSingOff(true); }, "m_mdiWindow.fnSingOff(true);"))
        return false;
    else if (intShowClientLog == 1 || m_strSSOCalledFrom != '')
        fnSingOff(false);
    else {
        fnSingOff(true);
    }
}

function fnSingOff(blnShowDojo) {
    //PageMethods.LogOff(onSuccess,onError);
	
	var fncallBack_logOff = function(){
										
	    var promptmessage = "Do you wish to log off?";
		var strCobIds;
		if (blnShowDojo != undefined && blnShowDojo == true) {
			if (!fnCheckUploadFilesExsit())
				promptmessage = "Media file(s) upload in progress, Please wait.... <br>Data may be lost if you log off.<br>" + promptmessage;
			   
			OpenCustomDialog(promptmessage, '4', "300px", '150px', '1', 'Excelicare', function (retVal) {
				if (retVal == 6) {
					sessionStorage.setItem("Ec_Jwt","");
					fnUpdateAvailableStatus(16372);				
					m_blnLogoutClicked = true;
					var retValue = AxCommunicatorFx().setProperties("MDISite","m_blnLogoutClicked:"+m_blnLogoutClicked);
					if(retValue == false) return;
					AxCommunicatorFx()["MDISite"]["FilterConditions"] = [];
					//modified code by SSuresh, to close EC when called from SSO
					if (m_strSSOCalledFrom == "") {
						SiteExcelicare.fnAppUnLockCarePlan(UnLockCarePlan("Logoff"));
						strCobIds = GetFailedCobIDs();
						if (strCobIds != "0") {
							SiteExcelicare.DeleteFailedMediaEntries(fnDeleteFailedMediaEntries(strCobIds));
						}
						SiteExcelicare.fnAppLogOff(fnLogOff(1),onSuccess);
					}
					else if (m_strSSOCalledFrom != "") {
						fnSendeRxDatatoEMR()    //Added by Suresh to send eRx data to EMR while EC unload
					}
				}
			});
			// return false;
		}
		else 
		{
			if (m_blnLoginRedirect == true)
			{
				m_blnLogoutClicked = true;
			}
			//modified code by SSuresh, to close EC when called from SSO
			if (m_strSSOCalledFrom == "") {
				SiteExcelicare.fnAppLogOff(fnLogOff(1),onSuccess);
			}
			else if (m_strSSOCalledFrom != "") {
				fnSendeRxDatatoEMR()    //Added by Suresh to send eRx data to EMR while EC unload
			}
		}
	}
	if(oPopupWindow["popupmodule"] != undefined && Object.keys(oPopupWindow["popupmodule"]).length > 0){
		oContainerWindow = oPopupWindow["popupmodule"].frames[1]
		var _callBack = function(){
			$ec.fn.setValue("PopupModuleID", "");
			$ec.fn.setValue("IsSplFormLoadedInPopup","");
			$ec.fn.fnUpdatePopupFormDetails("Close");
			oPopupWindow["popupmodule"].close();
			fncallBack_logOff();
			oPopupWindow["popupmodule"] = undefined;
		}
		if(oContainerWindow != undefined && oContainerWindow.isFormDirty != undefined && typeof (oContainerWindow.isFormDirty) === "function"){
			oPopupWindow["popupmodule"].focus();
			oContainerWindow.isFormDirty(_callBack)
		} 
		else{
			fncallBack_logOff();
		}
	} 
	else{
		fncallBack_logOff();
	}

}

function onSuccess(retVal) {
    if (m_blnLoginRedirect == true) {
        m_blnLoginRedirect = false;
        window.location.replace("../AxWebUILogin/frmSignon.aspx");
	location.reload();
    } else {
        //Modified code by SSuresh, to send eRx data to EMR while EC unload
        if (m_strSSOCalledFrom == "" && intShowClientLog == 0) {
            window.location.replace("../AxWebUILogin/frmSignon.aspx");
	    location.reload();
        }
        else if (m_strSSOCalledFrom != "" || intShowClientLog == 1) {
            window.open("", "_self", "");
            window.opener = top;
            window.close();
        }
    }
}
$(window).bind('beforeunload', function (e) {
    //Added by Suresh to send eRx data to EMR while EC unload
    if (m_blnLogoutClicked == false) {
        if (m_strSSOCalledFrom.toLowerCase() == "ssoep" || m_strSSOCalledFrom.toLowerCase() == "ssoer") {
            var strReturnValue = SiteExcelicare.fnSaveArtifactDetails(m_intUserId, m_lngPatientID, 1136)
        }
    }
})
//Added by Suresh to send eRx data to EMR while EC unload
function fnSendeRxDatatoEMR() {

    if (m_strSSOCalledFrom.toLowerCase() == "ssoep" || m_strSSOCalledFrom.toLowerCase() == "ssoer") {
        var strReturnValue = SiteExcelicare.fnSaveArtifactDetails(m_intUserId, m_lngPatientID, 1136)
    }
    SiteExcelicare.fnAppLogOff(fnLogOff(0));
    window.open("", "_self", "");
    window.opener = top;
    window.close();
}
function showflyout(src, type,blnClose) {
    type = (type == 1) ? "west" : "east";
	if (this.frames["fraContent"].$("#l1_east").css("display") == "none" && blnClose == undefined)
    this.frames["fraContent"].fnShowHidePane(type, "show", true);
	else if (blnClose != undefined && blnClose == true)
		this.frames["fraContent"].fnShowHidePane(type, "show", true);
}

function setRightflyoutCloseState() {
	if (this.frames["fraContent"].$("#l1_east").css("display") == "block") {
		$ec.fn.setValue("RightFlyoutClosed",true);
	}
	else {
		$ec.fn.setValue("RightFlyoutClosed",false);
	}
}

function fnOpenHelp() {
    try {
        if($ec.fn.getValue("ModuleName") !="")
			m_mdiWindow.frames.fraContent.$("#fraLayoutContent").contents().trigger("help");
		else
			AxOpenDojo('../AxCommon/Help/frmHelpMDI.htm', 800, 500, "Help", '', '',false);
    } catch (e) { m_mdiWindow.frames.fraContent.$("#fraLayoutContent").trigger("help") }

}

//Added by Srinivas V on 04-Feb-2014 to show browser native navigation confirmation alert while closing the window by click on close button of browser or borwser tab
window.onbeforeunload = function (event) {
	if(objGuideLineDocWin!=undefined){
		for(var dialog in objGuideLineDocWin){
            objGuideLineDocWin[dialog].close();
		};
	}
	
	for(var ModuleID in oPopupWindow) {
		if(oPopupWindow[ModuleID] != undefined)
			oPopupWindow[ModuleID].close();
	}	
		
	if (navigator.userAgent.indexOf("Firefox") > 0 || navigator.appName == "Microsoft Internet Explorer") {
                clearData();
             
            }
		
    if (m_blnLogoutClicked != true) {
		return "Your session is going to expired.?";
       /* var objResponse = SiteExcelicare.LogOff(0);
        if (objResponse.value == 1)
            return "Your session has been expired.";
        else
            return "";*/
    }
    if(m_strSSOCalledFrom!="")
	{
	fnSessionLogout();
	}
}
function fnShowPrismDialog(URL, title) {
    try {
	var agent = navigator.userAgent.toLowerCase();		
        if (m_mdiWindow.$("#frmPRISMDialog").length > 0) {
			if(agent.indexOf('andriod') >= 0 || agent.indexOf('iphone') >= 0 || agent.indexOf('ipad') >= 0 || agent.indexOf('ipod') >= 0){
				m_mdiWindow.$("#divPRISMDialog").dialog(
							{
							    "width": 900,
							    "height": 370,
							    "resizable": true,
							    "draggable": true,
							    beforeClose: function (event, ui) { if (fnbeforeClosePRISMDialog() == false) { return false; } }
							}
						).dialogExtend(
							{
							    "closable": true,
							    "minimizable": true,
							    "minimizeLocation": "left",
							    "icons": {
							        "close": "ui-icon-closethick",
							        "minimize": "ui-icon-minus"
							    }
							}
						);
			}
			else{
            m_mdiWindow.$("#divPRISMDialog").dialog(
							{
							    "width": 950,
							    "height": 570,
							    "resizable": true,
							    "draggable": true,
							    beforeClose: function (event, ui) { if (fnbeforeClosePRISMDialog() == false) { return false; } }
							}
						).dialogExtend(
							{
							    "closable": true,
							    "minimizable": true,
							    "minimizeLocation": "left",
							    "icons": {
							        "close": "ui-icon-closethick",
							        "minimize": "ui-icon-minus"
							    }
							}
						);
			}
            if (m_mdiWindow.$("#frmPRISMDialog").attr("src").indexOf("frmBlankPage.htm") > -1) {
                m_mdiWindow.$("#frmPRISMDialog").attr("src", URL);
            }
            if ($('.ui-icon-newwin').length > 0) {
                m_mdiWindow.$("#divPRISMDialog").dialogExtend("restore");
            }
            if ($(".ui-dialog-titlebar-close").length > 0) {
                $(".ui-dialog-titlebar-close").attr("title", "Close");
            }
            if ($(".ui-dialog-titlebar-minimize").length > 0) {
                $(".ui-dialog-titlebar-minimize").attr("title", "Minimize");
            }
            if ($(".ui-dialog-titlebar-restore").length > 0) {
                $(".ui-dialog-titlebar-restore").attr("title", "Restore");
            }
        } else {
			if(title!=undefined)
            m_mdiWindow.$("body").append('<div id="divPRISMDialog" style="overflow:hidden;width:100%;height:100%" title="Excelicare Requests"></div>').find("#divPRISMDialog").html('<iframe id="frmPRISMDialog" style="border:0;width:100%;height:100%" width="100%" height="100%" scrolling="none" frameborder="0"></iframe>');
			else
            m_mdiWindow.$("body").append('<div id="divPRISMDialog" style="overflow:hidden;width:100%;height:100%" title="PRISM"></div>').find("#divPRISMDialog").html('<iframe id="frmPRISMDialog" style="border:0;width:100%;height:100%" width="100%" height="100%" scrolling="none" frameborder="0"></iframe>');
			if(agent.indexOf('andriod') >= 0){
				m_mdiWindow.$("#divPRISMDialog").dialog(
							{
							    "width": 900,
							    "height": 370,
							    "resizable": true,
							    "draggable": true,								
							    beforeClose: function (event, ui) { if (fnbeforeClosePRISMDialog() == false) { return false; } }
							}
						).dialogExtend(
							{
							    "closable": true,
							    "minimizable": true,
							    "minimizeLocation": "left",
							    "icons": {
							        "close": "ui-icon-closethick",
							        "minimize": "ui-icon-minus"
							    }
							}
						);
			}
			else{
				m_mdiWindow.$("#divPRISMDialog").dialog(
							{
							    "width": 950,
							    "height": 570,
							    "resizable": true,
							    "draggable": true,
							    beforeClose: function (event, ui) { if (fnbeforeClosePRISMDialog() == false) { return false; } }
							}
						).dialogExtend(
							{
							    "closable": true,
							    "minimizable": true,
							    "minimizeLocation": "left",
							    "icons": {
							        "close": "ui-icon-closethick",
							        "minimize": "ui-icon-minus"
							    }
							}
						);
			}            
            m_mdiWindow.$("#frmPRISMDialog").attr("src", URL);
            if ($(".ui-dialog-titlebar-close").length > 0) {
                $(".ui-dialog-titlebar-close").attr("title", "Close");
            }
            if ($(".ui-dialog-titlebar-minimize").length > 0) {
                $(".ui-dialog-titlebar-minimize").attr("title", "Minimize");
            }
            if ($(".ui-dialog-titlebar-restore").length > 0) {
                $(".ui-dialog-titlebar-restore").attr("title", "Restore");
            }
        }
    } catch (e) { }
}
function fnbeforeClosePRISMDialog() {
    try {
        if (!($.browser.msie)) {
            if (frmPRISMDialog.contentWindow.isFormDirty != undefined) {
                $ec.fn.setValue("blnCloseedPrism", true);
                if (frmPRISMDialog.contentWindow.isFormDirty(function () {
                    m_mdiWindow.$("#frmPRISMDialog").attr("src", "../frmBlankPage.htm");
                    m_mdiWindow.$("#divPRISMDialog").dialog('destroy').remove();
                    $ec.fn.setValue("blnCloseedPrism", false);
                }) == false) {
                    m_mdiWindow.$("#frmPRISMDialog").attr("src", "../frmBlankPage.htm");
                    m_mdiWindow.$("#divPRISMDialog").dialog('destroy').remove();
                    $ec.fn.setValue("blnCloseedPrism", false);
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        else {
            if (frmPRISMDialog.isFormDirty != undefined) {
                $ec.fn.setValue("blnCloseedPrism", true);
                if (frmPRISMDialog.isFormDirty(function () {
                    m_mdiWindow.$("#frmPRISMDialog").attr("src", "../frmBlankPage.htm");
                    m_mdiWindow.$("#divPRISMDialog").dialog('destroy').remove();
                    $ec.fn.setValue("blnCloseedPrism", false);
                }) == false) {
                    m_mdiWindow.$("#frmPRISMDialog").attr("src", "../frmBlankPage.htm");
                    m_mdiWindow.$("#divPRISMDialog").dialog('destroy').remove();
                    $ec.fn.setValue("blnCloseedPrism", false);
                    return true;
                }
                else {
                    return false;
                }
            }
        }
    } catch (e) { }
}
function fnShowUserPreferences() {
    try {
        if (m_mdiWindow.$("#frmUserPreferenceDialog").length > 0) {
            m_mdiWindow.$("#divUserPreferenceDialog").dialog(
							{
							    "width": 750,
							    "height": 560,
							    "resizable": true,
							    "draggable": true,
							    beforeClose: function (event, ui) {
							        if ($("#frmUserPreferenceDialog", document)[0].contentWindow.isFormDirty != undefined) {
							            if ($("#frmUserPreferenceDialog", document)[0].contentWindow.isFormDirty(function () {
							                m_mdiWindow.$("#frmUserPreferenceDialog").attr("src", "../frmBlankPage.htm");
							                m_mdiWindow.$("#divUserPreferenceDialog").dialog('destroy').remove();
							                document.getElementById('drpUserName').selectedIndex = 0;
							            }) == false) {
							                m_mdiWindow.$("#frmUserPreferenceDialog").attr("src", "../frmBlankPage.htm");
							                m_mdiWindow.$("#divUserPreferenceDialog").dialog('destroy').remove();
							                document.getElementById('drpUserName').selectedIndex = 0;
							                return true;
							            }
							            else {
							                return false;
							            }
							        }
							    }
							}
						)
            if (m_mdiWindow.$("#frmUserPreferenceDialog").attr("src").indexOf("frmBlankPage.htm") > -1) {
                m_mdiWindow.$("#frmUserPreferenceDialog").attr("src", "../AxWebUIUserPreferences/frmUserPreferences.aspx");
            }
            if ($(".ui-dialog-titlebar-close").length > 0) {
                $(".ui-dialog-titlebar-close").attr("title", "Close");
            }
        } else {
            m_mdiWindow.$("body").append('<div id="divUserPreferenceDialog" style="overflow:hidden;width:100%;height:100%" title="User Preferences"></div>').find("#divUserPreferenceDialog").html('<iframe id="frmUserPreferenceDialog" style="border:0;width:100%;height:100%" width="100%" scrolling="none" frameborder="0"></iframe>');
            m_mdiWindow.$("#divUserPreferenceDialog").dialog(
						{
						    "width": 750,
						    "height": 560,
						    "resizable": true,
						    "draggable": true,
						    beforeClose: function (event, ui) {
						        if ($("#frmUserPreferenceDialog", document)[0].contentWindow.isFormDirty != undefined) {
						            if ($("#frmUserPreferenceDialog", document)[0].contentWindow.isFormDirty(function () {
						                m_mdiWindow.$("#frmUserPreferenceDialog").attr("src", "../frmBlankPage.htm");
						                m_mdiWindow.$("#divUserPreferenceDialog").dialog('destroy').remove();
						                document.getElementById('drpUserName').selectedIndex = 0;
						            }) == false) {
						                m_mdiWindow.$("#frmUserPreferenceDialog").attr("src", "../frmBlankPage.htm");
						                m_mdiWindow.$("#divUserPreferenceDialog").dialog('destroy').remove();
						                document.getElementById('drpUserName').selectedIndex = 0;
						                return true;
						            }
						            else {
						                return false;
						            }
						        }
						    }
						}
					)
            m_mdiWindow.$("#frmUserPreferenceDialog").attr("src", "../AxWebUIUserPreferences/frmUserPreferences.aspx");
            if ($(".ui-dialog-titlebar-close").length > 0) {
                $(".ui-dialog-titlebar-close").attr("title", "Close");
            }
        }
    } catch (e) { }
}


function fnOpenApptSchedulerScreen(URL, winHeight, winWidth) {
    try {
        winHeight = $(document.body).prop("clientHeight");
		var strDialogSrc="";
		if(URL !=""){
			strDialogSrc=URL;
		}else if(URL == "" && tempURL != undefined && tempURL != "" && m_mdiWindow.$("#frmApptScheduleDialog").length > 0){
			strDialogSrc=m_mdiWindow.$("#frmApptScheduleDialog").attr("Src");
		}
        if (m_mdiWindow.$("#frmApptScheduleDialog").length > 0 && tempURL != undefined && tempURL == strDialogSrc) {
            if ($("#frmApptScheduleDialog", document)[0].contentWindow.AxToolBar.button("btnRestore")._button.className == "ax_minimize") {
                if (winWidth == undefined) {
                    winWidth = '99%';
                }
            }
            if (winHeight == undefined) {
                //winHeight=590;
                winHeight = $(document.body).prop("clientHeight");
            }
            if (winWidth == undefined) {
                winWidth = '85%';
            }
            m_mdiWindow.$("#divApptScheduleDialog").dialog(
							{
							    "width": winWidth,
							    "height": parseInt(winHeight),
							    "resizable": false,
							    "draggable": true,
							    beforeClose: function (event, ui) {
							        if ($("#frmApptScheduleDialog", document)[0].contentWindow.UnloadForm != undefined) {
							            if ($("#frmApptScheduleDialog", document)[0].contentWindow.UnloadForm('Close') == false) {
							                m_mdiWindow.$("#frmApptScheduleDialog").attr("src", "../frmBlankPage.htm");
							                m_mdiWindow.$("#divApptScheduleDialog").dialog('destroy').remove();
							                return true;
							            }
							            else {
							                return false;
							            }
							        }
							    }
							}
						).dialogExtend(
							{
							    "closable": true,
							    "minimizable": true,
							    "minimizeLocation": "left",
							    "icons": {
							        "close": "ui-icon-closethick",
							        "minimize": "ui-icon-minus"
							    }
							}
						);
            if (m_mdiWindow.$("#frmApptScheduleDialog").attr("src").indexOf("frmBlankPage.htm") > -1) {
                m_mdiWindow.$("#divApptScheduleDialog").attr("src", URL);
            }
            if ($('.ui-icon-newwin').length > 0 && URL != "") {
                m_mdiWindow.$("#divApptScheduleDialog").dialogExtend("restore");
                if ($("#frmApptScheduleDialog", document)[0].contentWindow.PageRefresh != undefined) {
                    $("#frmApptScheduleDialog", document)[0].contentWindow.PageRefresh();
                }
            }
            if ($(".ui-dialog-titlebar-close").length > 0) {
                $(".ui-dialog-titlebar-close").attr("title", "Close");
            }
            if ($(".ui-dialog-titlebar-minimize").length > 0) {
                $(".ui-dialog-titlebar-minimize").attr("title", "Minimize");
            }
            if ($(".ui-dialog-titlebar-restore").length > 0) {
                $(".ui-dialog-titlebar-restore").attr("title", "Restore");
            }
        } else {
				m_mdiWindow.$("#frmApptScheduleDialog").attr("src", "../frmBlankPage.htm");
				m_mdiWindow.$("#divApptScheduleDialog").dialog('destroy').remove();
            if (winHeight == undefined) {
                winHeight = 590;
            }
            if (winWidth == undefined) {
                winWidth = '85%';
            }
            m_mdiWindow.$("body").append('<div id="divApptScheduleDialog" style="overflow:hidden;width:100%;height:100%" title="Appointment Scheduler"></div>').find("#divApptScheduleDialog").html('<iframe id="frmApptScheduleDialog" style="border:0;width:100%;height:100%" width="100%" height="100%" scrolling="none" frameborder="0"></iframe>');
            m_mdiWindow.$("#divApptScheduleDialog").dialog(
							{
							    "width": winWidth,
							    "height": parseInt(winHeight),
							    "resizable": false,
							    "draggable": true,
							    beforeClose: function (event, ui) {
							        if ($("#frmApptScheduleDialog", document)[0].contentWindow.UnloadForm != undefined) {
							            if ($("#frmApptScheduleDialog", document)[0].contentWindow.UnloadForm('Close') == false) {
							                if (m_mdiWindow.$("#frmApptScheduleDialog").length > 0) {
							                    $("#frmApptScheduleDialog", document)[0].contentWindow.UnloadForm.fnCloseModuleForms();
							                    m_mdiWindow.$("#frmApptScheduleDialog").attr("src", "../frmBlankPage.htm");
							                    m_mdiWindow.$("#divApptScheduleDialog").dialog('destroy').remove();
							                }
							                return true;
							            }
							            else {
							                return false;
							            }
							        }
							    }
							}
						).dialogExtend(
							{
							    "closable": true,
							    "minimizable": true,
							    "minimizeLocation": "left",
							    "icons": {
							        "close": "ui-icon-closethick",
							        "minimize": "ui-icon-minus"
							    }
							}
						);
            m_mdiWindow.$("#frmApptScheduleDialog").attr("src", URL);
            if ($(".ui-dialog-titlebar-close").length > 0) {
                $(".ui-dialog-titlebar-close").attr("title", "Close");
            }
            if ($(".ui-dialog-titlebar-minimize").length > 0) {
                $(".ui-dialog-titlebar-minimize").attr("title", "Minimize");
            }
            if ($(".ui-dialog-titlebar-restore").length > 0) {
                $(".ui-dialog-titlebar-restore").attr("title", "Restore");
            }
        }
    } catch (e) { }
	finally{
		tempURL = URL =="" ? strDialogSrc : URL;
	}
}
function fnGetSysBroadcastDetails() {
	
    try {
        var strActualStartDateTime;
        var dtActualStartDateTime;
        var strActualEndDateTime;
        var dtActualEndDateTime;
        var strCurrentDateTime;
        var dtCurrentDateTime;
        var strMessage = "";
        var intRows = 0;
        var intShow_At_Login_Before_InHours = 1;
        var dblShow_Reminder_Before_InMinutes = 60;
        var dblBroadCastType = 0;
        var blnRequiresSysShutdown = "false";
        var xmlDom, xmlCDom;
        if ($.browser.msie) {
            xmlDom = new ActiveXObject("Microsoft.XMLDOM");
            xmlCDom = new ActiveXObject("Microsoft.XMLDOM");
        } else {
            xmlDom = new DOMParser();
        }
        xmlDom.async = "false";
        var strSysBroadcastDetails = oDynamicValues.SysBroadcastDetails;
       // ProcessAjaxException(strSysBroadcastDetails)

        if (strSysBroadcastDetails != null && strSysBroadcastDetails != "" && strSysBroadcastDetails != "<DataSet />") {
            if ($.browser.msie) {
                xmlDom.loadXML(strSysBroadcastDetails);
            } else {
                xmlDom = xmlDom.parseFromString(strSysBroadcastDetails, 'text/xml');
            }
            if (xmlDom.selectNodes("DataSet/Table").length > 1) {
                for (intRows = 0; intRows < xmlDom.selectNodes("DataSet/Table").length; intRows++) {
                    if ($.browser.msie) {
                        xmlCDom.loadXML(xmlDom.selectNodes("DataSet/Table").item(intRows).xml);
                        xmlCDom.async = "false";
                    } else {
                        xmlCDom = null;
                        xmlCDom = new DOMParser();
                        xmlCDom = xmlCDom.parseFromString((new XMLSerializer()).serializeToString(xmlDom.selectNodes("DataSet/Table")[intRows]), 'text/xml')
                    }
                    if (xmlCDom.selectSingleNode("Table/Actual_StartDateTime") != null && xmlCDom.selectSingleNode("Table/Actual_StartDateTime").text != "") {
                        strActualStartDateTime = xmlCDom.selectSingleNode("Table/Actual_StartDateTime").text;
                        strActualStartDateTime = strActualStartDateTime.replace("-", "/").replace("-", "/").replace("T", " ");
                        if (strActualStartDateTime.indexOf("+") > -1)
                            strActualStartDateTime = strActualStartDateTime.substring(0, strActualStartDateTime.indexOf("+"))
                        if (strActualStartDateTime.indexOf("-") > -1)
                            strActualStartDateTime = strActualStartDateTime.substring(0, strActualStartDateTime.indexOf("-"))
                        dtActualStartDateTime = new Date(strActualStartDateTime)
                    } else if (xmlCDom.selectSingleNode("Table/Scheduled_StartDateTime") != null && xmlCDom.selectSingleNode("Table/Scheduled_StartDateTime").text != "") {
                        strActualStartDateTime = xmlCDom.selectSingleNode("Table/Scheduled_StartDateTime").text;
                        strActualStartDateTime = strActualStartDateTime.replace("-", "/").replace("-", "/").replace("T", " ");
                        if (strActualStartDateTime.indexOf("+") > -1)
                            strActualStartDateTime = strActualStartDateTime.substring(0, strActualStartDateTime.indexOf("+"))
                        if (strActualStartDateTime.indexOf("-") > -1)
                            strActualStartDateTime = strActualStartDateTime.substring(0, strActualStartDateTime.indexOf("-"))
                        dtActualStartDateTime = new Date(strActualStartDateTime)
                    }
                    if (xmlCDom.selectSingleNode("Table/Actual_EndDateTime") != null && xmlCDom.selectSingleNode("Table/Actual_EndDateTime").text != "") {
                        strActualEndDateTime = xmlCDom.selectSingleNode("Table/Actual_EndDateTime").text;
                        strActualEndDateTime = strActualEndDateTime.replace("-", "/").replace("-", "/").replace("T", " ");
                        if (strActualEndDateTime.indexOf("+") > -1)
                            strActualEndDateTime = strActualEndDateTime.substring(0, strActualEndDateTime.indexOf("+"))
                        if (strActualEndDateTime.indexOf("-") > -1)
                            strActualEndDateTime = strActualEndDateTime.substring(0, strActualEndDateTime.indexOf("-"))
                        dtActualEndDateTime = new Date(strActualEndDateTime);
                    } else if (xmlCDom.selectSingleNode("Table/Scheduled_EndDateTime") != null && xmlCDom.selectSingleNode("Table/Scheduled_EndDateTime").text != "") {
                        strActualEndDateTime = xmlCDom.selectSingleNode("Table/Scheduled_EndDateTime").text;
                        strActualEndDateTime = strActualEndDateTime.replace("-", "/").replace("-", "/").replace("T", " ");
                        if (strActualEndDateTime.indexOf("+") > -1)
                            strActualEndDateTime = strActualEndDateTime.substring(0, strActualEndDateTime.indexOf("+"))
                        if (strActualEndDateTime.indexOf("-") > -1)
                            strActualEndDateTime = strActualEndDateTime.substring(0, strActualEndDateTime.indexOf("-"))
                        dtActualEndDateTime = new Date(strActualEndDateTime);
                    }
                    if (xmlCDom.selectSingleNode("Table/CurrentDateTime") != null) {
                        strCurrentDateTime = xmlCDom.selectSingleNode("Table/CurrentDateTime").text;
                        strCurrentDateTime = strCurrentDateTime.replace("-", "/").replace("-", "/").replace("T", " ");
                        if (strCurrentDateTime.indexOf(".") > -1)
                            strCurrentDateTime = strCurrentDateTime.substring(0, strCurrentDateTime.indexOf("."))
                        if (strCurrentDateTime.indexOf("+") > -1)
                            strCurrentDateTime = strCurrentDateTime.substring(0, strCurrentDateTime.indexOf("+"))
                        if (strCurrentDateTime.indexOf("-") > -1)
                            strCurrentDateTime = strCurrentDateTime.substring(0, strCurrentDateTime.indexOf("-"))
                        dtCurrentDateTime = new Date(strCurrentDateTime);
                    }
                    if (xmlCDom.selectSingleNode("Table/Display_Info_At_Login_InHours") != null)
                        intShow_At_Login_Before_InHours = xmlCDom.selectSingleNode("Table/Display_Info_At_Login_InHours").text;
                    if (xmlCDom.selectSingleNode("Table/Display_Reminder_Message_InMins") != null)
                        dblShow_Reminder_Before_InMinutes = xmlCDom.selectSingleNode("Table/Display_Reminder_Message_InMins").text;
                    if (xmlCDom.selectSingleNode("Table/Message_To_Broadcast") != null)
                        strMessage = xmlCDom.selectSingleNode("Table/Message_To_Broadcast").text;
                    if (xmlCDom.selectSingleNode("Table/BroadCastType_LU") != null)
                        dblBroadCastType = xmlCDom.selectSingleNode("Table/BroadCastType_LU").text;
                    if (xmlCDom.selectSingleNode("Table/RequiresShutDown") != null)
                        blnRequiresSysShutdown = xmlCDom.selectSingleNode("Table/RequiresShutDown").text;
                }
            }
            else if (xmlDom.selectNodes("DataSet/Table").length > 0) {
                if (xmlDom.selectSingleNode("DataSet/Table/Actual_StartDateTime") != null && xmlDom.selectSingleNode("DataSet/Table/Actual_StartDateTime").text != "") {
                    strActualStartDateTime = xmlDom.selectSingleNode("DataSet/Table/Actual_StartDateTime").text;
                    strActualStartDateTime = strActualStartDateTime.replace("-", "/").replace("-", "/").replace("T", " ");
                    if (strActualStartDateTime.indexOf("+") > -1)
                        strActualStartDateTime = strActualStartDateTime.substring(0, strActualStartDateTime.indexOf("+"))
                    if (strActualStartDateTime.indexOf("-") > -1)
                        strActualStartDateTime = strActualStartDateTime.substring(0, strActualStartDateTime.indexOf("-"))
                    dtActualStartDateTime = new Date(strActualStartDateTime)
                }
                else if (xmlDom.selectSingleNode("DataSet/Table/Scheduled_StartDateTime") != null && xmlDom.selectSingleNode("DataSet/Table/Scheduled_StartDateTime").text != "") {
                    strActualStartDateTime = xmlDom.selectSingleNode("DataSet/Table/Scheduled_StartDateTime").text;
                    strActualStartDateTime = strActualStartDateTime.replace("-", "/").replace("-", "/").replace("T", " ");
                    if (strActualStartDateTime.indexOf("+") > -1)
                        strActualStartDateTime = strActualStartDateTime.substring(0, strActualStartDateTime.indexOf("+"))
                    if (strActualStartDateTime.indexOf("-") > -1)
                        strActualStartDateTime = strActualStartDateTime.substring(0, strActualStartDateTime.indexOf("-"))
                    dtActualStartDateTime = new Date(strActualStartDateTime)
                }
                if (xmlDom.selectSingleNode("DataSet/Table/Actual_EndDateTime") != null && xmlDom.selectSingleNode("DataSet/Table/Actual_EndDateTime").text != "") {
                    strActualEndDateTime = xmlDom.selectSingleNode("DataSet/Table/Actual_EndDateTime").text;
                    strActualEndDateTime = strActualEndDateTime.replace("-", "/").replace("-", "/").replace("T", " ");
                    if (strActualEndDateTime.indexOf("+") > -1)
                        strActualEndDateTime = strActualEndDateTime.substring(0, strActualEndDateTime.indexOf("+"))
                    if (strActualEndDateTime.indexOf("-") > -1)
                        strActualEndDateTime = strActualEndDateTime.substring(0, strActualEndDateTime.indexOf("-"))
                    dtActualEndDateTime = new Date(strActualEndDateTime);
                } else if (xmlDom.selectSingleNode("DataSet/Table/Scheduled_EndDateTime") != null && xmlDom.selectSingleNode("DataSet/Table/Scheduled_EndDateTime").text != "") {
                    strActualEndDateTime = xmlDom.selectSingleNode("DataSet/Table/Scheduled_EndDateTime").text;
                    strActualEndDateTime = strActualEndDateTime.replace("-", "/").replace("-", "/").replace("T", " ");
                    if (strActualEndDateTime.indexOf("+") > -1)
                        strActualEndDateTime = strActualEndDateTime.substring(0, strActualEndDateTime.indexOf("+"))
                    if (strActualEndDateTime.indexOf("-") > -1)
                        strActualEndDateTime = strActualEndDateTime.substring(0, strActualEndDateTime.indexOf("-"))
                    dtActualEndDateTime = new Date(strActualEndDateTime);
                }
                if (xmlDom.selectSingleNode("DataSet/Table/CurrentDateTime") != null) {
                    strCurrentDateTime = xmlDom.selectSingleNode("DataSet/Table/CurrentDateTime").text;
                    strCurrentDateTime = strCurrentDateTime.replace("-", "/").replace("-", "/").replace("T", " ");
                    if (strCurrentDateTime.indexOf(".") > -1)
                        strCurrentDateTime = strCurrentDateTime.substring(0, strCurrentDateTime.indexOf("."))
                    if (strCurrentDateTime.indexOf("+") > -1)
                        strCurrentDateTime = strCurrentDateTime.substring(0, strCurrentDateTime.indexOf("+"))
                    if (strCurrentDateTime.indexOf("-") > -1)
                        strCurrentDateTime = strCurrentDateTime.substring(0, strCurrentDateTime.indexOf("-"))
                    dtCurrentDateTime = new Date(strCurrentDateTime);
                }
                if (xmlDom.selectSingleNode("DataSet/Table/Display_Info_At_Login_InHours") != null)
                    intShow_At_Login_Before_InHours = xmlDom.selectSingleNode("DataSet/Table/Display_Info_At_Login_InHours").text;
                if (xmlDom.selectSingleNode("DataSet/Table/Display_Reminder_Message_InMins") != null)
                    dblShow_Reminder_Before_InMinutes = xmlDom.selectSingleNode("DataSet/Table/Display_Reminder_Message_InMins").text;
                if (xmlDom.selectSingleNode("DataSet/Table/Message_To_Broadcast") != null)
                    strMessage = xmlDom.selectSingleNode("DataSet/Table/Message_To_Broadcast").text;
                if (xmlDom.selectSingleNode("DataSet/Table/BroadCastType_LU") != null)
                    dblBroadCastType = xmlDom.selectSingleNode("DataSet/Table/BroadCastType_LU").text;
                if (xmlDom.selectSingleNode("DataSet/Table/RequiresShutDown") != null)
                    blnRequiresSysShutdown = xmlDom.selectSingleNode("DataSet/Table/RequiresShutDown").text;

            }
			var intDiffinSeconds = (new Date(Date()) - dtCurrentDateTime) / 1000;
            $ec.fn.setValue("ServerTimeDiffInSeconds", intDiffinSeconds);
            $ec.fn.setValue('SysBroadcastDetails', strSysBroadcastDetails);
        }
    } catch (e) { ShowAjaxException(ex, "fnGetSysBroadcastDetails") }
}
function GetExternalURL(intFormLibItemID,lngDataID) {
   return SiteExcelicare.GetExternalURL(fnGetExternalURL(intFormLibItemID,lngDataID));
}
function GetExternalURLFLID(strExternalURLName) {
    return SiteExcelicare.GetExternalURLFLID(fnGetExternalURLFLID(strExternalURLName));
}
function controlNavigation (){
	if(isLogOff){
		isLogOff=false;
		fnSingOff(true);
	}
	else{
	if(m_mdiWindow.frames.fraContent.frames.fraLayoutContent.actionExceuted!=undefined &&
	 m_mdiWindow.frames.fraContent.frames.fraLayoutContent.actionExceuted !="" &&
	 m_mdiWindow.frames.fraContent.frames.fraLayoutContent.actionExceuted !="cancelled")
	 {
		m_mdiWindow.frames.fraContent.frames.fraLayoutContent.isV45Framework = false;
		m_mdiWindow.frames.fraContent.frames.fraLayoutContent.isV45FormDirty = false;
		m_mdiWindow.frames.fraContent.frames.fraLayoutContent.isFromV45 = false;
		LoadContentPage(m_mdiWindow.frames.fraContent.frames.fraLayoutContent.navigationData.URL, 
						m_mdiWindow.frames.fraContent.frames.fraLayoutContent.navigationData.isPSM, 
						m_mdiWindow.frames.fraContent.frames.fraLayoutContent.navigationData.ModuleName, 
						m_mdiWindow.frames.fraContent.frames.fraLayoutContent.navigationData.ModuleId);
		m_mdiWindow.frames.fraContent.frames.fraLayoutContent.navigationData = {};
		m_mdiWindow.frames.fraContent.frames.fraLayoutContent.callbackMethod = null;
	 }
	 return false;
	}
}

function getConfirmation() {
    m_mdiWindow.frames.fraContent.frames.fraLayoutContent.callCloseByOutside(controlNavigation);
}
function ShowLog(e){
if (e.ctrlKey && e.altKey){
//fnShowRequestDialog("../AxFXWebUISummaryPanel/frmLinkedForm.aspx?linkedFormId=7400001","Excelicare Requests");
//AxOpenDojo("../AxFXWebUISummaryPanel/frmLinkedForm.aspx?linkedFormId=7400001","1200px", "500px", "Excelicare Requests");
// AxOpenDojo("../AxWebUIMDI/ECBrowserRequestLogs.htm?SessId=" + m_strSessionID, "700px", "400px", "Excelicare Requests");
  //  return false;
}
}

function fnLogClear(){
SiteExcelicare.fnDeleteRequestLog();
}


function fnShowRequestDialog(URL) {
    try {
        if (m_mdiWindow.$("#frmRequestDialog").length > 0) {
            m_mdiWindow.$("#divRequestDialog").dialog(
							{
							    "width": 1150,
							    "height": 570,
							    "resizable": true,
							    "draggable": true,
							    beforeClose: function (event, ui) { if (fnbeforeCloseRequestDialog() == false) { return false; } }
							}
						).dialogExtend(
							{
							    "closable": true,
							    "minimizable": true,
							    "minimizeLocation": "left",
							    "icons": {
							        "close": "ui-icon-closethick",
							        "minimize": "ui-icon-minus"
							    }
							}
						);
            if (m_mdiWindow.$("#frmRequestDialog").attr("src").indexOf("frmBlankPage.htm") > -1) {
                m_mdiWindow.$("#frmRequestDialog").attr("src", URL);
            }
            if ($('.ui-icon-newwin').length > 0) {
                m_mdiWindow.$("#divRequestDialog").dialogExtend("restore");
            }
            if ($(".ui-dialog-titlebar-close").length > 0) {
                $(".ui-dialog-titlebar-close").attr("title", "Close");
            }
            if ($(".ui-dialog-titlebar-minimize").length > 0) {
                $(".ui-dialog-titlebar-minimize").attr("title", "Minimize");
            }
            if ($(".ui-dialog-titlebar-restore").length > 0) {
                $(".ui-dialog-titlebar-restore").attr("title", "Restore");
            }
        } else {
            m_mdiWindow.$("body").append('<div id="divRequestDialog" style="overflow:hidden;width:100%;height:100%" title="Excelicare Requests"></div>').find("#divRequestDialog").html('<iframe id="frmRequestDialog" style="border:0;width:100%;height:100%" width="100%" height="100%" scrolling="none" frameborder="0"></iframe>');			
            m_mdiWindow.$("#divRequestDialog").dialog(
							{
							    "width": 950,
							    "height": 570,
							    "resizable": true,
							    "draggable": true,
							    beforeClose: function (event, ui) { if (fnbeforeCloseRequestDialog() == false) { return false; } }
							}
						).dialogExtend(
							{
							    "closable": true,
							    "minimizable": true,
							    "minimizeLocation": "left",
							    "icons": {
							        "close": "ui-icon-closethick",
							        "minimize": "ui-icon-minus"
							    }
							}
						);
            m_mdiWindow.$("#frmRequestDialog").attr("src", URL);
            if ($(".ui-dialog-titlebar-close").length > 0) {
                $(".ui-dialog-titlebar-close").attr("title", "Close");
            }
            if ($(".ui-dialog-titlebar-minimize").length > 0) {
                $(".ui-dialog-titlebar-minimize").attr("title", "Minimize");
            }
            if ($(".ui-dialog-titlebar-restore").length > 0) {
                $(".ui-dialog-titlebar-restore").attr("title", "Restore");
            }
        }
    } catch (e) { }
}
//
//' -----------------------------------------------------------------------------------------------
//' <summary>
//'   function to initiate the upload of large media to web server
//' </summary>
//' <remarks>
//' </remarks>
//' <history>
//'      Shireesha              22-Dec-2019               Created    
//' </history>
//' -----------------------------------------------------------------------------------------------
function UploadFile(file, intUploadChunkFileSize, ChildCallback) {
    try {

        var intmaxFileSizeKB = intUploadChunkFileSize * (1000);
        var bytefileChunks = [];
        var intbufferChunkSizeInBytes = intmaxFileSizeKB * (1024);
        var intCurrentStreamPosition = 0;
        var intEndPosition = intbufferChunkSizeInBytes;
        var intSize = file.size;
        var strMediadojoID;
        var strUUID = $ec.fn.getGUID();  //"uuid-" + ((new Date).getTime().toString(16) + Math.floor(1E7 * Math.random()).toString(16))
        var strFileName = strUUID + "_" + file.name;
      
        strFileName = strFileName.replace(/([%$#*@~&])/g, "");
        m_strCurrentUploadingUUID = strUUID;
		var strMessage = "Uploading " + strFileName + " (Size: " + intSize + "(kb)) to server Start :"
		//strJsonData = JSON.stringify({"strMessage": strMessage})
		//SiteExcelicare.LogLargeMediaTrace($ec.fn.et(strJsonData))
		SiteExcelicare.logECWebSessionAction(2039, -1,strMessage)
        while (intCurrentStreamPosition < intSize) {
            bytefileChunks.push(file.slice(intCurrentStreamPosition, intEndPosition));
            intCurrentStreamPosition = intEndPosition;
            intEndPosition = intCurrentStreamPosition + intbufferChunkSizeInBytes;
        }

        strMediadojoID = window.top.dijit.byId(window.top.dojoDialogStack[window.top.dojoDialogStack.length - 1]);
        CreateMediaUploadJsonObject(strUUID, strFileName, file.type, intSize);

        $("#message_area").css('visibility', 'visible');
        UpdateMDIUploadStatusIconText();

        UploadFileChunk(bytefileChunks, strFileName, 1, bytefileChunks.length, strUUID, intSize, file.type, strMediadojoID, ChildCallback);
    }
    catch (e) {
        console.log('UploadFile :-' + e.message)
    }
}
//
//' -----------------------------------------------------------------------------------------------
//' <summary>
//'   function to create media upload status json array
//' </summary>
//' <remarks>
//' </remarks>
//' <history>
//'      Shireesha              22-Dec-2019               Created    
//' </history>
//' -----------------------------------------------------------------------------------------------
function CreateMediaUploadJsonObject(strUUID, strFileName, strType, intSize)
{
    try {
        var objMediaUploaded = {};

        objMediaUploaded['UUID'] = strUUID;
        objMediaUploaded['Cob_ID'] = 0;
        objMediaUploaded['ItemName'] = "";
        objMediaUploaded['DateCreated'] = "";
        objMediaUploaded['CreatedBy'] = $ec.fn.getValue("UserName");
        objMediaUploaded['PatientName'] = $ec.fn.getPatientObject("name");
        objMediaUploaded['DOB'] = $ec.fn.getPatientObject("dobvalue");
        objMediaUploaded['Primary'] = $ec.fn.getPatientObject("primary");
        objMediaUploaded['FileName'] = strFileName;
        objMediaUploaded['FileType'] = strType;
        objMediaUploaded['Size'] = intSize;
        objMediaUploaded['Status'] = UploadStaus.InProgress;
        objMediaUploaded['Saving'] = 0;

        objMediaUploadStatus.push(objMediaUploaded);
    }
    catch(e){}
}

//' -----------------------------------------------------------------------------------------------
//' <summary>
//'   Ajax call to  upload media in chunks to server
//' </summary>
//' <remarks>
//' </remarks>
//' <history>
//'      Shireesha              22-Dec-2019               Created    
//' </history>
//' -----------------------------------------------------------------------------------------------
function UploadFileChunk(bytefileChunks, strFileName, intCurrentPart, intTotalPart, strUUID, intSize, strContentType, strMediaDojoID, ChildCallback) {
    try {
     
        var formData = new FormData();
        var strUpdatedUUID = "";
        var intDiologCount;
        var strDojoID;

        formData.append('file', bytefileChunks[intCurrentPart - 1], strFileName);
        $.ajax({
            type: "POST",
            url: "../AxFXWebUISharedUtilities/AxRsLargeMediaUpload.ashx",
            data: formData,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            processData: false,
            contentType: false,
            async: true,
            success: function (result) {
                if (intTotalPart >= intCurrentPart) {
                    if (intTotalPart == intCurrentPart) {
                        //Whole file uploaded
						var strMessage = "Uploading " + strFileName + "( Size: " + intSize + "(kb)) to server End : "
                        		//strJsonData = JSON.stringify({"strMessage": strMessage})
						SiteExcelicare.logECWebSessionAction(2039, -1, strMessage)
                        if (window.top.dojoDialogStack.length >= 1) {
                            intDiologCount = window.top.dojoDialogStack.length
                            for (intDiologCount; intDiologCount > 0; intDiologCount--) {
                                strdojoID = window.top.dijit.byId(window.top.dojoDialogStack[intDiologCount - 1]);
                                if (strdojoID != undefined && strdojoID == strMediaDojoID) {
                                    DeleteMediaUploadJsonItem(strUUID);
                                 
                                    if (m_strCurrentUploadingUUID == strUUID) {
                                        m_strCurrentUploadingUUID = "";
                                        ChildCallback(strContentType, intSize, strFileName);
                                    }
                                }
                                else if (strUpdatedUUID != strUUID) {
                                    UpdateMediaUploadJson(strUUID, 'Status', UploadStaus.UploadedNotSaved);
                                    strUpdatedUUID = strUUID;
                                }
                            }
                         }
                        else {
                           
                            UpdateMediaUploadJson(strUUID, 'Status', UploadStaus.UploadedNotSaved);
                        }

                    } else {

                        UploadFileChunk(bytefileChunks, strFileName, intCurrentPart + 1, intTotalPart, strUUID, intSize, strContentType, strMediaDojoID, ChildCallback);
                    }
                }
            },
            error: function (err) {
                console.log(err.statusText);
            }
        });

    }
    catch (e) {
        console.log("UploadFileChunk" + e.message)
    }

}
//' -----------------------------------------------------------------------------------------------
//' <summary>
//'   To get cobids which are not saved into tblPatientMediaFS due to errors or logoff
//' </summary>
//' <remarks>
//' </remarks>
//' <history>
//'      Shireesha              17-Mar-2019               Created    
//' </history>
//' -----------------------------------------------------------------------------------------------
function GetFailedCobIDs() {
    var strCob_ID = "0";
    try {

        $.each(objMediaUploadStatus, function (i, media) {
            if (media.Status != UploadStaus.Success && media.Cob_ID > 0) {
                strCob_ID = strCob_ID + "," + media.Cob_ID;
            }
        });

        return strCob_ID;
    }
    catch (e) { }
}
//
//' -----------------------------------------------------------------------------------------------
//' <summary>
//'   To get saved media item cobid for saving the large image
//' </summary>
//' <remarks>
//' </remarks>
//' <history>
//'      Shireesha              22-Dec-2019               Created    
//' </history>
//' -----------------------------------------------------------------------------------------------
function GetCobID(strUUID) {
    var intCob_ID;
    try {

        $.each(objMediaUploadStatus, function (i, media) {
            //console.log(media.UUID)
            if (media.UUID == strUUID) {
                intCob_ID = media.Cob_ID;
                return false;
            }
        });
        return intCob_ID;
    }
    catch(e){}
}
//' -----------------------------------------------------------------------------------------------
//' <summary>
//'   To update json object attributes
//' </summary>
//' <remarks>
//' </remarks>
//' <history>
//'      Shireesha              22-Dec-2019               Created    
//' </history>
//' -----------------------------------------------------------------------------------------------
function UpdateMediaUploadJson(strUUID,strAttrName,strAttrValue) {
    try {
        var blnSave;

        $.each(objMediaUploadStatus, function (i, media) {
       
            if (media.UUID == strUUID) {
                media[strAttrName] = strAttrValue;
                return false;
            }
        });
      
        blnSave = true;
        //To update status icon when status attribute value changes
        if (strAttrName == "Status") {
            UpdateMDIUploadStatusIconText();
            if (strAttrValue == 2) {
                $.each(objMediaUploadStatus, function (i, media) {
                    if (media.UUID != strUUID && media.Status == UploadStaus.UploadedNotSaved) {
                        blnSave = false;
                        return false;
                    }
                });
            }
          
            if (blnSave == true && (strAttrValue != 0)) {
                $.each(objMediaUploadStatus, function (i, media) {
                    if (media.Status == 2 && media.Saving == 0) {
                        if (media.Cob_ID > 0) {
                            media.Saving = 1;
                            fnSaveUploadedMedia(media.Cob_ID, media.FileName, media.FileType.substring(media.FileType.indexOf("/") + 1), media.Size.toString(), m_intUserId, m_strSessionID, media.UUID)
                        }
                        else {
                            UpdateMediaUploadJson(media.UUID, 'Status', UploadStaus.Error)
                        }
                        return false;
                    }
                });
            }
        }
    }
    catch (e) {}
}
//
//' -----------------------------------------------------------------------------------------------
//' <summary>
//'  To delete upload record from upload status json
//' </summary>
//' <remarks>
//' </remarks>
//' <history>
//'      Shireesha              22-Dec-2019               Created    
//' </history>
//' -----------------------------------------------------------------------------------------------
function DeleteMediaUploadJsonItem(strUUID) {
    try {
        $.each(objMediaUploadStatus, function (i, media) {
            if (media.UUID == strUUID) {
               objMediaUploadStatus.splice(i,1);
                return false;
            }
        });
        if (objMediaUploadStatus.length == 0) {
            $("#message_area").css('visibility', 'hidden');
        }
        else {
            UpdateMDIUploadStatusIconText();
        }
    }
    catch (e) {}
}
//' -----------------------------------------------------------------------------------------------
//' <summary>
//' To change the upload status text after all files are uploaded and also when new file is added to upload
//' </summary>
//' <remarks>
//' </remarks>
//' <history>
//'      Shireesha              22-Dec-2019               Created    
//' </history>
//' -----------------------------------------------------------------------------------------------
function UpdateMDIUploadStatusIconText() {
    var blnStatus = true;
    try {
       
        $.each(objMediaUploadStatus, function (i, media) {
            if (media.Status == 0 || media.Status == UploadStaus.UploadedNotSaved) {
                blnStatus = false;
                return false;
            }
         });

        if (blnStatus) {
            $("#UploadStatusSpan").text("All Media File(s) Uploaded Successfully");
            $("#UploadClose").show();
        }
        else {
            $("#UploadStatusSpan").text("Uploading Media File(s)..");
            $("#UploadClose").hide();
        }
    }
    catch (e) { }
}
//' -----------------------------------------------------------------------------------------------
//' <summary>
//' To save large media file to DB by calling media service method
//' </summary>
//' <remarks>
//' </remarks>
//' <history>
//'      Shireesha              22-Dec-2019               Created    
//' </history>
//' -----------------------------------------------------------------------------------------------
function fnSaveUploadedMedia(intCob_id, strFileName, strFileFormat, dblSize, intUserID, strSessionID,strUUID) {
    try {
        $.ajax({
            type: "POST",
            url: ServiceURL + '/AxRSMediaService.svc/SaveLargeMediaItem',
            dataType: "json",
            contentType: "application/json",
            data: '{"lngCobId":"' + intCob_id + '","strFileName":"' + strFileName + '","strFileFormat": "' + strFileFormat + '","lngUserId":"' + intUserID + '","strSessionID": "' + strSessionID + '","dblSize":"' + dblSize + '"}',
            success: function (data) {
                UpdateMediaUploadJson(strUUID, 'Status', UploadStaus.Success)
            },
            error: function (xhr, status) {
                UpdateMediaUploadJson(strUUID, 'Status', UploadStaus.Error)
                console.log("An error occurred: " + status);
            }
        });
    }
    catch(e){}
}
function fnbeforeCloseRequestDialog() {
    try {
        if (!($.browser.msie)) {
            if (frmRequestDialog.contentWindow.isFormDirty != undefined) {
                $ec.fn.setValue("blnCloseedPrism", true);
                if (frmRequestDialog.contentWindow.isFormDirty(function () {
                    m_mdiWindow.$("#frmRequestDialog").attr("src", "../frmBlankPage.htm");
                    m_mdiWindow.$("#divRequestDialog").dialog('destroy').remove();
                    $ec.fn.setValue("blnCloseedPrism", false);
                }) == false) {
                    m_mdiWindow.$("#frmRequestDialog").attr("src", "../frmBlankPage.htm");
                    m_mdiWindow.$("#divRequestDialog").dialog('destroy').remove();
                    $ec.fn.setValue("blnCloseedPrism", false);
                    return true;
                }
                else {
                    return false;
                }
            }
        }
        else {
            if (frmRequestDialog.isFormDirty != undefined) {
                $ec.fn.setValue("blnCloseedPrism", true);
                if (frmRequestDialog.isFormDirty(function () {
                    m_mdiWindow.$("#frmRequestDialog").attr("src", "../frmBlankPage.htm");
                    m_mdiWindow.$("#divRequestDialog").dialog('destroy').remove();
                    $ec.fn.setValue("blnCloseedPrism", false);
                }) == false) {
                    m_mdiWindow.$("#frmRequestDialog").attr("src", "../frmBlankPage.htm");
                    m_mdiWindow.$("#divRequestDialog").dialog('destroy').remove();
                    $ec.fn.setValue("blnCloseedPrism", false);
                    return true;
                }
                else {
                    return false;
                }
            }
        }
    } catch (e) { }
	}
	
function ShowRIOSummary(strRIOHTML) {
    return SiteExcelicare.AxSysF_fnShowRioSummary(fnShowRioSummary(strRIOHTML));
}

function SaveRIOAlerts(strPatID,intMode) {
    return SiteExcelicare.AxSysF_fnSaveRioAlerts(fnSaveRioAlerts(strPatID,intMode));
}
if (m_strSessionValidate == "" || m_strSessionValidate == undefined || m_strSessionValidate == 0)
    m_strSessionValidate = 30000;

//var handle = window.setInterval("fnSessionLogout()", m_strSessionValidate);
var handle = window.setInterval(function(){if(blnUserActive){fnSessionLogout();}}, m_strSessionValidate);
window.setInterval(function(){if(blnUserActive && blnAppActive){fnSessionLogout();}}, 0);

function fnSessionLogout() {
    var blnstatus = SiteExcelicare.IsSessionActive(fnSLogout(m_strSessionID));
	blnUserActive = blnAppActive = false;
    var strCobIds;
    if (blnstatus.value != false && m_blnLogoutClicked == false) {
        $ec.fn.setValue("SessionExpries", 1);
        if (oPopupWindow != undefined) {
            for (var ModuleID in oPopupWindow) {
                oPopupWindow[ModuleID].close();
            }
        }
        if (window.top.dojoDialogStack.length >= 1) {
            var intDiologCount = window.top.dojoDialogStack.length
            for (intDiologCount; intDiologCount > 0; intDiologCount--) {
                var dojoID = window.top.dijit.byId(window.top.dojoDialogStack[intDiologCount - 1]);
                if (dojoID != undefined) {
                    dojoID.hide();
                }
            }
        }
        m_blnLogoutClicked = true;
        clearInterval(handle);
        handle = 0;
        if (m_strSSOCalledFrom == "") {
            strCobIds = GetFailedCobIDs();
            if (strCobIds != "0") {
                SiteExcelicare.DeleteFailedMediaEntries(fnDeleteFailedMediaEntries(strCobIds));
            }
            window.location.href = '../AxWebUIMDI/CustomError.Aspx?ErrorCode=Your session has expired, Please close the current instance.';
			SiteExcelicare.fnAppLogOff(fnLogOff(1));
            return;
        }
        var retVal = OpenCustomDialog("Your session has expired, click ok to  close the window.", 0, '350px', '150px', 0, 'Excelicare', function (retVal) {
            retValue = retVal

            if (retVal != "" && m_strSSOCalledFrom != '') {
                window.open("", "_self", "");
                window.opener = top;
                window.close();

            }

        })
    }

}
//Added for showing file upload status data... 
function fnShowUploadStatus() {
    try {
        if (objMediaUploadStatus != undefined && objMediaUploadStatus.length > 0) {
            var OnHideHandle = function () {
            };
            var strUploadStatusURL = './frmUploadStatus.html';
            $ec.fn.setValue("UploadStatusJson", objMediaUploadStatus);
            if (window.top.dojoDialogStack.length >= 1) {
                var intDiologCount = window.top.dojoDialogStack.length
                for (intDiologCount; intDiologCount > 0; intDiologCount--) {
                    var dojoID = window.top.dijit.byId(window.top.dojoDialogStack[intDiologCount - 1]);
                    if (dojoID != undefined) {
                        dojoID.hide();
                    }
                }
            }
            AxOpenDojo(strUploadStatusURL, "1000px", "340px", "Media File Upload Status", '', OnHideHandle);
        }
    } catch (e) {

    }
}
function fnCheckUploadFilesExsit()
{
    var status = true;
    if (objMediaUploadStatus != undefined && objMediaUploadStatus.length > 0) {
        $.each(objMediaUploadStatus, function (i, item) {
            if (item.Status == 0 || item.Status == 2) {
                status = false;
                return false;
            }
        });
    }
    return status;
}
function fnHideUploadStatus()
{
    objMediaUploadStatus = [];
    $('#message_area').css('visibility', 'hidden');
}

function fnfrmGetLabOrderURL(blnCheckLocation)
{
	try{
		objJsonData = {"bcl": blnCheckLocation}
        return fnEncryptData(objJsonData)
	}catch(e){}
}

function fnGetPresAccountStatus(inteRxUserId, inteRxLocationId)
{
	try{
		objJsonData = { "ieu": inteRxUserId, "iel": inteRxLocationId}
        return fnEncryptData(objJsonData)
	}catch(e){}
}

function fnSLogout(m_strSessionID)
{
	try{
		objJsonData = { "ssi": m_strSessionID}
        return fnEncryptData(objJsonData)
	}catch(e){}
}

function fnShowRioSummary(strRIOHTML)
{
	try{
		objJsonData = { "rht": strRIOHTML}
        return fnEncryptData(objJsonData)
	}catch(e){}
}

function fnSaveRioAlerts(strPatID,intMode)
{
	try{
		objJsonData = { "spi": strPatID, "imd": intMode}
        return fnEncryptData(objJsonData)
	}catch(e){}
}

function GetTquestURL(blnCheckLocation)
{
	try{
		objJsonData = {"bcl": blnCheckLocation}
        return fnEncryptData(objJsonData)
	}catch(e){}
}

function fnLogOff(intLogOff)
{
	try{
		objJsonData = {"intLogOff": intLogOff}
        return fnEncryptData(objJsonData)
	}catch(e){}
}

function fnSaveUsrNavigationHistory(ModuleId, FormId, URL)
{
	try{
		objJsonData = {"ModuleId": ModuleId, "FormId": FormId, "URL": URL,}
        return fnEncryptData(objJsonData)
	}catch(e){}
}

function fnUpdateDisclaimer(blnShowDisclaimer)
{
	try{
		objJsonData = {"blnShowDisclaimer": blnShowDisclaimer}
        return fnEncryptData(objJsonData)
	}catch(e){}
}

function fnGetExternalURL(intFormLibItemID,lngDataID)
{
	try{
		objJsonData = {"intFormLibItemID": intFormLibItemID, "lngDataID": lngDataID}
        return fnEncryptData(objJsonData)
	}catch(e){}
}

function fnGetExternalURLFLID(strExternalURLName)
{
	try{
		objJsonData = {"strExternalURLName": strExternalURLName}
        return fnEncryptData(objJsonData)
	}catch(e){}
}

function UnLockCarePlan(strname)
{
	try{
		objJsonData = {"strname": strname}
        return fnEncryptData(objJsonData)
	}catch(e){}
}

function fnDeleteFailedMediaEntries(strCobIds)
{
	try{
		objJsonData = {"strCobIds": strCobIds}
        return fnEncryptData(objJsonData)
	}catch(e){}
}

function fnEncryptData(strJsonData) {
    try {
        if (strJsonData != "") {
            strJsonData = JSON.stringify(strJsonData)
            return $ec.fn.et(strJsonData)
        } else {
            return null
        }
    } catch (e) { }
}

function fnValidateBeforeSendingWelcomePackage(){
	try{
	    return SiteExcelicare.fnValidateBeforeSendingWelcomePackage().value;
	}
	catch(ex){}	
}

function fnUpdateHTMLVersion(URL){
	if (URL.indexOf(".html") > 0 && URL.indexOf("v=") < 0){
		if (URL.indexOf(".html?") > 0)
			URL = URL + "&v=" + $ec.fn.getValue("ECVersion");		
		else
			URL = URL + "?v=" + $ec.fn.getValue("ECVersion");			
	}
	return URL;
}
function fnOpenUserStatus()
{
	try
	
	{
		 var index=0;
		 var ddlHtml='';
	     var strClassName="";
		$("#divAvailabilityStatus").css("display","");
		var strDataJSon = '{"lcId":"3564"}';
		strDataJSon = $ec.fn.et(strDataJSon);
		var res = SiteExcelicare.GetUserStatusLookup(strDataJSon).value;
		if(res.value!="")
		{
			var dllList = JSON.parse(res.replace(/'/g,'"'))["UserAvailabilityStatus"]
			for(index=0;index<=dllList.length-1;index++){
						ddlHtml += '<a href="#" class="dropdown-item" onClick="fnUserAvailableStatus(event)" value='+dllList[index][Object.keys(dllList[index])[0]]+"><img src='../AxCommon/Images/"+dllList[index][Object.keys(dllList[index])[1]].replace(/\s+/g,"_")+".png '/> "+dllList[index][Object.keys(dllList[index])[1]]+ "</a>";
					}
					$("#UserStatus").html(ddlHtml);		
	   }
	   fnShowHidePhotoButton();
	   $("#Userimg").focus();					
	}
	catch(ex){}
	
}
function fnShowUserStatus()
{
	try{
		$("#UserStatus").show()
	}
	catch(ex){}
}	

function fnUserAvailableStatus(e)
{
	try{
		var strStaus=$(e.target).attr("value")
		
		var res=fnUpdateAvailableStatus(strStaus);
		if(res.replace(/\"/g, "")=="1")
		{
	     fnGetUSerAvailableStatus($(e.target).text());
			   
		}
	}catch(ex){	}
}
function fnUpdateAvailableStatus(strStatus)
{
	try{
	   var strDataJSon = '{"lus":"'+strStatus+'"}';
		strDataJSon = $ec.fn.et(strDataJSon);
		return SiteExcelicare.UpdateUserStatus(strDataJSon).value;
	}catch(ex){}
}
function fnGetUSerAvailableStatus(strStatus)
{
	try{
		       m_UserStatus=strStatus
		       $("#imgMenuStatus").attr("src","../AxCommon/Images/"+m_UserStatus.trim().replace(/\"/g, "").replace(/\ /g,"_")+".png");
		       $("#imgStatus").attr("src","../AxCommon/Images/"+m_UserStatus.trim().replace(/\"/g, "").replace(/\ /g,"_")+".png");
			   $("#imgMenuStatus").attr("title",m_UserStatus);
			   $("#imgStatus").attr("title",m_UserStatus);
			   $("#dvUserStatus")[0].innerHTML=m_UserStatus.trim().replace(/\"/g, "")+" <img src='../AxCommon/Images/down.png' width=13px/>";
			   $("#UserStatus").hide();
			   //$("#divAvailabilityStatus").css("display","none");
	}
	catch(ex){}
}

function fnhideDropdownContent(e){
   if(e.target.id!='UserStatus')
	$("#UserStatus").hide();
 }
 
function fnhideUserStatus()
{
	 $("#UserStatus").hide();
	 $("#divAvailabilityStatus").css("display","none");
}
var intPhotoExist=0;
function AxSysF_ImageOver() {
	
            try { 
                    document.getElementById("btnAddPhoto").style.display = "block"
                    if (intPhotoExist != "0") {
                        //document.getElementById("btnDeleltePhoto").style.left = "15px"
						 document.getElementById("btnAddPhoto").style.display = "none"
						  document.getElementById("btnDeleltePhoto").style.display = "block"
                        //document.getElementById("btnDeleltePhoto").style.left = "15px"
                        //document.getElementById("btnDeleltePhoto").style.top = "30px"
                    }
                    else {
                        //document.getElementById("btnAddPhoto").style.left = "15px"
                        document.getElementById("btnAddPhoto").title = "Add Photo"
						document.getElementById("btnDeleltePhoto").style.display = "none"
                    }
                   // document.getElementById("btnAddPhoto").style.top = "20px"

                 
               
            }
            catch (e)
            { alert(e.message) }
        }
        
        function AxSysF_ImageOut() {
            try { 
                HidePhotoButtons();
            }
            catch (e) { }
        }
		
		        function HidePhotoButtons() {
            document.getElementById("btnAddPhoto").style.display = "none"
            document.getElementById("btnDeleltePhoto").style.display = "none"
        }
        
		function fnShowHidePhotoButton()
		{
			try{
				if (intPhotoExist != "0") {
						console.log("intPhotoExist ImageOver" );
                        
						 document.getElementById("btnAddPhoto").style.display = "none"
						  document.getElementById("btnDeleltePhoto").style.display = "block"
                    }
                    else {
                        document.getElementById("btnAddPhoto").style.display = "block"
						document.getElementById("btnDeleltePhoto").style.display = "none"
                    }
			}
			catch(ex){}
			
		}
        function fnAddPhoto() { 
           
            var strPatientUploadURl = "../AxWebUIPersonRegistration/frmUploadPhoto.htm?calledFrom=Userstatus"
           AxOpenDojo(strPatientUploadURl, "450px", "160px", 'Upload Photograph', function (retVal) {			   
                 if (retVal != undefined && retVal !="")
					$("#Userimg").attr("src",retVal)
				    intPhotoExist=1;
					 fnShowHidePhotoButton();
            });
            return false; 
        }
        
        function fnDeleltePhoto() {  
			 /*m_mdiWindow.OpenCustomDialog("Do you wish to delete the photo?", '4', "300px", '150px', '1', 'Excelicare', function (retVal) {
				if (retVal == 6) {
					var objResult = SiteExcelicare.DeleteUserPhoto();
                   $("#Userimg").attr("src","../AxCommon/Images/DefaultDP.png")		
                   intPhotoExist=0;				   
                   return false;  
				    
				}
			});*/
            var strMsg = "Do you wish to delete the photo?"
				var strDialogTitle = "Excelicare"
				var URL = "../AxFXDialog/frmDialogPage.html?t=" + strDialogTitle + "&p=" + encodeURIComponent(strMsg) + "&bs=4&is=1";
				AxOpenDojo(URL,450,145,strDialogTitle, function (retVal) {
					
					if (retVal == 6) {
				var objResult = SiteExcelicare.DeleteUserPhoto();
                   $("#Userimg").attr("src","../AxCommon/Images/DefaultDP.png")		
                   intPhotoExist=0;	
                   fnShowHidePhotoButton();				   
                   return false;  
				}
				});
				return false;
           
        }      
        
		function fnGetUserPhoto()
		{
			var ObjResult=SiteExcelicare.GetUserPhoto();
			if(JSON.parse(ObjResult.value).data!="")
			{
				
				//$("#Userimg").attr("src",JSON.parse(ObjResult.value).data)
				var strimagePath="";
				if(JSON.parse(ObjResult.value).data!=undefined){
				 strimagePath=oDynamicValues.AxServerTempURL.replace(m_strSessionID,"")+"/"+JSON.parse(ObjResult.value).data;
				 intPhotoExist=1;
				}
			   else
				 strimagePath=oDynamicValues.AxServerTempURL.replace(m_strSessionID,"")+$ec.fn.getValue("UserId")+".jpg";
				$("#Userimg").attr("src",strimagePath)
			}
		}
		
		function fnShowHideUserStatus()
		{
			try{
				if(intShowUserStatus=="0"){
					$("#dvMenuStatus").css("display","none");
				}
				else{
				 $("#dvMenuStatus").css("display","");
				 fnUpdateAvailableStatus(16369);							
	             fnGetUserPhoto();
				}
			}
			catch(ex){}
		}
		
		
function fnUpdatePDLInEditMode(strInput){
	try{
	    return SiteExcelicare.fnUpdatePDLInEditMode(strInput).value;
	}
	catch(ex){}	
}

function fnAddUsertoDirectCall(){
			   
            try{    
				
                var strRetUrl = "", strName,ID;
			var strReturnValue=""; 
	       strRetUrl =  "../AxFXWebCusCtrlLOV/frmLOV.aspx?txtlovid=216&txtSelectAll=Y&EC=1"
            strWidth = "930", strHeight = "530", strtitle = "List of Users"
            AxOpenDojo(strRetUrl, strWidth, strHeight, strtitle,function (strReturnValue){
			 var objxml_dom = fnLoadXML(unescape(strReturnValue));
			  var ID=objxml_dom.documentElement.selectSingleNode('_2458').text;
			  var strName =objxml_dom.documentElement.selectSingleNode('_2459').text;
				var UserType=objxml_dom.documentElement.selectSingleNode('_2465').text;				   
				var request={};
				
					request["SenderUserId"] = window.top.m_intUserId;
					request["ReceiverUserId"] = ID;
					request["Type"] = "Call";
					
					$.ajax({
							type: "post",
							url: $ec.fn.getValue("ECWebServiceURL")+"/TeleHealth/SendFCMPushNotification",
							data: JSON.stringify(request),
							headers: {
								"Token":"@" + window.top.m_strSessionID
							},
							contentType: "application/json; charset=utf-8",
							dataType: "json",
							crossDomain : true,
							crossOrigin : true,
							async: false,
							success: function (response) {
								var xPosition,xWidth,xHeight,xTop;					
                           xPosition = (parseInt(screen.width)/7.6);
                           xWidth = (parseInt(screen.width)/7)*6 ;
                           xHeight = parseInt(screen.height/8)*6.1;
                           xTop = parseInt(screen.height)/7.9;
						   if(oDynamicValues.TypeOfUser==0)
					       strURL="../AxTeleHealth/ecteleHealth.aspx?r=c&cn=&EntityID=" + window.top.m_intUserId + "&EntityTypeID=16318&eventid="+response.data.toLowerCase();
				          else  if(oDynamicValues.TypeOfUser==1)
					       strURL="../AxTeleHealth/ecteleHealth.aspx?r=o&cn=&EntityID=" + window.top.m_intUserId + "&EntityTypeID=16318&eventid="+response.data.toLowerCase(); 
				fnShowPrismDialog(strURL,"Direct Meeting");
              // window.top.parent.open(strURL,"Direct Meeting Window","top=" + xTop + "px,left=" + xPosition + "px,width=" + xWidth + "px,height=" + xHeight + "px");
							},
							error: function (response) {
								return null;
							}
						});
				
								
            },'');
                			
            }
            catch (e){}
        }
var audio;	
function FCMCustomActons(eventid,attendeeid,RoomName){
var request={};
				
		request["EventID"] = eventid;
		request["AttendanceStatus_SLU"] = 5988;
		request["AttendeeId"] = "";
		request["RoomName"] =RoomName;
		request["AdditionalInfo"] = "";
		request["UserId"] = 10;
		request["CallType"]="3575"
		$.ajax({
				type: "post",
				url: $ec.fn.getValue("ECWebServiceURL")+"/TeleHealth/UpdateExternalAttendeeStatus",
				data: JSON.stringify(request),
				headers: {
					"Token":"@" + window.top.m_strSessionID
				},
				contentType: "application/json; charset=utf-8",
				dataType: "json",
				crossDomain : true,
				crossOrigin : true,
				async: false,
				success: function (response) {
					window.top.$('#open-modal').remove();
					var xPosition,xWidth,xHeight,xTop;					
                           xPosition = (parseInt(screen.width)/7.6);
                           xWidth = (parseInt(screen.width)/7)*6 ;
                           xHeight = parseInt(screen.height/8)*6.1;
                           xTop = parseInt(screen.height)/7.9;
						   
					var strURL="";
					  if(oDynamicValues.TypeOfUser==1)
					      strURL="../AxTeleHealth/ecteleHealth.aspx?r=o&cn=&eventid=" + eventid.toLowerCase() + "&AttendeeID=" + attendeeid.toLowerCase();
				    else  if(oDynamicValues.TypeOfUser==0)
						  strURL="../AxTeleHealth/ecteleHealth.aspx?r=c&cn=&eventid=" + eventid.toLowerCase() + "&AttendeeID=" + attendeeid.toLowerCase();
					window.top.parent.open(strURL,"Direct Meeting Window","top=" + xTop + "px,left=" + xPosition + "px,width=" + xWidth + "px,height=" + xHeight + "px");
				},
				error: function (response) {
					return null;
				}
			});
}

function FCMOpenChatWindow(senderuserid,receiveruserid,name,photo){
	var URL;
	URL = '../AxTeleHealth/vchat.html?Token=@' + m_strSessionID + '&userid=' + receiveruserid + '&FilterBy=' + senderuserid + '|0&siteID=1602&Username=' + name + '&groupname=' + name + '&Image=' + photo;
	AxOpenDojo(URL, "1400px", "700px", "Chat");
	window.top.$('#open-modal').remove();
	
	return false;
}

function fnUpdateDeclineAttendeeStatus(eventid,status,RoomName)
{
	try{
		
		var streventid='';
		var request={};
				
		request["EventID"] = eventid;
		request["AttendanceStatus_SLU"] = status;
		request["AttendeeId"] = "";
		request["RoomName"] =RoomName;
		request["AdditionalInfo"] = "";
		request["UserId"] = 10;
		
		$.ajax({
				type: "post",
				url: $ec.fn.getValue("ECWebServiceURL")+"/TeleHealth/UpdateExternalAttendeeStatus",
				data: JSON.stringify(request),
				headers: {
					"Token":"@" + window.top.m_strSessionID
				},
				contentType: "application/json; charset=utf-8",
				dataType: "json",
				crossDomain : true,
				crossOrigin : true,
				async: false,
				success: function (response) {
				window.top.$('#open-modal').remove();
		        console.log("Sucessfully");
				
				},
				error: function (response) {
					return null;
				}
			});
	}
	catch(ex){}
}

function fnOpenMissedCallhistory(e)
{
	
	try{
		m_mdiWindow.frames.fraContent.fnLoadLayoutContent("../AxTeleHealth/frmCallHistory.html?Token=@"+m_strSessionID+"&FilterCriteria=Missed", '', '');
		$("#dvMissedCall").css("display","none");
	}catch(ex){}
}
function fnPopoutChat() {
    
    try {
		var FilterBy,strGroupName=""
        var strEcToken = m_strSessionID;
		if(JSON.parse(localStorage.listVariables)["FilterCriteria"]!=undefined){
         FilterBy = JSON.parse(localStorage.listVariables)["FilterCriteria"];
         strGroupName = username;
        if ($ec.fn.getValue("chatgroupName").length > 0) {
            strGroupName = $ec.fn.getValue("chatgroupName");
        }
		var scope = angular.element($("body")).scope();
		
        var strURL = "../AxTeleHealth/vchat.html?Token=" + strEcToken + "&userid=" + scope["userid"] + "&FilterBy=" + FilterBy + "&siteID=1602&Username=" + scope["username"] + "&groupname=" + strGroupName + "&Image=" + scope["Image"];
         ShowChatDialog(strURL, 950, 450, username, FilterBy.split("|")[0]);
		}
		else{
			 var strURL = "../AxTeleHealth/vchat.html?Token=" + strEcToken + "&userid=" + lngUserId + "&FilterBy=" + FilterBy + "&siteID=1602&Username=" + UserName + "&groupname=" + strGroupName + "&Image=" + strImg;
         ShowChatDialog(strURL, 950, 450, username, FilterBy.split("|")[0]);
		}
    } catch (ex) {}
}
function ShowChatDialog(URL, Height, Width, Title, userId) {
    if (window.top.$("#frmFormPropertiesDialog" + userId).length > 0) {
        window.top.$("#frmFormPropertiesDialog" + userId).attr("src", URL);
        window.top.$("#frmFormPropertiesDialog" + userId).show();
    } else {
        window.top.$("body").append('<div id="FormPropertiesDialog' + userId + '" class="auto" style="overflow:hidden;" title="' + Title + '"></div>').find("#FormPropertiesDialog" + userId).html('<iframe id="frmFormPropertiesDialog' + userId + '" style="border: 0" width="100%" height="100%" scrolling="none" frameborder="0"></iframe>');

    }
    window.top.$("#FormPropertiesDialog" + userId).dialog({
        "width": "800",
        "height": "420",
        position: {
            my: "right top",
            at: "left+31 top+161",
            of: "body"
        },
        close: function (event, ui) {
            window.top.$("#frmFormPropertiesDialog" + userId).attr("src", "../frmBlankPage.htm");
        }
    }).dialogExtend({
        "closable": true,
        "minimizable": true,
        "minimizeLocation": "left",
        "icons": {
            "close": "ui-icon-closethick",
            "minimize": "ui-icon-minus"
        }
    });
    window.top.$("#frmFormPropertiesDialog" + userId).attr("src", URL);

    window.top.$("#frmFormPropertiesDialog" + userId).load(function () {
        var id = "#" + $(this).attr('id');
        var frame = window.top.document.getElementById($(this).attr('id')).contentWindow;
        window.top.$(frame).on("resize", function () {
            $(window.top.$(id).parent().parent()).width(window.top.$(id).width());
            $(window.top.$(id).parent().parent()).height(window.top.$(id).height() + 20);
        })
    });

}