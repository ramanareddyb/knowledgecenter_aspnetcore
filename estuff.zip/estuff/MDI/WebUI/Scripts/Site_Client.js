AxCommunicator.register("MDIDes", window); 
AxCommunicator.register("MDISource", window); 
AxCommunicator.subscribe("MDIDes","MDISource", "PatChange"); 
AxCommunicator.registerEvents("MDIDes","fnBeforePatientChange","fnAfterPatientChange"); 

function fnBeforePatientChange()
{
return true;
}
function fnAfterPatientChange() {
    return false;
}
