/*$(m_strClinicianInfo).find("td").each(function (index, obj) {
    if ($(obj).prop("children").length == 0 && $(obj).prop("innerText") != "")
        strClinicianHTML = strClinicianHTML + "<b>" + $(obj).prop("innerText") + '</b><br>';
});
$(m_strConnectedSystemInfo).find("td").each(function (index, obj) {
    if ($(obj).prop("children").length == 0 && $(obj).prop("innerText") != "")
        strSystemHTML = strSystemHTML + "<b>" + $(obj).prop("innerText") + '</b><br>';
}); */
var m_mdiWindow = getRootNode(window);
m_mdiWindow = parentWindow;
if (navigator.appName == "Microsoft Internet Explorer")
    window.document.onreadystatechange = fnPageLoaded;
else
    document.addEventListener('DOMContentLoaded', fnPageLoaded, false);
//onerror = handleErrors



function LoadPatientRecordStartupForm() {
    var parentModuleId = $ec.fn.getValue('ParentModuleId');
if($ec.fn.getValue("allowbacknavigation") == 0) // PHM Backbutton changes rolling into Product by BRR
	$ec.fn.removeAllFromStack();
	
    $ec.fn.setValue("isPSM", 1);
    var strURL;
    if ($ec.fn.getValue("PrevSpecialFormURL") != undefined && $ec.fn.getValue("PrevSpecialFormURL") != "")
        strURL = $ec.fn.getValue("PrevSpecialFormURL");
    else {
        strURL = $ec.fn.getValue('hdnSelectedAxselBarItemUrl');

        // Code added For Get and set the parent Module ID and Module Name -- Krishna Prasad S
        $ec.fn.setValue('ModuleId', $ec.fn.getValue('ParentModuleId'));
       
        $ec.fn.setValue("ModuleName", $ec.fn.getValue('ParentModuleName'));

    }
    $ec.fn.setValue("PrevSpecialFormURL", "");
    $ec.fn.hidePatientBar(false);
    if (ModuleId == 111) {
        document.getElementById("hdnStartUpUrl").value = parent.m_strClinicalNotesURL
    }
    if (strURL != undefined && strURL != "") {
        if ($ec.fn.getValue("SignOn") == "1")
            m_mdiWindow.frames.fraContent.fnLoadLayoutContent(strURL, '');
        else
            m_mdiWindow.frames.fraContent.location.href = strURL;

    }
    else if (document.getElementById('hdnIsStartupFormAccessible').value != null && document.getElementById('hdnIsStartupFormAccessible').value != "") {
        var ModuleId = document.getElementById('hdnUserStartupForm').value;
        if (($ec.fn.getValue("GetPatRestrictionLevel") == 1 && ModuleId != 100 && ModuleId != 104) || ($ec.fn.getValue("GetPatRestrictionLevel") == 2 && ModuleId != 100 && ModuleId != 104 && ModuleId != 1008)) {
            m_mdiWindow.OpenCustomDialog('Sorry. You do not have access to this form.', 0, '300px', '120px', 0);
            m_mdiWindow.frames.fraContent.fnLoadLayoutContent("../frmBlankPage.htm", '');
            return false;
        }
        else if (document.getElementById('hdnIsStartupFormAccessible').value.toUpperCase() == "TRUE".toUpperCase() || document.getElementById('hdnIsStartupFormAccessible').value == 1) {// checking access control
            // ObjParent.frames[0].document.getElementById('hdnCurrentUrl').value = strStartUpformUrl

            if (ModuleId == 1316) {
                var strPatientID = $ec.fn.getPatient()
                var blnCheckLocation = false
                var TquestURL = frmPatientBar.fnGetTquestURL(GetTquestURL(m_intUserId, strPatientID, blnCheckLocation));
                if (TquestURL.value == "") {
                    m_mdiWindow.OpenCustomDialog("Unable to open TQuest url with these credentials. Please contact system administrator.", '8192', '500px', '150px', '1', 'Excelicare', '')
                    return false;
                }
                else if (TquestURL.value.toLowerCase() == "noidentifiers") {
                    m_mdiWindow.OpenCustomDialog("Insufficient Patient Details. Unable to load TQuest url.", 0, '300px', '150px', 0);
                    return false;
                }
                else if (JSON.parse(TquestURL.value).Status == "Success" && JSON.parse(TquestURL.value).data != "") {

                    AxOpenDojo(JSON.parse(TquestURL.value).data, '800', '450', 'TQuest', '', '');
                }
                else {
                    m_mdiWindow.OpenCustomDialog(JSON.parse(TquestURL.value).Message, 0, '300px', '150px', 0);
                }

            }
            else {
                $ec.fn.setValue('ModuleId', document.getElementById('hdnUserStartupForm').value);
                if ($ec.fn.getValue("SignOn") == "1")
                    m_mdiWindow.frames.fraContent.fnLoadLayoutContent(document.getElementById("hdnStartUpUrl").value, '');
                else
                    m_mdiWindow.frames.fraContent.location.href = document.getElementById("hdnStartUpUrl").value;
            }
        }
        else {
            m_mdiWindow.OpenCustomDialog('You have no security clearance to view the start up form.', 0, '300px', '150px', 0);
            m_mdiWindow.frames.fraContent.fnLoadLayoutContent("../frmBlankPage.htm", '')
            return false;
        }
    }
    else {
        if ($ec.fn.getValue("SignOn") == "1")
            m_mdiWindow.frames.fraContent.fnLoadLayoutContent("../frmBlankPage.htm", '');
        else
            m_mdiWindow.frames.fraContent.location.href = "../frmBlankPage.htm";
    }
}


function fnPageLoaded() {
    try {
        if (parent.oPopupWindow["SunquestWindow"] != undefined) {
            parent.oPopupWindow["SunquestWindow"].close();
        }
        if (navigator.appName == "Microsoft Internet Explorer") {
            if (window.document.readyState != "complete") {
                return;
            }
        }
        var fnPatientCallback;
        fnPatientCallback = $ec.fn.getValue('SetPatientCallback');
		parent.AxCommunicator.setProperties("MDISource","PatChange:"+document.getElementById("hdnSLPatID").value); //Added by manikyam.							 
        $ec.fn.setValue("GetPatRestrictionLevel", GetPatRestrictionLevel);
        if (fnPatientCallback != '') {
            fnPatientCallback.apply();
            //$ec.fn.unmask();
            return false;
        }

        var strEventDescription = "PageLoad client side:Patient ID:" + document.getElementById('hdnChangePatID').value + " | Session Patient ID:" + document.getElementById("hdnSLPatID").value + " | Session Current Patient ID: " + document.getElementById("hdnCurrentPatID").value;
        frmPatientBar.fnLogwebsessionAction(fnLogwebsession("Patient bar", document.getElementById('hdnChangePatID').value, 2398, strEventDescription, 1031))
        if (document.getElementById('PatDetailsSpan') != null) {
            document.getElementById('PatDetailsSpan').title = document.getElementById('hdnPatAddress').value;
            document.getElementById('hdnPatAddress').value = ""
        }

        var strNHSNumber = trim(m_strPriIdentValue.split(' ').join(''));
        $ec.fn.setValue('NHS', strNHSNumber)
        // if (strNHSNumber != "")
            // parent.AxCommunicator.setProperties("MDISource", "PatChange:0");
        AlertIconInfo(document.getElementById('hdnChangePatID').value)

        var ModID = ($ec.fn.getValue("PreviousLoadedModuleID") != undefined && $ec.fn.getValue("PreviousLoadedModuleID") != 0)? $ec.fn.getValue("PreviousLoadedModuleID") : $ec.fn.getValue("ModuleId");
        if ($ec.fn.getValue("isPSM") == "1" && (($ec.fn.getValue("GetPatRestrictionLevel") == 1 && ModID != 100 && ModID != 104) || ($ec.fn.getValue("GetPatRestrictionLevel") == 2 && ModID != 100 && ModID != 104 && ModID != 1008))) {
            m_mdiWindow.frames.fraContent.fnLoadLayoutContent("../frmBlankPage.htm", '');
            m_mdiWindow.OpenCustomDialog('Sorry. You do not have access to this form.', 0, '300px', '120px', 0);
            return false;
        } else {
            var strURL;

            strURL = $ec.fn.getValue("LayoutContainerURL");

            if ($ec.fn.getValue('blnIsMyPatient') == 1 && document.getElementById('hdnChangePatID').value == 0) {
                m_mdiWindow.frames.fraContent.fnLoadLayoutContent("../frmBlankPage.htm", '');
            }
            else if (strURL.toLowerCase().indexOf("frmblankpage") == -1 && $ec.fn.getValue('blnIsMyPatient') != undefined && $ec.fn.getValue('blnIsMyPatient') == 1 && $ec.fn.getValue("isPSM") == "1") {
                if (strURL.toLowerCase().indexOf("axwebuidisplayspecialform") != -1 && $ec.fn.getValue("PrevSpecialFormURL") != undefined && $ec.fn.getValue("PrevSpecialFormURL") != "") {
                    //m_mdiWindow.frames.fraContent.frames.fraLayoutContent.document.location.href = $ec.fn.getValue("SpecialFormURL");
                    m_mdiWindow.frames.fraContent.fnLoadLayoutContent($ec.fn.getValue("PrevSpecialFormURL"), '');
                }
                else {
                    if ($ec.fn.getValue("ModuleId") == 111 && $ec.fn.getValue("IsPatientChange") != undefined && $ec.fn.getValue("IsPatientChange") == "1") {
                        strURL = strURL + (strURL.indexOf("ID") > 0 ? "&PC=1" : "")
                    }
                    else if (strURL.toLowerCase().indexOf("frmdocprocessor.aspx") > 0) {
                        strURL = strURL.substring(0, strURL.toLowerCase().indexOf("frmdocprocessor.aspx")) + "frmDocProcessor.aspx?CalledFrom=showback";
                    }
                    if (strURL.lastIndexOf("#") != -1)
                        strURL = strURL.substring(0, strURL.lastIndexOf("#"));
                    //m_mdiWindow.frames.fraContent.frames.fraLayoutContent.document.location.href = strURL;
                    m_mdiWindow.frames.fraContent.fnLoadLayoutContent(strURL, '');
                }
                $ec.fn.setValue("PrevSpecialFormURL", "");
            }
            else if ($ec.fn.getValue('blnIsMyPatient') != undefined && $ec.fn.getValue('blnIsMyPatient') == 1) {
                LoadPatientRecordStartupForm();
            }
            else if (document.getElementById('hdnCurrentPatID').value > 0 && $ec.fn.getValue('ShowPatientRecordStartupForm') == 1 && $ec.fn.getValue('blnIsMyPatient') == 0) {
                LoadPatientRecordStartupForm();
            }

        }
        $ec.fn.setValue("PreviousLoadedModuleID", 0);
        if (document.getElementById("hdnCallBackFunction").value != "") {
            //alert("pat ID : " + document.getElementById('hdnCurrentPatID').value);
            eval(document.getElementById("hdnCallBackFunction").value);
            document.getElementById("hdnCallBackFunction").value = "";
        }

        if (M_blnValidPatient.toUpperCase() == "FALSE" && parseInt(document.getElementById('hdnChangePatID').value) == 0) /*Added by K.Bhavani on 25/04/2008 to check whether patient selection is done properly or not*/
        {
            var strEventDesc = "Critial Message from client side:Patient ID:" + document.getElementById('hdnChangePatID').value + " | Session Patient ID:" + parent.frames[1].document.getElementById("hdnSLPatID").value + " | Session Current Patient ID: " + parent.frames[1].document.getElementById("hdnCurrentPatID").value;
            frmPatientBar.LogwebsessionAction(fnLogwebsession("Patient bar", document.getElementById('hdnChangePatID').value, 2400, strEventDesc, 1031))
            parent.frames[0].fnShowCriticalMessage(1031)
        }
		if(window.top.PatientBanner != undefined && typeof(window.top.PatientBanner) == "object" && window.parent.$("#bannerContainer")[0].style.display != "none") window.top.PatientBanner.Toggle();
    }
    catch (ex) { }
}



//code to prevent right mouse click starts here
function click(e) {
    if (document.all) {
        if (event.button == 2) {
            event.cancelBubble = true;
            return false;
        }
    }

    if (document.layers) {
        if (e.which == 3) {
            event.cancelBubble = true;
            return false;
        }
    }
}

if (document.layers) {
    document.captureEvents(Event.MOUSEDOWN);
}
document.onmousedown = click;
document.oncontextmenu = function () { return false; };
//code to prevent right mouse click ends here



/*
Purpose : To log client side errors at server side
Author  : K.R.Nagodaya Bhaskar 
Date    : 07/10/2004
Modification Log : 
-------------------------------------------------------------------------------------------------
*/
function handleErrors(errorMessage, url, line) {
    // Create an instance of the XML HTTP Request object
    var oXMLHTTP = new ActiveXObject("Microsoft.XMLHTTP");
    document.body.style.cursor = 'wait';
    // Prepare the XMLHTTP object for a HTTP POST to error trapping aspx page
    var sURL = '../AxWebUILogin/frmLogClientScriptException.aspx?url=' + url + '&em=' + errorMessage + '&l=' + line;
    oXMLHTTP.open("POST", sURL, false);
    // Execute the request
    oXMLHTTP.send();
    document.body.style.cursor = 'auto';
    return true
}



function window_onload() {
    m_GenderIdentity = (m_GenderIdentity != "" ? JSON.parse(m_GenderIdentity) : "");
    if (document.getElementById("hdnChangePatID").value > 0) {
        if ($ec.fn.getValue("SignOn") == "1") {
            try {
                $ec.fn.hidePatientBar(false);
                m_mdiWindow.frames.fraContent.fnLoadLayoutContent("../AxFXWebUISummaryPanel/frmLinkedForm.aspx?linkedFormId=27&LO=1", "fral1_east")
                if (parseInt(intShowPatientKeySummary) == 1 && $ec.fn.getValue("RightFlyoutClosed") == false && $ec.fn.isSecureModule("1132")) {

                    setTimeout("parent.showflyout(this,2)", 300)

                }
            } catch (e) {
            }
            if (strEntityType == "" && $("#hdnEntityType").val() == "2936") {
                strEntityType = parseInt($("#hdnEntityType").val())
            }
            if (strEntityType != 2936) {
                $("#Facility_banner").css("display", "none")
                $("#patient_banner").css("display", "")
                if (patJSON.name.title != "") {
                    $("#patient_banner  div[axid='name']").text(patJSON.name.surname.toUpperCase() + ", " + patJSON.name.forename.substring(0, 1).toUpperCase() + patJSON.name.forename.substring(1).toLowerCase() + " " + patJSON.name.middlename.substring(0, 1).toUpperCase() + patJSON.name.middlename.substring(1).toLowerCase() + " (" + patJSON.name.title + ") ")
                } else {
                    $("#patient_banner  div[axid='name']").text(patJSON.name.surname.toUpperCase() + ", " + patJSON.name.forename.substring(0, 1).toUpperCase() + patJSON.name.forename.substring(1).toLowerCase() + " " + patJSON.name.middlename.substring(0, 1).toUpperCase() + patJSON.name.middlename.substring(1).toLowerCase() + " ")

                }
                if (patJSON.name.knownas.length == 0) {
                    $("#imgKnownas").hide();
                    $("#imgKnownas1").hide();
                }
                else {
                    if ($("#patient_banner  div[axid='name']")[0].innerText.length > 20) {
                        $("#imgKnownas").show();
                        $("#imgKnownas").attr("title", patJSON.name.knownas)
                    }
                    else {
                        $("#imgKnownas").hide();
                        var img = $('<img />').attr({
                            'id': 'imgKnownas1',
                            'src': '../AxCommon/Images/icon_KnownAs.png',
                            'title': '',
                            'style': 'vertical-align:middle;width:20px;height:20px;'
                        }).appendTo("#patient_banner  div[axid='name']");
                        $("#imgKnownas1").attr("title", patJSON.name.knownas)
                    }
                }

                if(m_GenderIdentity !== "" && m_GenderIdentity[0].Pronouns != undefined && m_GenderIdentity[0].Pronouns.trim() !== ''){
                    $("#dvProNoun").css('display','block');
                    if($("#patient_banner  div[axid='name']")[0].innerText.length > 20){
                        $('.Patient_Name').css('overflow','');
                        if($('#imgKnownas').css('display') === 'none')
                            $('#dvProNoun').css('right','-8px');
                        else
                            $('#dvProNoun').css('left','99px');
                    }else{
                        if($('#imgKnownas1').css('display') === 'none')
                            $('#dvProNoun').css('right','80px');
                        else if($("#patient_banner  div[axid='name']")[0].innerText.length >= 20)
                            $('#dvProNoun').css('right','2px');
                        else 
                        $('#dvProNoun').css('right','22px');
                    }

                    $("#patient_banner div[id='dvProNoun']").attr("title", m_GenderIdentity[0]?.Pronouns)
                }
                    
                var genderIdentity = "";
                genderIdentity = (m_GenderIdentity[0]?.Sex ? m_strSex+': '+ m_GenderIdentity[0]?.Sex + '\n' : "") + (m_GenderIdentity[0]?.GenderIdentity ? 'Gender Identity: '+ m_GenderIdentity[0]?.GenderIdentity + '\n' : "") + (m_GenderIdentity[0]?.GISameAsBirth ? 'GI same as birth: '+ m_GenderIdentity[0]?.GISameAsBirth : "");
                    if(genderIdentity !== ""){
                        $('<div />').attr({
                            'id': 'imgGender',
                            'title': '',
                            'style': 'border: 1px solid black; width: 53px; height: 18px; margin-top: 2px; float: right; border-radius: 3px; font-weight: bold; font-style: italic; background-color: #ffcccc; font-size: 11px; text-align: center; position: relative; top: 3px;'
                        }).append("<span style='position: relative; top: -4.5px;'>Gender</span>").appendTo("#patient_banner  span[id='spnGenderImage']");
                        $('#imgGender').attr("title",genderIdentity);
                    }
                //$("#patient_banner  div[axid='name']")[0].append('<img id="imgKnownas" src="../AxCommon/Images/28 stop.gif" class="right" title="Smiley face" width="5%" height="20%">')
                // document.getElementById("patient_banner  div[axid='name']").appendChild(img);


                //$("div[axid='name']").attr("title", $("#patient_banner  div[axid='name']").text());
                $("div[axid='name']").attr("title", $("#patient_banner  div[axid='name']").contents().get(0).nodeValue);
                $("#patient_banner  span[axid='gender']").text(patJSON?.sexcode + " ");
                $("#patient_banner  span[axid='dob']").text(m_strDOB + " (" + m_strAge + ") ");
                $("#patient_banner  span[axid='primaryid']").text(m_strPriIdentValue + " ");
                $("#patient_banner  span[axid='secondaryid']").text(m_strSecIdentValue + " ");
                $("#patient_banner  span[axid='secondaryid']").attr("title", $("#patient_banner  span[axid='secondaryid']").text());
                SetActionWidth();
                if (patJSON.sex.length > 6 && window.screen.width * window.devicePixelRatio == 1280 && window.screen.height * window.devicePixelRatio == 1025) {
                    $("#seciden").hide();
                    $("#secondaryid").hide();
                }
                if (m_blnDeadPatient == "True") {
                    $("#patient_banner  span[axid='dod']").text(m_strDOD);
                    $("#patient_banner").attr("class", "deceased")
                    $(".Patient_Name").css("width", "20%")
                    $("#Pat_details").css("width", "72%")
                    $("#seciden").hide();
                    $("#secondaryid").hide();
                } else {
                    $("#patient_banner  span[axid='dod']").css("display", "none");
                    $("#patient_banner  em[id='emdod']").css("display", "none")
                }
            }
            else {

                $("#patient_banner").css("display", "none")
                $("#Facility_banner").css("display", "")
                if (patJSON.toString() != "") {
                    $("#Facility_banner  span[axid='facName']").text(patJSON.FacName.toUpperCase());
                    $("span[axid='facName']").attr("title", $("#Facility_banner  span[axid='facName']").text());
                    $("#Facility_banner  span[axid='iden']").text(patJSON.Facident + " ");
                    $("#Facility_banner  span[axid='phone']").text(patJSON.Phone + " ");
                    $("#Facility_banner  span[axid='addr']").text(patJSON.Address + " ");
                    $("span[axid='addr']").attr("title", $("#Facility_banner  span[axid='addr']").text());
                }

            }
            if ($ec.fn.getValue("isPRMSelected") == "0") $ec.fn.hidePatientBar(true);
        }
        else {
            if ($ec.fn.getValue("SignOn") == "1") {
                try {
                    hidePatBar(true);
                    m_mdiWindow.frames.fraContent.fnLoadLayoutContent("../AxFXWebUISummaryPanel/frmLinkedForm.aspx?linkedFormId=27&LO=1", "fral1_east")
                } catch (e) {
                }
            }
        }


    }
    else if ($ec.fn.getValue("SignOn") != "1") {
        $("#outerTable").css("display", "block");
        $("#patient_banner").css("display", "none")
    }
    else {
        if ($ec.fn.getValue("SignOn") == "1") {
            try {
                $ec.fn.hidePatientBar(true);
                m_mdiWindow.frames.fraContent.fnLoadLayoutContent("../AxFXWebUISummaryPanel/frmLinkedForm.aspx?linkedFormId=27&LO=1", "fral1_east")
            } catch (e) {
            }
        }
    }
    AxCommunicatorFx().register("PatientBannerLoaded", window);
    AxCommunicatorFx().setProperties("PatientBannerLoaded", "PatientID:" + $ec.fn.getPatient());

    // Start - PHM Back button changes rolling
    if ($ec.fn.getValue("allowbacknavigation") == 1) {
        AxCommunicatorFx().register("PatientBannerLoaded", window);
        AxCommunicatorFx().setProperties("PatientBannerLoaded", "PatientID:" + $ec.fn.getPatient());
        if ($ec.fn.getValue("PrePatient") != undefined && $ec.fn.getValue("PrePatient") != "0" && $ec.fn.getPatient() != "0") {
            if ($ec.fn.getValue("PrePatient") != $ec.fn.getPatient())
                $ec.fn.removeAllFromStack();
        }
        $ec.fn.setValue("PrePatient", $ec.fn.getPatient());
    }
    // End - PHM Back button changes rolling

}
window.onresize = function (event) {
    SetActionWidth();
}
function SetActionWidth() {

    if (m_strActionValue != '') {
        $("#patient_banner  span[axid='action']").text(m_strActionValue);
        var intWindowWidth = $(window).width();
        var intPatDetWidth = $("#patient_banner  span[axid='name']").width() + $("#patient_banner  span[axid='patdet']").width() + 62;
        var intActionWidth = $("#patient_banner  span[axid='action']").width();
        $("#patient_banner  span[axid='action']").text("");
        var intAvailWidth = intWindowWidth - intPatDetWidth
        if (intActionWidth > intAvailWidth) {
            $("#patient_banner  span[axid='action']").attr("class", "actionIcon")
            if (intAvailWidth > 0) {
                $("#dvAction").css("width", intAvailWidth + "px")
                if (intAvailWidth > 40) {
                    var intMargin = (intAvailWidth - 10) / 2
                    $("#patient_banner  span[axid='action']").css("margin-left", intMargin + "px")
                }
            }
            else {
                $("#dvAction").css("width", "38px")
                $("#patient_banner  span[axid='action']").css("margin-left", "10px")
            }
        }
        else {
            $("#dvAction").css("width", intAvailWidth + "px")
            $("#patient_banner  span[axid='action']").attr("class", "actionItem")
            $("#patient_banner  span[axid='action']").text(m_strActionValue);
            $("#patient_banner  span[axid='action']").css("margin-left", Math.round(intAvailWidth - 22) + "px")
            $("#patient_banner  span[axid='action']").css("color", "Red")
        }
        $("#patient_banner  span[axid='action']").css("display", "block")
    }
    else
        $("#patient_banner  span[axid='action']").css("display", "none")
}
function hidePatBar(blnHideBar) {
    var g_hidePatientBar;
    try {
        blnHideBar = (blnHideBar == undefined ? true : blnHideBar);
        g_hidePatientBar = $ec.fn.getValue("hidePatinetBar");
        blnHideBar = (g_hidePatientBar == undefined ? blnHideBar : g_hidePatientBar);
        if (blnHideBar == true) {
            showflyout(this, 2, true)
        }
        if (strEntityType == 2936)
            $("#Facility_banner").css("display", " ")
        else
            $("#patient_banner").css("display", "")
        parent.$("#patBar").css("display", (blnHideBar ? "none" : "inline-block"));
        parent.oECLayout.resizeAll()
    } catch (e) {
    }

}

function AlertIconInfo(patientID) {
    var result = frmPatientBar.GetPatientZone1AlertIconInfo(fnGetPatientZone1AlertIconInfo(m_usrRstLevel, m_strAppType, m_IsACLPatient))
    result.value = $ec.fn.ecDecode(result.value)
    UpdateAlertInfo(result.value);
}

function UpdateAlertInfo(resultXML) {

    if (resultXML == undefined || resultXML == "") {
        $("#zoneAlergy").css("display", "none")
    } else {
        $("#divAlergy").remove();
        $("#zoneAlergy").css("display", "")
        if (resultXML != "") {
            var xmlDOM = fnLoadXML(resultXML);
            $("#zoneAlergy").append('<span id="divAlergy" style ="width:auto; height:auto;display: inline;"></span>');
            var xmlNodeList = xmlDOM.getElementsByTagName("AllergyInfo")
            if (xmlNodeList.length >= 1)
                $("#patient_banner  span[axid='patdet']").css("width", "65%");
            for (intIndex = 0; intIndex < xmlNodeList.length; intIndex++) {
                var count = xmlNodeList[intIndex].selectSingleNode('RecCnt').text;

                if (count == "0")
                    count = "&nbsp;";
                $("#divAlergy").append('<span style=border class="' + xmlNodeList[intIndex].selectSingleNode('ImageName').text + '" title="' + xmlNodeList[intIndex].selectSingleNode('RecCnt').text + '"></span>')
            }
        }
    }



}

$(document).ready(function () {

    var strBannerAddress = ""
    //$("#hdnBannerAddress").val().replace(/&gt;/g, ">").replace(/&lt;/g, "<");
    var strBannerMobile = ""
    //$("#hdnBannerMobile").val().replace(/&gt;/g, ">").replace(/&lt;/g, "<");
    strEntityType = $("#hdnEntityType").val()
    strBannerAllergy = $("#hdnBannerAllergy").val().replace(/&gt;/g, ">").replace(/&lt;/g, "<");
    strBannerAllergy = strBannerAllergy.replace(/\n/g, "<br/>")
    //m_mdiWindow.PatientBanner.Display("<i>Address</i></br><b title='" + strBannerAddress.replace(/<br\/>/g, '\n') + "'>" + strBannerAddress + "</b>", "<i>Contact Info</i><br/><b title='" + strBannerMobile.replace(/<br\/>/g, '\n') + "'>" + strBannerMobile + "</b>", "<i>Allergies, ADR and Others</i><br/><div style='overflow:auto;height:120px'><b title=\"" + strBannerAllergy.replace(/<br\/>/g, '\n').replace(/"/g,"\"") + "\">" + strBannerAllergy + "</b><div>", strClinicianHTML, strSystemHTML);
    $("#zone_Facility").click(function () {
        m_mdiWindow.PatientBanner.Toggle();
    });
    $("#zone2").click(function () {
        m_mdiWindow.PatientBanner.Toggle();
    });
    if (strEntityType != 2936) {
        if (strBannerAllergy == undefined || strBannerAllergy == "") {
            $("#patient_banner  span[axid='patdet']").css("width", "");
            $("#zoneAlergy").css("display", "none")
        } else {
            //  $("#divAlergy").remove();
            $("#zoneAlergy").css("display", "")
            if ($("#hdnBannerAllergy").val() != "") {
                $("#patient_banner  span[axid='patdet']").css("width", "75%");
                $("#secondaryid").css({ "overflow": "hidden", "text-overflow": "ellipsis", "width": "9%", "position": "fixed" });



                UpdateAlertInfo($("#hdnBannerAllergy").val())

                /* var xmlDOM = fnLoadXML($("#hdnBannerAllergy").val());
                 $("#zoneAlergy").append('<div id="divAlergy" style ="width:auto; height:auto;display: inline;"></div>');
                     var xmlNodeList = xmlDOM.getElementsByTagName("AllergyInfo")
                for (intIndex = 0; intIndex < xmlNodeList.length; intIndex++) {
                    var count =xmlNodeList[intIndex].selectSingleNode('RecCnt').text;
                  
                    if (count == "0")
                        count = "&nbsp;";
                    $("#divAlergy").append('&nbsp;<span style=border class="' + xmlNodeList[intIndex].selectSingleNode('ImageName').text + '" title="' + xmlNodeList[intIndex].selectSingleNode('RecCnt').text + '"></span>')
                }*/
            }
        }

    }

});

function showflyout(src, type, blnhide) {
    type = (type == 1) ? "west" : "east";
    if (blnhide == true) {
        parent.parent.frames["fraContent"].fnShowHidePane(type, "hide", true);
    }
    else {
        //if (this.frames["fraContent"].$("#l1_east").css("display") == "none")
        parent.parent.frames["fraContent"].fnShowHidePane(type, "show", true);
    }
}

function GetTquestURL(m_intUserId, strPatientID, blnCheckLocation) {
    try {
        objJsonData = { "iud": m_intUserId, "spd": strPatientID, "bcl": blnCheckLocation }
        return fnEncryptData(objJsonData)
    } catch (e) { }
}

function fnGetPatientZone1AlertIconInfo(m_usrRstLevel, m_strAppType, m_IsACLPatient) {
    try {
        objJsonData = { "usl": m_usrRstLevel, "sat": m_strAppType, "acl": m_IsACLPatient }
        return fnEncryptData(objJsonData)

    } catch (e) { }
}

function fnLogwebsession(strModuleName, intPatientID, intActionID, strDecription, intModuleID) {
    try {
        objJsonData = { "strModuleName": strModuleName, "intPatientID": intPatientID, "intActionID": intActionID, "strDecription": strDecription, "intModuleID": intModuleID }
        return fnEncryptData(objJsonData)

    } catch (e) { }
}

function fnEncryptData(strJsonData) {
    try {
        if (strJsonData != "") {
            strJsonData = JSON.stringify(strJsonData)
            return $ec.fn.et(strJsonData)
        } else {
            return null
        }
    } catch (e) { }
}