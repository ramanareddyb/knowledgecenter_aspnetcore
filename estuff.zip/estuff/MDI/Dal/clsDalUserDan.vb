Option Explicit On 
Imports Excelicare.Framework.AppDataSupport  ' To access sql helper functions
Imports Excelicare.Framework.AppSupport ' To access exception handling functionality
Imports System.Data
Imports System.Data.SqlClient
Namespace Excelicare.Dal.MDI
    '*******************************************************************************************
    'Class Name : clsDalUserDan
    'PURPOSE    : Exposes user information to bizl 
    '
    'MODIFICATION LOG  :
    '
    'AUTHOR                      Ver#       Date        Reason/Changes
    '-------------------------------------------------------------------------------------------
    'Nagodaya Bhaskar KR.      1.0.000    25/05/2004    First version.
    '*******************************************************************************************
    Public Class clsDalUserDan
        Implements IDisposable

        Public Overloads Sub Dispose() Implements IDisposable.Dispose           'Added by mani pratap to destroy the unused objects 
            GC.SuppressFinalize(Me)
        End Sub
        '****************************************************************************************
        'Sub/Function/Property Name : GetUserDetails
        'Parameters   : int64USR_ID,strCommaDelimitedColumns
        'Return Values: DataSet
        'Purpose      : This function is used to get user details
        '
        'Other relevant sources: 
        '     
        'Author            : Nagodaya Bhaskar KR
        'Created Date      : 25/05/2004
        'Last Modified Date: None
        'Modification Log  :
        'Author                 Date           Reason
        '----------------------------------------------------------------------------------------
        '****************************************************************************************
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This function is used to get user details
        ' </summary>
        ' <param name="int64USR_ID"> user id </param>
        ' <param name="strCommaDelimitedColumns"> CommaDelimitedColumns </param>
        ' <returns></returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Nagodaya Bhaskar KR]   25/05/2004   Created 
        ' 	    [srinivas k]	        16/06/2005	 Comments added
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function GetUserDetails(ByVal int64USR_ID As Int64, ByVal strCommaDelimitedColumns As String) As DataSet
            Dim objClsDataAccess As clsDataAccess
            Dim strQuery As String
            Try
                objClsDataAccess = New clsDataAccess
                strQuery = "Select " & strCommaDelimitedColumns & " from tblUser Where USR_ID = " & int64USR_ID & " and IsActive=1" & _
                            "; Select ID,Name,LookupValue from tblSyslookup where id=500 "
                Return (objClsDataAccess.ExecuteDataSet(strQuery, CommandType.Text))
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strQuery = Nothing
            End Try
        End Function
        Public Function getPatIdentifierValue(ByVal lngPatId As Long) As String
            Dim objClsDataAccess As clsDataAccess
            Dim strQuery As String
            Try
                objClsDataAccess = New clsDataAccess
                strQuery = "select Value from tblpatientidentifier where identifier_lu = 5328 and pat_id = " & lngPatId
                Return objClsDataAccess.ExecuteScalar(strQuery, CommandType.Text)

            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strQuery = Nothing
            End Try
        End Function
        '****************************************************************************************
        'Sub/Function/Property Name : CanMakeQueueRedForTheLoggedInUser
        'Parameters   : int64USR_ID
        'Return Values: Boolean
        'Purpose      : This function returns a boolean vale and is used to make the Queue red or white
        '
        'Other relevant sources: 
        '     
        'Author            : Suneetha B
        'Created Date      : 27.05.2005
        'Last Modified Date: None
        'Modification Log  :
        'Author                 Date           Reason
        '----------------------------------------------------------------------------------------
        '****************************************************************************************

        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This function returns a boolean vale and is used to make the Queue red or white
        ' </summary>
        ' <param name="int64UsrId"> user id </param>
        ' <returns></returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]    27/05/2005  Created
        ' 	    [srinivas k]	16/06/2005	Comments added
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function CanMakeQueueRedForTheLoggedInUser(ByVal int64UsrId As Int64) As Boolean
            Dim objDataAccess As clsDataAccess
            Dim strQuery As String = ""
            'Dim drQueue As System.Data.IDataReader
            Dim intcount As Int64 = 0
            Try
                objDataAccess = New clsDataAccess
                strQuery = " SELECT  COUNT(Signer_CLN_ID) FROM tblSignoffQueue  WHERE   Signer_CLN_ID = " & int64UsrId & "AND TableName = 'TBLALERT'  " & _
                "UNION  SELECT  COUNT(Signer_CLN_ID) FROM tblSignoffQueue  WHERE  (msgType <> 1  OR msgType Is Null ) " & _
                "AND  Signer_CLN_ID = 0 AND TableName <> 'TBLALERT' " & _
                "UNION  SELECT COUNT(Sig1_User_ID) FROM tblScript WHERE IsSignedOff = 0 AND (IsActive = 1  OR IsActive = 2) " & _
                "AND  Sig1_User_ID = " & int64UsrId
                intcount = objDataAccess.ExecuteScalar(strQuery, CommandType.Text)
                'Dim count As Integer = 0
                'While drQueue.Read()
                '    If Not IsDBNull(drQueue.Item(0)) Then
                '        count = count + CInt(drQueue.Item(0))
                '    End If
                'End While
                If intcount > 0 Then
                    Return True
                Else
                    Return False
                End If
            Catch ex As Exception
                Throw
            Finally
                objDataAccess = Nothing
                strQuery = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       Used to  Select The Items from tblMyFavourites
        ' </summary>
        ' <param name="intUsr_Id"> user id </param>
        ' <returns></returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Srinivas k]    13/06/2005  Created
        ' 	    [Srinivas K]	15/06/2005	Added Comments
        '       [Suneetha B]    28/06/2005  Modified to return a boolean value whether the supplied user has any favourites attached
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function HasMyFavourites(ByVal intUsr_Id As Integer) As Boolean
            Dim strSQL As String = String.Empty
            Dim objClsDataAccess As clsDataAccess
            Try
                objClsDataAccess = New clsDataAccess
                strSQL = "Select Count(FormName) From tblMyFavourites Where Usr_ID = " & intUsr_Id
                If objClsDataAccess.ExecuteScalar(strSQL, CommandType.Text) > 0 Then
                    Return True
                Else
                    Return False
                End If
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strSQL = Nothing
            End Try
        End Function

        ' -----------------------------------------------------------------------------
        ' <summary>
        '       whether to show the Q as the start up form or not for the given user ID
        ' </summary>
        ' <param name="intUsr_Id"> user id </param>
        ' <returns>Boolean</returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]    26/08/2005  Created
        ' 	    [Suneetha B]	26/08/2005	Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function ShowQAsStartUpForm(ByVal intUsr_Id As Integer) As Boolean
            Dim strSQL As String = String.Empty
            Dim objClsDataAccess As clsDataAccess
            Try
                objClsDataAccess = New clsDataAccess
                strSQL = "select isnull(StartUpReminder,0) as StartUpReminder  from tbluser  Where Usr_ID = " & intUsr_Id
                Return CBool(objClsDataAccess.ExecuteScalar(strSQL, CommandType.Text))
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strSQL = Nothing
            End Try
        End Function


        '************************************************************************************************
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This  function is used to find whether the logged in user is a privileged to view the Key word search button 
        ' </summary>
        ' <param name="intUser_ID"> user id </param>
        ' <returns> Boolean </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '   [Suneetha B]    30/09/2005    Created
        ' 	[Suneetha B]	30/09/2005	  Comments added
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function IsUserPrivilegedToViewKeyWordSearch(ByVal intUser_ID As Int32) As Boolean
            Dim objClsDataAccess As clsDataAccess
            Dim valid As Boolean = False
            Dim strQuery As String = ""
            Dim strResult As String = ""
            Try
                objClsDataAccess = New clsDataAccess
                strQuery = "select privilegedforms from tblUser where usr_id = " & intUser_ID
                strResult = objClsDataAccess.ExecuteScalar(strQuery, CommandType.Text)
                If Not IsDBNull(strResult) Then
                    If strResult <> "" Then
                        If Len(strResult) >= 18 Then
                            If strResult.Substring(17, 1) = "1" Then ''if the character at 18th position is 1 then only key word search button is shown in the toolbar to the user
                                valid = True
                            End If
                        End If
                    End If
                End If

                Return valid

            Catch ex As Exception
                Throw ex
            Finally
                objClsDataAccess = Nothing
                strQuery = Nothing
                strResult = Nothing
            End Try
        End Function


        ' -----------------------------------------------------------------------------
        ' <summary>
        '       whether to show the Start up object  based on user preferences
        ' </summary>
        ' <param name="intUsr_Id"> user id </param>
        ' <returns>Boolean</returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]    15/11/2005  Created
        ' 	    [Suneetha B]	15/11/2005 	Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function ShowStartUpObject(ByVal intUsr_Id As Integer) As Integer
            Dim strSQL As String = String.Empty
            Dim objClsDataAccess As clsDataAccess
            Try
                objClsDataAccess = New clsDataAccess
                strSQL = "select isnull(StartUpObject,-1) as StartUpObject  from tbluser  Where Usr_ID= " & intUsr_Id
                Return objClsDataAccess.ExecuteScalar(strSQL, CommandType.Text)
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strSQL = Nothing
            End Try
        End Function


        ' -----------------------------------------------------------------------------
        ' <summary>
        '      This is used to delete the temporary session data of patient reg 
        ' </summary>
        ' <param name="intUsr_Id"> user id </param>
        ' <param name="strSessionID"> Session ID </param>
        ' <returns>Boolean</returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]    12/12/2005  Created
        ' 	    [Suneetha B]	12/12/2005 	Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------


        Public Function DeleteTempPatientRegistrationData(ByVal intUserID As Integer, ByVal strSessionID As String) As Boolean
            Dim strQuery As String = ""
            Dim objClsDataAccess As clsDataAccess
            Try
                strQuery = "DELETE FROM tblSessTempData  WHERE UserID = " & intUserID & "  AND SessionID = '" & strSessionID & "'"
                objClsDataAccess = New clsDataAccess
                objClsDataAccess.ExecuteNonQuery(strQuery, CommandType.Text)
                DeleteTempPatientRegistrationData = True
            Catch ex As Exception
                DeleteTempPatientRegistrationData = False
                Throw
            Finally
                objClsDataAccess = Nothing
                strQuery = Nothing
            End Try
            Return DeleteTempPatientRegistrationData
        End Function


        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This is used to get the user restriction level for the selected patient
        ' </summary>
        '<param Name="intUserID">holds user ID</param>
        '<param Name="intPAT_ID">holds Patient ID</param>
        '<param Name="IntuserRestrictionLevel">holds user restriction level on the current selected patient</param>
        '<returns>returns an integer value</returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]  14.03.2006    Created
        '       [Suneetha B]  14.03.2006	Comments Added
        ' </history>
        ' ----------------------------------------------------------------------------
        Public Function GetPatRestrictionLevel(ByVal intUserID As Integer, ByVal intPAT_ID As Integer, ByVal IntRestrictionLevel As Integer) As Integer
            Dim strQuery As String = ""
            Dim objDataAccess As clsDataAccess
            Dim objAppSupport As Excelicare.Framework.AppSupport.clsAppSettings
            GetPatRestrictionLevel = 0
            Try

                objDataAccess = New clsDataAccess
                objAppSupport = New clsAppSettings
                strQuery = "SELECT COUNT(USR_ID) FROM DBO.AxFn_IsACLUser (" & intPAT_ID & "," & intUserID & ")"
                If objDataAccess.ExecuteScalar(strQuery, CommandType.Text) = 0 Then
                    GetPatRestrictionLevel = IntRestrictionLevel
                End If
            Catch ex As Exception
                Throw
            Finally
                objDataAccess = Nothing
                objAppSupport = Nothing
                strQuery = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '      This is used to add the suppiled module ID , for supplied user as a My Favourite
        ' </summary>
        ' <param name="intUsr_Id"> user id </param>
        ' <param name="intModuleID"> Module ID </param>
        ' <param name="strFormName"> Form Name </param>
        ' <param name="strFormType"> Form Type </param>
        ' <returns>Integer</returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]    03/03/2006  Created
        ' 	    [Suneetha B]	03/03/2006 	Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function AddToMyFavourites(ByVal intUserID As Integer, ByVal intModuleID As Integer, ByVal strFormName As String, ByVal strFormType As String) As Integer
            '' Dim strQuery As String = "" string is replaced with string builder for performance
            Dim sbQuery As New System.Text.StringBuilder()
            Dim objClsDataAccess As clsDataAccess
            Dim intRowsAfftected As Integer = -1
            Try
                ''strQuery = "IF NOT  EXISTS( SELECT  FORMID FROM tblMyFavourites WHERE USR_id = " & intUserID & " AND FORMID = " & intModuleID & " ) BEGIN INSERT INTO tblMyFavourites(USR_ID,FORMID,FORMLIBID,FORMNAME,FORMTYPE,ADDED_USER_ID,ISPROTECTED) VALUES (" & intUserID & "," & intModuleID & ",NULL,'" & strFormName & "','" & strFormType & "'," & intUserID & ", 1) END"
                sbQuery.Append("IF NOT  EXISTS( SELECT  FORMID FROM tblMyFavourites WHERE USR_id = " & intUserID & " AND FORMID = " & intModuleID & " ) BEGIN INSERT INTO tblMyFavourites(USR_ID,FORMID,FORMLIBID,FORMNAME,FORMTYPE,ADDED_USER_ID,ISPROTECTED) VALUES (" & intUserID & "," & intModuleID & ",NULL,'" & strFormName & "','" & strFormType & "'," & intUserID & ", 1) END")
                objClsDataAccess = New clsDataAccess
                intRowsAfftected = objClsDataAccess.ExecuteNonQuery(sbQuery.ToString, CommandType.Text)
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                ''strQuery = Nothing
                sbQuery = Nothing
            End Try
            Return intRowsAfftected
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '      This is used to find the given ModuleID is added to a paticular user or not
        ' </summary>
        ' <param name="intUserID"> user id </param>
        ' <param name="intModuleID"> Module ID </param>
        ' <param name="strFormType"> Form Type </param>
        ' <param name="intFIBID"> Form Lib Item ID </param>
        ' <returns>Boolean</returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]    03/03/2006  Created
        ' 	    [Suneetha B]	03/03/2006 	Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function IsModuleAddedToMyFavourites(ByVal intUserID As Integer, ByVal intModuleID As Integer, ByVal strFormType As String, Optional ByVal intFIBID As Integer = 0) As Boolean
            ''Dim strQuery As String = "" string is replaced with string builder for performance
            Dim sbQuery As New System.Text.StringBuilder()
            Dim intCount As Integer = 0
            Dim objClsDataAccess As clsDataAccess
            Try
                If intFIBID < 1 Then
                    ''strQuery = " SELECT  COUNT(FORMID) as MyFavCount  FROM tblMyFavourites WHERE USR_id = " & intUserID & " AND FORMID = " & intModuleID & " AND FORMLIBID IS NULL  AND FORMTYPE Like '" & strFormType & "'"
                    sbQuery.Append(" SELECT  COUNT(FORMID) as MyFavCount  FROM tblMyFavourites WHERE USR_id = " & intUserID & " AND FORMID = " & intModuleID & " AND FORMLIBID IS NULL  AND FORMTYPE Like '" & strFormType & "'")

                    ''strQuery = " SELECT  COUNT(FORMID) as MyFavCount  FROM tblMyFavourites WHERE USR_id = " & intUserID & " AND FORMID = " & intModuleID & " AND FORMLIBID = " & intFIBID & "  AND FORMTYPE Like '" & strFormType & "'"
                    sbQuery.Append(" SELECT  COUNT(FORMID) as MyFavCount  FROM tblMyFavourites WHERE USR_id = " & intUserID & " AND FORMID = " & intModuleID & " AND FORMLIBID = " & intFIBID & "  AND FORMTYPE Like '" & strFormType & "'")
                End If
                ''strQuery = " SELECT  COUNT(FORMID) as MyFavCount  FROM tblMyFavourites WHERE USR_id = " & intUserID & " AND FORMID = " & intModuleID & " AND FORMLIBID = " & intFIBID & "  AND FORMTYPE Like '" & strFormType & "'"

                objClsDataAccess = New clsDataAccess
                intCount = objClsDataAccess.ExecuteScalar(sbQuery.ToString, CommandType.Text)
                If intCount > 0 Then
                    Return (True)
                ElseIf intCount = 0 Then
                    Return False
                End If
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                ''strQuery = Nothing
                sbQuery = Nothing
            End Try
        End Function
        Public Function GetUserValues(ByVal lngUserId As Long) As DataSet
            Dim sbSql As New System.Text.StringBuilder(5000)
            Dim objClsDataAccess As clsDataAccess
            Try
                objClsDataAccess = New clsDataAccess
                sbSql.Append("SELECT USR.USR_ID, USR.USR_SECURITY_LEVEL, USR.USR_IDENTIFIER_LU, USR.IDENTIFIERTYPE AS USR_IDENTIFIER, ")
                '  sbSql.Append("ISNULL(SYSL.LOOKUPVALUE,'') AS USR_PREFIDENCAPTION, 
                sbSql.Append("ISNULL(ACLS.RESTRICTIONLEVEL,0) AS RESTRICTIONLEVEL , CASE WHEN USR.ISACLMANAGER=1 THEN USR.ISACLMANAGER  ELSE USR.ALLPATIENTACCESS ")
                sbSql.Append("END AS ACLSUPERUSER, USR.ISACLMANAGER, USR.PrivilegedForms, USR.ShowInActiveRecords AS SHOWINACTIVERECORDS FROM TBLUSER AS USR ")
                'sbSql.Append(" LEFT JOIN TBLSYSLOOKUP AS SYSL ON USR.USR_IDENTIFIER_LU = SYSL.ID  AND USR.IDENTIFIERTYPE = 0")
                'sbSql.Append(" LEFT JOIN TBLLOOKUP AS LL ON USR.USR_IDENTIFIER_LU = LL.ID  AND USR.IDENTIFIERTYPE = 1")
                sbSql.Append(" LEFT JOIN TBLACLSTAFF AS ACLS ON USR.USR_ID = ACLS.USR_ID  AND ACLS.ACLGROUP_ID=1")
                sbSql.Append(" WHERE USR.USR_ID=")
                sbSql.Append(lngUserId)
                sbSql.Append(";SELECT A.ID, A.VALUE AS IDENTIFIER_LU, CASE WHEN C.LOOKUPCATEGORY_SLU=178 THEN 1 ELSE 0 END AS IDENTIFIERTYPE")
                sbSql.Append(",CASE WHEN C.LOOKUPCATEGORY_SLU=178 THEN C.LOOKUPVALUE ELSE B.LOOKUPVALUE END AS IDENTIFIERCAPTION ")
                sbSql.Append("FROM TBLSYSDEFAULT A ")
                sbSql.Append("LEFT JOIN TBLSYSLOOKUP B ON B.ID=A.VALUE AND B.NAME = 'PI' ")
                sbSql.Append("LEFT JOIN TBLLOOKUP C ON C.ID=A.VALUE AND C.LOOKUPCATEGORY_SLU=178 ")
                sbSql.Append("WHERE A.ID IN (30,41,46) ")
                sbSql.Append(";DECLARE @iCnt INT ")
                sbSql.Append("SELECT @iCnt=COUNT(ID) FROM tblUserFunction WHERE SysECFunction_ID=104 AND isActive=0 AND USER_ID=" & lngUserId & " ")
                sbSql.Append("IF (@iCnt > 0) ")
                sbSql.Append("BEGIN ")
                sbSql.Append("SELECT 0 AS CanPrint ")
                sbSql.Append("END ")
                sbSql.Append("ELSE ")
                sbSql.Append("BEGIN ")
                sbSql.Append("SET @iCnt=0 ")
                sbSql.Append("SELECT @iCnt=COUNT(ID) FROM tblUserFunction WHERE SysECFunction_ID=104 AND isActive=1 AND USER_ID=" & lngUserId & " ")
                sbSql.Append("IF (@iCnt > 0) ")
                sbSql.Append("BEGIN ")
                sbSql.Append("SELECT 1 AS CanPrint ")
                sbSql.Append("END ")
                sbSql.Append("ELSE ")
                sbSql.Append("BEGIN ")
                sbSql.Append("SELECT COUNT(ID) AS CanPrint FROM tblUserCapability WHERE Capability_ID IN (SELECT Capability_ID  FROM tblCapabilityDetail WHERE SysECFunction_ID=104 AND IsActive=1) AND ")
                sbSql.Append("User_ID=")
                sbSql.Append(lngUserId & " END ")
                sbSql.Append("END ")
                Return objClsDataAccess.ExecuteDataSet(sbSql.ToString, CommandType.Text)
            Catch ex As Exception
                Throw ex
            Finally
                objClsDataAccess = Nothing
                sbSql = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       To get the Startup form for user preferences / System preference
        ' </summary>
        ' <param name="intUsr_Id"> user id </param>
        ' <returns>Boolean</returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Vanisri]    28/11/2006  Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function GetPatientRecordStartUpForm(ByVal intUsr_Id As Integer) As String
            ''Dim strSQL As String string is replaced with string builder for performance
            Dim sbSQL As New System.Text.StringBuilder
            Dim objClsDataAccess As clsDataAccess
            Dim strSystemPref As String = ""
            Dim strUserPref As String = ""

            Try
                objClsDataAccess = New clsDataAccess
                ''strSQL = "SELECT ISNUll(PatientRecordStartUpForm,'') AS PatientRecordStartUpForm FROM tblUser  WHERE USR_ID  = " & intUsr_Id
                sbSQL.Append("SELECT ISNUll(PatientRecordStartUpForm,'') AS PatientRecordStartUpForm FROM tblUser  WHERE USR_ID  = " & intUsr_Id)
                strUserPref = objClsDataAccess.ExecuteScalar(sbSQL.ToString, CommandType.Text).ToString.Trim
                If strUserPref <> "" And strUserPref <> "0" And strUserPref <> "-1" Then
                    Return strUserPref
                Else '' getiing the system start up 
                    ''strSQL = " select ISNULL(value,'') as Value from tblsysdefault where id = 1329 "
                    sbSQL.Append(" select ISNULL(value,'') as Value from tblsysdefault where id = 1329 ")
                    strSystemPref = objClsDataAccess.ExecuteScalar(sbSQL.ToString, CommandType.Text).ToString.Trim
                    If strSystemPref <> "" Then
                        If strSystemPref.IndexOf(Chr(17)) <> -1 Then
                            If strSystemPref.Substring(0, 1) = "1" Then
                                strSystemPref = "129" & Chr(17) & strSystemPref.Split(Chr(17))(1)
                            Else
                                strSystemPref = strSystemPref.Split(Chr(17))(1)
                            End If
                        End If
                    End If
                End If
                Return strSystemPref
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                ''strSQL = Nothing
                sbSQL = Nothing
                strSystemPref = Nothing
                strUserPref = Nothing
            End Try
        End Function

        ' -----------------------------------------------------------------------------
        ' <summary>
        '       To get the fully qualified Url of the supplied module ID
        ' </summary>
        ' <param name="intModuleId"> Module Id </param>
        ' <returns>Boolean</returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Vanisri]    28/11/2006  Created
        ' </history>
        ' -----------------------------------------------------------------------------

        Public Function GetPatientRecordStartUpFormUrl(ByVal intModuleId As Integer) As String
            ''Dim strSQL As String = String.Empty string is replaced with string builder for performance
            Dim sbSQL As New System.Text.StringBuilder
            Dim objClsDataAccess As clsDataAccess
            Try
                objClsDataAccess = New clsDataAccess
                ''strSQL = "SELECT CASE  WHEN TargetUrl IS null THEN '' ELSE ISNULL(DomainName,'') + TargetUrl   END AS TargetUrl FROM tblSysModule WHERE ID = " & intModuleId
                sbSQL.Append("SELECT CASE  WHEN TargetUrl IS null THEN '' ELSE ISNULL(DomainName,'') + TargetUrl   END AS TargetUrl FROM tblSysModule WHERE ID = " & intModuleId)
                Return objClsDataAccess.ExecuteScalar(sbSQL.ToString, CommandType.Text).ToString.Trim
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                '' strSQL = Nothing
                sbSQL = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       To get the lookupvalue for the given lookup id
        ' </summary>
        ' <param name="lngLookupId"> Lookup Id </param>
        ' <returns>String</returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [B.N.Jagadeesh]    25/06/2007  Created
        '       [B.N.Jagadeesh]    02/07/2007  Checking return object for nothing
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function GetSysLookupValue(ByVal lngLookupId As Long) As String
            '' Dim strSQL As String = String.Empty string is replaced with string builder for performance
            Dim sbSQL As New System.Text.StringBuilder
            Dim objClsDataAccess As clsDataAccess
            Dim objReturn As Object
            ''Dim strLookupValue As String
            Dim sbLookupValue As New System.Text.StringBuilder
            Try
                ''strLookupValue = ""
                sbLookupValue.Append("")
                objClsDataAccess = New clsDataAccess
                ''strSQL = "SELECT LookupValue FROM tblSysLookup WHERE ID = " & lngLookupId
                sbSQL.Append("SELECT LookupValue FROM tblSysLookup WHERE ID = " & lngLookupId)
                objReturn = objClsDataAccess.ExecuteScalar(sbSQL.ToString, CommandType.Text)
                If Not objReturn Is Nothing Then
                    ''strLookupValue = objReturn.ToString
                    sbLookupValue.Append(objReturn.ToString)
                End If
                ''Return strLookupValue
                Return sbLookupValue.ToString
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                '' strSQL = Nothing
                sbSQL = Nothing
                objReturn = Nothing
                sbLookupValue = Nothing
            End Try
        End Function




        ' Added on 07-Dec-2011

        ' -----------------------------------------------------------------------------------------------
        ' <summary>
        '       This get the User Prescribing Role
        ' </summary>
        ' <remarks>
        '       First version.
        ' </remarks>
        ' <history>
        '      [N.Sujith Kumar]      05/05/2011  Created
        ' </history>
        ' -----------------------------------------------------------------------------------------------
        Public Function GetUserPrescribingRole(ByVal UserID As Long, ByVal intUserLocId As Integer) As String
            Dim objDataAcess As clsDataAccess
            Dim psValues(1) As ParamStruct
            Dim strPrescriptionRole As String
            Dim strePrescRetXML As String = ""

            Try
                psValues(0).DataType = DbType.Int64
                psValues(0).direction = ParameterDirection.Input
                psValues(0).ParamName = "@UserID"
                psValues(0).value = UserID
                psValues(1).DataType = DbType.Int64
                psValues(1).direction = ParameterDirection.Input
                psValues(1).ParamName = "@intUserLocId"
                psValues(1).value = intUserLocId
                'Dim arrParamStruct() As ParamStruct
                'arrParamStruct = New ParamStruct(0) {}
                'arrParamStruct(0).direction = ParameterDirection.Input
                'arrParamStruct(0).ParamName = "@UserID"
                'arrParamStruct(0).DataType = DbType.Int64
                'arrParamStruct(0).sourceColumn = "UserID"
                'arrParamStruct(0).value = UserID


                objDataAcess = New clsDataAccess
                strPrescriptionRole = objDataAcess.ExecuteScalar("AxSP_GetUserPrescribingRole", CommandType.StoredProcedure, psValues)
                strePrescRetXML = "<ePresc><Role>" & strPrescriptionRole.Split("|")(0) & "</Role><eRxAccountLocationID>" & strPrescriptionRole.Split("|")(1) & "</eRxAccountLocationID><eRxClnID>" & strPrescriptionRole.Split("|")(2) & "</eRxClnID><AccountName>" & strPrescriptionRole.Split("|")(3) & "</AccountName><LocationName>" & strPrescriptionRole.Split("|")(4) & "</LocationName><ProviderName>" & strPrescriptionRole.Split("|")(5) & "</ProviderName><eRxUsrId>" & strPrescriptionRole.Split("|")(6) & "</eRxUsrId></ePresc>"
                Return strePrescRetXML

            Catch ex As Exception
                Throw ex
            Finally
                objDataAcess = Nothing
                psValues = Nothing
                strPrescriptionRole = Nothing
                strePrescRetXML = Nothing
            End Try
        End Function

        ' -----------------------------------------------------------------------------------------------
        ' <summary>
        '       This get the User's ACL Restriction Level
        ' </summary>
        ' <remarks>
        '       First version.
        ' </remarks>
        ' <history>
        '      [Pradeep Kumar]      09/03/2010  Created
        ' </history>
        ' -----------------------------------------------------------------------------------------------
        Public Function GetUserACLLevel(ByVal intUserID As Long, ByVal intPatientId As Integer) As Integer
            Dim objDataAcess As clsDataAccess
            Dim arrParamStruct() As ParamStruct
            Dim intRestrictionLevel As Integer
            Try
                arrParamStruct = New ParamStruct(1) {}
                arrParamStruct(0).direction = ParameterDirection.Input
                arrParamStruct(0).ParamName = "@UserID"
                arrParamStruct(0).DataType = DbType.Int64
                arrParamStruct(0).sourceColumn = "UserID"
                arrParamStruct(0).value = intUserID

                arrParamStruct(1).direction = ParameterDirection.Input
                arrParamStruct(1).ParamName = "@PatientID"
                arrParamStruct(1).DataType = DbType.Int64
                arrParamStruct(1).sourceColumn = "PatientID"
                arrParamStruct(1).value = intPatientId

                objDataAcess = New clsDataAccess
                intRestrictionLevel = objDataAcess.ExecuteScalar("AxSP_GetUserACLLevel", CommandType.StoredProcedure, arrParamStruct)

                Return intRestrictionLevel

            Catch ex As Exception
                Throw ex

            Finally
                objDataAcess = Nothing
                arrParamStruct = Nothing
            End Try
        End Function
        Public Function GetSunQuestICELab(ByVal intUserID As Integer, ByVal lngPatiendID As Integer, Optional ByVal blnCheckLocation As Boolean = False) As DataSet
            Dim objClsDataAccess As clsDataAccess
            Dim arrParams(2) As ParamStruct
            Try
                arrParams(0).ParamName = "@intUserId"
                arrParams(0).direction = ParameterDirection.Input
                arrParams(0).DataType = DbType.Int32
                arrParams(0).value = intUserID

                arrParams(1).ParamName = "@intPatId"
                arrParams(1).direction = ParameterDirection.Input
                arrParams(1).DataType = DbType.Int32
                arrParams(1).value = lngPatiendID

                arrParams(2).ParamName = "@blnCheckLocation"
                arrParams(2).direction = ParameterDirection.Input
                arrParams(2).DataType = DbType.Boolean
                arrParams(2).value = blnCheckLocation

                'arrParams(3).ParamName = "@intResult"
                'arrParams(3).direction = ParameterDirection.Output
                'arrParams(3).DataType = DbType.Int32
                'arrParams(3).value = DBNull.Value

                objClsDataAccess = New clsDataAccess
                Return objClsDataAccess.ExecuteDataSet("AxSP_SQ_GetExtLabPatientDetails", CommandType.StoredProcedure, arrParams)
            Catch ex As Exception
                Throw ex
            Finally
                objClsDataAccess = Nothing
                arrParams = Nothing
            End Try
        End Function
        Public Function fnSavePrintLogDetails(ByVal lngPatientId As Long, ByVal intItemID As Int64, ByVal lngModuleID As Long, ByVal strItemtype As String, ByVal strPrinterName As String, ByVal lngUserID As Long, ByVal strDatePrinted As DateTime, ByVal lndCustomFormID As Long, ByVal strPrintPreviewDate As DateTime, ByVal blnPrintStatus As Boolean) As Integer
            Dim objClsDataAccess As clsDataAccess
            Dim psValues(10) As ParamStruct

            Try
                objClsDataAccess = New clsDataAccess

                psValues(0).DataType = DbType.Int64
                psValues(0).direction = ParameterDirection.Input
                psValues(0).ParamName = "@ID"
                psValues(0).value = intItemID

                psValues(1).DataType = DbType.Int64
                psValues(1).direction = ParameterDirection.Input
                psValues(1).ParamName = "@ItemType"
                psValues(1).value = lngModuleID

                psValues(2).DataType = DbType.String
                psValues(2).direction = ParameterDirection.Input
                psValues(2).ParamName = "@ItemName"
                psValues(2).value = strItemtype

                psValues(3).DataType = DbType.String
                psValues(3).direction = ParameterDirection.Input
                psValues(3).ParamName = "@PrinterName"
                psValues(3).value = strPrinterName

                psValues(4).DataType = DbType.Int64
                psValues(4).direction = ParameterDirection.Input
                psValues(4).ParamName = "@UserID"
                psValues(4).value = lngUserID

                psValues(5).DataType = DbType.DateTime
                psValues(5).direction = ParameterDirection.Input
                psValues(5).ParamName = "@DatePrinted"
                psValues(5).value = strDatePrinted

                psValues(6).DataType = DbType.Int16
                psValues(6).direction = ParameterDirection.Output
                psValues(6).ParamName = "@RetId"


                psValues(7).DataType = DbType.Int64
                psValues(7).direction = ParameterDirection.Input
                psValues(7).ParamName = "@Patient_ID"
                If lngPatientId = 0 Then
                    psValues(7).value = DBNull.Value
                Else
                    psValues(7).value = lngPatientId
                End If

                psValues(8).DataType = DbType.DateTime
                psValues(8).direction = ParameterDirection.Input
                psValues(8).ParamName = "@DatePrintPreview"
                psValues(8).value = strPrintPreviewDate

                psValues(9).DataType = DbType.Int64
                psValues(9).direction = ParameterDirection.Input
                psValues(9).ParamName = "@CustformID"

                If lndCustomFormID = 0 Then
                    psValues(9).value = DBNull.Value
                Else
                    psValues(9).value = lndCustomFormID
                End If

                psValues(10).DataType = DbType.Boolean
                psValues(10).direction = ParameterDirection.Input
                psValues(10).ParamName = "@IsPrintSuccessful"
                psValues(10).value = blnPrintStatus

                Return objClsDataAccess.ExecuteNonQuery("AxSP_PRPrintLog", CommandType.StoredProcedure, psValues)

            Catch ex As Exception
                Throw
            Finally
                If Not IsNothing(psValues) Then
                    psValues = Nothing
                End If
                psValues = Nothing
                objClsDataAccess = Nothing
            End Try
        End Function

        Public Function getDataSet(ByVal lngFLID As Long) As DataSet
            'Dim objDs As DataSet
            Dim m_objClsDataAccess As Excelicare.Framework.AppDataSupport.clsDataAccess
            Try
                m_objClsDataAccess = New Excelicare.Framework.AppDataSupport.clsDataAccess
                Return m_objClsDataAccess.ExecuteDataSet("AxSp_GetSessionVariables", CommandType.StoredProcedure)
            Catch ex As Exception
                Throw
            Finally
                m_objClsDataAccess = Nothing
            End Try
        End Function

        Public Function GetExternalURLFLID(ByVal strExternalURLName As String) As String
            Dim strSQL As String = String.Empty
            Dim objClsDataAccess As clsDataAccess
            Dim objReturn As Object
            Dim lngExternalURLFLID As String
            Try
                objClsDataAccess = New clsDataAccess
                strSQL = "SELECT FormLibitem_id FROM tblFormLibParamURLExtension WHERE DisplayName like '%" & strExternalURLName & "%'"
                objReturn = objClsDataAccess.ExecuteScalar(strSQL, CommandType.Text)
                If Not objReturn Is Nothing Then
                    lngExternalURLFLID = objReturn
                End If
                Return lngExternalURLFLID
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strSQL = Nothing
                objReturn = Nothing
            End Try
        End Function

        Public Function GetTQuestICELab(ByVal intUserID As Integer, ByVal lngPatiendID As Integer, Optional ByVal blnCheckLocation As Boolean = False) As DataSet
            Dim objClsDataAccess As clsDataAccess
            Dim arrParams(2) As ParamStruct
            Try
                arrParams(0).ParamName = "@intUserId"
                arrParams(0).direction = ParameterDirection.Input
                arrParams(0).DataType = DbType.Int32
                arrParams(0).value = intUserID

                arrParams(1).ParamName = "@intPatId"
                arrParams(1).direction = ParameterDirection.Input
                arrParams(1).DataType = DbType.Int32
                arrParams(1).value = lngPatiendID

                arrParams(2).ParamName = "@blnCheckLocation"
                arrParams(2).direction = ParameterDirection.Input
                arrParams(2).DataType = DbType.Boolean
                arrParams(2).value = blnCheckLocation

                objClsDataAccess = New clsDataAccess
                Return objClsDataAccess.ExecuteDataSet("AxSP_SQ_GetExtLabPatientDetails", CommandType.StoredProcedure, arrParams)
            Catch ex As Exception
                Throw ex
            Finally
                objClsDataAccess = Nothing
                arrParams = Nothing
            End Try
        End Function
		Public Function GetUserDisclaimerStatus(ByVal intUserId As Integer) As String
            Dim m_objDataAccess As clsDataAccess
            Dim strResult As ArrayList
            Dim m_prmStructure() As ParamStruct
            Try
                m_objDataAccess = New clsDataAccess
                m_prmStructure = New ParamStruct(1) {}

                m_prmStructure(0).DataType = DbType.Int64
                m_prmStructure(0).ParamName = "@intUser_ID"
                m_prmStructure(0).direction = ParameterDirection.Input
                m_prmStructure(0).value = intUserId

                m_prmStructure(1).DataType = DbType.Int64
                m_prmStructure(1).ParamName = "@intDisclaimerMsgStatus"
                m_prmStructure(1).direction = ParameterDirection.Output
                m_prmStructure(1).value = String.Empty

                strResult = m_objDataAccess.ExecutePreparedSQL("AxSp_GetUserDisclaimerStatus", CommandType.StoredProcedure, m_prmStructure)
                Return strResult.Item(0)
            Catch ex As Exception

            End Try
        End Function

        Public Function SaveUserDisclaimer(ByVal intUserID As Integer, ByVal intDisclaimerStatus As Integer, ByVal strDisclaimerLU As String)
            Dim m_prmStructure() As ParamStruct
            Dim m_objDataAccess As clsDataAccess
            Try
                m_objDataAccess = New clsDataAccess
                m_prmStructure = New ParamStruct(2) {}
                With m_prmStructure(0)
                    .DataType = DbType.Int64
                    .direction = ParameterDirection.Input
                    .ParamName = "@intUser_ID"
                    .value = intUserID
                End With
                With m_prmStructure(1)
                    .DataType = DbType.Int64
                    .direction = ParameterDirection.Input
                    .ParamName = "@intDisclaimerStatus"
                    .value = intDisclaimerStatus
                End With

                With m_prmStructure(2)
                    .DataType = DbType.String
                    .direction = ParameterDirection.Input
                    .ParamName = "@strDisclaimerType_SLU"
                    .value = strDisclaimerLU
                End With

                m_objDataAccess.ExecutePreparedSQL("AxSp_SaveUserDisclaimer", CommandType.StoredProcedure, m_prmStructure)
                Return True
            Catch ex As Exception

            End Try
        End Function
        Public Sub SaveBrowserRequestLogs(sessionId As String, UserId As Integer, MachineName As String, MachineIP As String, strModule As String, Request As String, Version As String, HttpStatus As Integer, ExecuteAt As String)
            Dim objClsDataAccess As clsDataAccess
            Dim arrParams(8) As ParamStruct
            Try
                arrParams(0).ParamName = "@SessionID"
                arrParams(0).direction = ParameterDirection.Input
                arrParams(0).DataType = DbType.String
                arrParams(0).value = sessionId

                arrParams(1).ParamName = "@Usr_ID"
                arrParams(1).direction = ParameterDirection.Input
                arrParams(1).DataType = DbType.Int32
                arrParams(1).value = UserId

                arrParams(2).ParamName = "@MachineName"
                arrParams(2).direction = ParameterDirection.Input
                arrParams(2).DataType = DbType.String
                arrParams(2).value = MachineName

                arrParams(3).ParamName = "@MachineIP"
                arrParams(3).direction = ParameterDirection.Input
                arrParams(3).DataType = DbType.String
                arrParams(3).value = MachineIP

                arrParams(4).ParamName = "@Module"
                arrParams(4).direction = ParameterDirection.Input
                arrParams(4).DataType = DbType.String
                arrParams(4).value = strModule

                arrParams(5).ParamName = "@Request"
                arrParams(5).direction = ParameterDirection.Input
                arrParams(5).DataType = DbType.String
                arrParams(5).value = Request

                arrParams(6).ParamName = "@Version"
                arrParams(6).direction = ParameterDirection.Input
                arrParams(6).DataType = DbType.String
                arrParams(6).value = Version

                arrParams(7).ParamName = "@HttpStatus"
                arrParams(7).direction = ParameterDirection.Input
                arrParams(7).DataType = DbType.Int32
                arrParams(7).value = HttpStatus

                arrParams(8).ParamName = "@ExecutedAt"
                arrParams(8).direction = ParameterDirection.Input
                arrParams(8).DataType = DbType.String
                arrParams(8).value = ExecuteAt
                objClsDataAccess = New clsDataAccess


                objClsDataAccess.ExecuteDataSet("AxSP_Save_BrowserRequestLogs", CommandType.StoredProcedure, arrParams)
            Catch ex As Exception
                Throw ex
            Finally
                objClsDataAccess = Nothing
                arrParams = Nothing
            End Try
        End Sub
        Public Sub DeleteRequestLogs(sessionId As String)
            Dim objClsDataAccess As clsDataAccess
            Dim strSQL As String = String.Empty
            Try
                objClsDataAccess = New clsDataAccess
                strSQL = "Delete FROM tblECBRowserRequestLogs WHERE ID= '" & sessionId & "'"
                objClsDataAccess.ExecuteNonQuery(strSQL, CommandType.Text)
            Catch ex As Exception
                Throw ex
            Finally
                objClsDataAccess = Nothing
            End Try
        End Sub
        Public Function EndActiveSSOSessionsByUserID(ByVal lngUser_ID As Int64) As String
            Dim objClsDataAccess As clsDataAccess

            'Dim objClsEcSession As clsDalEcSessionDan
            'Dim dsActiveSessionIds As DataSet
            'Dim drActiveSessionIds As DataRow
            Dim strQuery As String
            Try
                objClsDataAccess = New clsDataAccess

                'objClsEcSession = New clsDalEcSessionDan
                'dsActiveSessionIds = New DataSet
                'objClsDataAccess.ExecuteDataSet(dsActiveSessionIds, strSql, CommandType.Text, "UserActiveSessions") 'objClsEcSession.GetActiveSessionIDsoftheUser(lngUser_ID)
                'If dsActiveSessionIds.Tables(0).Rows.Count > 0 Then
                'For Each drActiveSessionIds In dsActiveSessionIds.Tables(0).Rows
                strQuery = "SET NOCOUNT ON; update tblECSession set SystemLogout = 1,EndTime= getdate() where [USR_ID] = " & lngUser_ID & " AND LoggedFrom = 'Web' AND SystemLogout = 0" _
                            & ";DELETE from tblSessionData WHERE SessionID IN(select SessionID  from tblECSession where USR_ID= " & lngUser_ID & ")" '" & drActiveSessionIds.Item("SessionID") & "'"
                'objClsDataAccess.ExecuteNonQuery(strQuery, CommandType.Text)
                'strQuery = "DELETE from tblSessionData WHERE SessionID IN(select SessionID  from tblECSession where USR_ID= " & lngUser_ID & ")" '" & drActiveSessionIds.Item("SessionID") & "'"
                Return objClsDataAccess.ExecuteNonQuery(strQuery, CommandType.Text)
                'Next
                'End If
            Catch ex As Exception

                Throw
            Finally
                objClsDataAccess = Nothing
                strQuery = Nothing
            End Try

        End Function
        ' -----------------------------------------------------------------------------------------------
        ' <summary>
        '   Deletes the cob ids from consultationobject which are not saved to patientmediafs due to erros or logoff
        ' </summary>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      Shireesha    19-Mar-2020   Created    
        ' </history>
        ' -----------------------------------------------------------------------------------------------
        Public Function DeleteFailedMediaEntries(ByVal strCobIds As String) As Boolean
            Dim strQuery As String = ""
            Dim objClsDataAccess As clsDataAccess
            Try
                strQuery = "DELETE FROM ConSultation_Object  WHERE Cob_ID  in (" & strCobIds & ")"
                objClsDataAccess = New clsDataAccess
                objClsDataAccess.ExecuteNonQuery(strQuery, CommandType.Text)
                Return True
            Catch ex As Exception
                Return False
                Throw
            Finally
                objClsDataAccess = Nothing
                strQuery = Nothing
            End Try

        End Function
        Public Function fnUserPwdSettigs(ByVal lngUsrId As Long) As DataSet
            Dim objClsDataAccess As clsDataAccess
            Dim dsPwdSettings As DataSet
            Dim param(0) As ParamStruct
            Try
                dsPwdSettings = New DataSet
                objClsDataAccess = New clsDataAccess
                param(0).ParamName = "@intUser_ID"
                param(0).direction = ParameterDirection.Input
                param(0).DataType = DbType.Int32
                param(0).value = lngUsrId
                dsPwdSettings = objClsDataAccess.ExecuteDataSet("AxSp_GetPasswordSettings", CommandType.StoredProcedure, param)
                If Not dsPwdSettings Is Nothing AndAlso dsPwdSettings.Tables.Count > 0 Then
                    dsPwdSettings.Tables(0).TableName = "Preferences"
                    dsPwdSettings.Tables(1).TableName = "PwdSettings"
                End If
                Return dsPwdSettings
            Catch ex As Exception
                Throw ex
            Finally
                objClsDataAccess = Nothing
                dsPwdSettings = Nothing
                param = Nothing
            End Try
        End Function
		
        Public Function IsAssociatedPatientsExists(ByVal lngClnID As Long, ByVal lngLocID As Long) As Int16
            Dim objClsDataAccess As clsDataAccess
            Dim param(1) As ParamStruct
            Try
                objClsDataAccess = New clsDataAccess

                param(0).ParamName = "@intcln_id"
                param(0).direction = ParameterDirection.Input
                param(0).DataType = DbType.Int64
                param(0).value = lngClnID

                param(1).ParamName = "@intLoc_ID"
                param(1).direction = ParameterDirection.Input
                param(1).DataType = DbType.Int64
                param(1).value = lngLocID

                Return objClsDataAccess.ExecuteScalar("AxSp_GetGPAssociatedPatientStatus", CommandType.StoredProcedure, param)
            Catch ex As Exception
                Throw ex
            Finally
                objClsDataAccess = Nothing
                param = Nothing
            End Try
        End Function

        
    End Class
End Namespace