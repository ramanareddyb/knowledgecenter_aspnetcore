Option Explicit On 

Imports Excelicare.Framework.AppDataSupport  ' To access sql helper functions
'Imports AxSys.AppSupport ' To access exception handling functionality

Namespace Excelicare.Dal.MDI

    '*******************************************************************************************
    'Class Name : clsDalPatientDan
    'PURPOSE    : Exposes user information to bizl 
    '
    'MODIFICATION LOG  :
    '
    'AUTHOR                      Ver#       Date        Reason/Changes
    '-------------------------------------------------------------------------------------------
    'Nagodaya Bhaskar KR.      1.0.000    25/05/2004    First version.
    '*******************************************************************************************
    Public Class clsDalPatientDan
        Implements IDisposable

        Public Overloads Sub Dispose() Implements IDisposable.Dispose                  'Added by mani pratap to destroy the unused objects 
            GC.SuppressFinalize(Me)
        End Sub
        '****************************************************************************************
        'Sub/Function/Property Name : GetPatientDetails
        'Parameters   : int64PAT_ID,strCommaDelimitedColumns
        'Return Values: DataSet
        'Purpose      : This function is used to get user details
        '
        'Other relevant sources: 
        '     
        'Author            : Nagodaya Bhaskar KR
        'Created Date      : 25/05/2004
        'Last Modified Date: None
        'Modification Log  :
        'Author                 Date           Reason
        '----------------------------------------------------------------------------------------
        '****************************************************************************************
        '  ' ' -----------------------------------------------------------------------------
        ' <summary>
        '       This function is used to get Patient Details
        ' </summary>
        ' <param name="int64PAT_ID"> To get the particular User </param>
        ' <returns> Dataset get the values of user </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Nagodaya Bhaskar KR]   25/05/2004 Created
        ' 	    [Srinivas K]	        15/06/2005	Comments Added
        '       [Madhavi                10/06/2008  Modified to execute SP instead of query
        ' </history>
        ' -----------------------------------------------------------------------------

        ''Public Function GetPatientDetails(ByVal int64PAT_ID As Int64, ByVal lngUserId As Int64) As DataSet
        ''    Dim objClsDataAccess As clsDataAccess
        ''    Dim paramPatient(1) As ParamStruct
        ''    Try
        ''        objClsDataAccess = New clsDataAccess
        ''        Dim strQuery As String
        ''        With paramPatient(0)
        ''            .DataType = DbType.Int64
        ''            .direction = ParameterDirection.Input
        ''            .ParamName = "@lngPatID"
        ''            .value = int64PAT_ID
        ''        End With

        ''        With paramPatient(1)
        ''            .DataType = DbType.Int64
        ''            .direction = ParameterDirection.Input
        ''            .ParamName = "@lngUserID"
        ''            .value = lngUserId
        ''        End With
        ''        GetPatientDetails = objClsDataAccess.ExecuteDataSet("AxSP_WEBPatientDetails", CommandType.StoredProcedure, paramPatient, "PatientData")
        ''    Catch ex As Exception
        ''        Throw
        ''    Finally
        ''        objClsDataAccess = Nothing
        ''        paramPatient = Nothing
        ''    End Try
        ''End Function

        Public Function GetUserIdentifierDetails(lngIserId As Long, lngPatientId As Long) As DataSet
            Dim objClsDataAccess As clsDataAccess
            Dim arrParamStruct(1) As ParamStruct
            Dim dsResult As DataSet
            Try
                arrParamStruct(0).ParamName = "@PatID"
                arrParamStruct(0).direction = ParameterDirection.Input
                arrParamStruct(0).DataType = DbType.Int64
                arrParamStruct(0).value = lngPatientId

                arrParamStruct(1).ParamName = "@UserID"
                arrParamStruct(1).direction = ParameterDirection.Input
                arrParamStruct(1).DataType = DbType.Int64
                arrParamStruct(1).value = lngIserId
                objClsDataAccess = New clsDataAccess
                dsResult = objClsDataAccess.ExecuteDataSet("Axsp_getPatientIdentifierDetails", CommandType.StoredProcedure, arrParamStruct)
                Return dsResult
            Catch ex As Exception
                Throw ex
            Finally
                objClsDataAccess = Nothing
                dsResult = Nothing
            End Try
        End Function



        Public Function GetPatientDetails(ByVal int64PAT_ID As Int64, ByVal int64UsrID As Int64, ByVal intUsrSecurityLevel As Int16, _
        ByVal int64UserPreferredIdentifierID As Int64, ByVal int64UserPreferredIdentifierType As Int64, ByVal strAppType As String) As DataSet
            Dim objClsDataAccess As clsDataAccess
            Dim arrParamStruct(5) As ParamStruct
            Try
                arrParamStruct(0).ParamName = "@PATID"
                arrParamStruct(0).direction = ParameterDirection.Input
                arrParamStruct(0).DataType = DbType.Int64
                arrParamStruct(0).value = int64PAT_ID

                arrParamStruct(1).ParamName = "@USRID"
                arrParamStruct(1).direction = ParameterDirection.Input
                arrParamStruct(1).DataType = DbType.Int64
                arrParamStruct(1).value = int64UsrID

                arrParamStruct(2).ParamName = "@intUserSecLevel"
                arrParamStruct(2).direction = ParameterDirection.Input
                arrParamStruct(2).DataType = DbType.Int16
                arrParamStruct(2).value = intUsrSecurityLevel

                arrParamStruct(3).ParamName = "@int64UserPreferredIdentifierID"
                arrParamStruct(3).direction = ParameterDirection.Input
                arrParamStruct(3).DataType = DbType.Int64
                arrParamStruct(3).value = int64UserPreferredIdentifierID

                arrParamStruct(4).ParamName = "@int64UserPreferredIdentifierType"
                arrParamStruct(4).direction = ParameterDirection.Input
                arrParamStruct(4).DataType = DbType.Int64
                arrParamStruct(4).value = int64UserPreferredIdentifierType

                arrParamStruct(5).ParamName = "@strAppType"
                arrParamStruct(5).direction = ParameterDirection.Input
                arrParamStruct(5).DataType = DbType.String
                arrParamStruct(5).value = strAppType
                arrParamStruct(5).size = 100

                objClsDataAccess = New clsDataAccess
                GetPatientDetails = objClsDataAccess.ExecuteDataSet("AxSp_GetPatientBannerZone1", CommandType.StoredProcedure, arrParamStruct)
                If int64PAT_ID > 0 Then
                    GetPatientDetails.Tables(0).TableName = "PatDetails"
                    GetPatientDetails.Tables(1).TableName = "OtherInfo"
                    GetPatientDetails.Tables(2).TableName = "AllergyInfo"
                    GetPatientDetails.Tables(3).TableName = "PatActionItem"
                    GetPatientDetails.Tables(4).TableName = "SummaryPinnedstate"
                    If GetPatientDetails.Tables.Contains("Table5") Then
                        GetPatientDetails.Tables(5).TableName = "GenderIdentity"
                    End If
                Else
                    GetPatientDetails.Tables(0).TableName = "OtherInfo"
                End If
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                arrParamStruct = Nothing
            End Try
        End Function


        Public Function GetPatientZone1AlertIconInfo(ByVal int64PAT_ID As Int64, ByVal int64UsrID As Int64, ByVal intUsrSecurityLevel As Int16, ByVal strAppType As String, ByVal intIsACLPatient As Integer) As DataSet
            Dim objClsDataAccess As clsDataAccess
            Dim arrParamStruct(4) As ParamStruct
            Try
                arrParamStruct(0).ParamName = "@PATID"
                arrParamStruct(0).direction = ParameterDirection.Input
                arrParamStruct(0).DataType = DbType.Int64
                arrParamStruct(0).value = int64PAT_ID

                arrParamStruct(1).ParamName = "@USRID"
                arrParamStruct(1).direction = ParameterDirection.Input
                arrParamStruct(1).DataType = DbType.Int64
                arrParamStruct(1).value = int64UsrID

                arrParamStruct(2).ParamName = "@intUserSecLevel"
                arrParamStruct(2).direction = ParameterDirection.Input
                arrParamStruct(2).DataType = DbType.Int16
                arrParamStruct(2).value = intUsrSecurityLevel


                arrParamStruct(3).ParamName = "@IsACLPatient"
                arrParamStruct(3).direction = ParameterDirection.Input
                arrParamStruct(3).DataType = DbType.Int64
                arrParamStruct(3).value = intIsACLPatient

                arrParamStruct(4).ParamName = "@strAppType"
                arrParamStruct(4).direction = ParameterDirection.Input
                arrParamStruct(4).DataType = DbType.String
                arrParamStruct(4).value = strAppType
                arrParamStruct(4).size = 100

                objClsDataAccess = New clsDataAccess
                GetPatientZone1AlertIconInfo = objClsDataAccess.ExecuteDataSet("AxSP_GetPatientZone1AlertIconInfo", CommandType.StoredProcedure, arrParamStruct)
                If int64PAT_ID > 0 Then

                    GetPatientZone1AlertIconInfo.Tables(0).TableName = "AllergyInfo"
                Else
                    GetPatientZone1AlertIconInfo.Tables(0).TableName = "AllergyInfo"
                End If
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                arrParamStruct = Nothing
            End Try
        End Function
        '****************************************************************************************
        '  ' ' -----------------------------------------------------------------------------
        ' <summary>
        '       This function is used to check Allergy or ADRProblem problems of patient
        ' </summary>
        ' <param name="int64PAT_ID"> user id </param>
        ' <returns></returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Ashok Kumar Sole]  11/05/2005 Created
        ' 	    [Srinivas K]	    15/06/2005	Comments Added
        '       [Srinivas V]        14/06/2007  Modified Signatere to return Allergy Details to show tool tips
        '       [Srinivas V]        17/09/2007  Modified SQLQuery to Get Data from MPL New Tables tblPatCodedClinicCode, tblPatClinicCode
        '       [Surendra V]        11/01/2008  Modified SQLQuery :Removed Status_LU = 509 in Where condition from this Query.
        '       [K Srinivas Reddy]  28/01/2008  Modified SQLQuery :Added IsShowInMEL = 1 in Where condition from this Query.
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function IsPatientHavingAllergyorADRProblem(ByVal int64PAT_ID As Int64, ByRef strAllergyorADRText As String) As Boolean
            Dim objClsDataAccess As clsDataAccess
            Dim strQuery As String
            Try
                objClsDataAccess = New clsDataAccess
                'strQuery = "Select Top 1 PMP_ID From PATIENT_MASTER_PROBLEMS_LIST Where ProblemType  In(2504,2505) And IsActive in (1,2) and  Pat_ID = " & int64PAT_ID
                'strQuery = "DECLARE @STRPROBLEMTEXT VARCHAR(8000)" _
                '        & " SET @STRPROBLEMTEXT = ''" _
                '        & " SELECT @STRPROBLEMTEXT = @STRPROBLEMTEXT + PMP_PROBLEM_TEXT + CHAR(182) FROM PATIENT_MASTER_PROBLEMS_LIST Where ProblemType In(2504,2505) And IsActive in (1,2) and  Pat_ID = " & int64PAT_ID _
                '        & " SELECT @STRPROBLEMTEXT"
                ''strQuery = "DECLARE @STRPROBLEMTEXT VARCHAR(8000)" _
                ''        & " SET @STRPROBLEMTEXT = ''" _
                ''        & " SELECT @STRPROBLEMTEXT = @STRPROBLEMTEXT + [Description] + CHAR(182) FROM tblPatCodedClinicCode PCC JOIN tblPatClinicalCode  PC ON PC.ID = PCC.PatClinicalCode_ID AND PC.IsActive = 1 AND PC.Category_LU = 1 AND PC.Pat_ID =  " & int64PAT_ID & " AND PC.Status_LU = 509 " _
                ''        & " SELECT TOP 1 @STRPROBLEMTEXT = @STRPROBLEMTEXT + CHAR(181) + CAST(ID AS VARCHAR) from tblPatClinicalCode where IsActive = 1 AND Category_LU = 1 AND Pat_ID = " & int64PAT_ID & " AND Status_LU = 509 " _
                ''        & " SELECT @STRPROBLEMTEXT" ' Category_LU = 1 [Allergy/ADR Type Rows] Reffered for Category_LU in tblClinicalCodeGroup
                strQuery = "DECLARE @STRPROBLEMTEXT VARCHAR(8000)" _
                        & " SET @STRPROBLEMTEXT = ''" _
                        & " SELECT @STRPROBLEMTEXT = @STRPROBLEMTEXT + [Description] + CHAR(182) FROM tblPatCodedClinicCode PCC JOIN tblPatClinicalCode  PC ON PC.ID = PCC.PatClinicalCode_ID AND PC.Pat_ID =  " & int64PAT_ID & " AND PC.IsShowInMEL = 1 AND PC.IsActive = 1 AND PC.Category_LU = 1" _
                        & " SELECT TOP 1 @STRPROBLEMTEXT = @STRPROBLEMTEXT + CHAR(181) + CAST(ID AS VARCHAR) from tblPatClinicalCode where Pat_ID = " & int64PAT_ID & " AND IsShowInMEL = 1 AND IsActive = 1 AND Category_LU = 1" _
                        & " SELECT @STRPROBLEMTEXT" ' Category_LU = 1 [Allergy/ADR Type Rows] Reffered for Category_LU in tblClinicalCodeGroup

                strAllergyorADRText = CStr(objClsDataAccess.ExecuteScalar(strQuery, CommandType.Text))
                If Not strAllergyorADRText Is Nothing AndAlso strAllergyorADRText.Length > 0 Then
                    '  strAllergyorADRText = strAllergyorADRText.Substring(0, strAllergyorADRText.Length - 1)
                    Return True
                Else
                    Return False
                End If
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strQuery = Nothing
            End Try
        End Function




        '********************************************************************************************************
        'Purpose                :   To hold the tooltip information of ADR problem text 
        'Layer                  :   UI
        'Method Name            :   IsPatientHavingADR
        'Input Parameters       :   Int64, String
        'Return Values          :   Boolean
        '--------------------------------------------------------------------------------------------------------
        'Version            Author                      Date                Remarks
        '--------------------------------------------------------------------------------------------------------
        '1.0.0            Pradeep                   04/09/2008           Initial Implementation  
        '********************************************************************************************************
        Public Function IsPatientHavingADR(ByVal int64PAT_ID As Int64, ByRef strADRText As String) As Boolean
            Dim objClsDataAccess As clsDataAccess
            Dim paramPatient(0) As ParamStruct
            Dim strQuery As String
            Try
                objClsDataAccess = New clsDataAccess
                strQuery = "AxSP_PresGetADRDrugIngredientDetails"
                With paramPatient(0)
                    .DataType = DbType.Int64
                    .direction = ParameterDirection.Input
                    .ParamName = "@intPatientID"
                    .value = int64PAT_ID
                End With
                strADRText = CStr(objClsDataAccess.ExecuteScalar(strQuery, CommandType.StoredProcedure, paramPatient))
                If Not strADRText Is Nothing AndAlso strADRText.Length > 0 Then

                    Return True
                Else
                    Return False
                End If
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strQuery = Nothing
            End Try
        End Function


        '********************************************************************************************************
        'Purpose                :   To check the patient have any prescriptions in queue or not 
        'Layer                  :   UI
        'Method Name            :   IsPatientHavingADR
        'Input Parameters       :   Int64, String
        'Return Values          :   Boolean
        '--------------------------------------------------------------------------------------------------------
        'Version            Author                      Date                Remarks
        '--------------------------------------------------------------------------------------------------------
        '1.0.0            Pradeep                   04/09/2008           Initial Implementation  
        '********************************************************************************************************
        Public Function IsPatientHavingPrescriptionsInQueue(ByVal int64PAT_ID As Int64, ByVal intUserId As Integer) As Boolean
            Dim objClsDataAccess As clsDataAccess
            Dim intCount As Integer
            Dim strQuery As String
            Try
                objClsDataAccess = New clsDataAccess

                ''        & " SELECT @STRPROBLEMTEXT" ' Category_LU = 1 [Allergy/ADR Type Rows] Reffered for Category_LU in tblClinicalCodeGroup
                strQuery = "Select Count(*) from tblPatPrescriptionQueue Where PatPrescription_ID in(Select ID from tblPatPrescription Where Patient_ID =" & int64PAT_ID & " and IsActive=1 and PrescriptionType_LU != 5938) And IsActive=1 and QueueBy_User_ID=" & intUserId
                intCount = objClsDataAccess.ExecuteScalar(strQuery, CommandType.Text)
                If intCount > 0 Then
                    Return True
                Else
                    Return False
                End If
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strQuery = Nothing
            End Try
        End Function





        ' -----------------------------------------------------------------------------
        ' <summary>This function is used to check critical problems of patient. </summary>
        ' <param name="int64PAT_ID"> pass the uderid to get the particular User </param>
        ' <param name="strCriticalProblemText"> To Hold ToolTip Information </param>
        ' <returns></returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Ashok Kumar Sole]  11/05/2005 Created
        ' 	    [Srinivas K]	    15/06/2005	Commetns Added
        '       [Srinivas V]        16/06/2007  Modified Function signature and added strCriticalProblemText for Tooltip 
        '       [Srinivas V]        17/09/2007  Modified SQLQuery to Get Data from MPL New Tables tblPatCodedClinicCode, tblPatClinicCode
        '       [Surendra V]        11/01/2008  Modified SQLQuery :Removed Status_LU = 509 in Where condition from this Query.
        '       [K Srinivas Reddy]  28/01/2008  Modified SQLQuery :Added IsShowInMEL = 1 in Where condition from this Query.
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function IsPatientHavingCriticalProblems(ByVal int64PAT_ID As Int64, ByRef strCriticalProblemText As String) As Boolean
            Dim objClsDataAccess As clsDataAccess
            Dim strQuery As String
            Try
                objClsDataAccess = New clsDataAccess


                'strQuery = "Select Top 1 PMP_ID from PATIENT_MASTER_PROBLEMS_LIST " & _
                '          " Where pmp_critical = 1 And PMP_Problem_Status_Code = 1 And IsActive in (1,2) and  Pat_Id = " & int64PAT_ID
                'strQuery = "DECLARE @STRPROBLEMTEXT VARCHAR(8000)" _
                '        & " SET @STRPROBLEMTEXT = ''" _
                '        & " SELECT @STRPROBLEMTEXT = @STRPROBLEMTEXT + PMP_PROBLEM_TEXT + CHAR(182) FROM PATIENT_MASTER_PROBLEMS_LIST Where pmp_critical = 1 And PMP_Problem_Status_Code = 1 And IsActive in (1,2) and  Pat_Id = " & int64PAT_ID _
                '        & " SELECT @STRPROBLEMTEXT"
                'strQuery = "DECLARE @STRPROBLEMTEXT VARCHAR(8000)" _
                '        & " SET @STRPROBLEMTEXT = ''" _
                '        & " SELECT @STRPROBLEMTEXT = @STRPROBLEMTEXT + Description + CHAR(182) FROM tblPatCodedClinicCode PCC JOIN tblPatClinicalCode  PC ON PC.ID = PCC.PatClinicalCode_ID  AND PC.IsActive = 1 AND PC.IsCritical = 1 AND PC.Pat_ID = " & int64PAT_ID & " AND PC.Status_LU = 509 " _
                '        & " SELECT TOP 1 @STRPROBLEMTEXT = @STRPROBLEMTEXT + CHAR(181) + CAST(ID AS VARCHAR) from tblPatClinicalCode where IsActive = 1 AND IsCritical = 1 AND Pat_ID = " & int64PAT_ID & " AND Status_LU = 509 " _
                '        & " SELECT @STRPROBLEMTEXT"
                strQuery = "DECLARE @STRPROBLEMTEXT VARCHAR(8000)" _
                        & " SET @STRPROBLEMTEXT = ''" _
                        & " SELECT @STRPROBLEMTEXT = @STRPROBLEMTEXT + Description + CHAR(182) FROM tblPatCodedClinicCode PCC JOIN tblPatClinicalCode  PC ON PC.ID = PCC.PatClinicalCode_ID  AND PC.Pat_ID = " & int64PAT_ID & " AND PC.IsShowInMEL = 1 AND PC.IsActive = 1 AND PC.IsCritical = 1 " _
                        & " SELECT TOP 1 @STRPROBLEMTEXT = @STRPROBLEMTEXT + CHAR(181) + CAST(ID AS VARCHAR) from tblPatClinicalCode where  Pat_ID = " & int64PAT_ID & " AND IsActive = 1  AND IsShowInMEL = 1 AND IsCritical = 1" _
                        & " SELECT @STRPROBLEMTEXT"

                strCriticalProblemText = CStr(objClsDataAccess.ExecuteScalar(strQuery, CommandType.Text))
                If Not strCriticalProblemText Is Nothing AndAlso strCriticalProblemText.Length > 0 Then
                    ' strCriticalProblemText = strCriticalProblemText.Substring(0, strCriticalProblemText.Length - 1)
                    Return True
                Else
                    Return False
                End If
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strQuery = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>This function is used to check Other Alert Problems of patient.</summary>
        ' <param name="int64PAT_ID"> To get the particular UserId </param>
        ' <param name="strOtherAlertText"> To Hold ToolTip Information </param>
        ' <returns></returns>
        ' <remarks></remarks>

        ' <history>
        '       [Ashok Kumar Sole]  11/05/2005 Created
        ' 	    [Srinivas K]	    15/06/2005	Commetns Added
        '       [Srinivas V]        15/06/2007  Modified Function signature and added strOtherAlertText for Tooltip 
        '       [Srinivas V]        17/09/2007  Modified SQLQuery to Get Data from MPL New Tables tblPatCodedClinicCode, tblPatClinicCode
        '       [Surendra V]        11/01/2008  Modified SQLQuery :Removed Status_LU = 509 in Where condition from this Query.
        '       [K Srinivas Reddy]  28/01/2008  Modified SQLQuery :Added IsShowInMEL = 1 in Where condition from this Query.
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function IsPatientHavingOtherAlertProblems(ByVal int64PAT_ID As Int64, ByRef strOtherAlertText As String) As Boolean
            Dim objClsDataAccess As clsDataAccess
            ' Dim strProbId As String
            Dim strQuery As String
            Try
                objClsDataAccess = New clsDataAccess
                'strQuery = "Select Top 1 PMP_ID From PATIENT_MASTER_PROBLEMS_LIST Where ProblemType =  2507 And IsActive in (1,2) and  Pat_ID = " & int64PAT_ID
                'strQuery = "DECLARE @STRPROBLEMTEXT VARCHAR(8000)" _
                '        & " SET @STRPROBLEMTEXT = ''" _
                '        & " SELECT @STRPROBLEMTEXT = @STRPROBLEMTEXT + PMP_PROBLEM_TEXT + CHAR(182) FROM PATIENT_MASTER_PROBLEMS_LIST Where ProblemType =  2507 And IsActive in (1,2) and  Pat_ID = " & int64PAT_ID _
                '        & " SELECT @STRPROBLEMTEXT"
                ''strQuery = "DECLARE @STRPROBLEMTEXT VARCHAR(8000)" _
                ''       & " SET @STRPROBLEMTEXT = ''" _
                ''       & " SELECT @STRPROBLEMTEXT = @STRPROBLEMTEXT + [Description] + CHAR(182) FROM tblPatCodedClinicCode PCC JOIN tblPatClinicalCode  PC ON PC.ID = PCC.PatClinicalCode_ID AND PC.IsActive = 1 AND PC.Category_LU = 2 AND PC.Pat_ID =  " & int64PAT_ID & " AND PC.Status_LU = 509 " _
                ''       & " SELECT TOP 1 @STRPROBLEMTEXT = @STRPROBLEMTEXT + CHAR(181) + CAST(ID AS VARCHAR) from tblPatClinicalCode where IsActive = 1 AND Category_LU = 2 AND Pat_ID = " & int64PAT_ID & " AND Status_LU = 509 " _
                ''       & " SELECT @STRPROBLEMTEXT"  ' Category_LU = 2 [Other Alerts Type Rows] Reffered for Category_LU in tblClinicalCodeGroup
                strQuery = "DECLARE @STRPROBLEMTEXT VARCHAR(8000)" _
                        & " SET @STRPROBLEMTEXT = ''" _
                        & " SELECT @STRPROBLEMTEXT = @STRPROBLEMTEXT + [Description] + CHAR(182) FROM tblPatCodedClinicCode PCC JOIN tblPatClinicalCode  PC ON PC.ID = PCC.PatClinicalCode_ID AND PC.Pat_ID =  " & int64PAT_ID & " AND PC.IsActive = 1 AND PC.IsShowInMEL = 1 AND PC.Category_LU = 2 " _
                        & " SELECT TOP 1 @STRPROBLEMTEXT = @STRPROBLEMTEXT + CHAR(181) + CAST(ID AS VARCHAR) from tblPatClinicalCode where Pat_ID = " & int64PAT_ID & " AND IsActive = 1  AND IsShowInMEL = 1 AND Category_LU = 2 " _
                        & " SELECT @STRPROBLEMTEXT"  ' Category_LU = 2 [Other Alerts Type Rows] Reffered for Category_LU in tblClinicalCodeGroup

                strOtherAlertText = CStr(objClsDataAccess.ExecuteScalar(strQuery, CommandType.Text))
                If Not strOtherAlertText Is Nothing AndAlso strOtherAlertText.Length > 0 Then
                    ' strOtherAlertText = strOtherAlertText.Substring(0, strOtherAlertText.Length - 1)
                    Return True
                Else
                    Return False
                End If
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                '   strProbId = Nothing
                strQuery = Nothing
            End Try
        End Function
        '****************************************************************************************
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This function is used to get patient identifier value
        ' </summary>
        ' <param name="int64PAT_ID"> To get the particular UserId </param>
        ' <param name="int64UserPreferredIdentifierID"> UserPreferredIdentifierID </param>
        ' <param name="int64UserPreferredIdentifierType"> UserPreferredIdentifierType </param>
        ' <returns></returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Nagodaya Bhaskar KR] 02/05/2004 Created
        ' 	    [Srinivas K]	15/06/2005	Comments Added
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function GetPatientIdentifierValue(ByVal int64PAT_ID As Int64, ByVal int64UserPreferredIdentifierID As Int64, ByVal int64UserPreferredIdentifierType As Int64, ByVal usrid As Int64) As String()
            Dim objClsDataAccess As clsDataAccess
            Dim strResult As String()
            'Dim strQuery As String appending strings by using string builder
            Dim sbQuery As New System.Text.StringBuilder
            Try
                ReDim strResult(2)
                objClsDataAccess = New clsDataAccess
                ''strQuery = "Select Value From tblpatientidentifier Where  Pat_ID = " & int64PAT_ID & " And Identifier_LU = " & int64UserPreferredIdentifierID & " And Identifier_Type = " & int64UserPreferredIdentifierType
                sbQuery.Append("Select Value From tblpatientidentifier Where  Pat_ID = " & int64PAT_ID & " And Identifier_LU = " & int64UserPreferredIdentifierID & " And Identifier_Type = " & int64UserPreferredIdentifierType)
                strResult(0) = Convert.ToString((objClsDataAccess.ExecuteScalar(sbQuery.ToString, CommandType.Text)))
                'strQuery = "SELECT  " & _
                '        "Case IdentifierType " & _
                '        "When 0 THEN (SELECT LookUpValue FROM tblSysLookUp WHERE ID=" & int64UserPreferredIdentifierID & " ) " & _
                '        "WHEN 1 THEN (SELECT LookUpValue FROM tblLookUp WHERE ID= " & int64UserPreferredIdentifierID & " )   " & _
                '        "END AS Caption FROM tblUser where Usr_Id =" & usrid
                sbQuery.Append("SELECT  " & _
                        "Case IdentifierType " & _
                        "When 0 THEN (SELECT LookUpValue FROM tblSysLookUp WHERE ID=" & int64UserPreferredIdentifierID & " ) " & _
                        "WHEN 1 THEN (SELECT LookUpValue FROM tblLookUp WHERE ID= " & int64UserPreferredIdentifierID & " )   " & _
                        "END AS Caption FROM tblUser where Usr_Id =" & usrid)
                strResult(1) = Convert.ToString((objClsDataAccess.ExecuteScalar(sbQuery.ToString, CommandType.Text)))
                Return strResult
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strResult = Nothing
                sbQuery = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This function is used to check the whether the supplied Clinician is in MCN role of the patient or not
        ' </summary>
        ' <param name="lngPatientID">  Patient Id </param>
        ' <param name="lngClnID"> Clinician ID </param>
        ' <returns>Boolean</returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B] 25.07.2006 Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function IsClinicianInPatientMCNrole(ByVal lngPatientID As Long, ByVal lngClnID As Long) As Boolean
            Dim strSql As String = ""
            Dim objClsDataAccess As clsDataAccess
            Try
                objClsDataAccess = New clsDataAccess
                strSql = "select Count(ID) as TotCount from tblpatientMCNRole where Pat_ID = " & lngPatientID & " AND Staff_ID = " & lngClnID
                If objClsDataAccess.ExecuteScalar(strSql, CommandType.Text) > 0 Then
                    Return True
                Else
                    Return False
                End If
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strSql = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       To read Patient Notice board data
        ' </summary>
        ' <param name="lngPat_ID"> Patient Id </param>
        ' <returns>Boolean</returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [B.N.Jagadeesh]    26/07/2007  Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function IsNoticeBoardDataExists(ByVal lngPat_ID As Long) As Boolean
            Dim psNoticeBoard(1) As ParamStruct
            Dim objClsDataAccess As clsDataAccess
            ' Dim blnIsNoticeBoardDataExists As Boolean = False
            Dim arReturn As ArrayList
            Try
                objClsDataAccess = New clsDataAccess
                IsNoticeBoardDataExists = False
                With psNoticeBoard(0)
                    .DataType = DbType.Int64
                    .direction = ParameterDirection.Input
                    .ParamName = "@intPat_ID"
                    .value = lngPat_ID
                End With

                With psNoticeBoard(1)
                    .DataType = DbType.Byte
                    .direction = ParameterDirection.Output
                    .ParamName = "@bIsNoticeBoardDataExists"
                End With

                '  arReturn = objClsDataAccess.ExecuteDataReader("AxSP_CAMIsNoticeBoardDataExists", CommandType.StoredProcedure, psNoticeBoard)
                arReturn = objClsDataAccess.ExecutePreparedSQL("AxSP_CAMIsNoticeBoardDataExists", CommandType.StoredProcedure, psNoticeBoard)
                If Not arReturn Is Nothing Then
                    If arReturn(0) = 1 Then
                        ' blnIsNoticeBoardDataExists = True
                        IsNoticeBoardDataExists = True
                    End If
                End If
                Return IsNoticeBoardDataExists
            Catch ex As Exception
                Throw ex
            Finally
                objClsDataAccess = Nothing
                arReturn = Nothing
                psNoticeBoard = Nothing
            End Try
            'Return blnIsNoticeBoardDataExists
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        ' To log Session Action while selection patient from patient bar
        ' </summary>
        ' <param name="strModuleName"></param>
        ' <param name="strSessionID"></param>
        ' <param name="int64PatientID"></param>
        ' <param name="int64EventType_SLU"></param>
        ' <param name="strEventDetails"></param>
        ' <param name="int64ModuleId"></param>
        ' <param name="int32RecordId"></param>
        ' <returns></returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        ' 	[bhavani]	25/04/2008	Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function LogPatientChangeAction(ByVal strModuleName As String, ByVal strSessionID As String, ByVal int64PatientID As Int32, ByVal int64EventType_SLU As Int32, ByVal strEventDetails As String, ByVal int64ModuleId As Int32, ByVal int32RecordId As Int32) As Int32
            Dim objClsDataAccess As clsDataAccess
            Dim arrParams() As ParamStruct
            Dim alValues As ArrayList                   'To store return values from the stored procedure
            Dim strSQL As String
            Try
                strSQL = "AxSP_InsertPatientChange"

                'Crate Parameter array and specify all the parameters in 1-1 mapping to avoid conflicts when db provider is changed
                arrParams = New ParamStruct(8) {}

                arrParams(0).ParamName = "@ModuleName"
                arrParams(0).direction = ParameterDirection.Input
                arrParams(0).DataType = DbType.String
                arrParams(0).value = strModuleName

                arrParams(1).ParamName = "@ECSession_ID"
                arrParams(1).direction = ParameterDirection.Input
                arrParams(1).DataType = DbType.String
                arrParams(1).value = strSessionID

                arrParams(2).ParamName = "@Pat_ID"
                arrParams(2).direction = ParameterDirection.Input
                arrParams(2).DataType = DbType.Int32
                arrParams(2).value = int64PatientID

                arrParams(3).ParamName = "@EventType_SLU"
                arrParams(3).direction = ParameterDirection.Input
                arrParams(3).DataType = DbType.Int32
                arrParams(3).value = int64EventType_SLU

                arrParams(4).ParamName = "@EventDetails"
                arrParams(4).direction = ParameterDirection.Input
                arrParams(4).DataType = DbType.String
                arrParams(4).value = strEventDetails

                arrParams(5).ParamName = "@ModuleID"
                arrParams(5).direction = ParameterDirection.Input
                arrParams(5).DataType = DbType.Int32
                arrParams(5).value = int64ModuleId

                arrParams(6).ParamName = "@RecordID"
                arrParams(6).direction = ParameterDirection.Input
                arrParams(6).DataType = DbType.Int32
                arrParams(6).value = int32RecordId

                arrParams(7).ParamName = "@ResultValue"    '' Transaction Result Value
                arrParams(7).direction = ParameterDirection.Output
                arrParams(7).DataType = DbType.Int32
                arrParams(7).value = DBNull.Value

                arrParams(8).ParamName = "@ReturnSDBLogPatId"    '' SessionDBLog PatientId
                arrParams(8).direction = ParameterDirection.Output
                arrParams(8).DataType = DbType.Int32
                arrParams(8).value = DBNull.Value

                'create data access instance and execute the query
                objClsDataAccess = New clsDataAccess

                alValues = objClsDataAccess.ExecutePreparedSQL(strSQL, CommandType.StoredProcedure, arrParams)
                If alValues.Count > 0 Then
                    If alValues(0) = 0 Then
                        Return alValues(1)
                    Else
                        Return alValues(0)
                    End If
                End If
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                arrParams = Nothing
                alValues = Nothing
                strSQL = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        ' To define the image in Notice Board Icon in Patient Bar
        ' </summary>
        ' <param name="lngPat_ID"> Patient ID </param>
        ' <returns>Boolean</returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        ' 	[Pavithraraj]	25/01/2009	Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function UpdateNoticeBoardIcon(ByVal lngPat_ID As Long) As Boolean
            Dim objClsDataAccess As clsDataAccess
            Dim strSQL As Text.StringBuilder
            Dim intNoticeBoardUnReadCount As Integer
            Try
                strSQL = New Text.StringBuilder
                objClsDataAccess = New clsDataAccess
                UpdateNoticeBoardIcon = False
                strSQL.Append("Select Count(ID) from tblCAMNoticeBoard Where Pat_ID = " & lngPat_ID & " and IsRead = 0")
                intNoticeBoardUnReadCount = objClsDataAccess.ExecuteScalar(strSQL.ToString, CommandType.Text)
                If intNoticeBoardUnReadCount > 0 Then
                    UpdateNoticeBoardIcon = True
                End If
                Return UpdateNoticeBoardIcon
            Catch ex As Exception
                Throw ex
            Finally
                objClsDataAccess = Nothing
            End Try
        End Function
        Public Sub GetUserValues(ByVal lngUserId As Long, ByRef strACLGroups As String, ByRef intRestrictionLevelID As Int16)
            Dim ObjclsDataAccess As clsDataAccess
            Dim sbSql As New System.Text.StringBuilder(5000)
            Dim dsResults As DataSet
            Try
                sbSql.Append("DECLARE @ACLGROUP AS VARCHAR(500)")
                sbSql.Append(" SELECT @ACLGROUP = COALESCE(@ACLGROUP + ',', '') + RTRIM(LTRIM(STR(ACLGROUP_ID))) ")
                sbSql.Append(" FROM TBLACLSTAFF WHERE USR_ID=")
                sbSql.Append(lngUserId)
                sbSql.Append(" SELECT ISNULL(@ACLGROUP,'') AS ACLGROUP, ISNULL((SELECT RESTRICTIONLEVEL ")
                sbSql.Append(" FROM TBLACLSTAFF WHERE ACLGROUP_ID=1 AND USR_ID=")
                sbSql.Append(lngUserId)
                sbSql.Append("),0) AS RESTRICTIONLEVEL")

                ObjclsDataAccess = New clsDataAccess
                dsResults = ObjclsDataAccess.ExecuteDataSet(sbSql.ToString, CommandType.Text)
                If Not IsNothing(dsResults) AndAlso dsResults.Tables.Count > 0 AndAlso dsResults.Tables(0).Rows.Count > 0 Then
                    strACLGroups = dsResults.Tables(0).Rows(0).Item("ACLGROUP").ToString
                    intRestrictionLevelID = CType(dsResults.Tables(0).Rows(0).Item("RESTRICTIONLEVEL"), Int16)
                End If
            Catch ex As Exception
                Throw ex
            Finally
                ObjclsDataAccess = Nothing
                If Not IsNothing(dsResults) Then
                    dsResults.Dispose()
                    dsResults = Nothing
                End If
                sbSql = Nothing
            End Try
        End Sub
        ' -----------------------------------------------------------------------------
        ' <summary>
        ' Maintain 'Patient Selection History' for Logged in User
        ' </summary>
        ' <param name="int32PatientID"></param>
        ' <param name="int32Usr_Id"></param>
        ' <param name="strSessionID"></param>
        ' <remarks>
        ' </remarks>
        ' <history>
        ' 	[Posubabu]	06/02/2012	Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Sub InsLastViewPatDetails(ByVal lngPatientID As Long, ByVal int32Usr_Id As Int32, ByVal strSessionID As String)
            Dim objClsDataAccess As clsDataAccess
            'Dim blnQryResults As Boolean = False
            Dim arrParams() As ParamStruct
            Dim strSQL As String
            Try
                strSQL = "AxSP_GenSearch_SaveUserSelectedPatient"
                'Crate Parameter array and specify all the parameters in 1-1 mapping to avoid conflicts when db provider is changed
                arrParams = New ParamStruct(2) {}

                arrParams(0).ParamName = "@intPat_ID"
                arrParams(0).direction = ParameterDirection.Input
                arrParams(0).DataType = DbType.Int32
                arrParams(0).value = lngPatientID

                arrParams(1).ParamName = "@intUser_ID"
                arrParams(1).direction = ParameterDirection.Input
                arrParams(1).DataType = DbType.Int32
                arrParams(1).value = int32Usr_Id

                arrParams(2).ParamName = "@strECSessionID"
                arrParams(2).direction = ParameterDirection.Input
                arrParams(2).DataType = DbType.String
                arrParams(2).value = strSessionID

                objClsDataAccess = New clsDataAccess
                objClsDataAccess.ExecuteNonQuery(strSQL, CommandType.StoredProcedure, arrParams)

            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                arrParams = Nothing
                strSQL = Nothing
            End Try
        End Sub
        Public Function fnSaveMessageTrayItems(ByVal lngPatientID As Long, ByVal intModuleID As Integer, ByVal lngBaseFormID As Long, ByVal lngRecordId As Long, ByVal lngFormID As Long, ByVal lngMasterID As Long, ByVal lngMasterDataID As Long, ByVal lngGrandParentID As Long, ByVal lngGrandParentDataID As Long, ByVal strItemName As String, ByVal strLastModifiedDate As String, ByVal lngLastModifiedUserID As Long, ByVal intIsSourceActive As Integer, ByVal intIsActive As Integer, ByVal LastModifiedUserID As Long, ByVal strCriteria As String) As ArrayList
            Dim objClsDataAccess As clsDataAccess
            Dim arrParams() As ParamStruct
            Dim strSQL As String
            '  Dim strResult As String
            Dim arrResult As New ArrayList
            Try
                strSQL = "AxSP_SavePatientRecordMailBasketItem"
                'Crate Parameter array and specify all the parameters in 1-1 mapping to avoid conflicts when db provider is changed
                arrParams = New ParamStruct(19) {}

                arrParams(0).ParamName = "@intPatient_ID"
                arrParams(0).direction = ParameterDirection.Input
                arrParams(0).DataType = DbType.Int32
                arrParams(0).value = lngPatientID

                arrParams(1).ParamName = "@intUser_ID"
                arrParams(1).direction = ParameterDirection.Input
                arrParams(1).DataType = DbType.Int64
                arrParams(1).value = LastModifiedUserID

                arrParams(2).ParamName = "@intSysModule_ID"
                arrParams(2).direction = ParameterDirection.Input
                arrParams(2).DataType = DbType.Int64
                arrParams(2).value = intModuleID

                arrParams(3).ParamName = "@StrSource_ItemName"
                arrParams(3).direction = ParameterDirection.Input
                arrParams(3).DataType = DbType.String
                arrParams(3).value = strItemName

                arrParams(4).ParamName = "@intCustomForm_ID"
                arrParams(4).direction = ParameterDirection.Input
                arrParams(4).DataType = DbType.Int64
                arrParams(4).value = lngBaseFormID

                arrParams(5).ParamName = "@intFormLibItem_Id"
                arrParams(5).direction = ParameterDirection.Input
                arrParams(5).DataType = DbType.Int64
                arrParams(5).value = IIf(lngFormID = -1, DBNull.Value, lngFormID)

                arrParams(6).ParamName = "@intRecordID"
                arrParams(6).direction = ParameterDirection.Input
                arrParams(6).DataType = DbType.Int64
                arrParams(6).value = lngRecordId

                arrParams(7).ParamName = "@Parent_FormLibItem_ID"
                arrParams(7).direction = ParameterDirection.Input
                arrParams(7).DataType = DbType.Int64
                arrParams(7).value = IIf(lngMasterID = -1, DBNull.Value, lngMasterID)

                arrParams(8).ParamName = "@intParentDataID"
                arrParams(8).direction = ParameterDirection.Input
                arrParams(8).DataType = DbType.Int64
                arrParams(8).value = IIf(lngMasterDataID = -1, DBNull.Value, lngMasterDataID)

                arrParams(9).ParamName = "@intRoot_FormLibItem_ID"
                arrParams(9).direction = ParameterDirection.Input
                arrParams(9).DataType = DbType.Int64
                arrParams(9).value = IIf(lngGrandParentID = -1, DBNull.Value, lngGrandParentID)

                arrParams(10).ParamName = "@dtSource_CreatedDateTime"
                arrParams(10).direction = ParameterDirection.Input
                arrParams(10).DataType = DbType.DateTime
                arrParams(10).value = IIf(strLastModifiedDate = "", DBNull.Value, strLastModifiedDate)

                arrParams(11).ParamName = "@intSource_CreatedBy_User_Id"
                arrParams(11).direction = ParameterDirection.Input
                arrParams(11).DataType = DbType.Int64
                arrParams(11).value = lngLastModifiedUserID

                arrParams(12).ParamName = "@intIsActive"
                arrParams(12).direction = ParameterDirection.Input
                arrParams(12).DataType = DbType.Int64
                arrParams(12).value = intIsActive


                arrParams(13).ParamName = "@intLastModified_User_ID"
                arrParams(13).direction = ParameterDirection.Input
                arrParams(13).DataType = DbType.Int64
                arrParams(13).value = LastModifiedUserID

                arrParams(14).ParamName = "@intRootDataID"
                arrParams(14).direction = ParameterDirection.Input
                arrParams(14).DataType = DbType.Int64
                arrParams(14).value = IIf(lngGrandParentDataID = -1, DBNull.Value, lngGrandParentDataID)

                arrParams(15).ParamName = "@dtLastModifiedDate"
                arrParams(15).direction = ParameterDirection.Input
                arrParams(15).DataType = DbType.DateTime
                arrParams(15).value = Date.Now

                arrParams(16).ParamName = "@intIsSourceActive"
                arrParams(16).direction = ParameterDirection.Input
                arrParams(16).DataType = DbType.Int64
                arrParams(16).value = intIsSourceActive

                arrParams(17).ParamName = "@intStatus"
                arrParams(17).direction = ParameterDirection.Output
                arrParams(17).DataType = DbType.Int64

                arrParams(18).ParamName = "@intPatRecordCount"
                arrParams(18).direction = ParameterDirection.Output
                arrParams(18).DataType = DbType.Int64

                arrParams(19).ParamName = "@varCriteria"
                arrParams(19).direction = ParameterDirection.Input
                arrParams(19).DataType = DbType.String
                arrParams(19).value = IIf(strCriteria = Nothing, DBNull.Value, strCriteria)

                objClsDataAccess = New clsDataAccess
                arrResult = objClsDataAccess.ExecutePreparedSQL(strSQL, CommandType.StoredProcedure, arrParams)
                Return arrResult
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                arrParams = Nothing
                strSQL = Nothing
            End Try
        End Function
        Public Function GetMessageTrayCount(ByVal lngPatientID As Long, ByVal lngUserID As Long) As Integer
            Dim strQuery As String
            Dim objClsDataAccess As clsDataAccess
            Dim intMsgCount As Integer
            Try
                objClsDataAccess = New clsDataAccess
                'strQuery = "select Count(ID) from tblPatientRecordMailBasketItem where MailBasket_ID IS NULL And Patient_ID =" & lngPatientID & "and lastmodified_user_id=" & lngUserID
                strQuery = "Select  dbo.AxFn_GetPatientRecordMailBasketItem_Count(" & lngPatientID & "," & lngUserID & ")"
                intMsgCount = CInt(objClsDataAccess.ExecuteScalar(strQuery, CommandType.Text))
                Return intMsgCount
            Catch ex As Exception
                Throw ex
            Finally
                objClsDataAccess = Nothing
                strQuery = Nothing
            End Try
        End Function

        Public Function fnDeleteMessageTrayItems(ByVal strUniqueID As String, ByVal intMsgType_LU As Integer) As Integer
            Dim arrParams() As ParamStruct
            Dim objClsDataAccess As clsDataAccess
            Dim intDelCount As Integer
            Try
                objClsDataAccess = New clsDataAccess
                arrParams = New ParamStruct(1) {}

                arrParams(0).ParamName = "@intMailBasketItemID"
                arrParams(0).direction = ParameterDirection.Input
                arrParams(0).DataType = DbType.String
                arrParams(0).value = strUniqueID

                arrParams(1).ParamName = "@intMessageType"
                arrParams(1).direction = ParameterDirection.Input
                arrParams(1).DataType = DbType.String
                arrParams(1).value = IIf(intMsgType_LU = -1, DBNull.Value, intMsgType_LU)

                intDelCount = CInt(objClsDataAccess.ExecuteScalar("AxSP_DeletePatientRecordMailBasketItem", CommandType.StoredProcedure, arrParams))
                Return intDelCount
            Catch ex As Exception
                Throw ex
            Finally
                objClsDataAccess = Nothing
                arrParams = Nothing
            End Try
        End Function
		 Public Function fnSaveRioAlerts(ByVal lngPatID As Integer, ByVal intMode As Integer) As Integer
            Dim objClsDataAccess As clsDataAccess
            Dim arrParams(1) As ParamStruct
            Try
                arrParams(0).ParamName = "@patid"
                arrParams(0).direction = ParameterDirection.Input
                arrParams(0).DataType = DbType.Int32
                arrParams(0).value = lngPatID

                arrParams(1).ParamName = "@intmode"
                arrParams(1).direction = ParameterDirection.Input
                arrParams(1).DataType = DbType.Int32
                arrParams(1).value = intMode

                objClsDataAccess = New clsDataAccess
                objClsDataAccess.ExecuteNonQuery("AxSP_CUST_Add_Delete_Rio_Flag", CommandType.StoredProcedure, arrParams)
                Return 1
            Catch ex As Exception
                Throw ex
            Finally
                objClsDataAccess = Nothing
                arrParams = Nothing
            End Try
        End Function
    End Class
End Namespace