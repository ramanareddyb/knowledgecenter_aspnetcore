Option Explicit On 

Imports Excelicare.Framework.AppDataSupport  ' To access sql helper functions
'Imports AxSys.AppSupport ' To access exception handling functions
Imports System.Configuration

Namespace Excelicare.Dal.MDI
    '****************************************************************************************************
    'Class Name : clsDalSysModuleDan
    'PURPOSE    : Exposes SysModule Dan functionality to BIZL
    '
    'MODIFICATION LOG  :
    '
    'AUTHOR                      Ver#       Date        Reason/Changes
    '----------------------------------------------------------------------------------------------------
    'Nagodaya Bhaskar KR.      1.0.000    05/03/2004    First version.
    '****************************************************************************************************
    Public Class clsDalSysModuleDan
        Implements IDisposable

        Public Overloads Sub Dispose() Implements IDisposable.Dispose           'Added by mani pratap to destroy the unused objects 
            GC.SuppressFinalize(Me)
        End Sub
        'Private members
        'Private _ApplicationType As String
#Region "Properties"
        '@ -----------------------------------------------------------------------------
        '@ <summary>
        '@      Get the Application Type
        '@ </summary>
        '@ <value> ApplicationType </value>
        '@ <remarks>
        '@ </remarks>
        '@ <history>
        '@      [Nagodaya Bhaskar KR]   05/03/2004  Created
        '@ 	    [Srinivas k]	        15/06/2005	Comments Added
        '@ </history>
        '@ -----------------------------------------------------------------------------
        'Public Property ApplicationType() As String
        '    Get
        '        Return _ApplicationType
        '    End Get
        '    Set(ByVal Value As String)
        '        _ApplicationType = Value
        '    End Set
        'End Property
#End Region
#Region "New"
        '@ -----------------------------------------------------------------------------
        '@ <summary>
        '@ 
        '@ </summary>
        '@ <remarks>
        '@ </remarks>
        '@ <history>
        '@  [Nagodaya Bhaskar KR]   05/03/2004  Created
        '@ 	[Srinivas k]	        15/06/2005	Comments Added
        '@ </history>
        '@ -----------------------------------------------------------------------------
        Public Sub New()
            'Dim objClsApplication As clsApplication
            'Try
            '    objClsApplication = New clsApplication
            '    ApplicationType = objClsApplication.GetApplicationInstallType(1)
            'Catch ex As Exception
            '    Throw
            'Finally
            '    objClsApplication = Nothing
            'End Try
        End Sub
#End Region

        '************************************************************************************************
        'Sub/Function/Property Name : GetListBarGroups
        'Parameters   : None
        'Return Values: Data set Object Containing list bar group names and group items
        'Purpose      : This is a function to get group names and group items
        '
        'Other relevant sources: 
        '     
        'Author            : Nagodaya Bhaskar KR
        'Created Date      : 5/03/2004    
        'Last Modified Date: 11/03/2004
        'Modification Log  :
        'Author                 Date           Reason
        '------------------------------------------------------------------------------------------------
        'Nagodaya Bhaskar KR    26/03/2004     Added exception handling
        '************************************************************************************************
        ' -----------------------------------------------------------------------------
        ' <summary>
        '      This function used  to get group names and group items
        ' </summary>
        ' <param name="iSecurityLevel_ID"> SecurityLevel Id </param>
        ' <returns> Data set Object Containing list bar group names and group items </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Nagodaya Bhaskar KR] 05/03/2004 Created
        '      [skoora]	15/06/2005	Comments Added
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function GetListBarGroups(ByVal iSecurityLevel_ID As Int32, ByVal strApplicationType As String) As DataSet
            Dim objClsDataAccess As clsDataAccess
            Dim strQuery As String
            Try
                objClsDataAccess = New clsDataAccess
                'Dim strQuery As String = "select ID,Name,Caption,Type,DisplayOrder,isnull(ParentModule_ID,0) as 'ParentModule_ID' from tblSysModule where IsActive =1 order by Type,DisplayOrder"
                '****       Here need to change the app type accordingly.       ******
                strQuery = "SELECT Distinct(ID), Name, Caption, IsNull(ParentModule_ID, 0) As [ParentModule_ID], Type, ImageName, Displayorder, TargetURL,DomainName " & _
                            "From tblSysModule Join tblSecurityModule on tblSecurityModule.SysModule_ID = tblSysModule.ID Join tblSysModuleApp on " & _
                            "tblSysModuleApp.SysModule_ID = tblSysModule.ID Where tblSysModule.IsActive=1 and tblSecurityModule.SecurityLevel_ID = " & Convert.ToInt32(iSecurityLevel_ID) & _
                            "And tblSecurityModule.IsSystemModule = 1 and tblSysModuleApp.ApplicationType In (" & strApplicationType & ") " & _
                            " and targetURL is not null " & _
                            " Order By Type, DisplayOrder"
                Return (objClsDataAccess.ExecuteDataSet(strQuery, CommandType.Text))
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strQuery = Nothing
            End Try
        End Function
        '' Function : GetSecuritySysModuleForECFORMS
        '' Author   : suneetha
        '' 24th March 2005  
        '' Purpose : to get the system modules when logged in from ECFORMS
        '' return value : DataSet
        ''------------------------------------------------------------------------
        ' -----------------------------------------------------------------------------
        ' <summary>
        '      To get the system modules when logged in from ECFORMS
        ' </summary>
        ' <param name="iSecurityLevel_ID"> SecurityLevel Id </param>
        ' <param name="sModuleTypes"> ModuleType </param>
        ' <returns> Data set Object Containing System Modules </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Suneetha]      24/03/2005  Created
        '      [Srinivas k]	15/06/2005	Comments Added
        ' 
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function GetSecuritySysModuleForECFORMS(ByVal iSecurityLevel_ID As Int32, ByVal sModuleTypes As String, ByVal StrDomainIDList As String, ByVal strApplicationType As String, Optional ByVal intDefID As Integer = 0, Optional ByRef strDefValue As String = "") As DataSet
            Dim objDataAccess As clsDataAccess
            'Dim strQuery As String string is replaced with string builder for performance
            Dim sbQuery As New System.Text.StringBuilder
            Try
                objDataAccess = New clsDataAccess
                ''strQuery = "SELECT ID ,DomainName FROM tblSysModule WHERE ID IN (" & StrDomainIDList & ")"
                sbQuery.Append("SELECT ID ,DomainName FROM tblSysModule WHERE ID IN (" & StrDomainIDList & ")")
                GetSecuritySysModuleForECFORMS = objDataAccess.ExecuteDataSet(sbQuery.ToString, CommandType.Text, "dtDomain")
                'strQuery = ""
                sbQuery.Append("")
                '****       Here need to change the app type accordingly.       ******
                'strQuery = "declare @var as varchar(30) select @var = value from tblsysdefault where id=1299 SELECT Distinct(ID), Name, Caption, IsNull(ParentModule_ID, 0) As [ParentModule_ID], Type, ImageName, Displayorder, TargetURL,DomainName From tblSysModule " & _
                '            " Join tblSecurityModule on tblSecurityModule.SysModule_ID = tblSysModule.ID Join tblSysModuleApp on tblSysModuleApp.SysModule_ID = tblSysModule.ID " & _
                '            " And tblSysModule.Type In (" & sModuleTypes & ") Where tblSysModule.IsActive=1 and tblSecurityModule.SecurityLevel_ID = " & Convert.ToInt32(iSecurityLevel_ID) & _
                '             " And tblSecurityModule.IsSystemModule = 1 and tblSysModuleApp.ApplicationType In (" & strApplicationType & ") and tblSysModule.ID in (" & "(select value from Axfn_ReturnIdentityValue (@var, ','))" & ")  Order By Type, DisplayOrder"
                sbQuery.Append("declare @var as varchar(30) select @var = value from tblsysdefault where id=1299 SELECT Distinct(ID), Name, Caption, IsNull(ParentModule_ID, 0) As [ParentModule_ID], Type, ImageName, Displayorder, TargetURL,DomainName From tblSysModule " & _
                            " Join tblSecurityModule on tblSecurityModule.SysModule_ID = tblSysModule.ID Join tblSysModuleApp on tblSysModuleApp.SysModule_ID = tblSysModule.ID " & _
                            " And tblSysModule.Type In (" & sModuleTypes & ") Where tblSysModule.IsActive=1 and tblSecurityModule.SecurityLevel_ID = " & Convert.ToInt32(iSecurityLevel_ID) & _
                             " And tblSecurityModule.IsSystemModule = 1 and tblSysModuleApp.ApplicationType In (" & strApplicationType & ") and tblSysModule.ID in (" & "(select value from Axfn_ReturnIdentityValue (@var, ','))" & ")  Order By Type, DisplayOrder")
                ''" And tblSecurityModule.IsSystemModule = 1 and tblSysModuleApp.ApplicationType In (" & ApplicationType & ") and tblSysModule.ID in (" & ConfigurationSettings.AppSettings("DisplayPreference") & ")  Order By Type, DisplayOrder"
                objDataAccess.ExecuteDataSet(GetSecuritySysModuleForECFORMS, sbQuery.ToString, CommandType.Text, "dtModule")
                ''strQuery = "SELECT  ISNULL(value,'') as Value  FROM tblSysDefault WHERE ID = " & intDefID
                sbQuery.Append("SELECT  ISNULL(value,'') as Value  FROM tblSysDefault WHERE ID = " & intDefID)
                strDefValue = objDataAccess.ExecuteScalar(sbQuery.ToString, CommandType.Text)
            Catch ex As Exception
                Throw
            Finally
                objDataAccess = Nothing
                'strQuery = Nothing
                sbQuery = Nothing
            End Try
        End Function

        Public Function GetMDIQueueCount(lngUserId As Long, lngPatientId As Long) As String
            Dim objDataAccess As clsDataAccess
            Dim objParam(2) As ParamStruct
            Dim dsResult As DataSet
            Try
                objDataAccess = New clsDataAccess
                objParam(0) = New ParamStruct
                With objParam(0)
                    .ParamName = "@UserId"
                    .value = lngUserId
                    .direction = ParameterDirection.Input
                End With
                objParam(1) = New ParamStruct
                With objParam(1)
                    .ParamName = "@PatientId"
                    .value = lngPatientId
                    .direction = ParameterDirection.Input
                End With
                objParam(2) = New ParamStruct
                With objParam(2)
                    .DataType = DbType.Xml
                    .size = 8000
                    .direction = ParameterDirection.Output
                    .ParamName = "@ResultData"
                End With
                Return objDataAccess.ExecutePreparedSQL("AXSP_GETPATIENTLABELBARALERTINFO", CommandType.StoredProcedure, objParam)(0).ToString()
            Catch ex As Exception
                Throw ex
            Finally
                objDataAccess = Nothing
                dsResult = Nothing
                objParam = Nothing
            End Try
        End Function

        '' Function : GetMDIMenuItems
        '' Author   : P.Pradeep
        '' 25th Jan 2013  
        '' Purpose : to get the system moduless to display as menu. 
        '' return value : String
        ''------------------------------------------------------------------------
        ' -----------------------------------------------------------------------------
        ' <summary>
        '      to get the system moduless to display as menu. 
        ' </summary>
        ' <param name="iSecurityLevel_ID"> SecurityLevel Id </param>
        ' <param name="sModuleTypes"> ModuleType </param>
        ' <returns> string contain the xml with groups and items </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [P.Pradeep]      24/01/2013  Created
        ' 
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function GetMDIMenuItems(ByVal intUserSecurityLevel As Integer, ByVal strAppType As String, ByVal strModuleType As String, ByVal blnGUIDExists As Boolean, ByVal blnIsOfflineDBAdmin As Boolean, ByVal intUserId As Integer, ByVal intUserRole As Integer) As String
            Dim objDataAccess As clsDataAccess
            Dim dsResult As DataSet
            Dim objParam(6) As ParamStruct
            Dim strResult As String = ""
            Dim intIndex As Integer = 0
            Try
                objDataAccess = New clsDataAccess
                ' objParam(0) = New ParamStruct
                With objParam(0)
                    .ParamName = "@UsrSecLevel_ID"
                    .value = intUserSecurityLevel
                    .direction = ParameterDirection.Input
                    .DataType = DbType.Int16
                End With
                'objParam(1) = New ParamStruct
                With objParam(1)
                    .ParamName = "@strAppType"
                    .value = strAppType
                    .direction = ParameterDirection.Input
                    .DataType = DbType.String
                End With
                With objParam(2)
                    .ParamName = "@sModuleTypes"
                    .value = strModuleType
                    .direction = ParameterDirection.Input
                    .DataType = DbType.String
                End With

                With objParam(3)
                    .ParamName = "@intGUIDExists"
                    .value = blnGUIDExists
                    .DataType = DbType.Boolean
                    .direction = ParameterDirection.Input
                End With

                With objParam(4)
                    .ParamName = "@intIsOfflineDBAdmin"
                    .DataType = DbType.Boolean
                    .value = blnIsOfflineDBAdmin
                    .direction = ParameterDirection.Input
                End With

                With objParam(5)
                    .ParamName = "@UserId"
                    .DataType = DbType.Int64
                    .value = intUserId
                    .direction = ParameterDirection.Input
                End With

                With objParam(6)
                    .ParamName = "@intUserRole"
                    .DataType = DbType.Int64
                    .value = intUserRole
                    .direction = ParameterDirection.Input
                End With


                dsResult = objDataAccess.ExecuteDataSet("AxSp_GetMDIToolBarMenu", CommandType.StoredProcedure, objParam)
                'For intTableCnt As Integer = 0 To dsResult.Tables.Count - 1
                If dsResult.Tables(0).Rows.Count > 0 Then
                    For intCnt As Integer = 0 To dsResult.Tables(0).Rows.Count - 1
                        strResult += dsResult.Tables(0).Rows(intCnt).Item(0).ToString
                    Next
                End If
                'Next
                For intIndex = 1 To dsResult.Tables(0).Rows(0).ItemArray.Length - 1
                    strResult = strResult & Chr(186) & dsResult.Tables(0).Rows(0).Item(intIndex).ToString
                Next
                Return strResult
            Catch ex As Exception
                Throw ex
            End Try
        End Function



        '' Function : SaveUserNavigationHistory
        '' Author   : P.Pradeep
        '' 24th May 2013  
        '' Purpose : to save the user navigation history. 
        '' return value : String
        ''------------------------------------------------------------------------
        ' -----------------------------------------------------------------------------
        ' <summary>
        '      to save the user navigation history. 
        ' </summary>
        ' <param name="iSecurityLevel_ID"> SecurityLevel Id </param>
        ' <param name="sModuleTypes"> ModuleType </param>
        ' <returns> string contain the xml with groups and items </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [P.Pradeep]      24/01/2013  Created
        ' 
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function SaveUserNavigationHistory(lngUserId As Long, lngSysModuleId As Long, ByVal lngCustomFormId As Long, ByVal lngPatientId As Long, strECSessionId As String, strURL As String, strComments As String, dtNavigationDate As Date) As Boolean
            Dim objDataAccess As clsDataAccess
            Dim objParam(7) As ParamStruct
            Try
                objDataAccess = New clsDataAccess
                objParam(0) = New ParamStruct
                With objParam(0)
                    .ParamName = "@Usr_Id"
                    .value = lngUserId
                    .DataType = DbType.Int64
                    .direction = ParameterDirection.Input
                End With
                objParam(1) = New ParamStruct
                With objParam(1)
                    .ParamName = "@SysModule_ID"
                    .DataType = DbType.Int64
                    .value = lngSysModuleId
                    .direction = ParameterDirection.Input
                End With
                With objParam(2)
                    .ParamName = "@CustomForm_Id"
                    .DataType = DbType.Int64
                    .value = IIf(lngCustomFormId = -1, DBNull.Value, lngCustomFormId)
                    .direction = ParameterDirection.Input
                End With

                With objParam(3)
                    .ParamName = "@Patient_Id"
                    .value = IIf(lngPatientId <= 0, DBNull.Value, lngPatientId)
                    .DataType = DbType.Int64
                    .direction = ParameterDirection.Input
                End With

                With objParam(4)
                    .ParamName = "@ECSession_Id"
                    .DataType = DbType.String
                    .size = 70
                    .value = strECSessionId
                    .direction = ParameterDirection.Input
                End With

                With objParam(5)
                    .ParamName = "@URL"
                    .DataType = DbType.String
                    .size = 2056
                    .value = strURL
                    .direction = ParameterDirection.Input
                End With
                With objParam(6)
                    .ParamName = "@Comments"
                    .DataType = DbType.String
                    .size = 4000
                    .value = strComments
                    .direction = ParameterDirection.Input
                End With
                With objParam(7)
                    .ParamName = "@NavigationDate"
                    .DataType = DbType.DateTime
                    .value = dtNavigationDate
                    .direction = ParameterDirection.Input
                End With
                objDataAccess.ExecuteNonQuery("AxSP_SaveUserNavigationHistory", CommandType.StoredProcedure, objParam)
                Return True
            Catch ex As Exception
                Throw ex
                Return False
            Finally
                objDataAccess = Nothing
                objParam = Nothing
            End Try
        End Function




        ' -----------------------------------------------------------------------------
        ' <summary>
        ' This Function is Used to get system modules
        ' </summary>
        ' <param name="int32SecurityLevel_ID"> SecurityLevel Id </param>
        ' <param name="sModuleTypes"> ModuleType </param>
        ' <param name="StrDomainIDList"> Domain ID list as string  </param>
        ' <param name="intDefID"> an optional sys default ID  </param>
        ' <param name="strDefValue"> an optional sys default value </param>
        ' <returns> Data set Object Containing the system modules </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Nagodaya Bhaskar KR]   19/05/2004  Created
        ' 	    [Srinivas k]	        15/06/2005	Comments Added
        '       [Suneetha B]           22/06/2005 to get the reqired Domains , SysModules , Sysdefaults at one stretch
        '       [Madhavi]               10/07/2008 Modified to include blnGUIDExists and blnIsOfflineDBAdmin
        ' </history>
        ' -----------------------------------------------------------------------------
        '''Public Function GetSecuritySysModule(ByVal iSecurityLevel_ID As Int32, ByVal sModuleTypes As String, ByVal StrDomainIDList As String, ByVal strApplicationType As String, ByVal blnGUIDExists As Boolean, ByVal blnIsOfflineDBAdmin As Boolean, Optional ByVal intDefID As Integer = 0, Optional ByRef strDefValue As String = "") As DataSet
        '''    Dim objDataAccess As clsDataAccess
        '''    Dim dsModule As DataSet
        '''    Dim strQuery As String


        '''    Try
        '''        objDataAccess = New clsDataAccess
        '''        dsModule = New DataSet

        '''        strQuery = "SELECT ID ,DomainName FROM tblSysModule WHERE ID IN (" & StrDomainIDList & ")"
        '''        objDataAccess.ExecuteDataSet(dsModule, strQuery, CommandType.Text, "dtDomain")

        '''        strQuery = ""

        '''        '****       Here need to change the app type accordingly.       ******
        '''        strQuery = "SELECT Distinct(ID), Name, Caption, IsNull(ParentModule_ID, 0) As [ParentModule_ID], Type, ImageName, Displayorder, TargetURL,DomainName From tblSysModule " & _
        '''                    " Join tblSecurityModule on tblSecurityModule.SysModule_ID = tblSysModule.ID Join tblSysModuleApp on tblSysModuleApp.SysModule_ID = tblSysModule.ID " & _
        '''                    " And tblSysModule.Type In (" & sModuleTypes & ") Where tblSysModule.IsActive=1 and tblSecurityModule.SecurityLevel_ID = " & Convert.ToInt32(iSecurityLevel_ID) & _
        '''                    " And tblSecurityModule.IsSystemModule = 1 and tblSysModuleApp.ApplicationType In (" & strApplicationType & ") " & _
        '''                    " and targetURL is not null " & _
        '''                    " Order By Type, DisplayOrder"

        '''        If blnGUIDExists = True And blnIsOfflineDBAdmin = True Then
        '''            strQuery = "SELECT Distinct(ID), Name, Caption, IsNull(ParentModule_ID, 0) As [ParentModule_ID], Type, ImageName, Displayorder, TargetURL,DomainName From tblSysModule " & _
        '''                    " Join tblSecurityModule on tblSecurityModule.SysModule_ID = tblSysModule.ID Join tblSysModuleApp on tblSysModuleApp.SysModule_ID = tblSysModule.ID " & _
        '''                    " And tblSysModule.Type In (" & sModuleTypes & ") Where tblSysModule.IsActive=1 and tblSecurityModule.SecurityLevel_ID = " & Convert.ToInt32(iSecurityLevel_ID) & _
        '''                    " And tblSecurityModule.IsSystemModule = 1 and tblSysModuleApp.ApplicationType In (" & strApplicationType & ") " & _
        '''                    " and targetURL is not null " & _
        '''                    " Order By Type, DisplayOrder"

        '''        ElseIf blnGUIDExists = False And blnIsOfflineDBAdmin = False Then
        '''            strQuery = "SELECT Distinct(ID), Name, Caption, IsNull(ParentModule_ID, 0) As [ParentModule_ID], Type, ImageName, Displayorder, TargetURL,DomainName From tblSysModule " & _
        '''                     " Join tblSecurityModule on tblSecurityModule.SysModule_ID = tblSysModule.ID Join tblSysModuleApp on tblSysModuleApp.SysModule_ID = tblSysModule.ID " & _
        '''                     " And tblSysModule.Type In (" & sModuleTypes & ") Where tblSysModule.IsActive=1 and tblSecurityModule.SecurityLevel_ID = " & Convert.ToInt32(iSecurityLevel_ID) & _
        '''                     " And tblSecurityModule.IsSystemModule = 1 and tblSysModuleApp.ApplicationType In (" & strApplicationType & ") " & _
        '''                     " and targetURL is not null " & _
        '''                     " and tblSysModule.ID NOT IN(1152,1153) Order By Type, DisplayOrder"

        '''        ElseIf blnGUIDExists = True And blnIsOfflineDBAdmin = False Then
        '''            strQuery = "SELECT Distinct(ID), Name, Caption, IsNull(ParentModule_ID, 0) As [ParentModule_ID], Type, ImageName, Displayorder, TargetURL,DomainName From tblSysModule " & _
        '''                     " Join tblSecurityModule on tblSecurityModule.SysModule_ID = tblSysModule.ID Join tblSysModuleApp on tblSysModuleApp.SysModule_ID = tblSysModule.ID " & _
        '''                     " And tblSysModule.Type In (" & sModuleTypes & ") Where tblSysModule.IsActive=1 and tblSecurityModule.SecurityLevel_ID = " & Convert.ToInt32(iSecurityLevel_ID) & _
        '''                     " And tblSecurityModule.IsSystemModule = 1 and tblSysModuleApp.ApplicationType In (" & strApplicationType & ") " & _
        '''                     " and targetURL is not null " & _
        '''                     " and tblSysModule.ID NOT IN(1152)  Order By Type, DisplayOrder"

        '''        ElseIf blnGUIDExists = False And blnIsOfflineDBAdmin = True Then
        '''            strQuery = "SELECT Distinct(ID), Name, Caption, IsNull(ParentModule_ID, 0) As [ParentModule_ID], Type, ImageName, Displayorder, TargetURL,DomainName From tblSysModule " & _
        '''                        " Join tblSecurityModule on tblSecurityModule.SysModule_ID = tblSysModule.ID Join tblSysModuleApp on tblSysModuleApp.SysModule_ID = tblSysModule.ID " & _
        '''                        " And tblSysModule.Type In (" & sModuleTypes & ") Where tblSysModule.IsActive=1 and tblSecurityModule.SecurityLevel_ID = " & Convert.ToInt32(iSecurityLevel_ID) & _
        '''                        " And tblSecurityModule.IsSystemModule = 1 and tblSysModuleApp.ApplicationType In (" & strApplicationType & ") " & _
        '''                        " and targetURL is not null " & _
        '''                        " and tblSysModule.ID NOT IN(1153) Order By Type, DisplayOrder"
        '''        End If

        '''        objDataAccess.ExecuteDataSet(dsModule, strQuery, CommandType.Text, "dtModule")
        '''        If intDefID > 0 Then
        '''            strQuery = ""
        '''            strQuery = "SELECT  ISNULL(value,'') as Value FROM tblSysDefault WHERE ID = " & intDefID
        '''            strDefValue = objDataAccess.ExecuteScalar(strQuery, CommandType.Text)
        '''        End If





        '''        Return dsModule

        '''    Catch ex As Exception
        '''        Throw
        '''    Finally
        '''        objDataAccess = Nothing
        '''        dsModule = Nothing
        '''    End Try
        '''End Function
        Public Function GetSecuritySysModule(ByVal int64Usr_ID As Int64, ByVal intSecurityLevel_ID As Int32, ByVal sModuleTypes As String, ByVal strApplicationType As String, ByVal blnGUIDExists As Boolean, ByVal blnIsOfflineDBAdmin As Boolean, ByVal strproducttype As String, ByVal intUserLocationID As Integer) As DataSet
            Dim objDataAccess As clsDataAccess
            '' Dim strQuery As String
            Dim arrParamStruct(7) As ParamStruct

            Try
                objDataAccess = New clsDataAccess

                arrParamStruct(0).ParamName = "@USRID"
                arrParamStruct(0).direction = ParameterDirection.Input
                arrParamStruct(0).DataType = DbType.Int64
                arrParamStruct(0).value = int64Usr_ID

                arrParamStruct(1).ParamName = "@UsrSecLevel_ID"
                arrParamStruct(1).direction = ParameterDirection.Input
                arrParamStruct(1).DataType = DbType.Int64
                arrParamStruct(1).value = intSecurityLevel_ID

                arrParamStruct(2).ParamName = "@strAppType"
                arrParamStruct(2).direction = ParameterDirection.Input
                arrParamStruct(2).DataType = DbType.String
                arrParamStruct(2).value = strApplicationType
                arrParamStruct(2).size = 100

                arrParamStruct(3).ParamName = "@sModuleTypes"
                arrParamStruct(3).direction = ParameterDirection.Input
                arrParamStruct(3).DataType = DbType.String
                arrParamStruct(3).value = sModuleTypes
                arrParamStruct(3).size = 100

                arrParamStruct(4).ParamName = "@intGUIDExists"
                arrParamStruct(4).direction = ParameterDirection.Input
                arrParamStruct(4).DataType = DbType.Boolean
                arrParamStruct(4).value = blnGUIDExists


                arrParamStruct(5).ParamName = "@intIsOfflineDBAdmin"
                arrParamStruct(5).direction = ParameterDirection.Input
                arrParamStruct(5).DataType = DbType.Boolean
                arrParamStruct(5).value = blnIsOfflineDBAdmin

                arrParamStruct(6).ParamName = "@strProductType"
                arrParamStruct(6).direction = ParameterDirection.Input
                arrParamStruct(6).DataType = DbType.String
                arrParamStruct(6).value = strproducttype

                arrParamStruct(7).ParamName = "@intUserLocationID"
                arrParamStruct(7).direction = ParameterDirection.Input
                arrParamStruct(7).DataType = DbType.Int32
                arrParamStruct(7).value = intUserLocationID

                GetSecuritySysModule = objDataAccess.ExecuteDataSet("AxSp_GetWebMDIToolBarData", CommandType.StoredProcedure, arrParamStruct)
                GetSecuritySysModule.Tables(0).TableName = "ToolBarItems"
                GetSecuritySysModule.Tables(1).TableName = "PageLoadInfo"

            Catch ex As Exception
                Throw
            Finally
                objDataAccess = Nothing
                arrParamStruct = Nothing
                '' strQuery = Nothing
            End Try
        End Function


        '************************************************************************************************
        'Sub/Function/Property Name : GetSubFormsForModule
        'Parameters   : None
        'Return Values: Data set Object Containing list bar group names/group items
        'Purpose      : This is a function to get group items
        '
        'Other relevant sources: 
        '     
        'Author            : Nagodaya Bhaskar KR
        'Created Date      : 19/05/2004    
        'Last Modified Date: 
        'Modification Log  :
        'Author                 Date           Reason
        '------------------------------------------------------------------------------------------------
        '************************************************************************************************
        ' -----------------------------------------------------------------------------
        ' <summary>
        ' This Function is Used to get the Group Items
        ' </summary>
        ' <param name="int32SecurityLevel_ID"> SecurityLevel Id </param>
        ' <param name="sModuleTypes"> ModuleType </param>
        ' <param name="int64ParentForm_Id"> ParentForm Id </param>
        ' <returns> Data set Object Containing list bar group names/group items </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Nagodaya Bhaskar KR]   19/05/2004  Created
        ' 	    [Srinivas k]	        15/06/2005	Comments Added
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function GetSubFormsForModule(ByVal int32SecurityLevel_ID As Int32, ByVal sModuleTypes As String, ByVal int64ParentForm_Id As Int64, ByVal strApplicationType As String) As DataSet
            Dim objDataAccess As clsDataAccess
            Dim strQuery As String
            Try
                objDataAccess = New clsDataAccess
                '****       Here need to change the app type accordingly.       ******
                strQuery = "SELECT Distinct(ID), Name, Caption, IsNull(ParentModule_ID, 0) As [ParentModule_ID]," & _
                            " IsNull(ParentForm_ID, 0) As [ParentForm_ID], Type, ImageName, Displayorder, TargetURL,DomainName " & _
                            " from tblSysModule Join tblSecurityModule on tblSecurityModule.SysModule_ID = tblSysModule.ID  " & _
                            " Join tblSysModuleApp on tblSysModuleApp.SysModule_ID = tblSysModule.ID Where(tblSysModule.IsActive = 1 " & _
                            " And tblSecurityModule.SecurityLevel_ID = " & int32SecurityLevel_ID & " And tblSecurityModule.IsSystemModule = 1) " & _
                            " and tblSysModuleApp.ApplicationType In (" & strApplicationType & ")   and type=4 and Parentform_id= " & int64ParentForm_Id & _
                            " and targetURL is not null " & _
                            " Order By Type, DisplayOrder"

                Return objDataAccess.ExecuteDataSet(strQuery, CommandType.Text)
            Catch ex As Exception
                Throw
            Finally
                objDataAccess = Nothing
                strQuery = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        ' This Function is Used to get requested module domains
        ' </summary>
        ' <param name="strIDList"> Domain Id list as string </param>
        ' <returns> Data Table containing the requested Domains </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        ' 	    [Suneetha B]	   22/10/2005	Comments Added
        '       [Suneetha B]       22/10/2005   Added  

        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Function GetDomains(ByVal strIDList As String) As DataTable
            Dim objDataAccess As clsDataAccess
            Dim strSql As String
            Dim dsDomain As DataSet
            Try
                dsDomain = New DataSet
                strSql = "SELECT ID , DomainName FROM tblSysModule WHERE ID IN (" & strIDList & ")"
                objDataAccess = New clsDataAccess
                objDataAccess.ExecuteDataSet(dsDomain, strSql, CommandType.Text, "Domain")
                If Not dsDomain Is Nothing Then
                    If dsDomain.Tables.Count > 0 Then
                        GetDomains = dsDomain.Tables(0)
                    End If
                End If
            Catch ex As Exception
                Throw
            Finally
                If Not dsDomain Is Nothing Then
                    dsDomain.Dispose()
                    dsDomain = Nothing
                End If
                objDataAccess = Nothing
                strSql = Nothing
            End Try
        End Function
        Public Function IsFormAccessible(ByVal intSysModuleId As Integer, ByVal strAppType As String, ByVal intUserSecLevel As Integer) As Boolean
            Dim strSQL As String = String.Empty
            Dim objClsDataAccess As clsDataAccess
            Try
                objClsDataAccess = New clsDataAccess
                strSQL = "SELECT distinct id From tblSysModule " _
                     & " join tblSecurityModule on tblSecurityModule.SysModule_ID = tblSysModule.ID " _
                     & " join tblSysModuleApp on  tblSysModuleApp.SysModule_ID = tblSysModule.ID" _
                     & " Where(tblSecurityModule.SecurityLevel_ID = " & intUserSecLevel & ") " _
                     & " And tblSecurityModule.IsSystemModule = 1 " _
                     & " And tblSysModuleApp.ApplicationType IN (" & strAppType & ")" _
                     & " and id in (" & intSysModuleId & ")"
                If objClsDataAccess.ExecuteScalar(strSQL, CommandType.Text) > 0 Then
                    Return True
                Else
                    Return False
                End If
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strSQL = Nothing
            End Try
        End Function

        Public Function IsAdhocUser(ByVal lngUserID As Int64) As Boolean
            Dim strSQL As String = String.Empty
            Dim objClsDataAccess As clsDataAccess
            Try
                objClsDataAccess = New clsDataAccess
                strSQL = "Select IsAdhocReportUser from tblUser Where Usr_ID = " & lngUserID
                If objClsDataAccess.ExecuteScalar(strSQL, CommandType.Text) = True Then
                    Return True
                Else
                    Return False
                End If
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strSQL = Nothing
            End Try
        End Function

        Public Function GetAdhocPath(ByVal strSession_ID As String) As String
            Dim strSQL As String = String.Empty
            Dim strTemp As String = String.Empty
            Dim objClsDataAccess As clsDataAccess
            Try
                objClsDataAccess = New clsDataAccess
                strSQL = "Select isnull(AdhocExePath,'') from tblMachinePreference Where MachineName = (Select TOP 1 MachineName from tblECSession Where ID ='" & strSession_ID & "')"
                strTemp = objClsDataAccess.ExecuteScalar(strSQL, CommandType.Text)
                If Not IsDBNull(strTemp) Or Not strTemp Is Nothing Then
                    Return strTemp
                Else
                    Return ""
                End If
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strSQL = Nothing
                strTemp = Nothing
            End Try
        End Function
        '
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This function is used to get the Database version
        ' </summary>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]    02.03.2006  Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Function GetDBVersion() As DataSet
            Dim strQuery As String = ""
            Dim objclsDataAccess As clsDataAccess
            Try
                objclsDataAccess = New clsDataAccess
                strQuery = "Select Top 1 DBVersionMain, DBVersionInternal from tblSysDBMaintenanceLog order by ID DESC"
                Return objclsDataAccess.ExecuteDataSet(strQuery, CommandType.Text)
            Catch ex As Exception
                Throw
            Finally
                objclsDataAccess = Nothing
                strQuery = Nothing
            End Try
        End Function

        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This function is used to get the helpUrl for the supplied form Name
        ' </summary>
        '<param Name="strFormName">form Name</param>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]    09.05.2006  Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function GetHelpTargetUrl(ByVal strFormName As String) As String
            Dim strSQL As String = String.Empty
            Dim objClsDataAccess As clsDataAccess
            Try
                objClsDataAccess = New clsDataAccess
                strSQL = "SELECT IsNull(TargetHelpURL,'') AS TargetHelpUrl FROM tblsysEcv2helpmapping WHERE FormName = '" & strFormName.Trim & "'"
                Return objClsDataAccess.ExecuteScalar(strSQL, CommandType.Text)
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strSQL = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This function is used to get the values for Network Monitor Test
        ' </summary>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [K Srinivas Reddy]    26.02.2009  Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function GetNMTLimits() As String
            Dim strSQL As String = String.Empty
            Dim objClsDataAccess As clsDataAccess
            Dim dslimits As DataSet
            Dim dr As DataRow
            Dim strReturn As String = ""
            Try
                objClsDataAccess = New clsDataAccess
                strSQL = "SELECT VALUE FROM TBLSYSDEFAULT WHERE ID IN (1620,1621) ORDER BY ID ASC"
                dslimits = objClsDataAccess.ExecuteDataSet(strSQL, CommandType.Text)
                For Each dr In dslimits.Tables(0).Rows
                    strReturn = strReturn & dr.Item(0) & "|"
                Next
                Return strReturn
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strSQL = Nothing
                dslimits = Nothing
            End Try
        End Function

        Public Function GetExternalUrl(ByVal lngLibraryItemID As Long) As String
            Dim prmValues(0) As ParamStruct
            Dim objDataset As DataSet
            Dim m_objClsDataAccess As New clsDataAccess
            Try
                prmValues(0).DataType = DbType.Int64
                prmValues(0).direction = ParameterDirection.Input
                prmValues(0).ParamName = "@intFormLibID"
                prmValues(0).value = lngLibraryItemID

                objDataset = m_objClsDataAccess.ExecuteDataSet("AxSP_PCF_GetFormLibItemDetails", CommandType.StoredProcedure, prmValues)
                Return objDataset.Tables(0).Rows(0).Item(1).ToString()

            Catch ex As Exception
                Throw ex
            Finally
                objDataset = Nothing
                prmValues = Nothing
                lngLibraryItemID = Nothing
            End Try
        End Function
        Public Function GetSysActionMenuItems(ByVal strMenuGroupItemName As String, ByVal strActionName As String) As DataSet
            Dim prmValues(1) As ParamStruct
            Dim objDataset As DataSet
            Dim m_objClsDataAccess As New clsDataAccess
            Try
                prmValues(0).ParamName = "@ActionText"
                prmValues(0).DataType = DbType.String
                prmValues(0).direction = ParameterDirection.Input
                prmValues(0).value = strMenuGroupItemName

                prmValues(1).ParamName = "@ActionColumn"
                prmValues(1).DataType = DbType.String
                prmValues(1).direction = ParameterDirection.Input
                prmValues(1).value = strActionName
                objDataset = m_objClsDataAccess.ExecuteDataSet("AxSP_Gen_GetActionItems", CommandType.StoredProcedure, prmValues)
                If objDataset.Tables(0).Rows.Count > 0 Then
                    Return objDataset
                Else
                    Return Nothing
                End If
            Catch ex As Exception
                Throw ex
            Finally
                objDataset = Nothing
                prmValues = Nothing
            End Try
        End Function

        '***********************************************************************************************************************
        'Purpose            :   To get DropDown items
        'Method Name        :   GetItemsforUserDropDown
        'Input Parameters   :   lngUserID, intUserRole
        'Return Values      :   Lookupvalues dataset
        '-----------------------------------------------------------------------------------------------------------------------
        'Version        Author                              Date                            Remarks
        '-----------------------------------------------------------------------------------------------------------------------
        '7.5            RK                              25/04/2022                    Initial Implementation       
        '***********************************************************************************************************************
        Public Function GetItemsforUserDropDown(ByVal lngUserID As Long, ByVal intUserRole As Integer) As DataSet
            Dim prmValues(1) As ParamStruct
            Dim m_objClsDataAccess As New clsDataAccess
            Try
                prmValues(0).ParamName = "@intUserID"
                prmValues(0).DataType = DbType.Int64
                prmValues(0).direction = ParameterDirection.Input
                prmValues(0).value = lngUserID

                prmValues(1).ParamName = "@intUserRole"
                prmValues(1).DataType = DbType.Int64
                prmValues(1).direction = ParameterDirection.Input
                prmValues(1).value = intUserRole

                Return m_objClsDataAccess.ExecuteDataSet("AxSP_GetUserItems", CommandType.StoredProcedure, prmValues)

            Catch ex As Exception
                Throw ex
            Finally
                prmValues = Nothing
                m_objClsDataAccess = Nothing
            End Try
        End Function
    End Class
End Namespace
