﻿Option Explicit On

' -----------------------------------------------------------------------------
'Imports AxSys.AppSupport ' To access exception handling functionality
' -----------------------------------------------------------------------------
' <summary>
'      To access external service methods
' </summary>
' <remarks>
' </remarks>
' <history>
' 	    [Suresh S]	  12/06/2013	 Initial development.
' </history>
' -----------------------------------------------------------------------------

Namespace Excelicare.Bizl.ExternalService
    ' -----------------------------------------------------------------------------
    ' <summary>
    '      Used to connect external service and access required methods
    ' </summary>
    ' <remarks>
    '      First version.
    ' </remarks>
    ' <history>
    ' 	    [Suresh S]	  12/06/2013	 Initial development.
    ' </history>
    'Expected sample input format: <ExternalServiceConnectivity><MethodName></MethodName><Params><Error></Error><UserName></UserName><PassWord></PassWord></Params></ExternalServiceConnectivity>
    ' -----------------------------------------------------------------------------
    Public Class clsExternalServiceConnectivity
        Public Function AccessExternalService(ByVal strInput As String) As String
            Dim objxelement As XElement
            Dim strMethodName As String
            Dim strError As String
            Dim strUserName As String
            Dim strPassWord As String
            Dim strTokenID As String
            Dim strArtifactID As String
            Dim strRequestMessage As String
            Dim strOutputMessage As String
            Dim strPartnerServiceURL As String
            Dim strAETokenID As String
            Dim strPartnerID As String
            Dim strReturnValue As String = String.Empty
            Try
                If Not String.IsNullOrEmpty(strInput) Then
                    objxelement = XElement.Parse(strInput)
                    strMethodName = objxelement...<MethodName>.Value
                    Select Case strMethodName
                        Case "RequestPartnerToken"
                            strError = objxelement...<Params>.<Error>.Value
                            strUserName = objxelement...<Params>.<UserName>.Value
                            strPassWord = objxelement...<Params>.<PassWord>.Value
                            strReturnValue = RequestPartnerToken(strError, strUserName, strPassWord)
                        Case "RetrieveArtifact"
                            strError = objxelement...<Params>.<Error>.Value
                            strTokenID = objxelement...<Params>.<TokenID>.Value
                            strArtifactID = objxelement...<Params>.<ArtifactID>.Value
                            strReturnValue = RetrieveArtifact(strError, strTokenID, strArtifactID)
                        Case "PartnerRequestToken"
                            strRequestMessage = objxelement...<Params>.<RequestMessage>.Value
                            strPartnerServiceURL = objxelement...<Params>.<PartnerServiceURL>.Value
                            strReturnValue = PartnerRequestToken(strRequestMessage, strPartnerServiceURL)
                        Case "RetrievePartnerArtifact"
                            strError = objxelement...<Params>.<Error>.Value
                            strAETokenID = objxelement...<Params>.<AETokenID>.Value
                            strPartnerID = objxelement...<Params>.<PartnerID>.Value
                            strPartnerServiceURL = objxelement...<Params>.<PartnerServiceURL>.Value
                            strReturnValue = RetrievePartnerArtifact(strError, strAETokenID, strPartnerID, strPartnerServiceURL)
                    End Select
                End If
                Return strReturnValue
            Catch ex As Exception
                Throw ex
            Finally
                objxelement = Nothing
            End Try
        End Function

        Private Function RequestPartnerToken(ByVal strError As String, ByVal strUserName As String, ByVal strPassWord As String) As String
            Dim objMMMProxy As HUBSSOPersistenceService.MMMHubSSOClient
            Dim strReturnValue As String = ""
            Dim blnServiceClose As Boolean = False
            Try
                objMMMProxy = New HUBSSOPersistenceService.MMMHubSSOClient
                strReturnValue = objMMMProxy.RequestToken(strError, strUserName, strPassWord)
                objMMMProxy.Close()
                blnServiceClose = True
                ''strReturnValue = "<methodResponse><params><param><value><string>test 123 partnertoken</string></value></param><param><value><dateTime.iso8601>2012/08/13</dateTime.iso8601></value></param></params></methodResponse>"
            Catch ex As Exception
                Throw ex
            Finally
                ' Clearing the objects after usage
                If blnServiceClose = False Then
                    objMMMProxy.Abort()
                End If
                objMMMProxy = Nothing
            End Try
            Return strReturnValue
        End Function
        Private Function RetrieveArtifact(ByVal strError As String, ByVal strTokenID As String, ByVal strArtifactID As String) As String
            Dim objMMMProxy As HUBSSOPersistenceService.MMMHubSSOClient
            Dim strReturnValue As String = ""
            Dim blnServiceClose As Boolean = False
            Try
                objMMMProxy = New HUBSSOPersistenceService.MMMHubSSOClient
                strReturnValue = objMMMProxy.RetrieveArtifact(strError, strTokenID, strArtifactID)
                objMMMProxy.Close()
                blnServiceClose = True
                ''strReturnValue = "<response><type>login.selectMember</type><content><user><username>admin</username></user><member><memberid>123</memberid><MPI>123456</MPI><dob></dob><address></address><city></city><state></state><zip></zip><phone></phone></member></content></response>"
            Catch ex As Exception
                Throw ex
            Finally
                ' Clearing the objects after usage
                If blnServiceClose = False Then
                    objMMMProxy.Abort()
                End If
                objMMMProxy = Nothing
            End Try
            Return strReturnValue
        End Function
        Private Function PartnerRequestToken(ByVal strRequestMessage As String, ByVal strPartnerServiceURL As String) As String
            'This method is used for TuRecord functionality
            Dim strReturnValue As String = ""
            Dim objTURecordProxy As SSOPartner.Partner_SSOClient
            Dim blnServiceClose As Boolean = False
            Try
                objTURecordProxy = New SSOPartner.Partner_SSOClient
                objTURecordProxy.Endpoint.Address = New ServiceModel.EndpointAddress(strPartnerServiceURL)
                strReturnValue = objTURecordProxy.PartnerRequestToken(strRequestMessage)
                objTURecordProxy.Close()
                blnServiceClose = True
            Catch ex As Exception
                Throw ex
            Finally
                ' Clearing the objects after usage
                If blnServiceClose = False Then
                    objTURecordProxy.Abort()
                End If
                objTURecordProxy = Nothing
            End Try
            Return strReturnValue
        End Function
        Private Function RetrievePartnerArtifact(ByRef strError As String, ByVal strToken As String, ByVal strArtefactId As String, ByVal strPartnerServiceURL As String) As String
            Dim strReturnValue As String = ""
            Dim objTURecordProxy As SSOPartner.Partner_SSOClient
            Dim strInputMessage As String
            Dim strOutputMessage As String = String.Empty
            Dim objXelement As XElement
            Dim blnServiceClose As Boolean = False
            Try
                objTURecordProxy = New SSOPartner.Partner_SSOClient
                strInputMessage = "<RetrieveArtifact>" & _
                                      "<Token>" & strToken & "</Token>" & _
                                      "<PartnerArtifactID>" & strArtefactId & "</PartnerArtifactID>" & _
                                  "</RetrieveArtifact>"
                objTURecordProxy.Endpoint.Address = New ServiceModel.EndpointAddress(strPartnerServiceURL)
                strReturnValue = objTURecordProxy.PartnerRetrieveArtifact(strInputMessage)
                strOutputMessage = strReturnValue
                objTURecordProxy.Close()
                blnServiceClose = True
                If strOutputMessage.Length > 0 Then
                    objXelement = XElement.Parse(strOutputMessage)
                    strError = objXelement...<ErrorDescription>.Value
                End If
                strReturnValue = strOutputMessage
                ''strReturnValue = "<response><type>login.selectMember</type><content><user><username>admin</username></user><member><memberid>123</memberid><MPI>123456</MPI><dob></dob><address></address><city></city><state></state><zip></zip><phone></phone></member></content></response>"
            Catch ex As Exception
                Throw ex
            Finally
                ' Clearing the objects after usage
                If blnServiceClose = False Then
                    objTURecordProxy.Abort()
                End If
                objTURecordProxy = Nothing
                objXelement = Nothing
            End Try
            Return strReturnValue
        End Function
    End Class
End Namespace
