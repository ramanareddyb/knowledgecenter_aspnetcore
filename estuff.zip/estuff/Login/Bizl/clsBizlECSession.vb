Option Explicit On 

Imports Excelicare.Dal.Login  ' To access data access functionalty from DAL
' -----------------------------------------------------------------------------
' <summary>
'      To access functionalty from DAL
' </summary>
' <remarks>
' </remarks>
' <history>
' 	    [Ram R]	 15/06/2005	 Added Comments
' </history>
' -----------------------------------------------------------------------------
'Imports AxSys.AppSupport ' To access exception handling functionality
' -----------------------------------------------------------------------------
' <summary>
'      To access exception handling functions
' </summary>
' <remarks>
' </remarks>
' <history>
' 	    [Ram R]	  15/06/2005	 Added Comments
' </history>
' -----------------------------------------------------------------------------

Namespace Excelicare.Bizl.Login
    '****************************************************************************************************
    'Class Name: clsBizlECSession
    'PURPOSE   : Exposes EC session functionality to Presentation layer
    '
    'MODIFICATION LOG  :
    '
    'AUTHOR                      Ver#       Date        Reason/Changes
    '----------------------------------------------------------------------------------------------------
    'Nagodaya Bhaskar KR.      1.0.000    25/02/2004    First version.
    '****************************************************************************************************
    ' -----------------------------------------------------------------------------
    ' <summary>
    '      Exposes EC session functionality to Presentation layer
    ' </summary>
    ' <remarks>
    '      First version.
    ' </remarks>
    ' <history>
    '      [Nagodaya Bhaskar KR]   25/02/2004   Created
    ' 	   [Ram R]	               15/06/2005	Added Comments
    ' </history>
    ' -----------------------------------------------------------------------------
    Public Class clsBizlECSession

        'Class Variables
        Private _Session_ID As String

        'Class Properties

        '************************************************************************************************
        'Sub/Function/Property Name : Session_ID()
        'Parameters   : None
        'Return Values: Session_ID
        'Purpose      : This is a property to get or set session id  
        '
        'Other relevant sources: None
        '     
        'Author            : Nagodaya Bhaskar KR
        'Created Date      : 25/02/2004    
        'Last Modified Date: 00/00/0000
        'Modification Log  :
        'Author                 Date           Reason
        '------------------------------------------------------------------------------------------------
        '************************************************************************************************
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This is a property to get or set Session id 
        ' </summary>
        ' <returns> String </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Nagodaya Bhaskar KR]   25/02/2004   Created
        ' 	   [Ram R]	               15/06/2005	Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Property Session_ID() As String
            Get
                Return Me._Session_ID
            End Get
            Set(ByVal Value As String)
                Me._Session_ID = Value
            End Set
        End Property


        'Class functions

        '************************************************************************************************
        'Sub/Function/Property Name : StartSession
        'Parameters   : strLoginName,strMachineName,strMachineIP
        'Return Values:  Returns the no of rows affected
        'Purpose      : This is a funtion which creates a new session for the user.  If the user already has an open session this will be ignored and a new session is created.
        '
        'Other relevant sources: None
        '   
        '     
        'Author            : Nagodaya Bhaskar KR
        'Created Date      : 27/02/2004    
        'Last Modified Date: 00/00/0000
        'Modification Log  :
        'Author                 Date           Reason
        '------------------------------------------------------------------------------------------------
        'Nagodaya Bhaskar KR    26/03/2004     Added exception handling
        '************************************************************************************************
        ' -----------------------------------------------------------------------------
        ' <summary>
        '        This is a funtion which creates a new session for the user.  If the user already has an open session this will be ignored and a new session is created.
        ' </summary>
        ' <param name="strLoginName"> </param>
        ' <param name="strSession_ID"></param>
        ' <param name="strMachineName"></param>
        ' <param name="strMachineIP"></param>
        ' <returns> Int16 </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Nagodaya Bhaskar KR]   27/02/2004   Created
        '      [Nagodaya Bhaskar KR]   26/03/2004   Last Modified Date. Reason: Added exception handling
        ' 	   [Ram R]	               15/06/2005	Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------

        Public Function StartSession(ByVal strLoginName As String, ByVal strSession_ID As String, ByVal strMachineName As String, ByVal strMachineIP As String) As Int16
            Try
                Return clsDalECSessionDat.StartSession(strLoginName, strSession_ID, strMachineName, strMachineIP)

            Catch ex As Exception
                Throw
            Finally
            End Try
        End Function 'StartSession

        '************************************************************************************************
        'Sub/Function/Property Name : EndSession
        'Parameters   : Session_ID
        'Return Values: None
        'Purpose      : This is a sub to record the logout
        '
        'Other relevant sources: 
        '   
        '     
        'Author            : Nagodaya Bhaskar KR
        'Created Date      : 27/02/2004    
        'Last Modified Date: 00/00/0000
        'Modification Log  :
        'Author                 Date           Reason
        '------------------------------------------------------------------------------------------------
        'Nagodaya Bhaskar KR    26/03/2004     Added exception handling
        '************************************************************************************************
        ' -----------------------------------------------------------------------------
        ' <summary>
        '        This is a sub to record the logout
        ' </summary>
        ' <param name="strSession_ID">Retrieves the Session_ID value for the logged in user </param>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Nagodaya Bhaskar KR]   27/02/2004   Created
        '      [Nagodaya Bhaskar KR]   26/03/2004   Last Modified Date. Reason: Added exception handling
        ' 	   [Ram R]	               15/06/2005	Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Sub EndSession(ByVal strSession_ID As String)
            Try
                clsDalECSessionDat.EndSession(strSession_ID)
            Catch ex As Exception
                Throw
            Finally
            End Try
        End Sub 'EndSession

        '************************************************************************************************
        'Sub/Function/Property Name : StillActive
        'Parameters   : 
        'Return Values: 
        'Purpose      : This is a function that updates still connected time of the user
        '
        'Other relevant sources: None
        '     
        'Author            : Nagodaya Bhaskar KR
        'Created Date      : 05/04/2004    
        'Last Modified Date: 00/00/0000
        'Modification Log  :
        'Author                 Date           Reason
        '------------------------------------------------------------------------------------------------
        '************************************************************************************************
        ' -----------------------------------------------------------------------------
        ' <summary>
        '        This is a function that updates still connected time of the user
        ' </summary>
        ' <param name="strSession_ID">Retrieves the Session_ID value for the logged in user </param>
        ' <param name="dt"> To get the date and time </param>
        ' <returns> Int16 </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Nagodaya Bhaskar KR]   05/04/2004   Created
        ' 	   [Ram R]	               15/06/2005	Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Function StillActive(ByVal strSession_ID As String, ByVal dt As DateTime) As Int16
            Try
                Return clsDalECSessionDat.StillActive(strSession_ID, dt)
            Catch ex As Exception
                Throw
            Finally
            End Try
        End Function


        '************************************************************************************************
        'Sub/Function/Property Name : IncrementConcurrentUserCount
        'Parameters   : None
        'Return Values: None
        'Purpose      : This is a sub to increment the concurrent user count
        '
        'Other relevant sources: None
        '     
        'Author            : Nagodaya Bhaskar KR
        'Created Date      : 27/02/2004    
        'Last Modified Date: 00/00/0000
        'Modification Log  :
        'Author                 Date           Reason
        '------------------------------------------------------------------------------------------------
        'Nagodaya Bhaskar KR    26/03/2004     Added exception handling
        '************************************************************************************************
        ' -----------------------------------------------------------------------------
        ' <summary>
        '        This is a sub to increment the concurrent user count
        ' </summary>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Nagodaya Bhaskar KR]   27/02/2004   Created
        '      [Nagodaya Bhaskar KR]   26/03/2004   Last Modified Date
        ' 	    [Ram R]	                15/06/2005	 Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Sub IncrementConcurrentUserCount()
            Try
                clsDalECSessionDat.IncrementConcurrentUserCount()
            Catch ex As Exception
                Throw
            Finally
            End Try
        End Sub

        '************************************************************************************************
        'Sub/Function/Property Name : DecrementConcurrentUserCount
        'Parameters   : None
        'Return Values: None
        'Purpose      : This is a sub to decrement the concurrent user count
        '
        'Other relevant sources: None
        '     
        'Author            : Nagodaya Bhaskar KR
        'Created Date      : 27/02/2004    
        'Last Modified Date: 00/00/0000
        'Modification Log  :
        'Author                 Date           Reason
        '------------------------------------------------------------------------------------------------
        'Nagodaya Bhaskar KR    26/03/2004     Added exception handling
        '************************************************************************************************
        '************************************************************************************************
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This is a sub to decrement the concurrent user count
        ' </summary>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Nagodaya Bhaskar KR]   27/02/2004   Created
        '      [Nagodaya Bhaskar KR]   26/03/2004   Last Modified Date
        ' 	    [Ram R]	                15/06/2005	 Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Sub DecrementConcurrentUserCount()
            Try
                clsDalECSessionDat.DecrementConcurrentUserCount()
            Catch ex As Exception
                Throw
            Finally
            End Try
        End Sub

        '*************************************************************************************************
        'Sub/Function/Property Name : GetConcurrentUserCount
        'Parameters   : None
        'Return Values: concurrent user count
        'Purpose      : This is a function to get the concurrent user count
        '
        'Other relevant sources: None
        '     
        'Author            : Nagodaya Bhaskar KR
        'Created Date      : 27/02/2004    
        'Last Modified Date: 00/00/0000
        'Modification Log  :
        'Author                 Date           Reason
        '-------------------------------------------------------------------------------------------------
        'Nagodaya Bhaskar KR    26/03/2004     Added exception handling
        '*************************************************************************************************
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This is a function to get the concurrent user count
        ' </summary>
        ' <returns> Int16 </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Nagodaya Bhaskar KR]   27/02/2004   Created
        '      [Nagodaya Bhaskar KR]   26/03/2004   Last Modified Date
        ' 	   [Ram R]	               15/06/2005	Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------

        Public Shared Function GetConcurrentUserCount() As Int16
            Try
                Return clsDalEcSessionDan.GetConcurrentUserCount
            Catch ex As Exception
                Throw
            Finally
            End Try
        End Function 'GetConcurrentUserCount

        '*************************************************************************************************
        'Sub/Function/Property Name : IsUserSessionExists
        'Parameters   : LoginId
        'Return Values: True or False
        'Purpose      : This is a function to check whether the login user has a session exists or not
        '
        'Other relevant sources: None
        '     
        'Author            : Nagodaya Bhaskar KR
        'Created Date      : 05/04/2004    
        'Last Modified Date: 00/00/0000
        'Modification Log  :
        'Author                 Date           Reason
        '-------------------------------------------------------------------------------------------------           '*************************************************************************************************
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This is a function to check whether the login user has a session exists or not
        ' </summary>
        ' <param name="LoginName"> To get the LoginName of the user</param>
        ' <returns> String </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Nagodaya Bhaskar KR]   27/02/2004   Created
        ' 	    [Ram R]	                15/06/2005	 Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------

        Public Shared Function IsUserSessionExists(ByVal LoginName As String) As String
            Try
                Return clsDalEcSessionDan.IsUserSessionExists(LoginName)
            Catch ex As Exception
                Throw
            Finally
            End Try
        End Function

        Public Shared Function GetDomainNames() As DataSet
            Try
                Return clsDalEcSessionDan.GetDomainNames()
            Catch ex As Exception
                Throw ex
            End Try
        End Function

        Public Function IsSessionDuplicate(ByVal strSessionID As String) As Int16
            Dim objECsessionDan As clsDalEcSessionDan
            Try
                objECsessionDan = New clsDalEcSessionDan
                Return objECsessionDan.IsSessionDuplicate(strSessionID)
            Catch ex As Exception
            Finally
                objECsessionDan = Nothing
            End Try
        End Function


        '*************************************************************************************************
        'Sub/Function/Property Name : TerminateLeftOverSessions
        'Parameters   : None
        'Return Values: None
        'Purpose      : This function terminates all the sessions left unended
        '
        'Other relevant sources: None
        '     
        'Author            : Nagodaya Bhaskar KR
        'Created Date      : 07/04/2004    
        'Last Modified Date: 00/00/0000
        'Modification Log  :
        'Author                 Date           Reason
        '-------------------------------------------------------------------------------------------------
        '*************************************************************************************************
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This function terminates all the sessions left unended
        ' </summary>
        ' <returns> Int16 </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Nagodaya Bhaskar KR]   07/04/2004   Created
        ' 	    [Ram R]	                15/06/2005	 Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        'Public Shared Function TerminateLeftOverSessions() As Int16
        '    Try
        '        Return clsDalECSessionDat.TerminateLeftOverSessions()
        '    Catch ex As Exception
        '        Throw
        '    Finally
        '    End Try
        'End Function

        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This procedure is used to get the active session ID of the active account of the supplied user ID
        ' </summary>
        ' <param name="intUsrID"> Retrieves the Session_ID value for the logged in user</param>
        ' <returns> </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]   01/08/2005   Created
        ' 	    [Suneetha B]   01/08/2005   Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function GetActiveSessionIDoftheUser(ByVal intUsr_ID As Int32) As String
            Dim objECsessionDan As clsDalEcSessionDan
            Try
                objECsessionDan = New clsDalEcSessionDan
                Return objECsessionDan.GetActiveSessionIDoftheUser(intUsr_ID)
            Catch ex As Exception
                Throw
            Finally
                objECsessionDan = Nothing
            End Try


        End Function

        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This procedure is used to know the user session has expired or not
        ' </summary>
        ' <param name="strSessionID">  Session_ID of the logged in user</param>
        ' <returns>Boolean </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]   12/08/2005   Created
        ' 	    [Suneetha B]   12/08/2005   Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------

        Public Function IsUserSessionExpired(ByVal strSessionID As String) As Boolean
            Dim objECsessionDan As clsDalEcSessionDan
            Try
                objECsessionDan = New clsDalEcSessionDan
                Return objECsessionDan.IsUserSessionExpired(strSessionID)
            Catch ex As Exception
                Throw
            Finally
                objECsessionDan = Nothing
            End Try
        End Function

        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This procedure is used to get the active session ID of the active account of the supplied user ID
        ' </summary>
        ' <param name="intUsrID"> Retrieves the Session_IDs value for the logged in user</param>
        ' <returns>Dataset </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [K Bhavani]   18/11/2005   Created
        ' 	    [K Bhavani]   18/11/2005   Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function GetActiveSessionIDsoftheUser(ByVal intUsr_ID As Int32) As DataSet
            Dim objECsessionDan As clsDalEcSessionDan
            Try
                objECsessionDan = New clsDalEcSessionDan
                Return objECsessionDan.GetActiveSessionIDsoftheUser(intUsr_ID)
            Catch ex As Exception
                Throw
            Finally
                objECsessionDan = Nothing
            End Try
        End Function

        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This procedure is used to get the active session ID of the active account of the supplied user ID
        ' </summary>
        ' <param name="intUsrID"> Retrieves the Session_IDs value for the logged in user</param>
        ' <returns>Dataset </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [K Bhavani]   18/11/2005   Created
        ' 	    [K Bhavani]   18/11/2005   Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function GetActiveSessionIDsCountByUserID(ByVal intUsr_ID As Int32) As String
            Dim objECsessionDan As clsDalEcSessionDan
            Try
                objECsessionDan = New clsDalEcSessionDan
                Return objECsessionDan.GetActiveSessionIDsCountByUserID(intUsr_ID)
            Catch ex As Exception
                Throw
            Finally
                objECsessionDan = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This function is used to end the session that has already active and deletes the Sessiondata of already active sessions
        ' </summary>
        ' <param name="strSession_ID"> Retrieves the Session_ID value for the logged in user</param>
        ' <returns> </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [K.Bhavani]   18/11/2005   Created
        ' 	    [K.Bhavani]	  18/11/2005   Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Sub EndActiveSessionsByUserID(ByVal lngUser_ID As Int64)
            Try
                clsDalECSessionDat.EndActiveSessionsByUserID(lngUser_ID)
            Catch ex As Exception
                Throw
            Finally
            End Try
        End Sub
        'Author            : Nagodaya Bhaskar KR
        'Created Date      : 25/02/2004    
        'Last Modified Date: 00/00/0000
        'Modification Log  :
        'Author                 Date           Reason
        '-----------------------------------------------------------------------------------------------
        'Nagodaya Bhaskar KR    26/03/2004     Added exception handling
        '***********************************************************************************************
        ' -----------------------------------------------------------------------------
        ' <summary>
        '      This function  validates a username/password pair against credentials Stored in the users database.        ' </summary>
        ' <param name="strLoginName"> To get the LoginName of the user</param>
        ' <param name="strPassword">to authenticate login based on the credentials supplied </param>
        ' <returns> DataSet </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Nagodaya Bhaskar KR]   25/02/2004    Created
        '      [Nagodaya Bhaskar KR]   26/03/2004    Last Modified Date. Reason: Added exception handling
        ' 	   [Ram R]	               15/06/2005	 Added Comments
        '       [Narendra]               24/07/2006  moved from clsbizlogin and also added few queries to get the data required for pageload.
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Function AuthenticateLogin(ByVal strLoginName As String, ByVal strPassword As String, Optional ByVal strModuleIDs As String = "", Optional ByVal strSysDefaults As String = "", Optional ByVal strFailedLogins As String = "") As DataSet
            Try
                Return clsDalEcSessionDan.AuthenticateLogin(strLoginName, strPassword, strModuleIDs, strSysDefaults, strFailedLogins)
            Catch ex As Exception
                Throw
            Finally
            End Try
        End Function 'AuthenticateLogin
        ' -----------------------------------------------------------------------------
        ' <summary>
        '      To Get User Security Questions
        ' </summary>
        ' <param name="intSecUserid"> User ID</param>
        ' <returns> DataSet </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [UdayKirna A]   24/02/2016     Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Function GetUserSecurityQuestions(intSecUserid As Integer) As DataSet
            Dim objDal As clsDalEcSessionDan
            Try
                objDal = New clsDalEcSessionDan
                Return objDal.GetUserSecurityQuestions(intSecUserid)
            Catch ex As Exception
                Throw
            Finally
                objDal = Nothing
            End Try
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '      To Authenticate Secondary Login Details
        ' </summary>
        ' <param name="srtuserId"> User ID</param>
        ' <param name="strQuestion">  Question</param>
        ' <param name="stranswer">   answer</param>
        ' <returns> String </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [UdayKirna A]   24/02/2016     Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Function AuthenticateSecondaryLogin(ByVal srtuserId As Integer, ByVal strQuestion As Integer, ByVal stranswer As String) As String
            Dim objDal As clsDalEcSessionDan
            Try
                objDal = New clsDalEcSessionDan
                Return objDal.AuthenticateSecondaryLogin(srtuserId, strQuestion, stranswer)
            Catch ex As Exception
                Throw
            Finally
                objDal = Nothing
            End Try
        End Function

        Public Shared Function RecordInvalidAnswerCount(ByVal UserId As Integer)
            Dim objDal As clsDalEcSessionDan
            Try
                objDal = New clsDalEcSessionDan
                Return objDal.RecordInvalidAnswerCount(UserId)
            Catch ex As Exception
                Throw
            Finally
                objDal = Nothing
            End Try
        End Function
     ' -----------------------------------------------------------------------------
        ' <summary>
        '      To Get the user HBID
        ' </summary>
        ' <param name="lngUserId"> User ID</param>
        ' <returns> integer </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Suneetha B]   06/10/2006     Created
        ' </history>
        ' -----------------------------------------------------------------------------

        Public Function GetUserHealthBoardID(ByVal lngUserId As Long) As Integer
            Dim objclsDalEcSessionDan As Excelicare.Dal.Login.clsDalEcSessionDan
            Try
                objclsDalEcSessionDan = New Excelicare.Dal.Login.clsDalEcSessionDan
                Return objclsDalEcSessionDan.GetUserHealthBoardID(lngUserId)
            Catch ex As Exception
                Throw
            Finally
                objclsDalEcSessionDan = Nothing

            End Try
        End Function

        ' -----------------------------------------------------------------------------
        ' <summary>
        '      To check the DB Connection
        ' </summary>
        '  <returns> Boolean </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Mallika]   06/10/2006     Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function IsDBConnectionActive() As Boolean
            Dim objclsDalEcSessionDan
            Try
                objclsDalEcSessionDan = New Excelicare.Dal.Login.clsDalEcSessionDan
                Return objclsDalEcSessionDan.IsDBConnectionActive()
            Catch ex As Exception
                Throw
            Finally
                objclsDalEcSessionDan = Nothing
            End Try
        End Function
        ''Protected Overrides Sub Finalize()
        ''    _Session_ID = Nothing
        ''    MyBase.Finalize()
        ''End Sub
        ' -----------------------------------------------------------------------------
        ' <summary>
        '     whether to prompt the new user for the pwd change in Login or not 
        ' </summary>
        '<param Name="lngUserId"> user ID as long</param>
        ' <returns> Boolean </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Suneetha B]   21/11/2006     Created
        ' </history>
        ' -----------------------------------------------------------------------------


        Public Function IsPasswordPromptRequired(ByVal lngUserId As Long) As Boolean
            '   Dim objClsDalLoginDan As AxSys.Dal.Login.clsDalLoginDan
            Dim objClsDalLoginDan As Excelicare.Dal.Login.clsDalEcSessionDan
            Try
                '    objClsDalLoginDan = New AxSys.Dal.Login.clsDalLoginDan
                objClsDalLoginDan = New Excelicare.Dal.Login.clsDalEcSessionDan

                Return objClsDalLoginDan.IsPasswordPromptRequired(lngUserId)
            Catch ex As Exception
                Throw
            Finally
                objClsDalLoginDan = Nothing
            End Try

        End Function

        ' -----------------------------------------------------------------------------
        ' <summary>
        '    Used to check the user password has expired or not 
        ' </summary>
        '<param Name="lngUserId"> user ID as long</param>
        ' <returns> Boolean </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Suneetha B]   21/11/2006     Created
        ' </history>
        ' -----------------------------------------------------------------------------

        Public Function IsPasswordExpired(ByVal lngUserId As Long, ByVal strPwd As String) As Boolean
            '' Dim objClsDalLoginDan As AxSys.Dal.Login.clsDalLoginDan
            Dim objClsDalLoginDan As Excelicare.Dal.Login.clsDalEcSessionDan

            Try
                ''  objClsDalLoginDan = New AxSys.Dal.Login.clsDalLoginDan
                objClsDalLoginDan = New Excelicare.Dal.Login.clsDalEcSessionDan

                Return objClsDalLoginDan.IsPasswordExpired(lngUserId, strPwd)

            Catch ex As Exception
                Throw
            Finally
                objClsDalLoginDan = Nothing
            End Try
        End Function

        ' -----------------------------------------------------------------------------
        ' <summary>
        '     whether to prompt the user for the pwd expiry
        ' </summary>
        '<param Name="lngUserId"> user ID as long</param>
        ' <returns> Boolean </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Suneetha B]   21/11/2006     Created
        ' </history>
        ' -----------------------------------------------------------------------------

        Public Function IsForcePasswordChange(ByVal lngUserId As Long) As Boolean
            '''Dim objClsDalLoginDan As AxSys.Dal.Login.clsDalLoginDan
            Dim objClsDalLoginDan As Excelicare.Dal.Login.clsDalEcSessionDan

            Try
                ''objClsDalLoginDan = New AxSys.Dal.Login.clsDalLoginDan
                objClsDalLoginDan = New Excelicare.Dal.Login.clsDalEcSessionDan

                Return objClsDalLoginDan.IsForcePasswordChange(lngUserId)

            Catch ex As Exception
                Throw
            Finally
                objClsDalLoginDan = Nothing
            End Try
        End Function

        ' -----------------------------------------------------------------------------
        ' <summary>
        '    Used to get the remaining days for the user pwd to be expired 
        ' </summary>
        '<param Name="lngUserId"> user ID as long</param>
        ' <returns> Boolean </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Suneetha B]   21/11/2006     Created
        ' </history>
        ' -----------------------------------------------------------------------------

        Public Function GetRemainingDaysToExpirePwd(ByVal lngUserId As Long, ByVal strPwd As String) As Integer
            '''Dim objClsDalLoginDan As AxSys.Dal.Login.clsDalLoginDan
            Dim objClsDalLoginDan As Excelicare.Dal.Login.clsDalEcSessionDan

            Try
                ''''objClsDalLoginDan = New AxSys.Dal.Login.clsDalLoginDan
                objClsDalLoginDan = New Excelicare.Dal.Login.clsDalEcSessionDan

                Return objClsDalLoginDan.GetRemainingDaysToExpirePwd(lngUserId, strPwd)

            Catch ex As Exception
                Throw
            Finally
                objClsDalLoginDan = Nothing
            End Try
        End Function


        ' -----------------------------------------------------------------------------
        ' <summary>
        '    Used to get the User Details of a User
        ' </summary>
        '<param Name="strMID"> Module IDs as String</param>
        '<param Name="intUserId"> user ID as Integer</param>
        ' <returns> Boolean </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [PVP Mohan]   20/01/2007     Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Function GetUserDetails(ByVal strMID As String, ByVal intUserId As Integer) As DataSet

            Try

                Return clsDalEcSessionDan.GetUserDetails(strMID, intUserId)
            Catch ex As Exception
                Throw
            Finally
            End Try
        End Function

        ' -----------------------------------------------------------------------------
        ' <summary>
        '   This function inserts data into tblSHCFailedLoginData table
        ' </summary>
        '<param Name="strMachineName"> Machine Name as String</param>
        '<param Name="strMachineIP"> Machine IP as Integer</param>
        '<param Name="strLoginNameGiven"> LoginName as String</param>
        '<param Name="strSHCSettings"> SHCSettings as String</param>
        ' <returns> int16 </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Manohar]   10/05/2008     Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function fnInsertSHCFailedLoginData(ByVal strMachineName As String, ByVal strMachineIP As String, _
            ByVal strLoginNameGiven As String, ByVal strSHCSettings As String) As Int16
            Dim objECsessionDat As clsDalECSessionDat
            objECsessionDat = New clsDalECSessionDat
            Try
                Return objECsessionDat.fnInsertSHCFailedLoginData(strMachineName, strMachineIP, strLoginNameGiven, strSHCSettings)
            Catch ex As Exception
                Throw
            Finally
                objECsessionDat = Nothing
            End Try
        End Function
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[madhavi]	10/07/2008	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetGUID() As String
            Dim objClsDalLoginDan As clsDalEcSessionDan
            Try
                objClsDalLoginDan = New clsDalEcSessionDan
                Return objClsDalLoginDan.GetGUID()
            Catch ex As Exception
                Throw ex
            Finally
                objClsDalLoginDan = Nothing
            End Try
        End Function
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="strGUID"></param>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[madhavi]	10/07/2008	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function IsGUIDActive(ByVal strGUID As String) As String
            Dim objClsDalLoginDan As clsDalEcSessionDan
            Try
                objClsDalLoginDan = New clsDalEcSessionDan
                Return objClsDalLoginDan.IsGUIDActive(strGUID)
            Catch ex As Exception
                Throw ex
            Finally
                objClsDalLoginDan = Nothing
            End Try
        End Function
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="lgnUSerID"></param>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[madhavi]	10/07/2008	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        'Public Function IsOfflineDBAdmin(ByVal lgnUSerID As Long) As Int16
        '    Dim objClsDalLoginDan As clsDalEcSessionDan
        '    Try
        '        objClsDalLoginDan = New clsDalEcSessionDan
        '        Return objClsDalLoginDan.IsOfflineDBAdmin(lgnUSerID)
        '    Catch ex As Exception
        '        Throw ex
        '    Finally
        '        objClsDalLoginDan = Nothing
        '    End Try
        'End Function

        Public Function InsertSHCSessionLog(ByVal strSessionID As String, _
                                      ByVal strIEVersion As String, ByVal strCookiesEnabled As String, _
                                      ByVal strScreenResol As String, ByVal strOSVersion As String, ByVal strTextSize As String, _
                                      ByVal strTrustedSites As String, ByVal strDAX As String, ByVal strApac As String, ByVal strDsac As String, _
                                      ByVal strRacp As String, ByVal strSacmss As String, ByVal strFD As String, ByVal strAmr As String, _
                                      ByVal strActiveScript As String, ByVal strActiveXInstalled As String, ByVal strAdobeReader As String, _
                                      ByVal strMsExcel As String, ByVal strMsxml As String, ByVal strRWTempFolder As String, _
                                      ByVal strRWTempFile As String) As Int32
            Dim objClsDalLoginDat As clsDalECSessionDat
            Try
                objClsDalLoginDat = New clsDalECSessionDat
                Return objClsDalLoginDat.InsertSHCSessionLog(strSessionID, strIEVersion, strCookiesEnabled, strScreenResol, strOSVersion, strTextSize, _
                                                      strTrustedSites, strDAX, strApac, strDsac, strRacp, strSacmss, strFD, strAmr, _
                                                      strActiveScript, strActiveXInstalled, strAdobeReader, strMsExcel, strMsxml, _
                                                      strRWTempFolder, strRWTempFile)
            Catch ex As Exception
                Throw ex
            Finally
                objClsDalLoginDat = Nothing
            End Try
        End Function

        Public Function GetUserLocations(ByVal lngUserID As Long) As DataTable
            Dim objClsDalLoginDat As New clsDalEcSessionDan
            Return objClsDalLoginDat.GetUserLocations(lngUserID)
            objClsDalLoginDat = Nothing
        End Function
        Public Function GetSysBroadcastDetails() As String
            Dim objClsDalLoginDat As New clsDalEcSessionDan
            Return objClsDalLoginDat.GetSysBroadcastDetails().GetXml()
            objClsDalLoginDat = Nothing
        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        ' fnECMappingSsoUID
        ' </summary>
        ' <param name="intSecUserid"> User ID</param>
        ' <returns> Long </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [UdayKirna A]   01/06/2017     Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Function fnECMappingSsoUID(ByVal strUid As String, ByVal int64UserID As Integer) As Long
            Dim objDal As clsDalEcSessionDan
            Try
                objDal = New clsDalEcSessionDan
                Return objDal.fnECMappingSsoUID(strUid, int64UserID)
            Catch ex As Exception
                Throw
            Finally
                objDal = Nothing
            End Try
        End Function
        'Purpose         :To Save user entry in tbluserdisclaimer table
        'Method Name     : fnSaveDisclaimer
        'InputParameter  : UserId , DisclaimerIds
        'Output Parameter: --
        'Created By      : Narendra Chary --26/08/2019
        'Modified By     :

        Public Function fnSaveDisclaimer(ByVal userId As Int64, ByVal DisclaimerIds As String) As String
            Dim objclsDalEcSessionDan As New clsDalEcSessionDan
            Try
                objclsDalEcSessionDan.fnSaveDisclaimer(userId, DisclaimerIds)
            Catch ex As Exception
                Throw
            Finally
                objclsDalEcSessionDan = Nothing
            End Try
        End Function

        'Purpose         :To get Disclaimer text
        'Method Name     : GetDisclaimers
        'InputParameter  : UserId, DisclaimerId
        'Output Parameter: Disclaimer text as String
        'Created By      : Narendra Chary --26/08/2019
        'Modified By     :

        Public Function GetDisclaimers(ByVal lngUserID As Int32, ByVal intDisclaimerID As Int32) As String
            Dim objClsUserDan As clsDalEcSessionDan
            Try
                objClsUserDan = New clsDalEcSessionDan
                Return objClsUserDan.GetDisclaimers(lngUserID, intDisclaimerID)
            Catch ex As Exception
                Throw
            Finally
                objClsUserDan = Nothing
            End Try
        End Function

        'Purpose         :To get UserDisclaimer status
        'Method Name     : GetDisclaimerStatus
        'InputParameter  : UserId
        'Output Parameter: status
        'Created By      : Narendra Chary --26/08/2019
        'Modified By     :

        Public Function GetDisclaimerStatus(ByVal lngUserID As Int32) As DataSet
            Dim objClsUserDan As clsDalEcSessionDan
            Try
                objClsUserDan = New clsDalEcSessionDan
                Return objClsUserDan.GetDisclaimerStatus(lngUserID)
            Catch ex As Exception
                Throw
            Finally
                objClsUserDan = Nothing
            End Try
        End Function
        'Purpose         :To Get Credentials of user
        'Method Name     : GetUserCredentials
        'InputParameter  : userId
        'Output Parameter: UserName and Password
        'Created By      : Ashok
        'Modified By     :
        Public Function GetUserCredentials(ByVal UserId As Integer) As DataSet
            Dim objDal As clsDalEcSessionDan
            Try
                objDal = New clsDalEcSessionDan
                Return objDal.GetUserCredentials(UserId)
            Catch ex As Exception
                Throw
            Finally
                objDal = Nothing
            End Try
        End Function
        'Purpose         :To check Valid username
        'Method Name     : validUserName
        'InputParameter  : userName
        'Output Parameter: ValidUser and Failedcount
        'Created By      : Ashok
        'Modified By     :
        Public Function validUserName(ByVal usrName As String, ByVal Reason_Lu As Long) As ArrayList
            Dim objClsUserDan As clsDalEcSessionDan
            Try
                objClsUserDan = New clsDalEcSessionDan
                Return objClsUserDan.validUserName(usrName, Reason_Lu)
            Catch ex As Exception
                Throw
            Finally
                objClsUserDan = Nothing
            End Try
        End Function
		'Purpose         :To SaveQRcode
        'Method Name     : SaveQRcode
        'InputParameter  : lnguserId,setting,QRCode
        'Output Parameter: To save QRCode for the current User.
        'Created By      : seshukumar
        'Modified By     :
        Public Function SaveQRcode(ByVal lnguserId As Long, ByVal setting As String, ByVal QRCode As String) As String
            Dim objECsessionDat As clsDalECSessionDat
            Try
                objECsessionDat = New clsDalECSessionDat
                Return objECsessionDat.SaveQRCode(lnguserId, setting, QRCode)
            Catch ex As Exception
                Throw ex
            End Try
        End Function
    End Class
End Namespace