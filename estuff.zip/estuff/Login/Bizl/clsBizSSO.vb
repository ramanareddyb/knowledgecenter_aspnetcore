﻿Option Explicit On

Imports Excelicare.Framework.AppSupport
Imports Excelicare.ServiceProxy
Imports System.Xml
Imports System.Xml.Linq
Imports Excelicare.Bizl.ExternalService
Imports Excelicare.Dal.Login

Namespace Excelicare.Bizl.Login
    Public Class clsBizSSO
        Dim objSSOProxy As AxRSSSOClient
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' This function authenticates external application request
        ''' </summary>
        ''' <param name="strRequestMessage"></param>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function AuthenticateToken(ByVal strRequestMessage As String) As String
            Dim strReturn As String = ""
            Try
                objSSOProxy = New AxRSSSOClient
                strReturn = objSSOProxy.AuthenticateToken(strRequestMessage)
                objSSOProxy.Close()
                Return strReturn
            Catch ex As Exception
                Throw ex
                'LogException(ex)
                strReturn = "<methodResponse><fault><value><struct><member><name>faultCode</name><value><int> 200 </int></value></member><member><name>faultString</name><value<string> Invalid Syntax </string></value></member></struct></value></fault></methodResponse>"
            Finally
                If objSSOProxy.State <> ServiceModel.CommunicationState.Closed Then
                    objSSOProxy.Abort()
                End If
                objSSOProxy = Nothing
            End Try
            Return strReturn
        End Function
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' This function fetches patient ID from identifier value
        ''' </summary>
        ''' <param name="strMbrNO"></param>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function fnGetPatientBYMbrNo(ByVal strMbrNO As String) As Long
            Dim strPatientID As String = "0"
            Try
                objSSOProxy = New AxRSSSOClient
                strPatientID = objSSOProxy.GetPatientBYIdentifier(strMbrNO)
                objSSOProxy.Close()
            Catch ex As Exception
                Throw ex
                'LogException(ex)
            Finally
                If objSSOProxy.State <> ServiceModel.CommunicationState.Closed Then
                    objSSOProxy.Abort()
                End If
                
                objSSOProxy = Nothing
            End Try
            Return CLng(strPatientID)
        End Function
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' This function stores partner token into EC DB
        ''' </summary>
        ''' <param name="strGUID"></param>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function SaveParterToken(ByVal strPartnerTokenXML As String) As String
            Dim strReturnValue As String = "0"
            Try
                objSSOProxy = New AxRSSSOClient
                strReturnValue = objSSOProxy.SavePartnerToken(strPartnerTokenXML)
                objSSOProxy.Close()
            Catch ex As Exception
                Throw ex
                'LogException(ex)
            Finally
                If objSSOProxy.State <> ServiceModel.CommunicationState.Closed Then
                    objSSOProxy.Abort()
                End If
                objSSOProxy = Nothing
            End Try
            Return strReturnValue
        End Function
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' This function requests partner token
        ''' </summary>
        ''' <param name="strGUID"></param>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[madhavi]	10/07/2008	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function RequestPartnerToken(ByVal strError As String, ByVal strUserName As String, ByVal strPassWord As String) As String
            'Dim objMMMProxy As HUBSSOPersistenceService.MMMHubSSOClient
            Dim objExternalService As clsExternalServiceConnectivity
            Dim strReturnValue As String = ""
            Dim strInputData As String
            Try
                'objMMMProxy = New HUBSSOPersistenceService.MMMHubSSOClient
                'strReturnValue = objMMMProxy.RequestToken(strError, strUserName, strPassWord)
                objExternalService = New clsExternalServiceConnectivity
                strInputData = "<ExternalServiceConnectivity><MethodName>RequestPartnerToken</MethodName><Params>" & _
                                "<Error>" & strError & "</Error>" & _
                                "<UserName>" & strUserName & "</UserName>" & _
                                "<PassWord>" & strPassWord & "</PassWord>" & _
                                "</Params></ExternalServiceConnectivity>"
                strReturnValue = objExternalService.AccessExternalService(strInputData)

                ''strReturnValue = "<methodResponse><params><param><value><string>test 123 partnertoken</string></value></param><param><value><dateTime.iso8601>2012/08/13</dateTime.iso8601></value></param></params></methodResponse>"
            Catch ex As Exception
                'LogException(ex)
                Throw ex
            Finally
                'objMMMProxy.Close()
                'objMMMProxy = Nothing
                objExternalService = Nothing
            End Try
            Return strReturnValue
        End Function
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' This function requests partner to get artifact details
        ''' </summary>
        ''' <param name="strGUID"></param>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function RetrieveArtifact(ByVal strError As String, ByVal strTokenID As String, ByVal strArtifactID As String) As String
            'Dim objMMMProxy As HUBSSOPersistenceService.MMMHubSSOClient
            Dim objExternalService As clsExternalServiceConnectivity
            Dim strReturnValue As String = ""
            Dim strInputData As String
            Try
                'objMMMProxy = New HUBSSOPersistenceService.MMMHubSSOClient
                'strReturnValue = objMMMProxy.RetrieveArtifact(strError, strTokenID, strArtifactID)
                ''strReturnValue = "<response><type>login.selectMember</type><content><user><username>admin</username></user><member><memberid>123</memberid><MPI>123456</MPI><dob></dob><address></address><city></city><state></state><zip></zip><phone></phone></member></content></response>"
                objExternalService = New clsExternalServiceConnectivity
                strInputData = "<ExternalServiceConnectivity><MethodName>RetrieveArtifact</MethodName><Params>" & _
                                "<Error>" & strError & "</Error>" & _
                                "<TokenID>" & strTokenID & "</TokenID>" & _
                                "<ArtifactID>" & strArtifactID & "</ArtifactID>" & _
                                "</Params></ExternalServiceConnectivity>"
                strReturnValue = objExternalService.AccessExternalService(strInputData)
            Catch ex As Exception
                'LogException(ex)
                Throw ex
            Finally
                'objMMMProxy.Close()
                'objMMMProxy = Nothing
                objExternalService = Nothing
            End Try
            Return strReturnValue
        End Function
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' This function requests partner token
        ''' </summary>
        ''' <param name="strGUID"></param>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[madhavi]	10/07/2008	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function PartnerRequestToken(ByVal strRequestMessage As String, ByRef strOutputMessage As String, ByVal strPartnerServiceURL As String) As String
            'This method is used for eRx-SSO functionality
            Dim strReturnValue As String = ""
            Dim objExternalService As clsExternalServiceConnectivity
            Dim strInputData As String
            'Dim objTURecordProxy As SSOPartner.Partner_SSOClient
            Try
                'objTURecordProxy = New SSOPartner.Partner_SSOClient
                'objTURecordProxy.Endpoint.Address = New ServiceModel.EndpointAddress(strPartnerServiceURL)
                'strReturnValue = objTURecordProxy.PartnerRequestToken(strRequestMessage)
                objExternalService = New clsExternalServiceConnectivity
                strInputData = "<ExternalServiceConnectivity><MethodName>PartnerRequestToken</MethodName><Params>" & _
                                "<RequestMessage>" & strRequestMessage & "</RequestMessage>" & _
                                "<PartnerServiceURL>" & strPartnerServiceURL & "</PartnerServiceURL>" & _
                                "</Params></ExternalServiceConnectivity>"
                strReturnValue = objExternalService.AccessExternalService(strInputData)
                strOutputMessage = strReturnValue
            Catch ex As Exception
                'LogException(ex)
                Throw ex
            Finally
                'objTURecordProxy.Close()
                'objTURecordProxy = Nothing
            End Try
            Return strReturnValue
        End Function
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' This function requests partner to get artifact details
        ''' </summary>
        ''' <param name="strGUID"></param>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function RetrievePartnerArtifact(ByRef strError As String, ByVal strToken As String, ByVal strArtefactId As String, ByVal strPartnerServiceURL As String) As String
            'This method is used for eRx-SSO functionality
            Dim strReturnValue As String = ""
            'Dim objTURecordProxy As SSOPartner.Partner_SSOClient
            Dim objExternalService As clsExternalServiceConnectivity
            Dim strOutputMessage As String = String.Empty
            Dim objXelement As XElement
            Dim strInputData As String
            Try
                'objTURecordProxy = New SSOPartner.Partner_SSOClient
                'strInputMessage = "<RetrieveArtifact>" & _
                '                      "<Token>" & strToken & "</Token>" & _
                '                      "<PartnerArtifactID>" & strArtefactId & "</PartnerArtifactID>" & _
                '                  "</RetrieveArtifact>"
                'objTURecordProxy.Endpoint.Address = New ServiceModel.EndpointAddress(strPartnerServiceURL)
                'strReturnValue = objTURecordProxy.PartnerRetrieveArtifact(strInputMessage)

                objExternalService = New clsExternalServiceConnectivity
                strInputData = "<ExternalServiceConnectivity><MethodName>RetrievePartnerArtifact</MethodName><Params>" & _
                                "<Error>" & strError & "</Error>" & _
                                "<AETokenID>" & strToken & "</AETokenID>" & _
                                "<PartnerServiceURL>" & strPartnerServiceURL & "</PartnerServiceURL>" & _
                                "</Params></ExternalServiceConnectivity>"
                strReturnValue = objExternalService.AccessExternalService(strInputData)



                If strOutputMessage.Length > 0 Then
                    objXelement = XElement.Parse(strOutputMessage)
                    strError = objXelement...<ErrorDescription>.Value
                End If
                'strReturnValue = strOutputMessage
                ''strReturnValue = "<response><type>login.selectMember</type><content><user><username>admin</username></user><member><memberid>123</memberid><MPI>123456</MPI><dob></dob><address></address><city></city><state></state><zip></zip><phone></phone></member></content></response>"
            Catch ex As Exception
                'LogException(ex)
                Throw ex
            Finally
                'objTURecordProxy.Close()
                'objTURecordProxy = Nothing
                objXelement = Nothing
            End Try
            Return strReturnValue
        End Function
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' This function checks user details passed by external application
        ''' </summary>
        ''' <param name="strGUID"></param>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function fnValidateUser(ByVal strUserName As String, ByVal strVendorKey As String, ByRef lngUserID As Long, ByRef lngLocationID As Long, ByRef strVendorError As String, ByVal strAxsysTokenID As String) As Boolean
            Dim objUserProxy As New AxRSUserManagerClient
            Dim objUSer As New clsUser
            Dim objPresProxy As New WSPrescriptionManager.AxWSePrescriptionInterfaceManagerClient
            'Dim objVendorXmlDoc As New XmlDocument
            Dim blnReturnValue As Boolean = False
            'Dim strReturnValue As String = ""
            Dim blnValidateEMRUser As Boolean
            Try
                objUSer = objUserProxy.GetUserDetailsBasedOnName(strUserName)
                objUserProxy.Close()

                If objUSer IsNot Nothing AndAlso objUSer.ID > 0 Then
                    lngUserID = objUSer.ID
                    lngLocationID = objUSer.LocationID
                    blnValidateEMRUser = Configuration.ConfigurationSettings.AppSettings("ValidateEMRUser")
                    If blnValidateEMRUser = True Then
                        blnReturnValue = objPresProxy.fnValidateEMRUser(strUserName, strAxsysTokenID)
                    Else
                        blnReturnValue = True
                    End If
                    objPresProxy.Close()
                    If blnReturnValue = False Then
                        strVendorError = "<ResponseMessage><Error><ErrorCode>100</ErrorCode><ErrorDescription>Invalid Data</ErrorDescription></Error></ResponseMessage>"
                    End If
                    'blnReturnValue = True
                    'strReturnValue = objPresProxy.ValidateVendor(strVendorKey)
                    'objPresProxy.Close()
                    'objVendorXmlDoc.LoadXml(strReturnValue)
                    'If Not objVendorXmlDoc.SelectSingleNode("PracticeLinkKey/Error") Is Nothing AndAlso objVendorXmlDoc.SelectSingleNode("PracticeLinkKey/Error").InnerText.Trim = "" Then
                    '    If Not objVendorXmlDoc.SelectSingleNode("PracticeLinkKey/LocId") Is Nothing Then
                    '        lngLocationID = objVendorXmlDoc.SelectSingleNode("PracticeLinkKey/LocId").InnerText
                    '        blnReturnValue = True
                    '    End If
                    'Else
                    '    If Not objVendorXmlDoc.SelectSingleNode("PracticeLinkKey/Error") Is Nothing Then
                    '        strVendorError = objVendorXmlDoc.SelectSingleNode("PracticeLinkKey/Error").InnerText.Trim
                    '    End If
                    'End If
                Else
                    blnReturnValue = False
                    strVendorError = "<ResponseMessage><Error><ErrorCode>100</ErrorCode><ErrorDescription>Invalid Data</ErrorDescription></Error></ResponseMessage>"
                End If
            Catch ex As Exception
                Throw ex
                'LogException(ex)
            Finally
                objUSer = Nothing
                'objPresProxy = Nothing
                'objPresProxy = Nothing
            End Try
            Return blnReturnValue
        End Function
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' This function validates eRx data
        ''' </summary>
        ''' <param name="strGUID"></param>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[Suresh]	10/07/2010	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function fnValidateEPresData(ByVal strArtifactXML As String, ByVal lngPatientID As Long, ByVal lngUserID As Long, ByVal lngLocationID As Long, ByVal strAxsysToken As String) As String
            Dim objPresProxy As New WSPrescriptionManager.AxWSePrescriptionInterfaceManagerClient
            Dim strReturnValue As String = ""
            Try
                strReturnValue = objPresProxy.ValidatePatientPrescriptionData(strArtifactXML, lngPatientID, lngUserID, lngLocationID, strAxsysToken)
                objPresProxy.Close()
            Catch ex As Exception
                'LogException(ex)
                strReturnValue = ex.Message
                Throw ex
            Finally
                objPresProxy = Nothing
            End Try
            Return strReturnValue
        End Function
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' This function authenticates external application request
        ''' </summary>
        ''' <param name="strGUID"></param>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[Suresh]	10/07/2010	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function AuthenticateToken_EMReRx(ByVal strInputXML As String) As String
            Dim objPresProxy As New WSPrescriptionManager.AxWSePrescriptionInterfaceManagerClient
            Dim strReturnValue As String = ""
            Try
                strReturnValue = objPresProxy.AuthenticateToken_EMReRx(strInputXML)
                objPresProxy.Close()
            Catch ex As Exception
                'LogException(ex)
                strReturnValue = ex.Message
                Throw ex
            Finally
                objPresProxy = Nothing
            End Try
            Return strReturnValue
        End Function

        'Private Sub LogException(ByVal objExcep As Exception)
        '    Dim objClsExceptionHandler As clsExceptionHandler
        '    Try
        '        objClsExceptionHandler = New clsExceptionHandler(objExcep)
        '        objClsExceptionHandler.LogException()
        '    Catch ex As Exception
        '        objClsExceptionHandler = New clsExceptionHandler(ex)
        '        objClsExceptionHandler.LogException()
        '    Finally
        '        objClsExceptionHandler = Nothing
        '    End Try

        'End Sub
        'Public Function GetUserDetailsBasedOnName(ByVal strUserName As String) As WSUserManager.clsUser
        '    Dim objUSer As New WSUserManager.clsUser
        '    Dim strCanTerminateSession As String = String.Empty
        '    Dim blnServiceClose As Boolean = False
        '    Dim objUserProxy As WSUserManager.AxRSUserManagerClient
        '    Try
        '        logECWebSessionAction(1, 0, "SSO -GetUserDetailsBasedOnName strUserName: " & strUserName)
        '        objUserProxy = New WSUserManager.AxRSUserManagerClient
        '        objUSer = objUserProxy.GetUserDetailsBasedOnName(strUserName)
        '        objUserProxy.Close()
        '        blnServiceClose = True
        '        logECWebSessionAction(1, 0, "SSO -fnStartEcSession objUser.ID: " & objUSer.ID)
        '        Return objUSer
        '    Catch ex As Exception
        '        Throw ex
        '        logECWebSessionAction(1, 0, "SSO -fnStartEcSession Exeption: " & ex.Message)
        '        Return Nothing
        '    Finally
        '        ' Clearing the objects after usage
        '        If blnServiceClose = False Then
        '            objUserProxy.Abort()
        '        End If
        '        objUserProxy = Nothing
        '    End Try
        'End Function
        Private Sub logECWebSessionAction(ByVal lngEventId As Long, ByVal lngPatId As Long, ByVal strEventDet As String)
            Try
                Excelicare.Framework.AppSupport.clsECSession.LogWebSessionAction("Excelicare Ace Biz Login ", Web.HttpContext.Current.Session.SessionID, lngPatId, lngEventId, strEventDet & " - Biz Login ", 1132, 0)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' This function is used to get UserId from UID and starts EC session when called from external application.
        ''' </summary>
        ''' <param name="UID"></param>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[Udaykiran]	23/05/2017	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function fnGetSSOUserDetails(ByVal UID As String, Optional RoleId As String = "") As String 'clsUser
            Dim objDal As clsDalEcSessionDan
            Dim strUserName As String
            Try
                objDal = New clsDalEcSessionDan
                Return objDal.fnGetSSOUserDetails(UID)
                'If strUserName <> Nothing And strUserName <> "" Then
                '    Return fnStartSSOEcSession(strUserName)
                'End If
            Catch ex As Exception
                Throw
            End Try
        End Function
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' This function starts EC session when called from external application.
        ''' </summary>
        ''' <param name="strGUID"></param>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[madhavi]	10/07/2008	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function fnStartSSOEcSession(ByVal strUserName As String, Optional ByVal strProviderName As String = "", Optional ByVal intSSOLOVLookupID As Int64 = 0) As clsUser
            Dim objClsECSession As clsECSession
            objClsECSession = New clsECSession
            Dim Session_ID As String
            Dim objUSer As New clsUser
            Dim objUserProxy As New AxRSUserManagerClient
            Dim IntSessionCount As Int16 = 0
            Dim objDalEcSession As clsDalEcSessionDan
            Dim host As System.Net.IPHostEntry
            Dim strMachineName As String
            Dim objClsSessionData As clsSessionData
            Dim objClsSessionManager As clsSessionManager

            logECWebSessionAction(1, 0, "SSO -fnStartEcSession strUserName: " & strUserName & " - strProviderName:" & strProviderName)
            Try
                If strUserName <> Nothing Then
                    If strProviderName <> "" Then
                        'objUSer = objUserProxy.GetUserDetailsBasedOnNPI(strProviderName)
                    Else
                        objUSer = objUserProxy.GetUserDetailsBasedOnName(strUserName)

                    End If














                    objDalEcSession = New clsDalEcSessionDan
                    IntSessionCount = objDalEcSession.IsSSOSessionExist(objUSer.ID)
                    If IntSessionCount > 0 Then
                        objUSer.ActiveSessionsCount = 2
                        Return objUSer
                    Else
                        'objBizlECSession = New clsBizlECSession
                        Session_ID = Web.HttpContext.Current.Session.SessionID     ''clsNavigation.GetSession_ID(Page.Session)

                        'Getting Request User Machine Name - Start



                        'From35
                        'If IsUserHBIDFailed(intUSRHBoard_ID) Then






                        '    Exit Sub
                        'End If
                        Try
                            host = System.Net.Dns.GetHostByAddress(Web.HttpContext.Current.Request.ServerVariables.Item("REMOTE_ADDR"))
                            strMachineName = host.HostName
                            If strMachineName.IndexOf(".") <> -1 Then
                                strMachineName = strMachineName.Substring(0, strMachineName.IndexOf("."))


                            End If
                            If strMachineName.Length > 0 Then
                                strMachineName = strMachineName.ToUpper
                            End If
                        Catch ex As Exception
                            strMachineName = Web.HttpContext.Current.Request.UserHostName
                        End Try
                        'Getting Request User Machine Name - End

                        If Not Session_ID Is String.Empty Then
                            objClsECSession.StartSession(objUSer.ID, Session_ID, strMachineName, Web.HttpContext.Current.Request.UserHostAddress, "", 0, intSSOLOVLookupID)
                            'StartSession(dsTemp.Tables("UserDetails").Rows(0), blnForcePasswordChange, blnISPASSWORDEXPIRED, intRemainderDays)
                        End If











                        'intIsOfflineOfficeAdmin = dsTemp.Tables("UserDetails").Rows(0)("IsOfflineDBAdmin")
                        'If intIsOfflineOfficeAdmin <> 0 Then
                        '    Session("IsOfflineDBAdmin") = "true"
                        'Else
                        '    Session("IsOfflineDBAdmin") = "false"
                        'End If







                        Try
                            objClsSessionData = New clsSessionData
                            objClsSessionData.IsSuperUser = objUSer.CanDelete 'drTemp("CanDelete")
                            objClsSessionData.LinkID = objUSer.ClinicianID 'drTemp("CLN_ID")
                            objClsSessionData.ShowInActiveRecords = objUSer.ShowInActiveRecords 'drTemp("ShowInActiveRecords")
                            objClsSessionData.TypeOfUser = objUSer.TypeOfUser 'drTemp("TypeOfUser")
                            objClsSessionData.UserForeName = objUSer.ForeName 'drTemp("Usr_ForeName")
                            objClsSessionData.UserID = objUSer.ID 'drTemp("Usr_ID")
                            objClsSessionData.UserSurName = objUSer.SurName 'drTemp("Usr_SurName")
                            objClsSessionData.UserSecurityLevel = objUSer.SecurityLevel 'drTemp("USR_SECURITY_LEVEL")
                            If Not IsDBNull(objUSer.TypeOfUser) AndAlso objUSer.TypeOfUser = 2 Then
                                objClsSessionData.PatientID = objUSer.ClinicianID
                            End If
                            If IsNothing(objUSer.AutoLogOffTime) = False Then
                                objClsSessionData.AutoLogOffTime = objUSer.AutoLogOffTime
                            End If
                            Dim objGlobalizationSection As System.Web.Configuration.GlobalizationSection
                            objGlobalizationSection = System.Configuration.ConfigurationManager.GetSection("system.web/globalization")
                            objClsSessionData.LanguageCode = objGlobalizationSection.UICulture.ToString
                            objClsSessionData.LanguageCode = ""
                            objClsSessionData.UAO_ECLoc_ID = intSSOLOVLookupID
                            objClsSessionManager = New clsSessionManager
                            objClsSessionManager.SetSessionData(Web.HttpContext.Current.Session.SessionID, "APPDATA", objClsSessionData)
                            logECWebSessionAction(1, 0, "SSO -fnStartEcSession objUser.ID: " & objUSer.ID)
                            Return objUSer
                        Catch ex As Exception
                            logECWebSessionAction(1, 0, "SSO -fnStartEcSession Exeption: " & ex.Message)
                            Throw ex
                        Finally
                            objClsSessionData = Nothing
                            objClsSessionManager = Nothing
                        End Try
                    End If

















































































                Else
                    Return objUSer
                End If
            Catch ex As Exception
                Throw ex
            End Try
        End Function
        Public Function fnGetSSOLocations(ByVal strSSOLOCASIDCode As String) As String 'clsUser
            Dim objDal As clsDalEcSessionDan
            Dim strUserName As String
            Try
                objDal = New clsDalEcSessionDan
                Return objDal.fnGetSSOLocations(strSSOLOCASIDCode)
            Catch ex As Exception
                Throw
            End Try
        End Function
    End Class
End Namespace