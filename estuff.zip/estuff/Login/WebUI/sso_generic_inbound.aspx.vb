﻿'Imports AxLibBizLogin
Imports Excelicare.ServiceProxy
Imports Excelicare.Framework.AppSupport
Imports System.Xml
Imports System.Configuration.ConfigurationManager
Imports Ajax
Imports Excelicare.Bizl.Login
Imports System.Xml.Linq

Partial Public Class sso_generic_inbound
    Inherits System.Web.UI.Page
    Public strUserLocatons As String = ""
    Public m_lngLocationCount = 0
    Public strModuleVersionNo As String = ""
    Public intShowLocationCombo As Integer = 0
    Public strMDIVirFolderName As String = "../AxWebUIMDI"
    Public strLoginVirFolderName As String = "../AxWebUILogin"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim objBizLogin As New clsBizlECSession

        Dim objUSer As New clsUser
        Dim strAccessTokenID As String
        Dim strPartnerID As String
        Dim strInputXML As String
        Dim strRetrunXML As String
        Dim strResponseStringXML As String
        Dim strUserName As String = String.Empty  ''Or UserID From AE
        Dim objAppSetttings As New clsAppSettings

        Dim objXmlDom As New System.Xml.XmlDocument
        Dim xmlNodesList As XmlNodeList
        Dim lngPatientID As Long
        Dim objBizSSO As New Excelicare.Bizl.Login.clsBizSSO
        Dim objRetXmlDOm As New System.Xml.XmlDocument
        Dim intOption As Short
        Dim strSysIPAdress As String
        Dim strRetriveArtifatXML As String = String.Empty
        Dim strMbrNO As String = String.Empty
        Dim strPartnerName As String
        Dim strPartnerPWD As String
        Dim strSSOPartnerID As String
        Dim strXMLNodeName As String
        Dim strRequsetToken As String
        Dim strinput, strAETokenID, strSaveReturn, strExpiryDate As String
        Dim strSaveTokenXML As String
        Dim strSSOPartnerService As String = String.Empty
        Dim strTokenError As String = ""
        Dim strArtifaceError As String = ""
        Dim blnSelectPatient As Boolean = False
        Dim strPartnerError As String = String.Empty
        Dim strPartnerCalledFrom As String = String.Empty
        'Dim objLocations As WSUserManager.clsLocation()
        Dim objClsAppSettings As clsAppSettings
        Dim intAlloweRx As Integer
        Dim strIseRxRequest As String
        Dim strDebug As String
        Dim strPartnerTokenResponse As String = String.Empty
        Dim objXElement As XElement
        Dim strPartnerServiceURL As String = String.Empty
        Dim dtLocations As DataTable
        Dim Session_ID As String
        Dim strProviderName As String = ""
        Dim strUid As String = ""
        Dim strSSOLOCASIDCode As String = ""
        Dim strType As String = ""
        Dim strSSOData As String = ""
        Dim intSSOLOVLookupID As Int64 = 0
        Dim strBypass As String = ""
        Dim objQueryParams As New NameValueCollection
        Dim objClsSecurity As New clsSecurity
        Try
            Response.Expires = -1
            Response.Cache.SetNoServerCaching()
            Response.Cache.SetAllowResponseInBrowserHistory(False)
            Response.CacheControl = "no-cache"
            Response.Cache.SetNoStore()
            Ajax.Utility.RegisterTypeForAjax(GetType(sso_generic_inbound))

            objClsAppSettings = New clsAppSettings
            strModuleVersionNo = objClsAppSettings.GetModuleVersion("1030")
            intShowLocationCombo = IIf(AppSettings("UserLocation") & "" = "0", 0, 1) 'Check for User locations
            If Not IsPostBack Then
                If Not Request.QueryString("strQPData") Is Nothing Then
                    objQueryParams = objClsSecurity.fnGetQueryParamData(Request.QueryString("strQPData"))
                Else
                    objQueryParams = Request.QueryString
                End If

                If objQueryParams.Item("T") <> "" Then
                    strAccessTokenID = objQueryParams.Item("T")
                Else
                    strAccessTokenID = Request.QueryString("T")
                End If

                If objQueryParams.Item("ID") <> "" Then
                    strPartnerID = objQueryParams.Item("ID")
                    strPartnerID = HttpUtility.HtmlEncode(strPartnerID)
                    Session("PartnerArtifactID") = strPartnerID
                Else
                    strPartnerID = Request.QueryString("ID")
                    strPartnerID = HttpUtility.HtmlEncode(strPartnerID)
                    Session("PartnerArtifactID") = strPartnerID
                End If

                If objQueryParams.Item("UID") <> "" Then
                    strUid = objQueryParams.Item("UID")
                    strUid = HttpUtility.HtmlEncode(strUid)
                    Session("strUid") = strUid
                Else
                    strUid = Request.QueryString("UID")
                    strUid = HttpUtility.HtmlEncode(strUid)
                    Session("strUid") = strUid
                End If
                'If Not Request.QueryString("RoleId") Is Nothing Then
                '    strRoleId = Request.QueryString("RoleId")
                '    strRoleId = HttpUtility.HtmlEncode(strRoleId)
                '    Session("strRoleId") = strRoleId
                'End If

                If objQueryParams.Item("LId") <> "" Then
                    strSSOLOCASIDCode = objQueryParams.Item("LId")
                    strSSOLOCASIDCode = HttpUtility.HtmlEncode(strSSOLOCASIDCode)
                Else
                    strSSOLOCASIDCode = Request.QueryString("LId")
                    strSSOLOCASIDCode = HttpUtility.HtmlEncode(strSSOLOCASIDCode)
                End If
                If objQueryParams.Item("Type") <> "" Then
                    strType = objQueryParams.Item("Type")
                    strType = HttpUtility.HtmlEncode(strType)
                    Session("strType") = strType
                Else
                    strType = Request.QueryString("Type")
                    strType = HttpUtility.HtmlEncode(strType)
                    Session("strType") = strType
                End If
                If objQueryParams.Item("e") <> "" Then
                    strIseRxRequest = objQueryParams.Item("e")
                Else
                    strIseRxRequest = Request.QueryString("e")
                End If
                If objQueryParams.Item("Type") Then
                    strBypass = objQueryParams.Item("Type")
                Else
                    strBypass = Request.QueryString("Type")
                End If
                If strBypass.ToUpper = "BYPASS" Then
                    If Not strUid Is Nothing Then
                        objUSer = New clsUser
                        logECWebSessionAction(2575, -1, "SSO-Excelicare User Login Details: UserID - " & strUid)
                        strSSOData = objBizSSO.fnGetSSOUserDetails(strUid)
                        intSSOLOVLookupID = objBizSSO.fnGetSSOLocations(strSSOLOCASIDCode)
                        If strSSOData <> Nothing And strSSOData <> "" Then
                            If strSSOData <> "User Inactivated" AndAlso intSSOLOVLookupID > 0 Then
                                objUSer = objBizSSO.fnStartSSOEcSession(strSSOData, "", intSSOLOVLookupID)
                            ElseIf strSSOData <> "User Inactivated" AndAlso intSSOLOVLookupID = 0 Then
                                logECWebSessionAction(2575, -1, "SSO- Locations not mapped to the User ")
                                Response.Write("<methodResponse><member><value><string>Locations not mapped to the User</string></value></member></methodResponse>")
                                Exit Sub
                            Else
                                logECWebSessionAction(2575, -1, "SSO-Excelicare User Login Fails")
                                Response.Write("<methodResponse><member><value><string>Invalid User</string></value></member></methodResponse>")
                                Exit Sub
                            End If
                        Else
                            logECWebSessionAction(2575, -1, "SSO-Excelicare User Login Fails")
                            'Response.Write("<methodResponse><member><value><string>Invalid Data Partner Does not exists</string></value></member></methodResponse>")
                            Response.Redirect(strLoginVirFolderName & "/frmSignon.aspx?UID=" + strUid + "&LID=" & intSSOLOVLookupID, True)
                            Exit Sub
                        End If
                    End If
                    If objUSer IsNot Nothing AndAlso objUSer.ID > 0 Then

                        Session("TempUserID") = objUSer.ID
                        Session("UserLocationID") = objUSer.LocationID
                        Session.Add("UserLoginName", strUserName)

                        If intShowLocationCombo = 1 Then
                            logECWebSessionAction(2037, -1, "SSO -GetUserLocations Begin strUserName:" & strUserName & " - Password :" & objUSer.Password)
                            objBizLogin = New clsBizlECSession
                            dtLocations = objBizLogin.GetUserLocations(objUSer.ID)
                            strUserLocatons = "<Locations>"
                            For Each row As DataRow In dtLocations.Rows
                                strUserLocatons = strUserLocatons & "<Loc>"
                                strUserLocatons = strUserLocatons & "<ID>" & row("ID") & "</ID>"
                                strUserLocatons = strUserLocatons & "<Name>" & row("Name") & "</Name>"
                                strUserLocatons = strUserLocatons & "<IsPrimary>" & row("IsPrimary") & "</IsPrimary>"
                                strUserLocatons = strUserLocatons & "</Loc>"
                                m_lngLocationCount = m_lngLocationCount + 1
                            Next
                            strUserLocatons = strUserLocatons & "</Locations>"

                            logECWebSessionAction(2037, -1, "SSO -GetUserLocations End strUserLocatons:" & strUserLocatons)
                        End If
                        logECWebSessionAction(2037, -1, "SSO -Excelicare ACE Login UserLogin Success")
                        If lngPatientID > 0 Then
                            AddPatient(lngPatientID)
                            If m_lngLocationCount > 1 Then
                                Exit Sub
                            End If
                            Session("SSOCalledFrom") = "SSO"
                            Response.Redirect(strMDIVirFolderName & "/frmExcelicareMDI.aspx?CalledFrom=SSO", False)
                        Else
                            If blnSelectPatient Then
                                logECWebSessionAction(1, 0, "SSO -Patient information is not available strMbrNO: " & strMbrNO & " lngPatientID:" & lngPatientID)
                                Response.Write("Patient information is not available")
                                Exit Try
                            Else
                                If m_lngLocationCount > 1 Then
                                    Exit Sub
                                End If
                                Session("SSOCalledFrom") = "SSO"
                                Response.Redirect(strMDIVirFolderName & "/frmExcelicareMDI.aspx?CalledFrom=SSO", True)
                            End If
                        End If
                    Else
                        'Response.Write("<methodResponse><member><value><string>Invalid Data Partner Does not exists</string></value></member></methodResponse>")
                        Response.Redirect(strLoginVirFolderName & "/frmSignon.aspx?UID=" + strUid, True)
                    End If
                    'objBizSSO.fnStartSSOEcSession()
                    Exit Sub
                End If
                If objQueryParams.Item("Option") <> "" Then
                    intOption = objQueryParams.Item("Option")
                Else
                    intOption = Request.QueryString("Option")
                End If
                If Not System.Web.Configuration.WebConfigurationManager.AppSettings("SSOTest") Is Nothing AndAlso System.Web.Configuration.WebConfigurationManager.AppSettings("SSOTest").ToUpper = "TRUE" Then
                    'RedirectToACEMDI() 
                    RedirectToACEMDI(intOption)
                    Exit Try
                End If
                strSSOPartnerService = System.Web.Configuration.WebConfigurationManager.AppSettings("SSOPartnerService")
                logECWebSessionAction(1, 0, "SSO - Authentocate Token strSSOPartnerService :" & strSSOPartnerService)
                strSysIPAdress = HttpContext.Current.Request.ServerVariables("REMOTE_ADDR") ''HttpContext.Current.Request.Url.Host
                logECWebSessionAction(1, 0, "SSO - strSysIPAdress :" & strSysIPAdress & " strPartnerID:" & strPartnerID)
                strInputXML = "<?xml version=""1.0""?><methodCall><methodName>partners.AccessToken</methodName><params><param><value><string>" & strAccessTokenID & "</string></value></param><param><value><string>" & "123" & "</string></value></param><param><value><string>" & strSysIPAdress & "</string></value></param></params></methodCall>"
                logECWebSessionAction(1, 0, "SSO - strInputXML" & strInputXML)
                ''strInputXML = HttpUtility.HtmlEncode(strInputXML)
                'strRetrunXML = objBizSSO.AuthenticateToken(strInputXML) 

                If strIseRxRequest <> "1" Then
                    strRetrunXML = objBizSSO.AuthenticateToken(strInputXML)
                Else
                    strInputXML = "<?xml version=""1.0""?><methodCall><methodName>partners.AccessToken</methodName><params><param><value><string>" & strAccessTokenID & "</string></value></param><param><value><string>" & "123" & "</string></value></param><param><value><string>" & strSysIPAdress & "</string></value></param><param><value><string>eRx</string></value></param></params></methodCall>"
                    strRetrunXML = objBizSSO.AuthenticateToken_EMReRx(strInputXML)
                End If
                'End
                logECWebSessionAction(1, 0, "SSO - Authenticated strRetrunXML: " & strRetrunXML)
                If strRetrunXML <> "" Then
                    objRetXmlDOm.LoadXml(strRetrunXML)
                    If Not objRetXmlDOm Is Nothing Then
                        If Not objRetXmlDOm.SelectSingleNode("methodResponse/params/param/value/Boolean") Is Nothing AndAlso objRetXmlDOm.SelectSingleNode("methodResponse/params/param/value/Boolean").InnerText.ToUpper = "TRUE" Then
                            ' strResponseStringXML = objBizSSO.RetrieveArtifact("<?xml version=""1.0""?><methodCall><methodName>ae.partners.retrieveArtifact</methodName><params><param><value><string>" & strAccessTokenID & "</string></value></param><param><value><string>" & strParterID & "</string></value></param></params></methodCall>", intOption)
                            Dim xmlhttp
                            strRequsetToken = objRetXmlDOm.SelectSingleNode("methodResponse/ssopartner/request").InnerText
                            strPartnerName = objRetXmlDOm.SelectSingleNode("methodResponse/ssopartner/name").InnerText
                            strPartnerPWD = objRetXmlDOm.SelectSingleNode("methodResponse/ssopartner/passwd").InnerText
                            strSSOPartnerID = objRetXmlDOm.SelectSingleNode("methodResponse/ssopartner/id").InnerText
                            strXMLNodeName = objRetXmlDOm.SelectSingleNode("methodResponse/ssopartner/nodename").InnerText
                            strAETokenID = objRetXmlDOm.SelectSingleNode("methodResponse/ssopartner/token").InnerText

                            If Not objRetXmlDOm.SelectSingleNode("methodResponse/ssopartner/source") Is Nothing Then
                                strPartnerCalledFrom = objRetXmlDOm.SelectSingleNode("methodResponse/ssopartner/source").InnerText
                            End If
                            If Not objRetXmlDOm.SelectSingleNode("methodResponse/ssopartner/AlloweRx") Is Nothing Then
                                intAlloweRx = objRetXmlDOm.SelectSingleNode("methodResponse/ssopartner/AlloweRx").InnerText
                            End If
                            If Not objRetXmlDOm.SelectSingleNode("methodResponse/ssopartner/PartnerServiceURL") Is Nothing Then
                                strPartnerServiceURL = objRetXmlDOm.SelectSingleNode("methodResponse/ssopartner/PartnerServiceURL").InnerText
                                strPartnerServiceURL = strPartnerServiceURL.Trim
                            End If
                            logECWebSessionAction(1, 0, "SSO - strPartnerPWD: " & strPartnerPWD)
                            If strRequsetToken.ToUpper = "TRUE" Then
                                If Right(strSSOPartnerService, 3).ToLower = "asp" Then
                                    logECWebSessionAction(1, 0, "SSO - Token Authentocated and call AE")
                                    ''strinpit = "<?xml version=""1.0""?><methodCall><methodName>ae.partners.requestToken</methodName><params><param><value><string>AxSysSSO</string></value></param><param><value><string>M@t@r3@atF!@at$##</string></value></param></params></methodCall>"
                                    strinput = "<?xml version=""1.0""?><methodCall><methodName>ae.partners.requestToken</methodName><params><param><value><string>" & strPartnerName & "</string></value></param><param><value><string>" & strPartnerPWD & "</string></value></param></params></methodCall>"
                                    xmlhttp = Server.CreateObject("MSXML2.ServerXMLHTTP60")
                                    xmlhttp.Open("POST", strSSOPartnerService, False)
                                    xmlhttp.setRequestHeader("Content-Type", "text/xml")
                                    xmlhttp.send(strinput)
                                    strResponseStringXML = xmlhttp.responsexml.xml
                                    xmlhttp = Nothing
                                    logECWebSessionAction(1, 0, "SSO -AE Token: " & strResponseStringXML)
                                Else
                                    logECWebSessionAction(1, 0, "SSO - Token Authentocated and call Partner Token strPartnerName:" & strPartnerName)
                                    ''strinput = "<?xml version=""1.0""?><methodCall><methodName>ae.partners.requestToken</methodName><params><param><value><string>" & strPartnerName & "</string></value></param><param><value><string>" & strPartnerPWD & "</string></value></param></params></methodCall>"
                                    'strResponseStringXML = objBizSSO.RequestPartnerToken(strTokenError, strPartnerName, strPartnerPWD)   'commented by Dhananjay 20-Feb-2012
                                    'logECWebSessionAction(1, 0, "SSO -Partner Token strResponseStringXML: " & strResponseStringXML & " -strTokenError:" & strTokenError)   'commented by Dhananjay 20-Feb-2012
                                    'Added By Dhananjay 20-Feb-2012 Begin
                                    'strinput = "<?xml version=""1.0""?><methodCall><methodName>partners.requestToken</methodName><params><param><value><string>" & strPartnerName & "</string></value></param><param><value><string>" & strPartnerPWD & "</string></value></param></params></methodCall>"  'commented by Dhananjay 20-Feb-2012
                                    strinput = "<RequestToken><Username>" & strPartnerName.Trim & "</Username><Password>" & strPartnerPWD.Trim & "</Password></RequestToken>"
                                    If strPartnerCalledFrom = "innovamdhiehub" Then
                                        'strResponseStringXML = objBizSSO.RequestPartnerToken(strinput)  
                                        strResponseStringXML = objBizSSO.PartnerRequestToken(strinput, strPartnerTokenResponse, strPartnerServiceURL)
                                        strResponseStringXML = strPartnerTokenResponse
                                    Else
                                        strResponseStringXML = objBizSSO.RequestPartnerToken(strTokenError, strPartnerName, strPartnerPWD)
                                    End If
                                    logECWebSessionAction(1, 0, "SSO -Partner Token strResponseStringXML: " & strResponseStringXML & " -strinput:" & strinput)

                                End If
                                If strPartnerCalledFrom.ToLower = "innovamdhiehub" Then
                                    'objXmlDom.LoadXml(strPartnerTokenResponse)
                                    If strPartnerTokenResponse.Length > 0 Then
                                        objXElement = XElement.Parse(strPartnerTokenResponse)
                                        'To be modified further
                                        'If objXElement...<ErrorDescription>.Count > 0 Then
                                        '    logECWebSessionAction(1, 0, "SSO -Partner Token response error: " & objXElement...<ErrorDescription>.ToString)
                                        'Else
                                        '    strAETokenID = objXElement...<Token>.Value
                                        '    strExpiryDate = objXElement...<Expiration>.Value
                                        'End If
                                        strAETokenID = objXElement...<Token>.Value
                                        strExpiryDate = objXElement...<Expiration>.Value
                                    End If
                                Else
                                    objXmlDom.LoadXml(strResponseStringXML)
                                    logECWebSessionAction(1, 0, "SSO -Partner Token response xml loaded")
                                    strAETokenID = objXmlDom.SelectSingleNode("methodResponse/params/param/value/string").InnerText
                                    strExpiryDate = objXmlDom.SelectSingleNode("methodResponse/params/param/value/dateTime.iso8601").InnerText
                                End If


                                'objXmlDom.LoadXml(strResponseStringXML)
                                'strAETokenID = objXmlDom.SelectSingleNode("methodResponse/params/param/value/string").InnerText
                                'strExpiryDate = objXmlDom.SelectSingleNode("methodResponse/params/param/value/dateTime.iso8601").InnerText

                                strSaveTokenXML = "<?xml version=""1.0""?><methodCall><params><param><value><string>" & strSSOPartnerID & "</string></value></param><param><value><string>" & strPartnerName & "</string></value></param><param><value><string>" & strPartnerPWD & "</string></value></param><param><value><string>" & strAETokenID & "</string></value></param><param><value><string>" & strExpiryDate & "</string></value></param><param><value><string>" & strSysIPAdress & "</string></value></param></params></methodCall>"
                                strSaveReturn = objBizSSO.SaveParterToken(strSaveTokenXML)
                                logECWebSessionAction(1, 0, "SSO -Save Partner Token: " & strSaveTokenXML & "strSaveReturn:" & strSaveReturn)
                            End If

                            If strAETokenID <> "" Then
                                strResponseStringXML = ""
                                logECWebSessionAction(1, 0, "SSO -Partner Token: " & strAETokenID)
                                logECWebSessionAction(1, 0, "SSO -Partner Artifact ID: " & strPartnerID)
                                If Right(strSSOPartnerService, 3).ToLower = "asp" Then
                                    strinput = "<?xml version=""1.0""?><methodCall><methodName>ae.partners.retrieveArtifact</methodName><params><param><value><string>" & strAETokenID & "</string></value></param><param><value><string>" & strPartnerID & "</string></value></param></params></methodCall>"
                                    logECWebSessionAction(1, 0, "SSO -Artifact: " & strinput)
                                    xmlhttp = Server.CreateObject("MSXML2.ServerXMLHTTP60")
                                    xmlhttp.Open("POST", strSSOPartnerService, False)
                                    xmlhttp.setRequestHeader("Content-Type", "text/xml")
                                    xmlhttp.send(strinput)
                                    strResponseStringXML = xmlhttp.responsexml.xml
                                    xmlhttp = Nothing
                                Else
                                    logECWebSessionAction(1, 0, "SSO - Call RetrieveArtifact :" & strAETokenID & "Artifact ID:" & strPartnerID)
                                    'strResponseStringXML = objBizSSO.RetrieveArtifact(strArtifaceError, strAETokenID, strPartnerID)    
                                    'logECWebSessionAction(1, 0, "SSO -Partner RetrieveArtifact strResponseStringXML: " & strResponseStringXML & " -strArtifaceError:" & strArtifaceError)   

                                    If strPartnerCalledFrom = "innovamdhiehub" Then
                                        'strResponseStringXML = objBizSSO.RetrievePartnerArtifact(strPartnerError, strAETokenID, strPartnerID)
                                        strResponseStringXML = objBizSSO.RetrievePartnerArtifact(strPartnerError, strAETokenID, strPartnerID, strPartnerServiceURL)
                                    Else
                                        strResponseStringXML = objBizSSO.RetrieveArtifact(strArtifaceError, strAETokenID, strPartnerID)
                                    End If
                                    logECWebSessionAction(1, 0, "SSO -Partner RetrieveArtifact strResponseStringXML: " & strResponseStringXML & " -strPartnerError:" & strPartnerError)

                                End If
                            End If
                            logECWebSessionAction(1, 0, "SSO -Partner Artifact Response: " & strResponseStringXML)
                            If strResponseStringXML <> "" Then
                                strMDIVirFolderName = objAppSetttings.GetVirtualFolderPath("1031")
                                If strPartnerCalledFrom.ToLower = "innovamdhiehub" Then
                                    Session("PartnerToken") = strAETokenID
                                    Session("PartnerServiceURL") = strPartnerServiceURL
                                    Session("eRxCalledFrom") = "SSO"
                                    ValidateEPresData(strResponseStringXML, strMDIVirFolderName, strXMLNodeName, strAccessTokenID, strPartnerID, intAlloweRx)
                                Else
                                    objXmlDom.LoadXml(strResponseStringXML)
                                    If Right(strSSOPartnerService, 3).ToLower = "asp" Then
                                        ''objXmlDom.LoadXml(strResponseStringXML)
                                        strRetriveArtifatXML = objXmlDom.SelectSingleNode("methodResponse/params/param/value/string").InnerText
                                        strRetriveArtifatXML = HttpUtility.HtmlDecode(strRetriveArtifatXML)
                                        logECWebSessionAction(1, 0, "SSO -Artifact Decode: " & strRetriveArtifatXML)
                                        objXmlDom.LoadXml(strRetriveArtifatXML)
                                        If Not objXmlDom Is Nothing Then
                                            xmlNodesList = objXmlDom.SelectNodes("ae_response/content/member")
                                            If Not xmlNodesList Is Nothing AndAlso xmlNodesList.Count > 0 Then
                                                ''lngPatientID = objXmlDom.SelectSingleNode("ae_response/content/member/hmoid").InnerText
                                                ''strMbrNO = objXmlDom.SelectSingleNode("ae_response/content/member/mbrno").InnerText
                                                strMbrNO = objXmlDom.SelectSingleNode("ae_response/content/member/" & strXMLNodeName).InnerText
                                                blnSelectPatient = True
                                                lngPatientID = objBizSSO.fnGetPatientBYMbrNo(strMbrNO)
                                            End If
                                            xmlNodesList = objXmlDom.SelectNodes("ae_response/content/user")
                                            If Not xmlNodesList Is Nothing AndAlso xmlNodesList.Count > 0 Then
                                                strUserName = objXmlDom.SelectSingleNode("ae_response/content/user/username").InnerText
                                            End If
                                        End If
                                    Else
                                        ''objXmlDom.LoadXml(strResponseStringXML)
                                        If Not objXmlDom Is Nothing Then
                                            xmlNodesList = objXmlDom.SelectNodes("response/content/member")
                                            If Not xmlNodesList Is Nothing AndAlso xmlNodesList.Count > 0 Then
                                                ''lngPatientID = objXmlDom.SelectSingleNode("ae_response/content/member/hmoid").InnerText
                                                ''strMbrNO = objXmlDom.SelectSingleNode("ae_response/content/member/mbrno").InnerText
                                                strMbrNO = objXmlDom.SelectSingleNode("response/content/member/" & strXMLNodeName).InnerText
                                                blnSelectPatient = True
                                                lngPatientID = objBizSSO.fnGetPatientBYMbrNo(strMbrNO)
                                            End If
                                            If Not objXmlDom.SelectSingleNode("response/type") Is Nothing AndAlso (objXmlDom.SelectSingleNode("response/type").InnerText = "login.Provider" OrElse objXmlDom.SelectSingleNode("response/type").InnerText = "login.provider.selectMember") Then
                                                xmlNodesList = objXmlDom.SelectNodes("response/content/user")
                                                If Not xmlNodesList Is Nothing AndAlso xmlNodesList.Count > 0 Then
                                                    strProviderName = objXmlDom.SelectSingleNode("response/content/user/npi").InnerText
                                                End If
                                            Else
                                                xmlNodesList = objXmlDom.SelectNodes("response/content/user")
                                                If Not xmlNodesList Is Nothing AndAlso xmlNodesList.Count > 0 Then
                                                    strUserName = objXmlDom.SelectSingleNode("response/content/user/username").InnerText
                                                End If
                                            End If
                                        End If
                                    End If

                                    logECWebSessionAction(1, 0, "SSO -fnStartEcSession: " & strUserName)

                                    objUSer = objBizSSO.fnStartSSOEcSession(strUserName, strProviderName)
                                    If objUSer IsNot Nothing AndAlso objUSer.ID > 0 Then

                                        Session("TempUserID") = objUSer.ID
                                        Session("UserLocationID") = objUSer.LocationID
                                        Session.Add("UserLoginName", strUserName)

                                        If intShowLocationCombo = 1 Then
                                            logECWebSessionAction(2037, -1, "SSO -GetUserLocations Begin strUserName:" & strUserName & " - Password :" & objUSer.Password)
                                            objBizLogin = New clsBizlECSession
                                            dtLocations = objBizLogin.GetUserLocations(objUSer.ID)
                                            strUserLocatons = "<Locations>"
                                            For Each row As DataRow In dtLocations.Rows
                                                strUserLocatons = strUserLocatons & "<Loc>"
                                                strUserLocatons = strUserLocatons & "<ID>" & row("ID") & "</ID>"
                                                strUserLocatons = strUserLocatons & "<Name>" & row("Name") & "</Name>"
                                                strUserLocatons = strUserLocatons & "<IsPrimary>" & row("IsPrimary") & "</IsPrimary>"
                                                strUserLocatons = strUserLocatons & "</Loc>"
                                                m_lngLocationCount = m_lngLocationCount + 1
                                            Next
                                            strUserLocatons = strUserLocatons & "</Locations>"

                                            logECWebSessionAction(2037, -1, "SSO -GetUserLocations End strUserLocatons:" & strUserLocatons)
                                        End If
                                        logECWebSessionAction(2037, -1, "SSO -Excelicare ACE Login UserLogin Success")
                                        If lngPatientID > 0 Then
                                            AddPatient(lngPatientID)
                                            If m_lngLocationCount > 1 Then
                                                Exit Sub
                                            End If
                                            Session("SSOCalledFrom") = "SSO"
                                            Response.Redirect(strMDIVirFolderName & "/frmExcelicareMDI.aspx?CalledFrom=SSO", True)
                                        Else
                                            If blnSelectPatient Then
                                                logECWebSessionAction(1, 0, "SSO -Patient information is not available strMbrNO: " & strMbrNO & " lngPatientID:" & lngPatientID)
                                                Response.Write("Patient information is not available")
                                                Exit Try
                                            Else
                                                If m_lngLocationCount > 1 Then
                                                    Exit Sub
                                                End If
                                                Session("SSOCalledFrom") = "SSO"
                                                Response.Redirect(strMDIVirFolderName & "/frmExcelicareMDI.aspx?CalledFrom=SSO", True)
                                            End If
                                        End If
                                    Else
                                        Response.Write("<methodResponse><member><value><string>Invalid Data Partner Does not exists</string></value></member></methodResponse>")
                                    End If
                                    'End
                                End If
                            End If
                        Else
                            Response.Write(strRetrunXML)
                        End If
                    End If
                End If
            End If
        Catch ex As System.Threading.ThreadAbortException
        Catch ex As Exception
            logECWebSessionAction(1, 0, "SSO -exception: " & ex.Message)
            LogException(ex)
            Response.Write("<methodResponse><fault><value><struct><member><name>faultCode</name><value><int> 200 </int></value></member><member><name>faultString</name><value<string> Invalid Syntax </string></value></member></struct></value></fault></methodResponse>")
        Finally
            objBizLogin = Nothing
            objAppSetttings = Nothing
            objClsAppSettings = Nothing
            objUSer = Nothing
            objBizSSO = Nothing
            'objLocations = Nothing
            objXElement = Nothing
            xmlNodesList = Nothing
            objXmlDom = Nothing
            objRetXmlDOm = Nothing
	    objQueryParams = Nothing
	    objClsSecurity = Nothing
            logECWebSessionAction(1, 0, "SSO -PageLoad End: " & strRetrunXML)
        End Try
    End Sub
    Public Sub logECWebSessionAction(ByVal lngEventId As Long, ByVal lngPatId As Long, ByVal strEventDet As String)
        Try
            clsECSession.LogWebSessionAction("Excelicare Ace Login ", Session.SessionID, lngPatId, lngEventId, strEventDet & " - Generic Inbound ", 1132, 0)
        Catch ex As Exception
            LogException(ex)
        End Try
    End Sub
    Private Sub LogException(ByVal objExcep As Exception)
        Dim objClsExceptionHandler As clsExceptionHandler
        Try
            objClsExceptionHandler = New clsExceptionHandler(objExcep)
            If Not IsNothing(Page) Then
                objClsExceptionHandler.LogException(Page)
            Else
                objClsExceptionHandler.LogException()
            End If
        Catch ex As Exception
        Finally
            objClsExceptionHandler = Nothing
        End Try
    End Sub
    Public Function AddPatient(ByVal PatID As Long) As Boolean
        Dim objClsSessionData As clsSessionData
        Dim objClsSessionManager As clsSessionManager
        Try
            objClsSessionManager = New clsSessionManager
            objClsSessionData = objClsSessionManager.GetSessionData(Session.SessionID, "APPDATA")
            objClsSessionData.PatientID = PatID
            objClsSessionData.CurrentPatientID = PatID
            objClsSessionManager.SetSessionData(HttpContext.Current.Session.SessionID, "APPDATA", objClsSessionData)
            If PatID <> -1 Then
                logECWebSessionAction(2398, PatID, "SSO -Excelicare ACE MDI Patient Selected")
            Else
                logECWebSessionAction(2399, PatID, "SSO -Excelicare ACE MDI Patient Selected")
            End If
            Return True
        Catch ex As Exception
            Return False
        Finally
            objClsSessionManager = Nothing
        End Try
    End Function
    Private Sub ValidateEPresData(ByVal strArtifactXML As String, ByVal strMDIVirFolderName As String, ByVal strXMLNodeName As String, ByVal strAxsysTokenID As String, ByVal strPartnerArtefactID As String, ByVal intAlloweRx As Integer)
        Dim objBizSSO As New clsBizSSO
        Dim objBizLogin As New clsBizlECSession
        Dim objUSer As New clsUser
        'Dim objXMLDom As New XmlDocument  
        Dim strUserName As String = ""
        Dim lngUserID As Long
        Dim strVendorKey As String = ""
        Dim lngLocationID As Long
        Dim lngPatientID As Long
        Dim strReturnValue As String = ""
        Dim strVendorError As String = ""
        Dim objXElement As XElement
        Dim objSSOProxy As AxRSSSOClient
        Dim blnServiceClose As Boolean = False
        Dim IseRxDataValid As Boolean
        Dim streRxdataValidationError As String
        Dim objPresProxy As WSPrescriptionManager.AxWSePrescriptionInterfaceManagerClient
        Dim strTransactionGUID As String
        Try
            logECWebSessionAction(1, 0, "SSO -  ValidateEPresData Begin :strArtifactXML:" & strArtifactXML)
            strArtifactXML = strArtifactXML.Replace("<RetrieveArtifactResponse>", "").Replace("<Message>", "").Replace("</RetrieveArtifactResponse>", "").Replace("</Message>", "")
            objXElement = XElement.Parse(strArtifactXML)
            strUserName = objXElement...<UserName>.Value
            If objBizSSO.fnValidateUser(strUserName, strVendorKey, lngUserID, lngLocationID, strVendorError, strAxsysTokenID) Then
                logECWebSessionAction(1, 0, "SSO -  fnValidateUser :lngUserID:" & lngUserID & "lngLocationID:" & lngLocationID)
                'If objXElement...<Patient>.Count() > 0 Then
                logECWebSessionAction(1, 0, "SSO -  fnValidateEPresData :lngPatientID:" & lngPatientID & "strXMLNodeName:" & strXMLNodeName)
                'strReturnValue = objBizSSO.fnValidateEPresData(strArtifactXML, lngPatientID, lngUserID, lngLocationID) 
                If Not objXElement...<PatientFirstName>.Value Is Nothing Then
                    strReturnValue = objBizSSO.fnValidateEPresData(strArtifactXML, lngPatientID, lngUserID, lngLocationID, strAxsysTokenID)
                    logECWebSessionAction(1, 0, "SSO -  fnValidateEPresData :strReturnValue:" & strReturnValue)
                    Try
                        objXElement = XElement.Parse(strReturnValue)
                        lngPatientID = objXElement...<Pat_ID>.Value
                        IseRxDataValid = objXElement...<IseRxDataValid>.Value
                        streRxdataValidationError = objXElement...<StatusDescription>.Value
                        streRxdataValidationError = streRxdataValidationError.Replace("^~!`$#^", "<br/>")
                    Catch ex As Exception
                    End Try
                Else

                    strReturnValue = ""
                End If
                If Not objXElement...<Pat_ID>.Value Is Nothing Then
                    If lngPatientID = 0 Then
                        'strReturnValue = "<methodResponse><fault><value><struct><member><name>faultCode</name><value><int> 200 </int></value></member><member><name>faultString</name><value<string> Invalid Syntax </string></value></member></struct></value></fault></methodResponse>"   
                        If Not String.IsNullOrEmpty(streRxdataValidationError) AndAlso Not streRxdataValidationError Is Nothing Then
                            strReturnValue = streRxdataValidationError
                        Else
                            strReturnValue = "<ResponseMessage><Error><ErrorCode>100</ErrorCode><ErrorDescription>Invalid Data</ErrorDescription></Error></ResponseMessage>"
                        End If
                        'End
                    Else
                        'strReturnValue = "" 
                        If Not String.IsNullOrEmpty(streRxdataValidationError) AndAlso Not streRxdataValidationError Is Nothing Then
                            strReturnValue = ""
                        Else
                            strReturnValue = streRxdataValidationError
                        End If
                    End If
                End If
                If strReturnValue.Trim = "" Then
                    logECWebSessionAction(1, 0, "SSO -fnStartEcSession: " & strUserName)
                    'objUSer = objBizLogin.fnStartEcSession(strUserName)

                    objUSer = objBizSSO.fnStartSSOEcSession(strUserName)

                    If objUSer IsNot Nothing AndAlso objUSer.ID > 0 Then
                        Session("TempUserID") = objUSer.ID
                        Session("UserLocationID") = lngLocationID
                        Session.Add("UserLoginName", strUserName)
                        Session.Add("AxsysTokenID", strAxsysTokenID)
                        Session("AlloweRx") = intAlloweRx
                        logECWebSessionAction(2037, -1, "SSO -Excelicare ACE Login UserLogin Success")
                    End If
                    If lngPatientID > 0 Then
                        AddPatient(lngPatientID)
                        strTransactionGUID = System.Guid.NewGuid().ToString
                        If Not IsNothing(Session("eRxCalledFrom")) AndAlso Session("eRxCalledFrom") <> "" AndAlso Session("eRxCalledFrom") = "SSO" Then
                            objSSOProxy = New Excelicare.ServiceProxy.AxRSSSOClient
                            objSSOProxy.SaveArtifactDetails(Session("AxsysTokenID"), lngPatientID, Session.SessionID, objUSer.ID, 1030, strTransactionGUID)
                            objSSOProxy.Close()

                        End If
                        If IseRxDataValid Then
                            objPresProxy = New WSPrescriptionManager.AxWSePrescriptionInterfaceManagerClient
                            objPresProxy.SaveExternalPrescriptionData(lngPatientID, objUSer.ID, lngLocationID, strArtifactXML, strAxsysTokenID, strTransactionGUID)
                            objPresProxy.Close()
                        End If
                        blnServiceClose = True
                        'End
                        Session("SSOCalledFrom") = "SSOEP"
                        Response.Redirect(strMDIVirFolderName & "/frmExcelicareMDI.aspx?CalledFrom=SSOEP", True)
                    Else
                        Session("SSOCalledFrom") = "SSOER"
                        Response.Redirect(strMDIVirFolderName & "/frmExcelicareMDI.aspx?CalledFrom=SSOER", True)
                    End If
                Else
                    Response.Write(strReturnValue)
                End If
            Else
                Response.Write(strVendorError)
            End If
            'End
        Catch ex As Exception
            LogException(ex)
            logECWebSessionAction(1, 0, "SSO - ValidateEPresData Catch :Exception:" & ex.Message)
        Finally
            objBizLogin = Nothing
            objBizSSO = Nothing
            objUSer = Nothing
            'objXMLDom = Nothing 
            strUserName = Nothing
            If blnServiceClose = False Then
                If Not IsNothing(objSSOProxy) Then
                    objSSOProxy.Abort()
                End If
                If Not IsNothing(objPresProxy) Then
                    objPresProxy.Abort()
                End If
            End If
            objSSOProxy = Nothing
            objPresProxy = Nothing
            logECWebSessionAction(1, 0, "SSO - ValidateEPresData End :strReturnValue:" & strReturnValue)
        End Try
    End Sub
    'End
    Public Sub RedirectToACEMDI(ByVal intOption As Short)
        Dim strXMLFileName As String = String.Empty
        Dim objXMLDOM As New System.Xml.XmlDocument
        Dim xmlNodesList As XmlNodeList
        Dim strMbrNO As String = String.Empty
        Dim objBizSSO As New clsBizSSO
        Dim objBizLogin As New clsBizlECSession
        Dim objUSer As New clsUser
        Dim objAppSetttings As New clsAppSettings
        Dim lngPatientID As Long
        Dim strUserName As String = String.Empty
        Dim strMDIVirFolderName As String = String.Empty
        'Dim objLocations As WSUserManager.clsLocation()
        Dim dtLocations As DataTable
        Try
            logECWebSessionAction(1, 0, "SSO - Test RedirectToACEMDI: Begin")
            'strXMLFileName = Server.MapPath("XML/ArtifactDetails.xml") 
            If intOption = 2 Then
                strXMLFileName = Server.MapPath("XML/ArtifactDetailsMember.xml")
            Else
                strXMLFileName = Server.MapPath("XML/ArtifactDetails.xml")
            End If
            If System.IO.File.Exists(strXMLFileName) Then
                objXMLDOM.Load(strXMLFileName)
                If Not objXMLDOM Is Nothing Then
                    logECWebSessionAction(1, 0, "SSO - Test RedirectToACEMDI strXMLFileName:" & strXMLFileName)
                    xmlNodesList = objXMLDOM.SelectNodes("response/content/member")
                    If Not xmlNodesList Is Nothing AndAlso xmlNodesList.Count > 0 Then
                        strMbrNO = objXMLDOM.SelectSingleNode("response/content/member/memberid").InnerText
                        lngPatientID = objBizSSO.fnGetPatientBYMbrNo(strMbrNO)
                        If lngPatientID <= 0 Then
                            logECWebSessionAction(1, 0, "SSO -Test Patient information is not available strMbrNO: " & strMbrNO & " lngPatientID:" & lngPatientID)
                            Response.Write("Patient information is not available")
                            Exit Try
                        End If
                    End If
                    xmlNodesList = objXMLDOM.SelectNodes("response/content/user")
                    If Not xmlNodesList Is Nothing AndAlso xmlNodesList.Count > 0 Then
                        strUserName = objXMLDOM.SelectSingleNode("response/content/user/username").InnerText
                    End If
                    logECWebSessionAction(1, 0, "SSO - Test fnStartEcSession: " & strUserName)
                    'objUSer = objBizLogin.fnStartEcSession(strUserName)
                    objUSer = objBizSSO.fnStartSSOEcSession(strUserName)
                    If objUSer IsNot Nothing AndAlso objUSer.ID > 0 Then
                        Session("TempUserID") = objUSer.ID
                        Session("UserLocationID") = objUSer.LocationID
                        Session.Add("UserLoginName", strUserName)

                        If intShowLocationCombo = 1 Then
                            logECWebSessionAction(2037, -1, "SSO -GetUserLocations Begin strUserName:" & strUserName & " - Password :" & objUSer.Password)
                            objBizLogin = New clsBizlECSession
                            dtLocations = objBizLogin.GetUserLocations(objUSer.ID)
                            strUserLocatons = "<Locations>"
                            For Each row As DataRow In dtLocations.Rows
                                strUserLocatons = strUserLocatons & "<Loc>"
                                strUserLocatons = strUserLocatons & "<ID>" & row("ID") & "</ID>"
                                strUserLocatons = strUserLocatons & "<Name>" & row("Name") & "</Name>"
                                strUserLocatons = strUserLocatons & "<IsPrimary>" & row("IsPrimary") & "</IsPrimary>"
                                strUserLocatons = strUserLocatons & "</Loc>"
                                m_lngLocationCount = m_lngLocationCount + 1
                            Next
                            strUserLocatons = strUserLocatons & "</Locations>"
                            logECWebSessionAction(2037, -1, "SSO -GetUserLocations End strUserLocatons:" & strUserLocatons)
                        End If
                        'end
                        logECWebSessionAction(2037, -1, "SSO - Test Excelicare ACE Login UserLogin Success")
                        strMDIVirFolderName = objAppSetttings.GetVirtualFolderPath("1031")
                        'If lngPatientID > 0 Then
                        '    AddPatient(lngPatientID)
                        '    Response.Redirect(strMDIVirFolderName & "/frmExcelicareMDI.aspx?CalledFrom=SSO", True)
                        'Else
                        '    Response.Redirect(strMDIVirFolderName & "/frmExcelicareMDI.aspx?CalledFrom=SSO", True)
                        'End If
                        If lngPatientID > 0 Then
                            AddPatient(lngPatientID)
                            If m_lngLocationCount > 1 Then
                                Exit Sub
                            End If
                            Session("SSOCalledFrom") = "SSO"
                            Response.Redirect(strMDIVirFolderName & "/frmExcelicareMDI.aspx?CalledFrom=SSO", False)
                        Else
                            If m_lngLocationCount > 1 Then
                                Exit Sub
                            End If
                            Session("SSOCalledFrom") = "SSO"
                            Response.Redirect(strMDIVirFolderName & "/frmExcelicareMDI.aspx?CalledFrom=SSO", False)
                        End If
                    Else
                        Response.Write("<methodResponse><member><value><string>Invalid Data Partner Does not exists</string></value></member></methodResponse>")
                    End If
                Else
                    Response.Write("Artifact Details file is empty")
                End If
            Else
                Response.Write("Artifact Details file not found")
            End If
        Catch ex As Exception
            logECWebSessionAction(1, 0, "SSO -Test exception: " & ex.Message)
            LogException(ex)
        Finally
            objBizSSO = Nothing
            objBizLogin = Nothing
            objAppSetttings = Nothing
            objUSer = Nothing
            objXMLDOM = Nothing
            xmlNodesList = Nothing
        End Try
    End Sub
    <Ajax.AjaxMethod(HttpSessionStateRequirement.ReadWrite)> _
    Public Function SetLocation(ByVal lngLocationValue As Long) As Boolean
        If lngLocationValue > 0 Then
            Session("UserLocationID") = lngLocationValue
        End If
    End Function


End Class
