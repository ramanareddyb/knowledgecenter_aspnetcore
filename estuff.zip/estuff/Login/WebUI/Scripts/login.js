var retValue = 0;
var intUserId = 0;
var LoginAttemps = 0, strFailedLogins = '';
var intRemainderDays;
var blnSessionTerminateCalled = false
var lngUserID = 0;
var blnAuthenticated = false;
var m_Result = 0;
var arrSQuestions = new Array();

var intGenDisclaimerStatus =0;
var intCPTDisclaimerStatus =0;
var RedirectURL;
var strResult;
var m_SessionCount;
var IsUserMFAEnabled;
var IsValidateEmail;
var strTkn = "";

//==========================================================

//===========================================================
		
$(document).ready(function () {
	if ($ec.fn.getValue != undefined && $ec.fn.getValue("UserId") != undefined) {
        window.top.location.href = "../AxWebUILogin/frmSignon.aspx";
    }
    else {
		var xmlDOM = fnLoadXML(m_strLoginDefaults);
		 $("#clientlogo").prop("src", xmlDOM.documentElement.getAttribute("topleft"));
		 if(xmlDOM.documentElement.getAttribute("topleft") == ""){
			 $("#clientlogo").hide();
		 }
		 $("#excelicarelogo").prop("src",xmlDOM.documentElement.getAttribute("topright"));
		 $("#axsyslogo").prop("src",xmlDOM.documentElement.getAttribute("bottomright"));
		 if(xmlDOM.documentElement.getAttribute("bottomright") == ""){
			 $("#axsyslogo").hide();
		 }
		for (intIndex = 0; intIndex < xmlDOM.documentElement.childNodes.length; intIndex++) {
			if ( xmlDOM.documentElement.childNodes[intIndex].getAttribute("visible") == "1")
				$("#ulLinks").append('<li><a href="' + xmlDOM.documentElement.childNodes[intIndex].getAttribute("url") + '" target="_blank">' + xmlDOM.documentElement.childNodes[intIndex].getAttribute("name") + '</a></li>');
        }
    }
	
	if (blnSessionUsed == "True") document.location.replace("default.aspx?SD=1"); 
			
	if(m_showForgotPwdLink == "False")
		$('#forgotPwdLink').css("display","none");
	else
		$('#forgotPwdLink').css("display","block");
    
	if(m_issysMFAEnabled=="True")
        $("#WinAuthDownloadLink").css("display","");		
	else 
		$("#WinAuthDownloadLink").css("display","none");
		 
	 if (intShowClientLog == 1) $("#clientlogo").prop("src", "../AxCommon/Images/ChiefLogo_MMM.gif");
		$("#colSecLogin").hide();	
	
			
      if (document.all) 
		{
            top.window.resizeTo(screen.availWidth, screen.availHeight);
        }
        else 
		{
            if (document.layers || document.getElementById) {
                if (top.window.outerHeight < screen.availHeight || top.window.outerWidth < screen.availWidth) {
                    top.window.outerHeight = screen.availHeight;
                    top.window.outerWidth = screen.availWidth;
			}}            
        }		
		
	$("#LN,#PD,#strAnswer").on("keyup", "", function (event) {
				$("#secdivErrorMsg").css("display", "none");
					var srcEle = event.target || event.srcElement;
					var evtCode = event.which || event.keyCode;
					var txtLen = $(srcEle).val().length;
					if(event.ctrlKey==true)	fnBlockKey(event); 
					if (txtLen == 0)
						$(srcEle).next().show();
					else
						$(srcEle).next().hide();
					
					if(event.altKey==true && evtCode==115){
						window.open("", "_self", "");
						window.opener = top;
						window.close();
					}
					srcEle = null;
				});
				
		$(".tundra").on("keyup", "", function (event) {
				   var srcEle = event.target || event.srcElement;
					var evtCode = event.which || event.keyCode;
				   if(event.altKey==true && evtCode==115){
					  window.open("", "_self", "");
						window.opener = top;
						window.close();
					}
					srcEle = null;
				});
				
				
		fnLoad();	
		
});

 $(document).bind("onhelp",
			function fnHelp() 
			{
				window.showModalDialog("../AxCommon/Help/frmHelpLogin.htm", window, "dialogWidth=800px;dialogHeight=500px;center=yes;scroll=auto;help=no;status=no;resizable=yes");
				return false
			}
       );
	   
 document.onkeydown = function (event) {
            var KeyPressValue;
            try {
				event = event == undefined ? window.event : event;
                KeyPressValue = ($ec.fn.msie()) ? event.keyCode : event.which;
                switch (KeyPressValue) {
                    case event.ctrlKey && 86:
                        {
                            if ($ec.fn.msie()) {
                                event.cancelBubble = true;
                                event.returnValue = false;
                                event.keyCode = false;
                            }
                            else {
                                event.stopPropagation();
                                event.preventDefault();
                            }
                            return false;
                            break;
                        }
                }
            } catch (e) { }
        }	
		

$(function () {

    function fnModalKeyDown(e) {
        $('#cbLocation').focus();
        $('.boxy-wrapper').bind('keyup', function (e) { if (e.ctrlKey && e.keyCode == 13) { $('#divProceed').click(); } else { return false; } });
    }
    var name = $("#LN"),
	password = $("#PD"),
	btnLogin = $('#btnlogin'),
	showvk = $('#showVK'),
	security = $('#ST'),
	tips = $("#validateTips");
	var question = $('#dvQuestion');
	var answer = $('#strAnswer');
	allFields = $([]).add(name).add(password).add(question).add(answer),
	btnSecLogin = $('#btnSeclogin')
	
    var bValid = true;
    function updateTips(t, blnInvalidCaptcha,numberofattempes) {
		fnRefreshSecurityImage()
        security.val('')
        if (blnInvalidCaptcha == undefined)
            password.val('')
        $('#trvalidateTips').show();
		$('#colOne').show();
		$("#divErrorMsg").css("display", "block");
        if (intUserLocation == 1)
            document.getElementById('cbLocation').length = 0;
        // tips.toggleClass('validatehide', 'validateshow');
         //.effect("highlight", {}, 1500);
		if (numberofattempes != undefined) {
		     tips.text(t)
             if(m_ShowLoginFailedAttempts === '0')
                numberofattempes = "Too many attempts will lock the user."

			$("#numberofattempts").text(numberofattempes);
			 
		}
		else {
			$("#numberofattempts").text(t);
		}
    }
	
    function checkLength(o, n, min, max) {
		if (blnAuthenticated == true)
            return false;
        if (o.val().length > max || o.val().length > max || o.val().length < min) {
            o.addClass('ui-state-error');
            updateTips("The username or password you entered is incorrect. Please try again.");
            return false;
        } else {
            return true;
        }

    }
	function checkSecLength(o, n, min, max) {
        if (blnAuthenticated == true)
			return false;
		if(n == "question"){o = o.text();}
		else{o = o.val();}
		if (o.length > max || o.length < min) {
            o.addClass('ui-state-error');
            updateTips("The answer you entered is incorrect. Please try again.");
            return false;
        } else {
            return true;
        }

    }

    function checkRegexp(o, regexp, n) {

        if (!(regexp.test(o.val()))) {
            o.addClass('ui-state-error');
            updateTips(n);
            return false;
        } else {
            return true;
        }

    }
    function Chr(CharCode) {
        try {
            return String.fromCharCode(CharCode);
        }
        catch (ex) {
            //alert(ex.message);
        }
    }

    function OpenDialog(Prompt, MessageBoxStyle, DialogWidth, DialogHeight, IconStyle, PageTitle, fncallback,fncallbackclose) {
          var ButtonName1 = ' &nbsp;&nbsp; OK  &nbsp;&nbsp; ';


        var CustomReturnValue1 = 6;

        var ButtonName2 = ' Open new session / &#10;retain other session(s) ';
        var CustomReturnValue2 = 7;

        var ButtonName3 = ' Cancel ';
        var CustomReturnValue3 = 0;

        var ButtonName4 = '';
        var CustomReturnValue4 = '';

        var winW;
        var winH;
        winW = document.body.offsetWidth;

        if (winW != 0) {
            winW = (winW / 2) - (DialogWidth / 2);
            winW = winW + "px";
        }

        if (winW == 0)
            winW = "500px";

        if (MessageBoxStyle == 8192)
            var URL = strAxDialogVirFolderName + "/frmDialogPage.aspx?t=" + PageTitle + "&p=" + escape(Prompt) + "&bs=" + MessageBoxStyle + "&is=" + IconStyle + "&cbn1=" + escape(ButtonName1) + "&cbrv1=" + escape(CustomReturnValue1) +  "&cbn3=" + escape(ButtonName3) + "&cbrv3=" + escape(CustomReturnValue3) + "&cbn4=&cbrv4=&isDojoDialog=true&note=" + escape("If you choose  <B>OK,</B> any unsaved data in the another active session will be lost.");
        else
            var URL = strAxDialogVirFolderName + "/frmDialogPage.aspx?t=" + PageTitle + "&p=" + escape(Prompt) + "&bs=" + MessageBoxStyle + "&is=" + IconStyle + "&isDojoDialog=true";

        AxOpenDojo(URL, DialogWidth, DialogHeight, "Login", fncallback,fncallbackclose);
     
    }

    function fnCheckUserComplete(objResponse) {
        var decode = $ec.fn.ecDecode(objResponse.value)
        if (decode == "False" && objResponse != undefined) {
           window.location.href = '../AxWebUIMDI/CustomError.Aspx?ErrorCode=User session is active in this machine, please close the active session or open the URL in different browser.';
          return;
	   }
	
        if (objResponse.request.readyState == 4) {   

            fnValidUserCredentials(objResponse);

            m_securityQtns = decode.split(Chr(190))[1];
			if (strResult == 5 && m_showForgotPwdLink == "True" && (m_securityQtns == '' || m_securityQtns == undefined))
			{	
				$("#colOne").show();
				startSession();
				return false;
			}
			
			
            hidePopup();
			if (strResult != 0 && intUserId > 0) {
				if ((parseInt(m_allowSecondaryVerification) == 0 || (strResult == 2 && m_securityQtns == '' )) || (parseInt(m_allowSecondaryVerification) == 1 && (strResult == 6 && m_securityQtns == '' ) ) || ((m_allowSecondaryVerification) == 0 || (strResult == 3 && m_securityQtns == '' )))
				{	
					$("#colOne").show();
					m_SessionCount = strActiveSessionCount;
					startSession();
					return false;
				}
				
				m_SessionCount = strActiveSessionCount;
				m_Questions =  m_securityQtns.split(Chr(182));
				if (m_showForgotPwdLink == "True" && m_issysMFAEnabled == "False")
				{
					setQuestionsRandomforSecondary();
					$("#colOne").hide();
					$("#colTwo").hide();
					$("#colSecLogin").show();
					if (m_EnableChoose == 0)					
						$("#chooseLink").css("display","none");							 
					if($("#chooseLink").css("color")=="rgb(192, 192, 192)" && m_EnableChoose!=0)
					{
						$("#chooseLink").css("color","");
						$("#chooseLink").attr("onclick","setQuestion()");
						arrSQuestions=[];
					}
					$("#strAnswer").focus();
				}
				else
				{
					$("#colOne").show();
					m_SessionCount = strActiveSessionCount;
					startSession();
					return false;				
				}
				//LoginCallback();
            }
            else {

                blnSessionTerminateCalled = false;
                
                LoginAttemps = LoginAttemps + 1;
                /*if ($("#ST").val().length == 6 || blnSSI == 0) {
                    strFailedLogins = strFailedLogins + ',' + $("#LN").val().trim(',');
                }*/
                m_Result = strResult;
                if (strResult == 0)     //Fail
                {
                  showMessage();
                }
            }

        }
        else {
            updateTips("The username or password you entered is incorrect. Please try again.");
            return false;
        }
    }

	
	// To Show Number of attempts remaining
	
	function showMessage() {
					var count = 0;
					var userName=$("#LN").val().trim(',')
					var Reason_LU = 16302;
                    var IsValidUser = frmsignon.validateUsername(fnValidateUsername(userName,Reason_LU))
					var arrayvaliduser =IsValidUser.value.split(",")
					var maxLoginAttempts = strLoginAttempts
					if (arrayvaliduser[0] == 0) {
						updateTips("Invalid username or password. Please try again.");
						return false;
					}
					count= parseInt(maxLoginAttempts)-parseInt(arrayvaliduser[1])
					
                    if (parseInt(arrayvaliduser[1]) >= parseInt(maxLoginAttempts) && parseInt(maxLoginAttempts) > 0 && !isNaN(parseInt(maxLoginAttempts)) || parseInt(arrayvaliduser[2])==0) {
                        bValid = false;
                        OpenDialog("User authentication failure. <br> <br> Your account has been locked, please contact system administrator.", '0', "350", "150px", '3', 'Login', function (retVal) { });
                    }
                    else {
                        bValid = false;
                        if (RedirectURL != undefined) {
							$("#LN").focus();
							
							updateTips("Incorrect username and/or password.", undefined, +count + " " + "attempt(s) remaining.");
						}
                        else {
                            $("#ST").focus();
                            updateTips("The captcha text you entered is incorrect. Please try again.", true);
                        }
                        return false;
                    }
	}
	
	m_index=0;
	function setQuestion(){ 
		if (m_Questions.length <= m_index)
			m_index = 0;
		var randomNumber = randomNumberFromRange(0, m_Questions.length - 1);
	    m_index = randomNumber;
	    arrSQuestions.push(m_index);
		$('#dvQuestion').attr("value",m_Questions[m_index].split(Chr(181))[0]);
		$("#dvQuestion").text(m_Questions[m_index].split(Chr(181))[1]);
	}
	var m_indexSec=0; //For Random Questions
	function setQuestionsRandomforSecondary() {
		var m_Question;
		m_Question = m_securityQtns.split(Chr(182));
		m_Question = shuffle(m_Question);
		if (m_indexSec>=m_Question.length) {
			m_indexSec=0;
		if($("#dvQuestion").text()==m_Question[m_indexSec].split(Chr(181))[1] && m_Question.length>1){		
			setQuestionsRandomforSecondary();
			}
	    else if($("#dvQuestion").text()!= m_Question[m_indexSec].split(Chr(181))[1]){
				$('#dvQuestion').attr("value",m_Question[m_indexSec].split(Chr(181))[0]);
			    $("#dvQuestion").text(m_Question[m_indexSec].split(Chr(181))[1]);
			}
		}
		else if($("#dvQuestion").text()==m_Question[m_indexSec].split(Chr(181))[1])
		{
			setQuestionsRandomforSecondary();
		}
		else{
			$('#dvQuestion').attr("value",m_Question[m_indexSec].split(Chr(181))[0]);
		    $("#dvQuestion").text(m_Question[m_indexSec].split(Chr(181))[1]);
		}
		m_indexSec = m_indexSec + 1;
	}
	
	function randomNumberFromRange(min, max) {
		    return Math.floor(Math.random() * (max - min + 1) + min);
}
	
	function shuffle(array) {
	  var currentIndex = array.length, temporaryValue, randomIndex;

	  // While there remain elements to shuffle...
	  while (0 !== currentIndex) {

		// Pick a remaining element...
		randomIndex = Math.floor(Math.random() * currentIndex);
		currentIndex -= 1;

		// And swap it with the current element.
		temporaryValue = array[currentIndex];
		array[currentIndex] = array[randomIndex];
		array[randomIndex] = temporaryValue;
	  }

	  return array;
	}
	
	function fnGetUserDisclaimerStatus(lngUserID){
		var dsStatus = frmsignon.fnGetUserDisclaimerStatus(fnGUD(intUserId))
		return dsStatus;
	}
	
	function fnSaveDisclaimerDataOnUnload(methodName,strDisclaimerIDs)
	{
		try
		{
			var URL = "../AxWebUILogin/frmDisclaimer.aspx";
			var beaconData = { method: methodName, DisclaimerIDs: strDisclaimerIDs}
			var objformdata = new FormData();
			objformdata.append('data', JSON.stringify(beaconData));
			navigator.sendBeacon(URL, objformdata);
		} catch(e){}
	}
	
	function LoginCallback(objValue) {
		if (objValue.value == false) { //issue fix for 95558
            window.location.href = '../AxWebUIMDI/CustomError.Aspx?ErrorCode=User session is active in this machine, please close the active session or open the URL in different browser.';
            return false;
        }	
		
		 var dsStatus = fnGetUserDisclaimerStatus(intUserId);
		if(dsStatus.value.Tables[0].Rows[0] != undefined && dsStatus.value.Tables[0].Rows[0] != null)
		{
	     intGenDisclaimerStatus = dsStatus.value.Tables[0].Rows[0].DisclaimerStatus
		 intCPTDisclaimerStatus = dsStatus.value.Tables[0].Rows[1].DisclaimerStatus
		// strCPTDisclaimer       = dsStatus.value.Tables[0].Rows[1].DisclaimerText
		}
		var strDisIDs = "";
		 
        if (strResult == 1)     //Success 
        {
            if (bValid) {
                bValid = true;
				blnAuthenticated = true;
				if (intGenDisclaimerStatus ==1 && intCPTDisclaimerStatus == 1)
				{
					var intreturnvalue = 0;
					var strURL = "../AxWebUILogin/frmDisclaimer.aspx?Disclaimerid=5";
					AxOpenDojo(strURL, "480", "280","Excelicare Disclaimer", function(intreturnvalue) {
						if(intreturnvalue == 1)
						{
							var strURL = "../AxWebUILogin/frmDisclaimer.aspx?Disclaimerid=4";
							intreturnvalue= 0;
							AxOpenDojo(strURL, "480", "280","CPT Disclaimer", function (intreturnvalue) {
							if(intreturnvalue == 1)
							{
								if (navigator.sendBeacon) {	 
									fnSaveDisclaimerDataOnUnload("fnSaveDisclaimer","5,4");
								}
								else {
									strDisIDs = "5, 4"

										fnsaveDis(intUserId, strDisIDs)
								}
								fnNavigatetoMDI();
								ClearConent();
							}
							});
						}
					});
					
				}
				else if (intGenDisclaimerStatus == 1)
				{
					var strURL = "../AxWebUILogin/frmDisclaimer.aspx?Disclaimerid=5";
					     AxOpenDojo(strURL, "480", "280","Excelicare Disclaimer", function (intreturnvalue) {
							 if(intreturnvalue == 1)
							{
							if (navigator.sendBeacon) 
							{	 
							   fnSaveDisclaimerDataOnUnload("fnSaveDisclaimer",5);
							}
							 else 
							 {
								 strDisIDs = "5"

							   fnsaveDis(intUserId, strDisIDs)
							 }
								 fnNavigatetoMDI();
								 ClearConent();
							}
						 });
						
				}
				else if (intCPTDisclaimerStatus == 1)
				{
					var strURL = "../AxWebUILogin/frmDisclaimer.aspx?Disclaimerid=4";
					     AxOpenDojo(strURL, "480", "280","CPT Disclaimer", function (intreturnvalue) {
							 if(intreturnvalue == 1)
						       {
								if (navigator.sendBeacon) 
							{	 
							   fnSaveDisclaimerDataOnUnload("fnSaveDisclaimer",4);
							}
							 else 
							 {
								 strDisIDs = "4"
							   fnsaveDis(intUserId, strDisIDs)
							 }
								 fnNavigatetoMDI();
								 ClearConent();
							   }
						 });
				}
				else{
					fnNavigatetoMDI();
					ClearConent();
				}
            }
        }
        else if (strResult == 2)    //Force password change for first time login
        {
            if (bValid) {
                var blnConfirmPassRes;
                OpenDialog("You have logged in for the first time. Please change the password.", '0', "500px", "150px", '0', 'Login', function (retVal) {
                    if (retVal == 1) {
						
                        fnNavigatetoMDI();
                        bValid = true;
                        ClearConent();
                    }
                });
                //alert('You have logged in for the first time. Please change the password.');
            }
        }
        else if (strResult == 3)    //IsPasssordExpired
        {
            if (bValid) {
                var blnConfirmPassRes;

                //alert('Your password has expired. Please change it now.');
                OpenDialog("Your password has expired. Please change it now.", '0', "395px", "150px", '0', 'Login', function (retVal) {
                    if (retVal == 1) {
                        fnNavigatetoMDI();
                        bValid = true;
                        ClearConent();
                    }
                });

            }
        }
        else if (strResult == 4)    //Password Reminder
        {
            if (bValid) {
                var blnConfirmPassRes;

                //alert('Your password will expire in ' + intRemainderDays + ' day(s).');
                OpenDialog('Your password will expire in ' + intRemainderDays + ' day(s).', '0', "395px", "150px", '0', 'Login', function (retVal) {
               if (retVal == 1) 
			       {
				       if (intGenDisclaimerStatus ==1 && intCPTDisclaimerStatus == 1)
				          {
				          	 var intreturnvalue = 0;
				          	 var strURL = "../AxWebUILogin/frmDisclaimer.aspx?Disclaimerid=5";
				          	 AxOpenDojo(strURL, "480", "280","Excelicare Disclaimer", function(intreturnvalue) {
				          	  if(intreturnvalue == 1)
				          		{
				          		var strURL = "../AxWebUILogin/frmDisclaimer.aspx?Disclaimerid=4";
				          		intreturnvalue= 0;
				          	     AxOpenDojo(strURL, "480", "280","CPT Disclaimer", function (intreturnvalue) {
				          			 if(intreturnvalue == 1)
				          			 {
										if (navigator.sendBeacon) {	 
											fnSaveDisclaimerDataOnUnload("fnSaveDisclaimer","5,4");
										}
										else {
											strDisIDs = "5, 4"

											fnsaveDis(intUserId, strDisIDs)
										}
				          		      fnNavigatetoMDI();
       			          	           ClearConent();
				          			 }
				          	      });
				          		    
				          		}
				          	});
				          }
				          else if (intGenDisclaimerStatus == 1)
				           {
				          	var strURL = "../AxWebUILogin/frmDisclaimer.aspx?Disclaimerid=5";
				          	     AxOpenDojo(strURL, "480", "280","Excelicare Disclaimer", function (intreturnvalue) {
				          			 if(intreturnvalue == 1)
				          		       {
				          			 if (navigator.sendBeacon) {	 
											fnSaveDisclaimerDataOnUnload("fnSaveDisclaimer",5);
										}
										else {
											strDisIDs = "5"

												fnsaveDis(intUserId, strDisIDs)
										}
				          			 fnNavigatetoMDI();
				          		     ClearConent();
				          		       }
				          		 });
				           }
				          else if (intCPTDisclaimerStatus == 1)
				           {
				          	 var strURL = "../AxWebUILogin/frmDisclaimer.aspx?Disclaimerid=4";
							 AxOpenDojo(strURL, "480", "280","CPT Disclaimer", function (intreturnvalue) {
								if(intreturnvalue == 1)
								{
									if (navigator.sendBeacon) 
										fnSaveDisclaimerDataOnUnload("fnSaveDisclaimer",4);										
									else
										strDisIDs = "4"

										fnsaveDis(intUserId, strDisIDs)
									fnNavigatetoMDI();
									ClearConent();
								}
							 });
				           }
				          
				          else{
				          	fnNavigatetoMDI();
				          	ClearConent();
				          }
                    }
                });

            }
        }
		// else if (strResult == 5 && parseInt(m_allowSecondaryVerification) ==1)    //Password Reminder
		else if (strResult == 5 )    //Password Reminder
        {
            if (bValid) {
                var blnConfirmPassRes;
				loginresult=strResult
                if (m_showForgotPwdLink == "True"){
					OpenDialog("Security questions to verify users on login or when they request password resets must be completed. Please click OK to proceed.", '0', "450px", "150px", '0', 'Login', function (retVal) {
						if (retVal == 1) {
						    fnNavigatetoMDI();
							ClearConent();
							
						}
					});
				}else if(m_showForgotPwdLink == "False")
				{
					if (bValid) {
						bValid = true;
						blnAuthenticated = true;
						
						fnNavigatetoMDI();
					   
						ClearConent();
					}
				}
					

            }
        }
		else if (strResult == 6 ) { //Conditon for Reset password
			if (bValid) {
                var blnConfirmPassRes;
                OpenDialog("Please change your password.", '0', "500px", "150px", '0', 'Login', function (retVal) {
                    if (retVal == 1) {
						
                        fnNavigatetoMDI();
                        bValid = true;
                        ClearConent();
                    }
                });
             
            }
		}
    }


    function fnNavigatetoMDI() {	
         if (intUserLocation == 1)
            GetLocationsData('security', intUserId);
        if (document.getElementById("cbLocation").length == 1 || intUserLocation == 0) {
            fnOpenMDI();
        }
        else {
            //     dialoglocation.show();
        }
    }
    function fnOpenMDI() {
        var LocationValue = -1;
        if (intUserLocation == 1) {
            LocationValue = document.getElementById("cbLocation").value
            if (LocationValue == "")
                LocationValue = -1
        }
        ShowSucessLoingMessage()
		if(strResult==5){
		    
			RedirectURL = "../AxWebUIMDI/frmexcelicaremdi.aspx?ShowQues=True";
		}
        else if(strResult==3 || strResult == 6){
		    
			RedirectURL = "../AxWebUIMDI/frmexcelicaremdi.aspx?IsPwdExpired=True";
		}
  		else 
			RedirectURL = "../AxWebUIMDI/frmexcelicaremdi.aspx";
        if (LocationValue != -1 && intUserLocation == 1) {
            try {
                var objSetLocation = frmsignon.SetLocation(fnSetLocation(LocationValue))
                ProcessAjaxException(objSetLocation)
            }
            catch (ex) { ShowAjaxException(ex, "fnOpenMDI") }						
			sessionStorage.setItem("Ec_Jwt", strTkn);
			if(strTkn === "") { fnGenerateApiToken(); }
            window.location.replace(RedirectURL);
        }
        else if (intUserLocation == 0) {			
			sessionStorage.setItem("Ec_Jwt", strTkn);
			if(strTkn === "") {fnGenerateApiToken();}
            window.location.replace(RedirectURL);
            //window.location.replace(RedirectURL);
        }

        return true;
    }

    function ShowSucessLoingMessage() {
        if (m_Result == 2)    //Force password change for first time login
        {
            OpenDialog("You have logged in for the first time. Please change the password.", '0', "500", "150px", '0', 'Login');
        }
        else if (m_Result == 3)    //IsPasssordExpired
        {
            OpenDialog("Your password has expired. Please change it now.", '0', "395", "150px", '0', 'Login');
        }
        else if (m_Result == 4)    //Password Reminder
        {
            OpenDialog('Your password will expire in ' + intRemainderDays + ' day(s).', '0', "395", "150px", '0', 'Login');
        }
		else if (m_Result == 6)  //Condition for Reset Password
		{
			OpenDialog("Please change your password.", '0', "500", "150px", '0', 'Login');
		}	
    }
	
    function checkUserCredentials(username, password) { 
	var strUID=getUrlParameters()["UID"]
	if(strUID==undefined)
	strUID=""; 
	var objResponse
	showPopup('Authenticating User...', '50%', '50%', '300px', '30px');
	try {
		var strpd = '';
		//var strSysBroadcastDetails = frmsignon.GetSysBroadcastDetails();
		var strDomainNames = '';
		if (m_intADAuthentication == 1)
			strpd = password.val();
		else
			strpd = SHA256(password.val());
		if ($("#cbDomains").prop("selectedIndex") != -1)
			strDomainNames = $("#cbDomains")[0].options[$("#cbDomains").prop("selectedIndex")].text;
		var strUN = encodeURIComponent(username.val());
		var strSecVal = encodeURIComponent(security.val());
		var strUsID = encodeURIComponent(strUID);
		
		if ($ec.fn.fnValidateForXSS(username.val()) == true || $ec.fn.fnValidateForXSS(password.val()) == true) {
			hidePopup();
	    var strDialogUrl = OpenDialog("Invalid characters in content.", '0', "250px", "130px", '3', "Options");
	    AxOpenDojo(strDialogUrl, 300, 150, "Login", function (retXML) {
	        return false;
	    });
	    return false;
	}
		
		
		if (strUID != "")
		{
			  objResponse = frmsignon.CheckUserCredentials(fnCheckUC(strUN, strpd, strSecVal, strDomainNames, m_intADAuthentication, m_allowSecondaryVerification,strUsID, m_strSessionID), checkUserCredentials_Callback)
		}else
		{
			  objResponse = frmsignon.CheckUserCredentials(fnCheckUC(strUN, strpd, strSecVal, strDomainNames, m_intADAuthentication, m_allowSecondaryVerification,strUsID, m_strSessionID), checkUserCredentials_Callback)
			  
		}

	} catch (ex) {
		ShowAjaxException(ex, "checkUserCredentials")
	}

}
	function ValidateSecondaryLogin(intUserId, question, answer, blnInvoke) 
	{ 
        var objResponse
        showPopup('Authenticating Security question...', '50%', '50%', '300px', '30px');
		var intUsrID = encodeURIComponent(intUserId);
		var strQues = encodeURIComponent(question.attr('value'));
		var strAns = encodeURIComponent(answer.val());
		var bnlInv = encodeURIComponent(blnInvoke);
		try {
			  objResponse = frmsignon.ValidateSecondaryLogin(fnValidateSL(intUsrID, strQues, strAns, bnlInv),ValidateSecondaryLogin_Callback);
			hidePopup();
		}
        catch (ex)
        { ShowAjaxException(ex, "ValidateSecondaryLogin") }
    }
	
	function startSession(){
	//	var strURL = window.location.href;
		var intSSOLOCID=0;
		var intSSOLOCID =getUrlParameters()["LID"]
		if(intSSOLOCID ==undefined)
			intSSOLOCID=0;
		 
		if (strResult != 0 && parseInt(m_SessionCount) > 0 && blnSessionTerminateCalled == false) {
                var Rsponse;
                retVal = OpenDialog("You are already logged into Excelicare in another active session. Do you wish to end the active session?", 8192, "500px", "160px", '1', 'Login', function (retVal) {
					retValue = retVal
                    if (retVal == 6 ) {
						frmsignon.StartSession(fnStartSession(intUserId, retVal,intSSOLOCID), LoginCallback);
                    }
                    else if (retVal == 0) {
						$("#colSecLogin").hide();
						$("#colOne").show();
						$("#LN, #PD, #ST, #strAnswer").val("");
                        $("#LN").focus();
						$('.maskText').html('');
						hidePopup();
						intUserId = 0;
					}
                    else
                        return false
                });
            }
            else if (strResult != 0 && intUserId > 0) {
			          	var retVal = 0;
                frmsignon.StartSession(fnStartSession(intUserId, retVal,intSSOLOCID), LoginCallback);
            }
	}
	
	var invokeCount = 0;
	var blnValidSecondarycallback=false;								 
	var blnInvoke = false;
    function ValidateSecondaryLogin_Callback(objResponse) { 
        ProcessAjaxException(objResponse)
        var m_value = objResponse.value
		if (m_value == "true")
		{
			$('#strAnswer').attr("disabled", true); //Disabling Answer textbox to fix EIT-124494
			startSession();
		}else if(invokeCount <= m_MaxSecurityAnsAttempts && blnValidSecondarycallback ==false){
								 
								   
			var strStatus = new Array; //EIT-121795
			strStatus = m_value.split(Chr(186));
			//updateSecTips(strStatus[1]);
			OpenDialog(strStatus[1], '0', "250", "150px", '3', 'Login',"",function (retVal) {
			blnValidSecondarycallback=false;
			 invokeCount = invokeCount + 1;
			 setQuestionsRandomforSecondary()
			 $("#strAnswer").val("");
			 $("#btnSeclogin").removeAttr("disabled");								 
			if (invokeCount == m_MaxSecurityAnsAttempts-1 ) {
					
				  blnInvoke = true;
				}
			if(invokeCount == m_MaxSecurityAnsAttempts){
				    $("#colOne").show();
				 var strSysBroadcastDetails = frmsignon.GetSysBroadcastDetails();
				 if (strSysBroadcastDetails.value != null && strSysBroadcastDetails.value != "" && strSysBroadcastDetails.value != "<DataSet />")
					$("#colTwo").show();
					$("#colSecLogin").hide();
					blnInvoke = false;
					intUserId=0; // To Fix EIT-121771
					invokeCount=0;
					showMessage();
				//OpenDialog("User authentication failure.", '0', "250", "150px", '3', 'Login', function (retVal) { window.top.location.href = "../AxWebUILogin/frmSignOn.Aspx";}, function (retVal) { window.top.location.href = "../AxWebUILogin/frmSignOn.Aspx";});
			}
			});
		   blnValidSecondarycallback=true;	
		}else
			return false
    }
	function updateSecTips(t) {
        answer.val('')
        $('#trvalidateTips').show();
		$("#secdivErrorMsg").css("display", "block");
        // tips.toggleClass('validatehide', 'validateshow');
        $('#secvalidateTips').text(t)//.effect("highlight", {}, 1500);
    }
	
	function checkUserCredentials_Callback(objResponse) 
	{
		try{
			if($ec.fn.ecDecode(objResponse.value)!= "Invalid Session")
			{		
			fnValidUserCredentials(objResponse);
			if (m_issysMFAEnabled == "True" && IsUserMFAEnabled != "0" && strResult != 2 && intUserId > 0)
			{
				
						 
		  
							 
						
						var strURL = "frmMFA.aspx";
						var OnHideHandleCallback=function (retval) {
						  
									if(retval==2 && strResult!=0){
									ProcessAjaxException(objResponse)
									fnCheckUserComplete(objResponse)


									
								}   
								else 
								{
									blnAuthenticated=false
									$("#colSecLogin").hide();
									$("#colOne").show();
									if(parseInt(m_allowSecondaryVerification) == 0)						  
									$("#LN, #PD, #ST, #strAnswer").val("");
									$("#LN").focus();
									$('.maskText').html('');
									hidePopup();
									intUserId = 0;
									
								}
							};
							AxOpenDojo(strURL, "450", "350","Login with Two Factor Authentication", OnHideHandleCallback,OnHideHandleCallback);
						}
						else 
						 {
							ProcessAjaxException(objResponse)
							fnCheckUserComplete(objResponse)
						 }
			} else{
				hidePopup();
			}
			
			 } catch(e){}   
    }
	
    function checkSecurityKey() {
        if (document.getElementById("security1").style.visibility == "visible" && security.val() == "") {
            updateTips("Type the security image text correctly in the text box above.");
            return false;
        }
		var strSecvalue = security.val();
        var ReturnValue = frmsignon.CheckSecurity(fnChkSecurity(strSecvalue)).value;
        if (ReturnValue) {
            return true;
        }
        else {
            updateTips("Type the security image text correctly in the text box above.");
            return false;
        }

    }
    function checkLocationValue() {
		if (intUserLocation == 0)
            return true;
        var LocationValue;
        var blnValid;
        LocationValue = document.getElementById("cbLocation").value
        if (LocationValue > 0)
            blnValid = true
        else
            updateTips("The username or password you entered is incorrect. Please try again.");
        return blnValid;
    }
    function openNewWindow(strUrl) {
        window.location.replace(strUrl)
    }

    function clearLocation() {
        if (intUserLocation == 1)
            document.getElementById('cbLocation').length = 0;
    }


    $('#btnlogin').click(function (event) {
        
        if (($ec.fn.chrome() || $ec.fn.safari() || $ec.fn.firefox()) && event.clientX == 0) return false
        $('#trvalidateTips').hide();
        $("#divErrorMsg").css("display", "none");
        tips.text(' ');
        bValid = true;
        // allFields.removeClass('ui-state-error');
        bValid = bValid && checkLength(name, "username", 1, 200);
        bValid = bValid && checkLength(password, "password", 1, 30);
		invokeCount=0;
        //bValid = bValid && checkRegexp(name, /^[a-z]([0-9a-z_])+$/i, "Username may consist of a-z, 0-9, underscores, begin with a letter.");
        //  bValid = bValid && checkRegexp(password, /^([0-9a-zA-Z])+$/, "Password field only allow : a-z 0-9");
        //bValid = bValid && checkSecurityKey() && checkLocationValue()
        if (bValid)
            checkUserCredentials(name, password)

    });
	
	$('#cancel').click(function () {
        $('#trvalidateTips').hide();
        $("#divErrorMsg").css("display", "none");
        name.val('');
        password.val('');
        name.focus('');
        name.removeClass("ui-state-error");
        password.removeClass("ui-state-error");
        clearLocation();
        security.val('');
        tips.text(' ');
        fnRefreshSecurityImage();

        $("#LN,#PD").next().show();

    });
	$('#btnSeclogin').click(function (event) {
        if (($ec.fn.chrome() || $ec.fn.safari() || $ec.fn.firefox()) && event.clientX == 0) return false
        $('#trvalidateTips').hide();
        $("#divErrorMsg").css("display", "none");
        tips.text(' ');
        bValid = true;
        // allFields.removeClass('ui-state-error');
		//bValid = bValid && checkLength(name, "username", 1, 100);
        bValid = bValid && checkSecLength(question, "question", 1, 100);
        bValid = bValid && checkSecLength(answer, "answer", 1, 100);
		if (bValid)
			ValidateSecondaryLogin(intUserId,question, answer,blnInvoke)
		else if (parseInt(m_allowSecondaryVerification) != 0 && m_showForgotPwdLink == "True"){
			$("#colSecLogin").show();
			$("#colOne").hide();
			$("#colTwo").hide();
			updateSecTips("Please enter answer");
			$('#strAnswer').focus('');
			hidePopup();
			return false
		}			

    });
    $('#SecCancel').click(function () {
        $('#trvalidateTips').hide();
        $("#divErrorMsg").css("display", "none");
        answer.val('');
        answer.removeClass("ui-state-error");
        clearLocation();
		tips.text(' ');
		window.location.href = "frmSignOn.Aspx";
		$("#dvQuestion,#strAnswer").next().show();

    });
	
    $('#forgotyourpassword').click(function () {
        // openNewWindow("frmBlankPage.htm")
    });
    $('#register').click(function () {
        // openNewWindow("frmBlankPage.htm")
    });
	
	
    $(document).keyup(function (event) {
		var intKeyCode;
        var oSrcElement;
        try {
			$("#divErrorMsg").css("display", "none");
			event = event || window.event;
            intKeyCode = ($ec.fn.msie()) ? event.keyCode : event.which;
            oSrcElement = ($ec.fn.msie()) ? window.event.srcElement : event.target;
			//alert("  " + $('#strAnswer').val())
			if ((event.ctrlKey == false && (intKeyCode == 13 && intUserId == 0) && $('#LN').val() !="" && oSrcElement.id != ""  && oSrcElement.id != "cancel" && oSrcElement.id != "cmdRefresh" && oSrcElement.id != "strAnswer" && oSrcElement.id != "forgotPwdLink") )  {
                if ($ec.fn.chrome() || $ec.fn.safari()) {
                    $('#trvalidateTips').hide();
					$("#divErrorMsg").css("display", "none");
                    $("#validateTips").text(' ');
                    bValid = true;
                    bValid = bValid && checkLength(name, "username", 1, 200);
                    bValid = bValid && checkLength(password, "password", 1, 30);
                    if (bValid) 
                        checkUserCredentials(name, password)
				}
                else {
                    $('#btnlogin').trigger("click");
                }
            }else if ((event.ctrlKey == false && intKeyCode == 13  && oSrcElement.id != "cancel" && oSrcElement.id != ""  && $('#strAnswer').val() !="" && oSrcElement.id != "SecCancel" && parseInt(m_allowSecondaryVerification) == 1)){
					$("#colOne").hide();
					$("#colTwo").hide();
					if($ec.fn.chrome() || $ec.fn.safari()){
						$('#trvalidateTips').hide();
						$("#divErrorMsg").css("display", "none");
						$("#validateTips").text(' ');
						bValid = true;		
						bValid = bValid && checkSecLength(question, "question", 1, 100);
						bValid = bValid && checkSecLength(answer, "answer", 1, 100);
						if (bValid)
							ValidateSecondaryLogin(intUserId,question, answer,blnInvoke)
						else{
							$('#colOne').hide();					//done for enter 26-02-2015
							$("#colTwo").hide();	
							updateSecTips("Please enter answer");
						}
					}
					else{
						$('#btnSeclogin').trigger("click");
					}
			}
			
            KillSpaceBar(event);
        }
        catch (e) { }
    });
});

function stopkeypress() {
    return false;
}

var opened = false, vkb = null, text = null, insertionS = 0, insertionE = 0;

var userstr = navigator.userAgent.toLowerCase();
var safari = (userstr.indexOf('applewebkit') != -1);
var gecko = (userstr.indexOf('gecko') != -1) && !safari;
var standr = gecko || window.opera || safari;

// This function is the "connector" from arbitrary length
// units to "px" world. Parameters are:
//
// 'obj' - object, in which context we should determine
//            the px value from the size given in 'value';
//
// 'value' - string, consisting of the numeric value and
//                the length unit designator.
//
function convert_to_px(obj, value) {
    // Inner function - retrieves the (default) font size
    // for the given object.
    function get_font_size(obj) {
        // Standard way:
        if (window.getComputedStyle)
            return window.getComputedStyle(obj, "").getPropertyValue("font-size");

        // MS IE way:
        if (obj.currentStyle)
            return obj.currentStyle.fontSize;

        return "16px";
    }

    var unit, valu, last = value.length ? value.substr(value.length - 1, 1) : "";

    if (isNaN(last)) {
        var def = get_font_size(document.body);
        unit = def.substr(def.length - 2, 2), valu = def.substr(0, def.indexOf(unit));

        switch (value) {
            case "xx-small": valu -= 3; break;
            case "x-small": valu -= 2; break;
            case "small": valu -= 1; break;
            case "medium": break; // already set
            case "large": valu += 1; break;
            case "x-large": valu += 2; break;
            case "xx-large": valu += 3; break;
            default:
                if (value.length) {
                    unit = (last == "%") ? "%" : value.substr(value.length - 2, 2);
                    valu = value.substr(0, value.indexOf(unit));
                }
        }
    }
    else
        return value;

    if (unit == "px")
        return valu;

    // Below we have the main problem with the code. The problem is -
    // only MS IE has the facility ('window.screen.logicalXDPI' property)
    // to determine current screen DPI, which we need to convert values
    // from absolute length units (pt, pc, in, cm, mm) to pixels.
    //
    // Currently, no other browser has the way to retrieve the DPI,
    // so we have to use the "usual" value of 96 DPI (== 1.3333 pixels
    // per point), which is quite common for Windows machines.
    //
    // With browsers other than MS IE, only relative length units
    // (em, ex, % or px) can be used safely.

    // Pixels per point:
    var px_per_pt = window.screen.logicalXDPI ? (window.screen.logicalXDPI / 72.0) : 1.3333;

    // 'base_u' - base unit for current hierarchy level;
    // 'base_v' - base value for current hierarchy level;
    //
    var base_u, base_v = 1, obj_ = obj;

    do {
        var base = get_font_size(obj_);
        if (String(base).length) {
            var tmp = base.substr(base.length - 1, 1);

            if (isNaN(tmp)) {
                base_u = (tmp == "%") ? "%" : base.substr(base.length - 2, 2);
                base_v *= base.substr(0, base.indexOf(base_u));

                if (base_u == "%") { base_v /= 100.0; }
                else if (base_u == "ex") { base_v /= 2.0; }
                else if (base_u == "em") { }
                else break;
            }
            else {
                base_u = "px";
                base_v *= base;
                break;
            }
        }

        obj_ = obj_.parentNode;
    }
    while (obj_ != document.documentElement);

    if (!base_v) { base_v = 16; base_u = "px"; }

    switch (unit) {
        case "%": valu /= 50.0;
        case "ex": valu /= 2.0;
        case "em": valu *= base_v, unit = base_u;
    }

    switch (unit) {
        case "mm": valu *= 0.1;
        case "cm": valu *= 0.3937007874015748031496062992126;
        case "in": valu *= 6
        case "pc": valu *= 12;
        case "pt": valu *= px_per_pt;
    }

    return valu;
}

function keyb_change(size) {

    //document.getElementById("switch").innerHTML = (opened ? "Show keyboard" : "Hide keyboard");
    opened = !opened;

    if (opened && !vkb) {
        var obj = document.getElementById("keyboard");

        vkb = new VKeyboard("keyboard",    // container's id
                           keyb_callback, // reference to the callback function
                           false,          // create the arrow keys or not? (this and the following params are optional)
                           false,          // create up and down arrow keys? 
                           false,         // reserved
                           false,          // create the numpad or not?
                           "",            // font name ("" == system default)
   convert_to_px(obj, size) + "px",        // font size in px
                           "#000",        // font color
                           "#F00",        // font color for the dead keys
                           "#FFF",        // keyboard base background color
                           "#FFF",        // keys' background color
                           "#DDD",        // background color of switched/selected item
                           "#777",        // border color
                           "#CCC",        // border/font color of "inactive" key (key with no value/disabled)
                           "#FFF",        // background color of "inactive" key (key with no value/disabled)
                           "#F77",        // border color of the language selector's cell
                           true,          // show key flash on click? (false by default)
                           "#CC3300",     // font color during flash
                           "#FF9966",     // key background color during flash
                           "#CC3300",     // key border color during flash
                           false,         // embed VKeyboard into the page?
                           true,          // use 1-pixel gap between the keys?
                           0);            // index(0-based) of the initial layout
    }
    else
        vkb.Show(opened);

    text = document.getElementById("PD");
    /*text.focus();

    if (document.attachEvent)
    text.attachEvent("onblur", backFocus);
    */
}

function backFocus() {
    if (opened) {
        var l = text.value.length;

        setRange(text, insertionS, insertionE);

        text.focus();
    }
}

// Advanced callback function:
//
function keyb_callback(ch) {
    var val = text.value;

    switch (ch) {
        case "BackSpace":
            if (val.length) {
                var span = null;

                if (document.selection)
                    span = document.selection.createRange().duplicate();

                if (span && span.text.length > 0) {
                    span.text = "";
                    getCaretPositions(text);
                }
                else
                    deleteAtCaret(text);
            }

            break;

        case "<":
            if (insertionS > 0)
                setRange(text, insertionS - 1, insertionE - 1);

            break;

        case ">":
            if (insertionE < val.length)
                setRange(text, insertionS + 1, insertionE + 1);

            break;

        case "/\\":
            if (!standr) break;

            var prev = val.lastIndexOf("\n", insertionS) + 1;
            var pprev = val.lastIndexOf("\n", prev - 2);
            var next = val.indexOf("\n", insertionS);

            if (next == -1) next = val.length;
            var nnext = next - insertionS;

            if (prev > next) {
                prev = val.lastIndexOf("\n", insertionS - 1) + 1;
                pprev = val.lastIndexOf("\n", prev - 2);
            }

            // number of chars in current line to the left of the caret:
            var left = insertionS - prev;

            // length of the prev. line:
            var plen = prev - pprev - 1;

            // number of chars in the prev. line to the right of the caret:
            var right = (plen <= left) ? 1 : (plen - left);

            var change = left + right;
            setRange(text, insertionS - change, insertionE - change);

            break;

        case "\\/":
            if (!standr) break;

            var prev = val.lastIndexOf("\n", insertionS) + 1;
            var next = val.indexOf("\n", insertionS);
            var pnext = val.indexOf("\n", next + 1);

            if (next == -1) next = val.length;
            if (pnext == -1) pnext = val.length;

            if (pnext < next) pnext = next;

            if (prev > next)
                prev = val.lastIndexOf("\n", insertionS - 1) + 1;

            // number of chars in current line to the left of the caret:
            var left = insertionS - prev;

            // length of the next line:
            var nlen = pnext - next;

            // number of chars in the next line to the left of the caret:
            var right = (nlen <= left) ? 0 : (nlen - left - 1);

            var change = (next - insertionS) + nlen - right;
            setRange(text, insertionS + change, insertionE + change);

            break;

        default:
            insertAtCaret(text, (ch == "Enter" ? (window.opera ? '\r\n' : '\n') : ch));
    }
}

// This function retrieves the position (in chars, relative to
// the start of the text) of the edit cursor (caret), or, if
// text is selected in the TEXTAREA, the start and end positions
// of the selection.
//
function getCaretPositions(ctrl) {
    var CaretPosS = -1, CaretPosE = 0;

    // Mozilla way:
    if (ctrl.selectionStart || (ctrl.selectionStart == '0')) {
        CaretPosS = ctrl.selectionStart;
        CaretPosE = ctrl.selectionEnd;

        insertionS = CaretPosS == -1 ? CaretPosE : CaretPosS;
        insertionE = CaretPosE;
    }
    // IE way:
    else if (document.selection && ctrl.createTextRange) {
        var start = end = 0;
        try {
            start = Math.abs(document.selection.createRange().moveStart("character", -10000000)); // start

            if (start > 0) {
                try {
                    var endReal = Math.abs(ctrl.createTextRange().moveEnd("character", -10000000));

                    var r = document.body.createTextRange();
                    r.moveToElementText(ctrl);
                    var sTest = Math.abs(r.moveStart("character", -10000000));
                    var eTest = Math.abs(r.moveEnd("character", -10000000));

                    if ((ctrl.tagName.toLowerCase() != 'input') && (eTest - endReal == sTest))
                        start -= sTest;
                }
                catch (err) { }
            }
        }
        catch (e) { }

        try {
            end = Math.abs(document.selection.createRange().moveEnd("character", -10000000)); // end
            if (end > 0) {
                try {
                    var endReal = Math.abs(ctrl.createTextRange().moveEnd("character", -10000000));

                    var r = document.body.createTextRange();
                    r.moveToElementText(ctrl);
                    var sTest = Math.abs(r.moveStart("character", -10000000));
                    var eTest = Math.abs(r.moveEnd("character", -10000000));

                    if ((ctrl.tagName.toLowerCase() != 'input') && (eTest - endReal == sTest))
                        end -= sTest;
                }
                catch (err) { }
            }
        }
        catch (e) { }

        insertionS = start;
        insertionE = end
    }
}

function setRange(ctrl, start, end) {
    if (ctrl.setSelectionRange) // Standard way (Mozilla, Opera, Safari ...)
    {
        ctrl.setSelectionRange(start, end);
    }
    else // MS IE
    {
        var range;

        try {
            range = ctrl.createTextRange();
        }
        catch (e) {
            try {
                range = document.body.createTextRange();
                range.moveToElementText(ctrl);
            }
            catch (e) {
                range = null;
            }
        }

        if (!range) return;

        range.collapse(true);
        range.moveStart("character", start);
        range.moveEnd("character", end - start);
        range.select();
    }

    insertionS = start;
    insertionE = end;
}

function deleteSelection(ctrl) {
    if (insertionS == insertionE) return;

    var tmp = (document.selection && !window.opera) ? ctrl.value.replace(/\r/g, "") : ctrl.value;
    ctrl.value = tmp.substring(0, insertionS) + tmp.substring(insertionE, tmp.length);

    setRange(ctrl, insertionS, insertionS);
}

function deleteAtCaret(ctrl) {
    // if(insertionE < insertionS) insertionE = insertionS;
    if (insertionS != insertionE) {
        deleteSelection(ctrl);
        return;
    }

    if (insertionS == insertionE)
        insertionS = insertionS - 1;

    var tmp = (document.selection && !window.opera) ? ctrl.value.replace(/\r/g, "") : ctrl.value;
    ctrl.value = tmp.substring(0, insertionS) + tmp.substring(insertionE, tmp.length);

    setRange(ctrl, insertionS, insertionS);
}

// This function inserts text at the caret position:
//
function insertAtCaret(ctrl, val) {
    if (insertionS != insertionE) deleteSelection(ctrl);

    if (gecko && document.createEvent && !window.opera) {
        var e = document.createEvent("KeyboardEvent");

        if (e.initKeyEvent && ctrl.dispatchEvent) {
            e.initKeyEvent("keypress",        // in DOMString typeArg,
                        false,             // in boolean canBubbleArg,
                        true,              // in boolean cancelableArg,
                        null,              // in nsIDOMAbstractView viewArg, specifies UIEvent.view. This value may be null;
                        false,             // in boolean ctrlKeyArg,
                        false,             // in boolean altKeyArg,
                        false,             // in boolean shiftKeyArg,
                        false,             // in boolean metaKeyArg,
                        null,              // key code;
                        val.charCodeAt(0)); // char code.

            ctrl.dispatchEvent(e);
        }
    }
    else {
        var tmp = (document.selection && !window.opera) ? ctrl.value.replace(/\r/g, "") : ctrl.value;
        ctrl.value = tmp.substring(0, insertionS) + val + tmp.substring(insertionS, tmp.length);
    }

    setRange(ctrl, insertionS + val.length, insertionS + val.length);
}

function fnRefreshSecurityImage() {
    setTimeout("LoadCaptchaImage()", 0);
	return false;
}

function LoadCaptchaImage() {
    if (document.getElementById("imgCaptchaLogin") != null)
        document.getElementById("imgCaptchaLogin").src = "../AxWebUILogin/Captcha.aspx?from=login&V=" + new Date().valueOf();
}

function fnLinkClick(intValue) {
    try {
        if (intValue == 1)
            var strLoginURL = "/frmAxHelp.htm"
        else if (intValue == 2)
            var strLoginURL = "/frmAxPrivacy.htm"
        else
            var strLoginURL = "/frmAxServices.htm"

        var browser = navigator.appName;

        var b_version = navigator.appVersion;
        var version = parseFloat(b_version);
        if (browser == "Netscape") {
            document.location.replace(strLoginURL)
        }
        else if (browser == "Microsoft Internet Explorer") {
            if (document.all || document.layers) {
                w = screen.availWidth;
                h = screen.availHeight;
                //var popW = 800, popH = 380;
                var popW = 800, popH = 565;
                var leftPos = (w - popW) / 2, topPos = (h - popH) / 2;
            }
            window.open(strLoginURL, "", 'scrollbars=no ,menubar=no,location=no,resizable=0,width=' + popW + ',height=' + popH + ',left=' + leftPos + ',top=' + topPos);
            //this.focus();
            self.opener = top;
            //self.close();
        }
    }
    catch (e) {

    }
}
function SHA256(s) {
    var chrsz = 8, hexcase = 0;
    function safe_add(x, y) { var lsw = (x & 0xFFFF) + (y & 0xFFFF), msw = (x >> 16) + (y >> 16) + (lsw >> 16); return (msw << 16) | (lsw & 0xFFFF); }
    function S(X, n) { return (X >>> n) | (X << (32 - n)); }
    function R(X, n) { return (X >>> n); }
    function Ch(x, y, z) { return ((x & y) ^ ((~x) & z)); }
    function Maj(x, y, z) { return ((x & y) ^ (x & z) ^ (y & z)); }
    function Sigma0256(x) { return (S(x, 2) ^ S(x, 13) ^ S(x, 22)); }
    function Sigma1256(x) { return (S(x, 6) ^ S(x, 11) ^ S(x, 25)); }
    function Gamma0256(x) { return (S(x, 7) ^ S(x, 18) ^ R(x, 3)); }
    function Gamma1256(x) { return (S(x, 17) ^ S(x, 19) ^ R(x, 10)); }
    function core_sha256(m, l) {
        var K = new Array(0x428A2F98, 0x71374491, 0xB5C0FBCF, 0xE9B5DBA5, 0x3956C25B, 0x59F111F1, 0x923F82A4, 0xAB1C5ED5, 0xD807AA98, 0x12835B01, 0x243185BE, 0x550C7DC3, 0x72BE5D74, 0x80DEB1FE, 0x9BDC06A7, 0xC19BF174, 0xE49B69C1, 0xEFBE4786, 0xFC19DC6, 0x240CA1CC, 0x2DE92C6F, 0x4A7484AA, 0x5CB0A9DC, 0x76F988DA, 0x983E5152, 0xA831C66D, 0xB00327C8, 0xBF597FC7, 0xC6E00BF3, 0xD5A79147, 0x6CA6351, 0x14292967, 0x27B70A85, 0x2E1B2138, 0x4D2C6DFC, 0x53380D13, 0x650A7354, 0x766A0ABB, 0x81C2C92E, 0x92722C85, 0xA2BFE8A1, 0xA81A664B, 0xC24B8B70, 0xC76C51A3, 0xD192E819, 0xD6990624, 0xF40E3585, 0x106AA070, 0x19A4C116, 0x1E376C08, 0x2748774C, 0x34B0BCB5, 0x391C0CB3, 0x4ED8AA4A, 0x5B9CCA4F, 0x682E6FF3, 0x748F82EE, 0x78A5636F, 0x84C87814, 0x8CC70208, 0x90BEFFFA, 0xA4506CEB, 0xBEF9A3F7, 0xC67178F2);
        var HASH = new Array(0x6A09E667, 0xBB67AE85, 0x3C6EF372, 0xA54FF53A, 0x510E527F, 0x9B05688C, 0x1F83D9AB, 0x5BE0CD19);
        var W = new Array(64), a, b, c, d, e, f, g, h, i, j, T1, T2;
        m[l >> 5] |= 0x80 << (24 - l % 32); m[((l + 64 >> 9) << 4) + 15] = l;
        for (var i = 0; i < m.length; i += 16) {
            a = HASH[0]; b = HASH[1]; c = HASH[2]; d = HASH[3]; e = HASH[4]; f = HASH[5]; g = HASH[6]; h = HASH[7];
            for (var j = 0; j < 64; j++) {
                if (j < 16) W[j] = m[j + i];
                else W[j] = safe_add(safe_add(safe_add(Gamma1256(W[j - 2]), W[j - 7]), Gamma0256(W[j - 15])), W[j - 16]);
                T1 = safe_add(safe_add(safe_add(safe_add(h, Sigma1256(e)), Ch(e, f, g)), K[j]), W[j]);
                T2 = safe_add(Sigma0256(a), Maj(a, b, c)); h = g; g = f; f = e; e = safe_add(d, T1); d = c; c = b; b = a; a = safe_add(T1, T2);
            }
            HASH[0] = safe_add(a, HASH[0]); HASH[1] = safe_add(b, HASH[1]); HASH[2] = safe_add(c, HASH[2]); HASH[3] = safe_add(d, HASH[3]); HASH[4] = safe_add(e, HASH[4]); HASH[5] = safe_add(f, HASH[5]); HASH[6] = safe_add(g, HASH[6]); HASH[7] = safe_add(h, HASH[7]);
        } return HASH;
    }
    function str2binb(str) {
        var bin = Array(), mask = (1 << chrsz) - 1;
        for (var i = 0; i < str.length * chrsz; i += chrsz) { bin[i >> 5] |= (str.charCodeAt(i / chrsz) & mask) << (24 - i % 32); }
        return bin;
    }
    function Utf8Encode(string) {
        string = string.replace(/\r\n/g, "\n");
        var utftext = "";
        for (var n = 0; n < string.length; n++) {
            var c = string.charCodeAt(n);
            if (c < 128) { utftext += String.fromCharCode(c) }
            else if ((c > 127) && (c < 2048)) { utftext += String.fromCharCode((c >> 6) | 192); utftext += String.fromCharCode((c & 63) | 128); }
            else { utftext += String.fromCharCode((c >> 12) | 224); utftext += String.fromCharCode(((c >> 6) & 63) | 128); utftext += String.fromCharCode((c & 63) | 128); }
        }
        return utftext;
    }
    function binb2hex(binarray) {
        var hex_tab = hexcase ? "0123456789ABCDEF" : "0123456789abcdef";
        var str = "";
        for (var i = 0; i < binarray.length * 4; i++) {
            str += hex_tab.charAt((binarray[i >> 2] >> ((3 - i % 4) * 8 + 4)) & 0xF) +
					hex_tab.charAt((binarray[i >> 2] >> ((3 - i % 4) * 8)) & 0xF);
        }
        return str;
    }
    s = Utf8Encode(s);
    return binb2hex(core_sha256(str2binb(s), s.length * chrsz));
}


function GetLocationsData(strCalledFrom,intUserId) {

    if (intUserLocation != 0 && document.getElementById("LN").value != "" && document.getElementById("PD").value != "") {
        if (blnSSI == 0 || (blnSSI != 0 && document.getElementById("ST").value != "")) {
            GetUserLocations(document.getElementById("LN").value, document.getElementById("PD").value, document.getElementById("ST").value, strCalledFrom, intUserId)
        }
    }
}

function GetUserLocations(name, password, security, strCalledFrom, intUserId) {

    document.getElementById("cbLocation").length = 0;
    try {
		var strName = encodeURIComponent(name);
		var strPwd = SHA256(password);
		var strSecurity = encodeURIComponent(security);
        var Locations = $ec.fn.ecDecode(frmsignon.GetUserLocations(fnGetUserLocations(strName, strPwd, strSecurity, strCalledFrom, intUserId)).value);
        if (Locations != undefined && Locations != null) {

            if (Locations.error != null) throw new Error(-1, Locations.error.name + ' - ' + Locations.error.description);

            if ($ec.fn.msie()) {
                var xmlDom = new ActiveXObject("Microsoft.XMLDOM");
                xmlDom.async = "false";
                xmlDom.loadXML(Locations);
                xmlDom = $(xmlDom)
            }
            else {
                xmlDom = $(Locations)
            }

            xmlLOCNodeList = xmlDom.find("Loc");

            if (xmlLOCNodeList != undefined && xmlLOCNodeList != null && xmlLOCNodeList.length > 0) {
                for (intloop = 0; intloop < xmlLOCNodeList.length; intloop++) {
                    oLOC = $(xmlLOCNodeList.get(intloop))
                    fillLocations(oLOC.find("Name").text(), oLOC.find("ID").text(), oLOC.find("IsPrimary").text())
                    if (oLOC.find("IsPrimary").text() == "True") {
                        try {
                            $("#cbLocation").val(oLOC.find("ID").text());
                        }
                        catch (e) { }
                    }
                }
            }
        }
    }
    catch (e) {
        if (g_ShowScriptErrors == "True") alert("GetUserLocations : " + e.message)
    }

}

function fillLocations(strText, strValue, IsPrimary) {
    $('#cbLocation').append("<option value='" + strValue + "' " + ((IsPrimary == "True") ? "selected" : "") + ">" + strText + "</option>");
    //var oOption = document.createElement("option");
    // oOption.innerText = strText
    // oOption.value = strValue
    // oOption.title = strText
    //  document.getElementById("cbLocation").options.appendChild(oOption);

}
function cbLocationClick()
{	
if (document.getElementById('cbLocation').length == 0)
return GetLocationsData()
}
function ClearConent() {
    //document.getElementById("LN").value = ''
    //document.getElementById("PD").value = ''
    //document.getElementById("ST").value = ''
    $("#LN, #PD, #ST").val("");
    $("#divErrorMsg").css("display", "none");
 //   if (intUserLocation == 1)
 //   	document.getElementById('cbLocation').length = 0;
}

//System Broadcast - Start
function fnGetSysBroadcastDetails() {
	
    try {
        var strActualStartDateTime;
        var dtActualStartDateTime;
        var strActualEndDateTime;
        var dtActualEndDateTime;
        var strCurrentDateTime;
        var dtCurrentDateTime;
        var strMessage = "";
        var intRows = 0;
        var intShow_At_Login_Before_InHours = 1;
        var dblShow_Reminder_Before_InMinutes = 60;
        var dblBroadCastType = 0;
        var blnRequiresSysShutdown = "false";
        var xmlDom, xmlCDom;
        if ($ec.fn.msie()) {
            xmlDom = new ActiveXObject("Microsoft.XMLDOM");
            xmlCDom = new ActiveXObject("Microsoft.XMLDOM");
        } else {
            xmlDom = new DOMParser();
        }
        xmlDom.async = "false";
        var strSysBroadcastDetails = frmsignon.GetSysBroadcastDetails();
        ProcessAjaxException(strSysBroadcastDetails)

        if (strSysBroadcastDetails.value != null && strSysBroadcastDetails.value != "" && strSysBroadcastDetails.value != "<DataSet />") {
            $("#colTwo").css("display", "block");
            $("#colOne").css("float", "left");
            $("#colOne").css("margin-right", "2.5%");
            $("#colOne").css("margin-left", "28%");
            if ($ec.fn.msie()) {
                xmlDom.loadXML(strSysBroadcastDetails.value);
            } else {
                xmlDom = xmlDom.parseFromString(strSysBroadcastDetails.value, 'text/xml');
            }
            if (xmlDom.selectNodes("DataSet/Table").length > 1) {
                for (intRows = 0; intRows < xmlDom.selectNodes("DataSet/Table").length; intRows++) {
                    if ($ec.fn.msie()) {
                        xmlCDom.loadXML(xmlDom.selectNodes("DataSet/Table").item(intRows).xml);
                        xmlCDom.async = "false";
                    } else {
                        xmlCDom = null;
                        xmlCDom = new DOMParser();
                        xmlCDom = xmlCDom.parseFromString((new XMLSerializer()).serializeToString(xmlDom.selectNodes("DataSet/Table")[intRows]), 'text/xml')
                    }
                    if (xmlCDom.selectSingleNode("Table/Actual_StartDateTime") != null && xmlCDom.selectSingleNode("Table/Actual_StartDateTime").text != "") {
                        strActualStartDateTime = xmlCDom.selectSingleNode("Table/Actual_StartDateTime").text;
                        strActualStartDateTime = strActualStartDateTime.replace("-", "/").replace("-", "/").replace("T", " ");
                        if (strActualStartDateTime.indexOf("+") > -1)
                            strActualStartDateTime = strActualStartDateTime.substring(0, strActualStartDateTime.indexOf("+"))
                        if (strActualStartDateTime.indexOf("-") > -1)
                            strActualStartDateTime = strActualStartDateTime.substring(0, strActualStartDateTime.indexOf("-"))
                        dtActualStartDateTime = new Date(strActualStartDateTime)
                    } else if (xmlCDom.selectSingleNode("Table/Scheduled_StartDateTime") != null && xmlCDom.selectSingleNode("Table/Scheduled_StartDateTime").text != "") {
                        strActualStartDateTime = xmlCDom.selectSingleNode("Table/Scheduled_StartDateTime").text;
                        strActualStartDateTime = strActualStartDateTime.replace("-", "/").replace("-", "/").replace("T", " ");
                        if (strActualStartDateTime.indexOf("+") > -1)
                            strActualStartDateTime = strActualStartDateTime.substring(0, strActualStartDateTime.indexOf("+"))
                        if (strActualStartDateTime.indexOf("-") > -1)
                            strActualStartDateTime = strActualStartDateTime.substring(0, strActualStartDateTime.indexOf("-"))
                        dtActualStartDateTime = new Date(strActualStartDateTime)
                    }
                    if (xmlCDom.selectSingleNode("Table/Actual_EndDateTime") != null && xmlCDom.selectSingleNode("Table/Actual_EndDateTime").text != "") {
                        strActualEndDateTime = xmlCDom.selectSingleNode("Table/Actual_EndDateTime").text;
                        strActualEndDateTime = strActualEndDateTime.replace("-", "/").replace("-", "/").replace("T", " ");
                        if (strActualEndDateTime.indexOf("+") > -1)
                            strActualEndDateTime = strActualEndDateTime.substring(0, strActualEndDateTime.indexOf("+"))
                        if (strActualEndDateTime.indexOf("-") > -1)
                            strActualEndDateTime = strActualEndDateTime.substring(0, strActualEndDateTime.indexOf("-"))
                        dtActualEndDateTime = new Date(strActualEndDateTime);
                    } else if (xmlCDom.selectSingleNode("Table/Scheduled_EndDateTime") != null && xmlCDom.selectSingleNode("Table/Scheduled_EndDateTime").text != "") {
                        strActualEndDateTime = xmlCDom.selectSingleNode("Table/Scheduled_EndDateTime").text;
                        strActualEndDateTime = strActualEndDateTime.replace("-", "/").replace("-", "/").replace("T", " ");
                        if (strActualEndDateTime.indexOf("+") > -1)
                            strActualEndDateTime = strActualEndDateTime.substring(0, strActualEndDateTime.indexOf("+"))
                        if (strActualEndDateTime.indexOf("-") > -1)
                            strActualEndDateTime = strActualEndDateTime.substring(0, strActualEndDateTime.indexOf("-"))
                        dtActualEndDateTime = new Date(strActualEndDateTime);
                    }
                    if (xmlCDom.selectSingleNode("Table/CurrentDateTime") != null) {
                        strCurrentDateTime = xmlCDom.selectSingleNode("Table/CurrentDateTime").text;
                        strCurrentDateTime = strCurrentDateTime.replace("-", "/").replace("-", "/").replace("T", " ");
                        if (strCurrentDateTime.indexOf(".") > -1)
                            strCurrentDateTime = strCurrentDateTime.substring(0, strCurrentDateTime.indexOf("."))
                        if (strCurrentDateTime.indexOf("+") > -1)
                            strCurrentDateTime = strCurrentDateTime.substring(0, strCurrentDateTime.indexOf("+"))
                        if (strCurrentDateTime.indexOf("-") > -1)
                            strCurrentDateTime = strCurrentDateTime.substring(0, strCurrentDateTime.indexOf("-"))
                        dtCurrentDateTime = new Date(strCurrentDateTime);
                    }
                    if (xmlCDom.selectSingleNode("Table/Display_Info_At_Login_InHours") != null)
                        intShow_At_Login_Before_InHours = xmlCDom.selectSingleNode("Table/Display_Info_At_Login_InHours").text;
                    if (xmlCDom.selectSingleNode("Table/Display_Reminder_Message_InMins") != null)
                        dblShow_Reminder_Before_InMinutes = xmlCDom.selectSingleNode("Table/Display_Reminder_Message_InMins").text;
                    if (xmlCDom.selectSingleNode("Table/Message_To_Broadcast") != null)
                        strMessage = xmlCDom.selectSingleNode("Table/Message_To_Broadcast").text;
                    if (xmlCDom.selectSingleNode("Table/BroadCastType_LU") != null)
                        dblBroadCastType = xmlCDom.selectSingleNode("Table/BroadCastType_LU").text;
                    if (xmlCDom.selectSingleNode("Table/RequiresShutDown") != null)
                        blnRequiresSysShutdown = xmlCDom.selectSingleNode("Table/RequiresShutDown").text;
                    if (dtCurrentDateTime >= dtActualStartDateTime && dtCurrentDateTime <= dtActualEndDateTime) {
                        if (dblBroadCastType == 6273 || blnRequiresSysShutdown == "false") {
                            if (strMessage != "" && intRows == 0) {
                                //document.getElementById("section1content").childNodes[0].innerText = "Message from Administrator"
                                document.getElementById("section1content").innerHTML = strMessage;
                            }
                            else if (strMessage != "" && (document.getElementById("section1content").innerHTML != "Important Messages can be displayed here. ")) {
                                //document.getElementById("section1content").childNodes[0].innerText = "Message from Administrator"
                                document.getElementById("section1content").innerHTML += strMessage;
                            }
                            else if (strMessage != "")
                                document.getElementById("section1content").innerHTML = strMessage;
                        }
                        else if (blnRequiresSysShutdown == "true")
                            document.location.href = "../AxWebUILogin/frmBlankPage.htm?SD=" + strActualStartDateTime + "&ED=" + strActualEndDateTime;
                    }
                    else if (dtCurrentDateTime < dtActualStartDateTime) {
                        dtActualStartDateTime = new Date(dtActualStartDateTime.setHours(dtActualStartDateTime.getHours() - intShow_At_Login_Before_InHours))
                        if (dtCurrentDateTime >= dtActualStartDateTime) {
                            if (strMessage != "" && intRows == 0) {
                                document.getElementById("section1content").innerHTML = strMessage;
                            }
                            else if (strMessage != "" && (document.getElementById("section1content").innerHTML != "Important Messages can be displayed here. ")) {
                                document.getElementById("section1content").innerHTML += strMessage;
                            }
                            else if (strMessage != "") {
                                document.getElementById("section1content").innerHTML = strMessage;
                            }

                        }
                    }
                }
            }
            else if (xmlDom.selectNodes("DataSet/Table").length > 0) {
                if (xmlDom.selectSingleNode("DataSet/Table/Actual_StartDateTime") != null && xmlDom.selectSingleNode("DataSet/Table/Actual_StartDateTime").text != "") {
                    strActualStartDateTime = xmlDom.selectSingleNode("DataSet/Table/Actual_StartDateTime").text;
                    strActualStartDateTime = strActualStartDateTime.replace("-", "/").replace("-", "/").replace("T", " ");
                    if (strActualStartDateTime.indexOf("+") > -1)
                        strActualStartDateTime = strActualStartDateTime.substring(0, strActualStartDateTime.indexOf("+"))
                    if (strActualStartDateTime.indexOf("-") > -1)
                        strActualStartDateTime = strActualStartDateTime.substring(0, strActualStartDateTime.indexOf("-"))
                    dtActualStartDateTime = new Date(strActualStartDateTime)
                }
                else if (xmlDom.selectSingleNode("DataSet/Table/Scheduled_StartDateTime") != null && xmlDom.selectSingleNode("DataSet/Table/Scheduled_StartDateTime").text != "") {
                    strActualStartDateTime = xmlDom.selectSingleNode("DataSet/Table/Scheduled_StartDateTime").text;
                    strActualStartDateTime = strActualStartDateTime.replace("-", "/").replace("-", "/").replace("T", " ");
                    if (strActualStartDateTime.indexOf("+") > -1)
                        strActualStartDateTime = strActualStartDateTime.substring(0, strActualStartDateTime.indexOf("+"))
                    if (strActualStartDateTime.indexOf("-") > -1)
                        strActualStartDateTime = strActualStartDateTime.substring(0, strActualStartDateTime.indexOf("-"))
                    dtActualStartDateTime = new Date(strActualStartDateTime)
                }
                if (xmlDom.selectSingleNode("DataSet/Table/Actual_EndDateTime") != null && xmlDom.selectSingleNode("DataSet/Table/Actual_EndDateTime").text != "") {
                    strActualEndDateTime = xmlDom.selectSingleNode("DataSet/Table/Actual_EndDateTime").text;
                    strActualEndDateTime = strActualEndDateTime.replace("-", "/").replace("-", "/").replace("T", " ");
                    if (strActualEndDateTime.indexOf("+") > -1)
                        strActualEndDateTime = strActualEndDateTime.substring(0, strActualEndDateTime.indexOf("+"))
                    if (strActualEndDateTime.indexOf("-") > -1)
                        strActualEndDateTime = strActualEndDateTime.substring(0, strActualEndDateTime.indexOf("-"))
                    dtActualEndDateTime = new Date(strActualEndDateTime);
                } else if (xmlDom.selectSingleNode("DataSet/Table/Scheduled_EndDateTime") != null && xmlDom.selectSingleNode("DataSet/Table/Scheduled_EndDateTime").text != "") {
                    strActualEndDateTime = xmlDom.selectSingleNode("DataSet/Table/Scheduled_EndDateTime").text;
                    strActualEndDateTime = strActualEndDateTime.replace("-", "/").replace("-", "/").replace("T", " ");
                    if (strActualEndDateTime.indexOf("+") > -1)
                        strActualEndDateTime = strActualEndDateTime.substring(0, strActualEndDateTime.indexOf("+"))
                    if (strActualEndDateTime.indexOf("-") > -1)
                        strActualEndDateTime = strActualEndDateTime.substring(0, strActualEndDateTime.indexOf("-"))
                    dtActualEndDateTime = new Date(strActualEndDateTime);
                }
                if (xmlDom.selectSingleNode("DataSet/Table/CurrentDateTime") != null) {
                    strCurrentDateTime = xmlDom.selectSingleNode("DataSet/Table/CurrentDateTime").text;
                    strCurrentDateTime = strCurrentDateTime.replace("-", "/").replace("-", "/").replace("T", " ");
                    if (strCurrentDateTime.indexOf(".") > -1)
                        strCurrentDateTime = strCurrentDateTime.substring(0, strCurrentDateTime.indexOf("."))
                    if (strCurrentDateTime.indexOf("+") > -1)
                        strCurrentDateTime = strCurrentDateTime.substring(0, strCurrentDateTime.indexOf("+"))
                    if (strCurrentDateTime.indexOf("-") > -1)
                        strCurrentDateTime = strCurrentDateTime.substring(0, strCurrentDateTime.indexOf("-"))
                    dtCurrentDateTime = new Date(strCurrentDateTime);
                }
                if (xmlDom.selectSingleNode("DataSet/Table/Display_Info_At_Login_InHours") != null)
                    intShow_At_Login_Before_InHours = xmlDom.selectSingleNode("DataSet/Table/Display_Info_At_Login_InHours").text;
                if (xmlDom.selectSingleNode("DataSet/Table/Display_Reminder_Message_InMins") != null)
                    dblShow_Reminder_Before_InMinutes = xmlDom.selectSingleNode("DataSet/Table/Display_Reminder_Message_InMins").text;
                if (xmlDom.selectSingleNode("DataSet/Table/Message_To_Broadcast") != null)
                    strMessage = xmlDom.selectSingleNode("DataSet/Table/Message_To_Broadcast").text;
                if (xmlDom.selectSingleNode("DataSet/Table/BroadCastType_LU") != null)
                    dblBroadCastType = xmlDom.selectSingleNode("DataSet/Table/BroadCastType_LU").text;
                if (xmlDom.selectSingleNode("DataSet/Table/RequiresShutDown") != null)
                    blnRequiresSysShutdown = xmlDom.selectSingleNode("DataSet/Table/RequiresShutDown").text;


                
                if (dtCurrentDateTime >= dtActualStartDateTime && dtCurrentDateTime <= dtActualEndDateTime) {
                    if (dblBroadCastType == 6273 || blnRequiresSysShutdown == "false") {
                        if (strMessage != "" && intRows == 0) {
                            document.getElementById("section1content").innerHTML = strMessage;
                        }
                        else if (strMessage != "" && (document.getElementById("section1content").innerHTML != "Important Messages can be displayed here. ")) {
                            document.getElementById("section1content").innerHTML += strMessage;
                        }
                        else if (strMessage != "")
                            document.getElementById("section1content").innerHTML = strMessage;
                    }
                    else if (blnRequiresSysShutdown == "true")
                        document.location.href = "../AxWebUILogin/frmBlankPage.htm?SD=" + strActualStartDateTime + "&ED=" + strActualEndDateTime;
                }
                else if (dtCurrentDateTime < dtActualStartDateTime) {
                    dtActualStartDateTime = new Date(dtActualStartDateTime.setDate(dtActualStartDateTime.getDate() - intShow_At_Login_Before_InHours))
                    if (dtCurrentDateTime >= dtActualStartDateTime) {
                        if (strMessage != "" && intRows == 0) {
                            document.getElementById("section1content").innerHTML = strMessage;
                        }
                        else if (strMessage != "" && (document.getElementById("section1content").innerHTML != "Important Messages can be displayed here. ")) {
                            document.getElementById("section1content").innerHTML += strMessage;
                        }
                        else if (strMessage != "")
                            document.getElementById("section1content").innerHTML = strMessage;

                    }
                }
            }
            var intDiffinSeconds = (new Date(Date()) - dtCurrentDateTime) / 1000;
            $ec.fn.setValue("ServerTimeDiffInSeconds", intDiffinSeconds);
            $ec.fn.setValue('SysBroadcastDetails', decodeURIComponent(strSysBroadcastDetails.value));
        }
    } catch (e) { ShowAjaxException(ex, "fnGetSysBroadcastDetails") }
}
//System Broadcast - End

function ShowAjaxException(e, ProcName) {
    if (g_ShowScriptErrors == "True") alert(ProcName + " : " + e.message)
}
function ProcessAjaxException(objResponse) {
    if (objResponse != undefined && objResponse != null) {
        if (objResponse.error != null) throw new Error(-1, objResponse.error.name + ' - ' + objResponse.error.description);
    }
}
function fnBlockKey(event) {
    var intKeyPressValue;
    try {
        $("#LN").removeClass("ui-state-error");
        $("#PD").removeClass("ui-state-error");
        $('#trvalidateTips').hide();

        event = event || window.event;
        intKeyPressValue = ($ec.fn.msie()) ? event.keyCode : event.which;
        switch (intKeyPressValue) {
            case 112: //F1
            case 114: //F3
            case event.altKey && 36: //ALT + HOME
            case event.altKey && 39: //ALT + Right Arrow
            case event.altKey && (37 || 8): //ALT + left Arrow or backspace
            case event.shiftKey && 121: //Shift + F10
            case event.ctrlKey && 9: //Ctrl + Tab
            case 117: //F6
            case event.shiftKey && event.ctrlKey && 9: //Shift + Ctrl + Tab
            case event.ctrlKey && 70: //Ctrl + F
            case 116: // F5  
            case (event.ctrlKey && 82):        //Ctrl + R 
            case 27: // ESC
                //case (event.ctrlKey && 79) || (event.ctrlKey && 76): alert("L");break; // Ctrl + O or Ctrl + L
            case (event.ctrlKey && 79): // Ctrl+O
            case (event.ctrlKey && 76):  //Ctrl+L
            case (event.ctrlKey && 77):  //Ctrl+M
            case event.ctrlKey && 78: //Ctrl + N
            case event.ctrlKey && 87: //Ctrl + W
            case event.ctrlKey && 83: //Ctrl + S
            case event.ctrlKey && 80: //Ctrl + P
            case event.ctrlKey && 69: //Ctrl + E
            case event.ctrlKey && 73: //Ctrl + I
            case event.ctrlKey && 72: //Ctrl + H
            case event.altKey && 68: //Alt + D
            case 115: //F4
            case event.ctrlKey && 37: //Ctrl + left arrow
            case event.ctrlKey && 39: //Ctrl + right arrow
            case event.ctrlKey && 68: //Ctrl + D
            case event.ctrlKey && 66: //Ctrl + B
            case event.altKey && 38: //Alt + Up arrow
            case event.altKey && 40: //Alt + Down arrow
            case event.ctrlKey && 88: //Ctrl + X
            case event.ctrlKey && 67: //Ctrl + C
            case event.ctrlKey && 86: //Ctrl + V
            case event.ctrlKey && 65: //Ctrl + A
            case 122: // F11 full screen
            case 93: //keyboard key to display right-click menu
                if ($ec.fn.msie()) {
                    event.cancelBubble = true;
                    event.returnValue = false;
                    event.keyCode = false;
                }
                else {
                    event.stopPropagation();
                    event.preventDefault();
                }
                return false;
                break;
        }
    }
    catch (e) {
    }
}
function KeyUpEvent(event) {
    var intKeyCode;
    var oSrcElement;
    try {
        $("#divErrorMsg").css("display", "none");
        event = event || window.event;
        intKeyCode = ($ec.fn.msie()) ? event.keyCode : event.which;
        oSrcElement = ($ec.fn.msie()) ? event.srcElement : event.target;

        if ((event.ctrlKey == false && intKeyCode == 13 && oSrcElement.id != "cancel" && oSrcElement.id != "cmdRefresh") || (intKeyCode == 32 && oSrcElement.id == "btnlogin")) {

            if ($ec.fn.chrome() || $ec.fn.safari()) {
                $('#trvalidateTips').hide();
                $("#divErrorMsg").css("display", "none");
                $("#validateTips").text(' ');
                bValid = true;
                bValid = bValid && checkLength(name, "username", 1, 20);
                bValid = bValid && checkLength(password, "password", 1, 30);
                if (bValid)
                    checkUserCredentials(name, password)
            }
            else {
                $('#btnlogin').trigger("click");
            }
        }
        KillSpaceBar(event);
    }
    catch (e) { }
}
function OpenAxsys() {
    window.open("http://axsys.co.uk")
}
function KillSpaceBar(e) {
    var intKeyCode;
    var oSrcElement;
    try {
        e = e || window.event;
        intKeyCode = ($ec.fn.msie()) ? e.keyCode : e.which;
        oSrcElement = ($ec.fn.msie()) ? e.srcElement : e.target;
        if (intKeyCode == 32) {
            fnhRef(e);
            if ($ec.fn.msie()) {
                e.cancelBubble = true;
                e.returnValue = false;
            }
            else {
                e.stopPropagation();
                e.preventDefault();
            }
            return false;
        }
    } catch (e) {
    }
}
function fnhRef(e) {
    if ($ec.fn.msie())
        $(e.srcElement).trigger("click")
    else
        $(e.target).trigger("click");
}
function Chr(CharCode) {
    try {
        return String.fromCharCode(CharCode);
    }
    catch (ex) {
    }
}
var m_Questions = "";
var m_index = 0;
var Usr_QuestionsCount = 0;
function setQuestion() {
    $('#strAnswer').val('');
    $('#strAnswer').focus();
    m_Questions = m_securityQtns.split(Chr(182));
    Usr_QuestionsCount = m_Questions.length;
    if (parseInt(m_chInvokeCount) > Usr_QuestionsCount) m_chInvokeCount = Usr_QuestionsCount;
    for (var i = 0; i < Usr_QuestionsCount; i++) {

        if (arrSQuestions.indexOf(i) > -1) {
            continue;
        }
        else {
			if($("#dvQuestion").text()==m_Questions[i].split(Chr(181))[1])
			{
				if(i!=0)i=i-1;
				continue;
			}																			  
            $('#dvQuestion').attr("value", m_Questions[i].split(Chr(181))[0]);
            $("#dvQuestion").text(m_Questions[i].split(Chr(181))[1]);
            arrSQuestions.push(i);
            if (i == parseInt(m_chInvokeCount) - 1) {
                $("#chooseLink").removeAttr("onclick");
                $("#chooseLink").css("color", "silver");
                return false;
            }
		return false;	
        }
    }
}

function fnLoad() {
    try {
        if (document.getElementById("hdnValidateKey").value != "") {
            window.close();
        }
        //if (document.readyState != "complete") return false;
        try {
            if (dialogArguments.dialogArguments != undefined) {
                dialogArguments.dialogArguments.document.location.href = "../AxWebUILogin/frmSignon.aspx";
                self.close(); dialogArguments.window.close();
            }
            else if (dialogArguments != undefined) {
                dialogArguments.document.location.href =  "../AxWebUILogin/frmSignon.aspx";
                self.close();
            }
        } catch (e) { }

        if (blnSSI == 1) {
            $("#security1").css("display", "block");
            $("#imgCaptchaLogin").attr("src", "../AxWebUILogin/Captcha.aspx?from=login&T=" + (new Date().valueOf()));
            $("#imgCaptchaLogin").ready(function () { $("#security1").css("display", "visible"); })
        }
        $("#divLocation").css("visibility", ((intUserLocation == 0) ? "none" : "visible"));
        ClearConent();
        fnGetSysBroadcastDetails();
        fnStartTimer();
    } catch (e) { }
    finally {
        $('#LN').focus();
    }
}

function fnOpenAbout() {
    window.showModalDialog(strMDIVirFolderName + "/frmAbout.aspx", window, "dialogWidth=500px;dialogHeight=300px;center=yes;scroll=auto;help=no;status=no");
}
function fnOpenSupport() {
    window.showModalDialog("http://www.axsys.co.uk/support_services.htm", window, "dialogWidth=900px;dialogHeight=600px;center=yes;scroll=auto;help=no;status=no");
}
function fnOpenHelp() {
    window.showModalDialog("../AxCommon/Help/frmHelpLogin.htm", window, "dialogWidth=900px;dialogHeight=600px;center=yes;scroll=auto;help=no;status=no");
}

function fnFocusCtrl(event) {
    var srcEle = event.target || event.srcElement;
    $(srcEle).prev().focus();
    srcEle = null;
}

function setValue(key, value) {
    objVariables[key] = value;
}
function getValue(key) {
    return objVariables[key];
}
function getUrlParameters()
{
    var Params = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++)
    {
        hash = hashes[i].split('=');
        Params.push(hash[0]);
        Params[hash[0]] = hash[1];
    }
    return Params;
}

function fnShowDisclaimerDialog(Prompt, MessageBoxStyle, DialogWidth, DialogHeight, IconStyle, PageTitle, fncallback) {
       var URL = "../AxFXDialog/frmDialogPage.html?t=" + PageTitle + "&p=" + escape(Prompt) + "&bs=" + MessageBoxStyle + "&is=" + IconStyle + "&isDojoDialog=true";
       AxOpenDojo(URL, DialogWidth, DialogHeight, PageTitle, "", fncallback);

   }
function fnValidUserCredentials(objResponse)
{
    var response = $ec.fn.ecDecode(objResponse.value)
    strResult = response.split(Chr(190))[0];
	strTkn = response.split(Chr(190))[4];
	
    IsUserMFAEnabled = response.split(Chr(190))[response.split(Chr(190)).length - 2];
    IsValidateEmail = response.split(Chr(190))[response.split(Chr(190)).length - 1];
            if (strResult == undefined || strResult == null)
                strResult = "0";

            if (strResult.indexOf(Chr(182)) >= 0) {
                var arrValues = new Array;
                arrValues = strResult.split(Chr(182));
                strActiveSessionCount = arrValues[0];
                strResult = arrValues[1];
            }
            if (strResult.indexOf(Chr(186)) >= 0) {
                var arrValues = new Array;
                arrValues = strResult.split(Chr(186));
				strResult = arrValues[0];
                RedirectURL = arrValues[1];
                intUserId = arrValues[2].split(Chr(190))[0];
            }
			if (strResult.indexOf(',') > 0) {
				var arrValues = new Array;
				arrValues = strResult.split(",");
				strResult = arrValues[0];
				intRemainderDays = arrValues[1];
			}

 }
  function fnWinAuthDownloadLink()
   {
    try
	{
	  strURL ="https://winauth.github.io/winauth/download.html";
	    var xPosition, xWidth, xHeight, xTop
    if ((isNaN(xPosition) && isNaN(xWidth)) || (xPosition.length == 0 && xWidth.length == 0)) {
        xPosition = (parseInt(screen.width) / 7.6);
        xWidth = (parseInt(screen.width) / 7) * 6;
    }
    xHeight = parseInt(screen.height / 8) * 6.1;
    xTop = parseInt(screen.height) / 7.9;
    window.open(strURL, "", "top=" + xTop + "px,left=" + xPosition + "px,width=" + xWidth + "px,height=" + xHeight + "px,directories=0;location=0;menubar=0;resizable=0;scrollbars=0;status=0;toolbar =0;", true);

	}
	catch (ex) {ex.message}
   }
   
   function fnCheckUC(strUN, strpd, strSecVal, strDomainNames, m_intADAuthentication, m_allowSecondaryVerification, strUsID, m_strSessionID) {
    try {
        objJsonData = {
            "sun": strUN, "spd": strpd, "ssv": strSecVal, "sdn": strDomainNames, "ada": m_intADAuthentication, "asv":
                m_allowSecondaryVerification, "sus": strUsID, "m_strSessionID": m_strSessionID
        }
        return fnEncryptData(objJsonData);
    } catch (e) { }

}

function fnValidateSL(intUsrID, strQues, strAns, bnlInv) {
    try {
        objJsonData = { "iud": intUsrID, "squ": strQues, "san": strAns, "biv": bnlInv }
        return fnEncryptData(objJsonData);
    }
    catch (e) { }
}

function fnStartSession(intUserId, retVal, intSSOLOCID) {
    try {
        objJsonData = { "uid": intUserId, "rev": retVal, "sli": intSSOLOCID }
        return fnEncryptData(objJsonData);
    } catch (e) { }
}

function fnSetLocation(LocationValue) {
    try {
        objJsonData = { "loc": LocationValue }
        return fnEncryptData(objJsonData);
    } catch (e) { }
}
function fnChkSecurity(strSecvalue) {
    try {
        objJsonData = { "scv": strSecvalue }
        return fnEncryptData(objJsonData);
    } catch (e) { }
}

function fnGetUserLocations(strName, strPwd, strSecurity, strCalledFrom, intUserId) {
    try {
        objJsonData = { "snm": strName, "spd": strPwd, "ssc": strSecurity, "scf": strCalledFrom, "iud": intUserId }
        return fnEncryptData(objJsonData);
    } catch (e) { }
}

function fnGUD(intUserId) {
    try {
        objJsonData = { "iud": intUserId }
        return fnEncryptData(objJsonData);
    } catch (e) { }
}

function fnValidateUsername(userName, Reason_LU) {
    try {
        objJsonData = { "usn": userName, "rlu": Reason_LU }
        return fnEncryptData(objJsonData);

    } catch (e) { }
}

function fnEncryptData(strJsonData) {
    try {
        if (strJsonData != "") {
            strJsonData = JSON.stringify(strJsonData);
            return $ec.fn.et(strJsonData);
        } else {
            return null
        }
    } catch (e) { }
}

function fnsaveDis(intUserId, strDisIDs) {
    try {
        strJsonData = { "did": strDisIDs }
        strJsonData = JSON.stringify(strJsonData);
        strJsonData = $ec.fn.et(strJsonData);
        frmsignon.fnSaveDisclaimer(strJsonData);
    } catch (e) { }
}

function fnGenerateApiToken(){
	try{
		var item={};
	  item ["Username"]=$("#LN").val();
	  item ["Password"]='';
	  item ["resource"]='';
	  item["Eckey"]='A314570F7068B61D084ECD4AB78C578C';
        $.ajax({
			url: strServiceURL + "/api/register",
			type: 'POST',
			dataType: 'json',
			contentType: 'application/json',
			data: JSON.stringify(item),
			async: false,
			success: function (returnval) {
				console.log(returnval);
				 sessionStorage.setItem("Ec_Jwt",returnval);				
			},
			error: function (xer) {
				console.log(xer);
			}
		});	
	  
	}
	catch(ex){}
}
// forgotpassword functions
function fnOpenForgotPassword(){
				try{
					if($('#LN').val() != "" && $('#LN').val() != undefined){
					
					$.ajax({
						url: ServiceURL + '/AxRSUserDetails.svc/GetSecurityQuestions?Username=' + encodeURIComponent($('#LN').val()),
						type: 'GET',
						dataType: 'json',
						contentType: 'application/json',					
						async: false,
						success: function (response) {
							console.log(response)
							 if(JSON.parse($ec.fn.dt(response)).data != "" && JSON.parse($ec.fn.dt(response)).data != undefined && JSON.parse($ec.fn.dt(response)).Reason != "")
							{
								$("#divErrorMsg").css("display", "none");
								AxOpenDojo('../AxWebUIUserPreferences/frmForgotPassword.aspx?un='+ $('#LN').val() +'&ec=1', '465' , '240','Forgot Password','','');
								return false;
							}else if(JSON.parse($ec.fn.dt(response)).Reason.toLowerCase() == "invalid data"){
								$('#LN').val('').focus();
								fnShowValidation("The username you entered is incorrect.");
							}else if(JSON.parse($ec.fn.dt(response)).Reason.toLowerCase() == "new user" || JSON.parse($ec.fn.dt(response)).Reason.toLowerCase() == "user does not have questions"){
								$('#PD').focus();
								fnShowDialog("Before your password can be reset you must respond to some security questions. You have not recorded security questions and answers. Please contact your system administrator to reset your password.", '0', "450", "160", '0', 'Forgot Password',"");
							}else if(JSON.parse($ec.fn.dt(response)).Reason.toLowerCase() == "profile inactivated"){
								$('#LN').focus();
								fnShowDialog("You have reached your maximum count. So, please contact your system administrator to reset your password.", '0', "450", "140", '0', 'Forgot Password',"");
							}else if(JSON.parse($ec.fn.dt(response)).Reason.toLowerCase() == "profile not activated")
							{
								fnShowValidation("User profile is not activated.");
								$('#LN').val('').focus();
							}	
						},
						error: function (xer) {
							fnShowValidation("Please enter username.");
							$('#LN').focus();
						}
					});	
					
					}
					else
					{	
						fnShowValidation("Please enter username.");
						$('#LN').focus();
					}
				}catch(e)
				{
					alert(e.message);
				}			
				
			}
			
function fnShowDialog(Prompt, MessageBoxStyle, DialogWidth, DialogHeight, IconStyle, PageTitle, fncallback) {
			var URL = strAxDialogVirFolderName + "/frmDialogPage.aspx?t=" + PageTitle + "&p=" + escape(Prompt) + "&bs=" + MessageBoxStyle + "&is=" + IconStyle + "&isDojoDialog=true";
			AxOpenDojo(URL, DialogWidth, DialogHeight, "Forgot Password", fncallback);
			
		}
		
function fnShowValidation(text) {
			$('#trvalidateTips').show();
			$('#colOne').show();
			$("#divErrorMsg").css("display", "block");
			$("#divErrorMsg").text(text);
			$("#validateTips").text(text);
			$("#divErrorMsg").css("fontSize", "13px");			
		}