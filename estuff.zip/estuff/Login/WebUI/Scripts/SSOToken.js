var handle = 0;
var ticketApiHubServer;
var prService;

function loginViaNHSPortService() {
	_default.logECWebSessionAction(2729, -1, "Calling NHS Port Service.");
	prService = new PRService(successCallBack, errorCallBack);
}

// If call to NHS Port Service fails, then go to error page. 	
function errorCallBack(errorCode, errorMessage) {
	_default.logECWebSessionAction(2402, -1, "Error from NHS Port Service. (" + errorCode + ") " + errorMessage);
	 window.top.window.location.href = "frmSignon.aspx";
}

//If call to NHS Port service was successful, then call NHS Credential Management
function successCallBack() {
	//Determine if NHS Credential Management is available by checking to see if the dynamically generated signalR hub proxy is available...
	if ((typeof $.signalR.hub.proxies !== 'undefined')) {
		doLoginViaNHSCM();
	}
	else {
		// If NHS Credential Management not available, then go to error page. 	
		_default.logECWebSessionAction(2402, -1, "Error from successCallBack, NHS Credential Management not available.");
	}
}

//Login via NHS Credential Management
function doLoginViaNHSCM() {
	$.connection.hub.url = "http://localhost:" + prService.portNumber() + "/signalr";
	handle = 0;
	ticketApiHubServer = $.connection.ticketApiHub.server;
	if ($.connection.hub && $.connection.hub.state === $.signalR.connectionState.disconnected) {
		$.connection.hub.start({ transport: 'longPolling' })
			.then(initializeTicketApi)
			.then(getTicket)
			.then(login)
			.always(cleanupAfterSignalR);
	}
}

function initializeTicketApi() {
	return ticketApiHubServer.initialize();
}

function getTicket(result) {
	if (result.IsSuccess) {
		handle = result.Handle;
		return ticketApiHubServer.getTicket(handle);
	}
	else {
		//Ticket API initialization has failed.
		_default.logECWebSessionAction(2402, -1, "Error from getTicket, Ticket API initialization has failed.");
	}
}

function login(result) {
	if (result.IsSuccess && (result.Token != null)) {
	    strTokenID = result.Token;
		_default.logECWebSessionAction(2729, -1, "Calling fnOpenSCRData.");
		fnOpenSCRData();
	}
	else{
		_default.logECWebSessionAction(2402, -1, "Error from login, Login failed or Token not found.");
	}
}


function cleanupAfterSignalR() {
	if (handle != 0) {
		ticketApiHubServer.finalize(handle);
	}
}

function fnOpenSCRData() {
	var UserId = "";
	var xhttp = new XMLHttpRequest();
	if (strTokenID != "") {
		var objResponse = "";
		objResponse = _default.fnGetSmartCardUserDetails(encodeURIComponent(strTokenID));
		if (objResponse != undefined && objResponse != null) {
			if (objResponse.error != null) throw new Error(-1, objResponse.error.name + ' - ' + objResponse.error.description);
			if (objResponse.value != 'Failed')
				fnGetUserID(objResponse.value);
			else
				fnScrError();
		}
	}
	else
		window.top.window.location.href = "frmSignon.aspx";
}
function fnScrError() {
	fnShowDialog("We are sorry there seems to be a problem with your SmartCard.<br><br>Please contact the NEL CSU Health & Justice Service Desk for more assistance<br><br>nelcsu.hjservicedesk@nhs.net or 0203 688 1151<br><br>The Service Desk is open 8:00am to 6:00pm", '0', "490", "160", '0', 'Login', "");
}
function fnShowDialog(Prompt, MessageBoxStyle, DialogWidth, DialogHeight, IconStyle, PageTitle, fncallback) {
	var URL = "../AxFXDialog/frmDialogPage.html?t=" + PageTitle + "&p=" + escape(Prompt) + "&bs=" + MessageBoxStyle + "&is=" + IconStyle + "&isDojoDialog=true";
	AxOpenDojo(URL, DialogWidth, DialogHeight, "login", "", function () {
		window.top.window.location.href = "../AxWebUILogin/frmSignon.aspx";
	});

}
function fnGetUserID(strRetValue) {
	var UserId = strRetValue.split(String.fromCharCode(181))[0];
	var strLocCodeId = strRetValue.split(String.fromCharCode(181))[1];
	if (UserId != "" && strLocCodeId != "") {
		window.top.window.location.href = "sso_generic_inbound.aspx?UID=" + escape(UserId) + "&LId=" + escape(strLocCodeId) + "&type=bypass&ec=1";
	}
	else {
		window.top.window.location.href = "frmSignon.aspx";
	}
}