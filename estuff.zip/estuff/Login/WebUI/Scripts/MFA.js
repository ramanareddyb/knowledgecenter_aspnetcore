﻿$(document).ready(function () {

    var xmlDOM = fnLoadXML(m_strLoginDefaults);
    $("#excelicarelogo").prop("src", xmlDOM.documentElement.getAttribute("topright"));
    if(parent.IsValidateEmail=="False"){
	 $("#lnkreGenerateMFA").addClass("disablelink")
	 $("#dvMessage").css("display","");
	}
   else 
	   $("#lnkreGenerateMFA").removeClass("disablelink")
    window.setTimeout(function () {
        $("#lblUserName").text(parent.$("#LN").val())
        $("#txtMFACode").focus();
    }, 100);
});		
function fnValidateOTP() {

    var strOTp = "";
    var IsJSon
    try {

        if ($("#txtMFACode").val().length < 6) {
            updateTips("Please enter valid OTP.");
            return true;
        }
		if(parent.IsValidateEmail!="False"){
        strOTp = $("#txtMFACode").val();
        strReturnvalue = frmMFA.ValidateTOTP(btoa(strOTp));
        if (IsJsonString(strReturnvalue.value) == false) {
            $(".maskText").css("display", "");
            $("lblCount").text(strReturnvalue.value.split(",")[1])
            m_intOTPCount = strReturnvalue.value.split(",")[1];
            if (parseInt(m_intOTPCount) >= parseInt(m_maxattempts))
                fnShowDialog("User authentication failure.", '0', "250", "150px", '3', 'Two Factor Authentication', function (retVal) { _CallbackFn(); }, function (retVal) { _CallbackFn(); });
            else
                updateTips("Invalid OTP.");
        }
        else {
            strReturnvalue = JSON.parse(strReturnvalue.value)["data"]
            if (strReturnvalue == 2)
                _CallbackFn(strReturnvalue);

        }
		
		}
		else
			updateTips("Invalid OTP.");
    }


    catch (ex) {
        alert(ex.message);
    }
    finally {
        $('#txtMFACode').focus();
    }

}
function IsJsonString(str) {
    try {
        JSON.parse(str);
    } catch (e) {
        return false;
    }
    return true;
}
function fnSaveQRCode(setting) {

    var strMFASaveQRcode;
    try {
        if (setting != "") {
			var strUserPreferencesData = JSON.stringify({ "IsMFAEnabled": "1", "QRCode": setting });
             strMFASaveQRcode = fnSaveQR(m_intUserId,strUserPreferencesData);
            if (strMFASaveQRcode.value != "0" && strMFASaveQRcode.value.indexOf("No  e-mail address for current user") == -1) {
                OpenDialog("Mail sent successfully to the  registered Email ID.", '0', "350", "150px", '4', 'Two Factor Authentication', function (retVal) {
                    $('#lnkreGenerateMFA').addClass('enablelink').removeClass('disablelink');
                    parent.document.location.href = "../AxWebUILogin/frmSignon.aspx"; _CallbackFn();
                },
                function (retVal) {
                    $('#lnkreGenerateMFA').addClass('enablelink').removeClass('disablelink');
                    parent.document.location.href = "../AxWebUILogin/frmSignon.aspx";
                    _CallbackFn();
                });

            }
            else {
                fnShowDialog("There is no Email Address registered for the current user. Please contact the system administrator for assistance.", '0', "350", "150px", '4', 'Two Factor Authentication', function (retVal) {
                    $('#lnkreGenerateMFA').addClass('enablelink').removeClass('disablelink');
                    parent.document.location.href = "../AxWebUILogin/frmSignon.aspx"; _CallbackFn();
                },
              function (retVal) {
                  $('#lnkreGenerateMFA').addClass('enablelink').removeClass('disablelink');
                  parent.document.location.href = "../AxWebUILogin/frmSignon.aspx";
                  _CallbackFn();
              });
            }
        }
    }
    catch (ex) {
        ex.Message
        $('#lnkreGenerateMFA').addClass('enablelink').removeClass('disablelink');
    }
}

function fnNavigate() {

    try {
        $('#lnkreGenerateMFA').addClass('disablelink')
        $.ajax({
            dataType: 'jsonp',
            url: ServiceURL + '/AxRSMFA.svc/GenerateQRCode'
        }).then(function (data) {
            fnSaveQRCode(data.data);


        });

        return false;
    }
    catch (ex) {
        alert(ex.Message);
        $("#lnkreGenerateMFA").addClass('enablelink');
    }
}


function fnMFACodeKeyDown(event) {

    var KeyPressValue;
    try {

        $('#txtMFACode').focus();
        event = event == undefined ? window.event : event;
        KeyPressValue = ($ec.fn.msie()) ? event.keyCode : event.which;
        if (event.target.id == "txtMFACode" && KeyPressValue == 13) {

            event.preventDefault();
            fnValidateOTP();
        }
        else {
            $("#divErrorMsg").css("display", "none");
        }

    } catch (e) { }

}

function OpenDialog(Prompt, MessageBoxStyle, DialogWidth, DialogHeight, IconStyle, PageTitle, fncallback, fncallbackclose) {
    var URL = "../AxFXDialog/frmDialogPage.aspx?t=" + PageTitle + "&p=" + escape(Prompt) + "&bs=" + MessageBoxStyle + "&is=" + IconStyle + "&isDojoDialog=true&strInfo=" + escape("If you haven't received the email,please contact the system administrator for assistance.");
    AxOpenDojo(URL, DialogWidth, DialogHeight, "Two Factor Authentication", fncallback, fncallbackclose);
}
function fnShowDialog(Prompt, MessageBoxStyle, DialogWidth, DialogHeight, IconStyle, PageTitle, fncallback, fncallbackclose) {
    var URL = "../AxFXDialog/frmDialogPage.aspx?t=" + PageTitle + "&p=" + escape(Prompt) + "&bs=" + MessageBoxStyle + "&is=" + IconStyle + "&isDojoDialog=true";
    AxOpenDojo(URL, DialogWidth, DialogHeight, "Two Factor Authentication", fncallback, fncallbackclose);
}
document.onkeypress = function allowNumbersOnly(e) {
    var code = (e.which) ? e.which : e.keyCode;
    if (code > 31 && (code < 48 || code > 57)) {
        e.preventDefault();
    }
}
function CloseWindow() {
    _CallbackFn();
}
function updateTips(t) {
    tips = $("#validateTips");
    $("#divErrorMsg").css("display", "block");
    tips.text(t)

}

function fnSaveQR(m_intUserId, strUserPreferencesData)
{
	try{
		    strJsonData = JSON.stringify({"iun": m_intUserId})
			strJsonData = $ec.fn.et(strJsonData)
			strUPJson = $ec.fn.et(strUserPreferencesData)
		    return frmMFA.SaveQRCode(strJsonData, strUPJson);
	}catch(e){}
}