﻿Imports Excelicare.Framework.AppSupport
Imports Excelicare.Bizl.Login
Imports Newtonsoft.Json.Linq
Public Class frmDisclaimer
    Inherits System.Web.UI.Page

    Public m_strVerNo As String
    Public strDisclaimerText As String = String.Empty
    Public intDisclaimerid As Integer = 0
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim objSession As clsSessionManager
        Dim objBizEcsession As clsBizlECSession
        Dim objAppSupport As clsAppSettings
        Dim objSessionData As clsSessionData = New clsSessionData
        Dim intUserID As Integer
        Ajax.Utility.RegisterTypeForAjax(GetType(frmDisclaimer))
        Try
            Response.Expires = -1
            Response.Cache.SetNoServerCaching()
            Response.Cache.SetAllowResponseInBrowserHistory(False)
            Response.CacheControl = "no-cache"
            Response.Cache.SetNoStore()
            If IsSessionExists() = False Then
                clsECSession.LogWebSessionAction("Login", "", 0, 2729, "Redirecting to login page as session not found.", 1030, 0)
                Response.Redirect("../AxWebUILogin/", False)
                Exit Sub
            End If
            objAppSupport = New clsAppSettings
            m_strVerNo = objAppSupport.GetModuleVersion("1030")
            objSession = New clsSessionManager
            objSessionData = objSession.GetSessionData(Session.SessionID, "APPDATA")
            intUserID = objSessionData.UserID
            If Not IsPostBack AndAlso Not Request.Form("data") Is Nothing Then
                Dim json As JObject = JObject.Parse(Request.Form("data"))
                If json.SelectToken("method").ToString = "fnSaveDisclaimer" AndAlso Not json.SelectToken("DisclaimerIDs") Is Nothing Then
                    fnSaveDisclaimer(intUserID, json.SelectToken("DisclaimerIDs").ToString())
                End If
                Exit Sub
            End If
            If Request.QueryString("Disclaimerid") <> "" And Not Request.QueryString("Disclaimerid") Is Nothing Then
                intDisclaimerid = Request.QueryString("Disclaimerid")
                If Not IsNumeric(intDisclaimerid) Then
                    Response.End()
                End If
            End If
            Try
                objBizEcsession = New clsBizlECSession
                strDisclaimerText = objBizEcsession.GetDisclaimers(intUserID, intDisclaimerid)
            Catch ex As Exception
                ExceptionLog(ex)
            End Try
        Catch ex As Exception

        End Try
    End Sub
    <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
    Public Function fnSaveDisclaimer(ByVal UserId As Int64, ByVal DisclaimerIds As String) As String
        Dim objBizEcsession As clsBizlECSession
        Try
            objBizEcsession = New clsBizlECSession
            objBizEcsession.fnSaveDisclaimer(UserId, DisclaimerIds)
        Catch ex As Exception
            ExceptionLog(ex)
            Throw
        End Try
    End Function
    Private Sub ExceptionLog(ByVal exException As Exception)
        Dim objException As clsExceptionHandler
        objException = New clsExceptionHandler(exException)
        objException.LogException(Me.Page)
        objException = Nothing
    End Sub

    Public Shared Function IsSessionExists() As Boolean
        Dim objClsSessionManager As clsSessionManager
        Try
            objClsSessionManager = New clsSessionManager
            Return objClsSessionManager.IsSessionExists(HttpContext.Current.Session.SessionID)
        Catch ex As Exception
        Finally
            objClsSessionManager = Nothing
        End Try
    End Function

End Class