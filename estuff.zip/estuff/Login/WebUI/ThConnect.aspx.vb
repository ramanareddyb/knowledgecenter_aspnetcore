﻿Imports System.Net
Imports System.Runtime.Serialization
Imports Excelicare.Framework.AppSupport
Imports Newtonsoft.Json
Imports RestSharp

Public Class ThConnect
    Inherits System.Web.UI.Page
    Public lngUserId As Long = 0
    Public strSessionToken As String = ""
    Public strServiceURL As String = ""
    Public strTwilioURL As String = ""
    Protected strModuleVersionNo As String = ""
    Public intMinutes As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim objClsSessionData As clsSessionData
        Dim objClsSessionManager As clsSessionManager
        Dim objClsAppSettings As clsAppSettings
        Try
            intMinutes = clsSysDefault.GetSysDefaultValue(2503)
            objClsSessionManager = New clsSessionManager
            objClsAppSettings = New clsAppSettings
            objClsSessionData = objClsSessionManager.GetSessionData(Session.SessionID, "APPDATA")
            strServiceURL = System.Configuration.ConfigurationSettings.AppSettings("ExcelicareWebServiceURL")
			If IsNothing(System.Configuration.ConfigurationSettings.AppSettings.Get("InternalURL")) = False Then
                    strTwilioURL = System.Configuration.ConfigurationSettings.AppSettings("InternalURL")
                End If
            If Not objClsSessionData Is Nothing Then
                lngUserId = objClsSessionData.UserID
                strSessionToken = Session.SessionID
                strSessionToken = "@" + strSessionToken
            Else
                strSessionToken = AutheticateTeleUser()
            End If
            Session("TwilioUserToken") = strSessionToken
            strModuleVersionNo = objClsAppSettings.GetModuleVersion("1030")
        Catch ex As Exception
            LogException(ex)
        Finally
            objClsSessionData = Nothing
            objClsSessionManager = Nothing
        End Try
    End Sub
    Private Function AutheticateTeleUser() As String
        Dim client = New RestClient(strServiceURL + "/AxRSSecurity.SVC/AuthenticatePartnerUser")
        Dim request = New RestRequest(strServiceURL + "/AxRSSecurity.SVC/AuthenticatePartnerUser", RestSharp.Method.Post)
        Dim objLogin As clsAuthenticate
        Dim jsResult As Object
        Try
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12
            objLogin = New clsAuthenticate
            objLogin.Loginname = "Telehealth"
            objLogin.Password = "1ae8851f80b36a610e5c57d78fa512342be652c76de3350da80d6ea8a05a13da"
            request.AddHeader("content-type", "application/json")
            request.AddParameter("application/json", Newtonsoft.Json.JsonConvert.SerializeObject(objLogin), ParameterType.RequestBody)
            Dim response As RestResponse = client.Execute(request)
            jsResult = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(response.Content)
            If jsResult("Status") = "Success" Then
                Return jsResult("data")("token").ToString
            End If
        Catch ex As Exception
            LogException(ex)
        Finally
            client = Nothing
            request = Nothing
            objLogin = Nothing
        End Try
    End Function

    Private Sub LogException(ByVal objExcep As Exception)
        Dim objClsExceptionHandler As clsExceptionHandler
        Try
            objClsExceptionHandler = New clsExceptionHandler(objExcep)
            If Not IsNothing(Page) Then
                objClsExceptionHandler.LogException(Page)
            Else
                objClsExceptionHandler.LogException()
            End If
        Catch ex As Exception
        Finally
            objClsExceptionHandler = Nothing
        End Try
    End Sub
End Class

Public Class clsAuthenticate
    Private strLoginName As String
    Private strPassword As String

    <DataMember()>
    Property Loginname() As String
        Get
            Return strLoginName
        End Get
        Set(ByVal Value As String)
            strLoginName = Value
        End Set
    End Property
    <DataMember()>
    Property Password() As String
        Get
            Return strPassword
        End Get
        Set(ByVal Value As String)
            strPassword = Value
        End Set
    End Property
End Class