Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
'Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Text
Partial Class Captcha
    Inherits System.Web.UI.Page
    Private rand As New Random
#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    ''<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    ''End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    ''Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    ''    'CODEGEN: This method call is required by the Web Form Designer
    ''    'Do not modify it using the code editor.
    ''    InitializeComponent()
    ''End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            'Put user code to initialize the page here
            Response.Expires = -1
            Response.Cache.SetNoServerCaching()
            Response.Cache.SetAllowResponseInBrowserHistory(False)
            Response.CacheControl = "no-cache"
            Response.Cache.SetNoStore()
            If Not Request.QueryString("from") Is Nothing AndAlso String.Compare(Request.QueryString("from"), "login", False) = 0 Then
                CreateImageforLogin()
            Else
                CreateImage()
            End If
        Catch ex As Exception
            Response.Write(ex.Message)
        End Try
    End Sub
    Private Sub CreateImageforLogin()
        Try
            Dim code() As String = GetRandomText()
            Dim bitmap As New Bitmap(140, 60, System.Drawing.Imaging.PixelFormat.Format32bppArgb)
            Dim g As Graphics = Graphics.FromImage(bitmap)
            Dim pen As New Pen(Color.Black)
            Dim rect As New Rectangle(0, 0, 140, 60)
            Dim b As New SolidBrush(Color.Gainsboro)
            Dim blue As New SolidBrush(Color.MidnightBlue)
            Dim counter As Integer = 0
            g.DrawRectangle(pen, rect)
            g.FillRectangle(b, rect)
            For i As Integer = 0 To code.Length - 1
                g.DrawString(code(i).ToString(), New Font("Verdana", 10 + rand.[Next](14, 18)), blue, New PointF(10 + counter, 10))
                counter += 20
            Next
            Me.DrawRandomLines(g)
            bitmap.Save(Response.OutputStream, ImageFormat.Gif)
            g.Dispose()
            bitmap.Dispose()
        Catch exception1 As Exception
            Throw
        End Try
    End Sub
    Private Sub CreateImage()
        Try
            Dim code As String() = Me.GetRandomText
            Dim bitmap As New Bitmap(150, 100, System.Drawing.Imaging.PixelFormat.Format32bppArgb)
            Dim g As Graphics = Graphics.FromImage(bitmap)
            Dim pen As New Pen(Color.Black)
            Dim rect As New Rectangle(0, 0, 150, 100)
            Dim b As New SolidBrush(Color.Gainsboro)
            Dim blue As New SolidBrush(Color.MidnightBlue)
            Dim counter As Integer = 0
            g.DrawRectangle(pen, rect)
            g.FillRectangle(b, rect)
            For i As Integer = 0 To code.Length - 1
                g.DrawString(code(i).ToString(), New Font("Verdana", 10 + rand.[Next](14, 18)), blue, New PointF(10 + counter, 10))
                counter += 20
            Next
            Me.DrawRandomLines(g)
            bitmap.Save(Me.Response.OutputStream, ImageFormat.Gif)
            g.Dispose()
            bitmap.Dispose()
        Catch exception1 As Exception
            Throw
        End Try
    End Sub
    Private Sub DrawRandomLines(ByVal g As Graphics)
        Dim green As New SolidBrush(Color.DarkBlue)
        Dim intLinesCont As Integer = 0
        Try
            intLinesCont = CInt(ConfigurationSettings.AppSettings("SecurityImageDifficulty"))
        Catch ex As Exception
            intLinesCont = 0
        End Try
        For i As Integer = 0 To intLinesCont
            g.DrawLines(New Pen(green, 2), GetRandomPoints())
        Next
    End Sub
    Private Function GetRandomPoints() As Point()
        Dim points As Point() = {New Point(rand.[Next](10, 150), rand.[Next](10, 150)), New Point(rand.[Next](10, 100), rand.[Next](10, 100))}
        Return points
    End Function
    Private Function GetRandomText() As String()
        Dim randomText As New StringBuilder
        Dim strRetunValue(5) As String
        Session("Code") = ""
        If Not Session("Code") Is Nothing Then
            Dim alphabets As String() = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"}
            Dim r As New Random
            For j As Integer = 0 To 5
                strRetunValue(j) = alphabets(r.[Next](alphabets.Length))
            Next
            Dim i As Integer
            For i = 0 To strRetunValue.Length - 1
                Session("Code") &= strRetunValue(i)
            Next
        End If
        Return strRetunValue
    End Function
End Class
