﻿Imports Ajax
''Imports AxExceliCareICEProxy
Imports Excelicare.Framework.AppSupport
Imports System.Configuration.ConfigurationManager
Imports Excelicare.ServiceProxy
Imports Excelicare.Bizl.Login
Imports System.Data.SqlClient
Imports System.Web.SessionState
Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq
Imports System.Collections.Generic
Imports RestSharp
Imports System.Net
Imports System.Data
Imports System.Web

Partial Public Class frmsignon
    Inherits System.Web.UI.Page
    Protected strModuleVersionNo As String = ""
    Public blnSSI As Integer 'Show Security Image 
    Public intUserLocation As Integer
    Protected strMDIVirFolderName As String = ""
    Protected strAxDialogVirFolderName As String = ""
    Protected strAxLoginFolderName As String = ""
    Protected blnSessionUsed As Boolean = False
    Protected g_ShowScriptErrors As String = "False"
    Protected strLoginAttempts As String = ""
    Public blnUserHBIDFailed As Boolean = False 'From35
    Public intShowClientLog As Integer = 0
    Public m_strLoginDefaults As String = ""
    Public m_showdomaincombo As Int16 = 0
    Dim strKey As String = System.Configuration.ConfigurationSettings.AppSettings("ApplicationInstallType")
    Protected m_intADAuthentication As Int16 = 0

    Public m_chooseCount As Integer = 0
    Public EnableChoose As Integer = 0
    Public allowSecondaryVerification As Integer = 0
    Public intMaxSecurityAnsAttempts As Integer = 0
    Public blnshowForgotPwdLink As Boolean = False
    Public serviceURL As String = String.Empty
    Public m_issysMFAEnabled As Boolean = False
    Public JSonMFAResult As Object
    Public IsSecureIP As Boolean = True
    Public objclsSecurity As clsSecurity
    Public strSaltKey As String = ""
    Public m_strSessionID As String = ""
    Public m_ShowLoginFailedAttempts As Integer = 0



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        ' Manager.SaveSessionID(Context, NewID, redirected, IsAdded)
        Dim objClsAppSettings As clsAppSettings
        Dim objSysDefault As clsSysDefault
        Dim objBizEcsession As New clsBizlECSession
        Dim objClsSessionLog As New clsECSession
        ' Dim objclsSecurity As clsSecurity
        Dim arrDefaultIds() As Int64 = {1215, 2081, 2000, 2178, 2179, 2180, 2181, 2288, 2289, 2287, 2285, 2397, 2520, 2521, 2589}
        serviceURL = System.Configuration.ConfigurationManager.AppSettings("ExcelicareWebServiceURL")
        Dim SK As New Random
        Dim arrResult As Hashtable
        Dim intDuplicateSession As Int16 = 0
        Dim objAppSetttings As New clsAppSettings
        Try
            Response.Expires = -1
            Response.Cache.SetNoServerCaching()
            Response.Cache.SetAllowResponseInBrowserHistory(False)
            Response.CacheControl = "no-cache"
            Response.Cache.SetNoStore()

            If Not IsPostBack Then
                ''Added by Ramana Reddy to check  Duplicate Session Entry in DB by 26/12/2008
                '' Added by Pavan Koppenini to fix issue id: 58734 on 11/10/2012
                If Not Session("APPDATA") Is Nothing AndAlso fnSessionExist() Then

                    logECWebSessionAction(2039, -1, "Duplicate ASP Session, Logged from Login")
                    Response.Redirect("~/AxWebUIMDI/CustomError.Aspx?ErrorCode=User session is active in this machine, please close the active session or open the URL in different browser.", False)
                End If
            End If
            m_strSessionID = Session.SessionID
            logECWebSessionAction(2039, -1, "Login Page Load")
            strSaltKey = SK.Next(1000, 10000).ToString().Substring(0, 2)
            Session("SK") = strSaltKey
            'intMaxSecurityAnsAttempts = clsSysDefault.GetSysDefaultValue(2288)
            'm_chooseCount = clsSysDefault.GetSysDefaultValue(2289)
            'EnableChoose = clsSysDefault.GetSysDefaultValue(2287)
            'allowSecondaryVerification = clsSysDefault.GetSysDefaultValue(2285)            
            Ajax.Utility.RegisterTypeForAjax(GetType(frmsignon))

            blnSSI = IIf(AppSettings("SSI") & "" = "0", 0, 1) 'ShowSecurityImage
            intUserLocation = IIf(AppSettings("UserLocation") & "" = "0", 0, 1) 'Check for User locations
            g_ShowScriptErrors = AppSettings("ShowScriptErrors")
            '  blnSessionUsed = fnSessionExist()

            Session("MachineName") = Request.UserHostName
            Session("MachineIP") = Request.UserHostAddress
            Session("SignOn") = "1"

            strMDIVirFolderName = objAppSetttings.GetVirtualFolderPath("1031")
            strAxLoginFolderName = objAppSetttings.GetVirtualFolderPath("1030") & "/frmLogin.aspx"
            strAxDialogVirFolderName = objAppSetttings.GetVirtualFolderPath("1034")
            objClsAppSettings = New clsAppSettings
            objSysDefault = New clsSysDefault
            strModuleVersionNo = objClsAppSettings.GetModuleVersion("1030")
            arrResult = clsSysDefault.GetSysDefaultValues(arrDefaultIds)

            strLoginAttempts = arrResult(1215).value.ToString
            intMaxSecurityAnsAttempts = arrResult(2288).value
            m_chooseCount = arrResult(2289).value
            EnableChoose = arrResult(2287).value
            allowSecondaryVerification = arrResult(2285).value
            m_strLoginDefaults = Server.UrlEncode(arrResult(2081).value.ToString)
            m_strLoginDefaults = m_strLoginDefaults.Replace("+", " ")
            intShowClientLog = arrResult(2000).value
            If Not arrResult(2521) Is Nothing Then
                IsSecureIP = GetClientuserIP(arrResult(2521).value)
            End If
            If Not arrResult(2589) Is Nothing Then
                m_ShowLoginFailedAttempts = arrResult(2589).value
            End If
            If (System.Configuration.ConfigurationManager.AppSettings("MFAE").ToLower() = 1) Then
                If System.Text.RegularExpressions.Regex.IsMatch(clsSysDefault.GetSysDefaultValue(2520), "^[A-Z2-7]{16}") AndAlso IsSecureIP = False Then
                    m_issysMFAEnabled = True
                Else
                    m_issysMFAEnabled = False
                End If
            End If
            If IsNothing(arrResult(2178)) = False Then
                m_intADAuthentication = arrResult(2178).value
            End If
            If IsNothing(arrResult(2397)) = False Then
                blnshowForgotPwdLink = arrResult(2397).value
            End If

            If m_intADAuthentication = 1 Then
                Session("ADUser") = True
            Else
                Session("ADUser") = False
            End If
            If m_intADAuthentication = 1 Then
                cbDomains.DataSource = clsBizlECSession.GetDomainNames()
                cbDomains.DataTextField = "LookupValue"
                cbDomains.DataValueField = "ID"
                cbDomains.DataBind()
                If cbDomains.Items.Count > 1 Then
                    m_showdomaincombo = 1
                Else
                    m_showdomaincombo = 0
                End If
            End If
            hdnValidateKey.Value = ""
        Catch ex As Exception
            LogException(ex)
        Finally
            objSysDefault = Nothing
            objClsAppSettings = Nothing
            objBizEcsession = Nothing
            objClsSessionLog = Nothing
            arrDefaultIds = Nothing
            objAppSetttings = Nothing
        End Try

    End Sub

    Private Function isValidEmail(ByVal inputEmail As String) As Boolean
        Dim strRegex As String = "^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" & "\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" & ".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$"
        Dim re As Regex = New Regex(strRegex)

        If re.IsMatch(inputEmail) Then
            Return (True)
        Else
            Return (False)
        End If
    End Function


    Public Sub StartUserSession(ByVal dtTemp As DataTable, ByVal intSSOLOCID As Int64)
        Dim objClsSessionData As clsSessionData
        Dim objClsSessionManager As clsSessionManager
        Dim strLoginTitle As String = "Excelicare - Login"
        Dim arrDefaultIds() As Int64 = {2123, 2124, 2125, 2126, 1640, 2034, 2035, 2566, 2554}
        Dim arrResult As Hashtable
        Dim drTemp As DataRow
        'Dim objSysDefault As clsSysDefault

        Try
            drTemp = dtTemp.Rows(0)
            '  objSysDefault = New clsSysDefault
            logECWebSessionAction(2039, -1, "Login - Successful")
            objClsSessionData = New clsSessionData
            objClsSessionData.IsSuperUser = drTemp("CanDelete")
            objClsSessionData.LinkID = drTemp("CLN_ID")
            objClsSessionData.ShowInActiveRecords = drTemp("ShowInActiveRecords")
            objClsSessionData.TypeOfUser = IIf(drTemp("TypeOfUser") Is Nothing Or IsDBNull(drTemp("TypeOfUser")), 1, drTemp("TypeOfUser"))
            objClsSessionData.UserForeName = drTemp("Usr_ForeName")
            objClsSessionData.UserID = drTemp("Usr_ID")
            objClsSessionData.UserSurName = drTemp("Usr_SurName")
            objClsSessionData.UserSecurityLevel = drTemp("USR_SECURITY_LEVEL")

            'Print related configurations keeping in session object to access across application

            arrResult = clsSysDefault.GetSysDefaultValues(arrDefaultIds)
            objClsSessionData.PrintPdfHeaderFontName = arrResult(2123).value.ToString
            objClsSessionData.PrintPdfHeaderFontSize = arrResult(2124).value.ToString
            objClsSessionData.PrintPdfFooterFontName = arrResult(2125).value.ToString
            objClsSessionData.PrintPdfFooterFontSize = arrResult(2126).value.ToString
            objClsSessionData.PrintPdfWaterMark = arrResult(1640).value.ToString
            objClsSessionData.PrintPdfWidth = arrResult(2034).value.ToString
            objClsSessionData.PrintPdfbgColor = arrResult(2035).value.ToString
            If Not IsDBNull(drTemp("TypeOfUser")) AndAlso drTemp("TypeOfUser") = 2 Then
                objClsSessionData.PatientID = drTemp("CLN_ID")
            End If
            If IsNothing(drTemp("AutoLogOffTime")) = False Then
                objClsSessionData.AutoLogOffTime = drTemp("AutoLogOffTime")
            End If
            Dim objGlobalizationSection As System.Web.Configuration.GlobalizationSection
            objGlobalizationSection = System.Configuration.ConfigurationManager.GetSection("system.web/globalization")
            objClsSessionData.LanguageCode = objGlobalizationSection.UICulture.ToString
            objClsSessionData.LanguageCode = ""
            objClsSessionData.UAO_ECLoc_ID = intSSOLOCID
            objClsSessionData.User_GUID = Guid.NewGuid().ToString("N")
            objClsSessionManager = New clsSessionManager
            objClsSessionManager.SetSessionData(Session.SessionID, "APPDATA", objClsSessionData)
            ' adding OS and SQL injection validation Regx values in session object..
            HttpContext.Current.Session.Item("SysDefault_2554") = arrResult(2554).value.ToString & ""
            HttpContext.Current.Session.Item("SysDefault_2566") = arrResult(2566).value.ToString & ""
        Catch ex As Exception
            LogException(ex)
        Finally
            objClsSessionData = Nothing
            objClsSessionManager = Nothing
            drTemp = Nothing
            arrResult = Nothing
            arrDefaultIds = Nothing
        End Try
    End Sub

    <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
    Public Function CheckUserCredentials(ByVal strData As String) As String ', Optional strUid As String = "") As String
        Dim objClsLogin As clsLogin
        Dim objClsECSession As clsECSession
        Dim objBizlECSession As clsBizlECSession
        Dim arrStrSysDefaultNames As String = "'Max Login Attempts', 'Record Failed Attempts'"
        Dim int16MaxLoginAttempts As Int16
        Dim int16RecordFailedLoginAttempts As Int16
        Dim intSysPreferenceValue As Int16
        Dim strActiveSessionIdsCount As String = String.Empty
        Dim dsTemp As DataSet
        Dim intRowIndex As Int16
        Dim intIsOfflineOfficeAdmin As Int16
        'Dim objclsSecurity As clsSecurity
        Dim blnForcePasswordChange As Boolean
        Dim intSessionIDCount As Int16
        Dim blnISPASSWORDEXPIRED As Boolean
        Dim intRemainderDays As Int16
        Dim intUSRHBoard_ID As Int64
        Dim intSysModId As Integer
        Dim strRedirectURL As String = ""
        Dim strLoginURL As String = ""
        Dim strDialogDomainName As String = ""
        Dim strVerNo As String = ""
        Dim intPWDpromptRequired As Integer
        Dim int64USR_ID As Integer
        Dim blnMaximumNoOfLoginsReached As Boolean = False
        Dim strReturnValue As String = ""
        Dim blnCheckSecurityText As Boolean = False
        Dim intActiveSessionCount As Integer = 0
        Dim enResult As String = enAuthenticateResult.Fail
        Dim dtQstns As DataSet
        Dim objSecurityProxy As AxRSSecurityService.AxRSSecurityClient
        Dim intIndex As Integer
        Dim JsonResult As String = ""
        Dim intSSOID As Integer = 0
        Dim UMFAEnabled As String = String.Empty
        Dim IsValidateEmail As Boolean = False
        Dim UserName As String
        Dim Password As String
        Dim strSecurityText As String
        Dim strDomainName As String
        Dim intADAuthentication As Int16
        Dim intSecondLevelVerification As Int16
        Dim strUid As String
        Dim strSession_ID As String = ""
        Dim jsResult As Object
        Dim strToken As String = String.Empty
        Try
            If Not Session("APPDATA") Is Nothing AndAlso fnSessionExist() Then
                logECWebSessionAction(2039, -1, "Duplicate ASP Session, Logged from CheckUserCredentials().")
                Return False
            End If
            objBizlECSession = New clsBizlECSession
            objclsSecurity = New clsSecurity
            strData = objclsSecurity.DecryptData(strData)
            jsResult = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(strData)
            UserName = jsResult("sun")
            Password = jsResult("spd")
            strSecurityText = jsResult("ssv")
            strDomainName = jsResult("sdn")
            intADAuthentication = jsResult("ada")
            intSecondLevelVerification = jsResult("asv")
            strUid = jsResult("sus").ToString
            strSession_ID = jsResult("m_strSessionID")
            If strSession_ID = Session.SessionID Then
                UserName = HttpUtility.UrlDecode(UserName)
                strSecurityText = HttpUtility.UrlDecode(strSecurityText)
                Session("SignOn") = "1"
                Session("UserLoginName") = UserName
                dsTemp = New DataSet
                intSysModId = CInt(HttpContext.Current.Request.QueryString("CalledFrom"))
                objclsSecurity = New clsSecurity
                Select Case intSysModId
                    Case 129, 176, 100, 104 'Splfrms, documents, pat reg , pat sumamry
                        intSysModId = 50
                    Case 0
                        intSysModId = 1031
                    Case 1031
                        intSysModId = 1031

                End Select
                If Not ((AscW(UserName.Chars(0)) > 64 AndAlso AscW(UserName.Chars(0)) < 91) OrElse (AscW(UserName.Chars(0)) > 96 AndAlso AscW(UserName.Chars(0)) < 123)) Then
                    Return strReturnValue & Chr(186) & strRedirectURL & Chr(186) & int64USR_ID
                End If

                If intADAuthentication = 1 Then
                    objSecurityProxy = New AxRSSecurityService.AxRSSecurityClient 'AxWSSecurityService.AxSecurityClient
                    Session("UserDomainName") = strDomainName
                    dsTemp = objSecurityProxy.AuthenticateECUser(UserName, Password, strDomainName)
                    If dsTemp.Tables.Count > 0 AndAlso dsTemp.Tables(0).Rows.Count > 0 Then
                        enResult = enAuthenticateResult.Success
                    End If
                Else
                    dsTemp = objBizlECSession.AuthenticateLogin(UserName, Password, "1030,1034," & intSysModId, "1345", arrStrSysDefaultNames)
                End If
                If Not dsTemp Is Nothing Then

                    If Not dsTemp.Tables("DefaultValues") Is Nothing AndAlso intADAuthentication = 0 Then
                        enResult = enAuthenticateResult.Success
                        If dsTemp.Tables("DefaultValues").Rows.Count > 0 Then
                            intSessionIDCount = dsTemp.Tables("DefaultValues").Rows(0).Item("SessionIDCount")
                            'If intSessionIDCount <= 0 Then
                            If Not IsDBNull(dsTemp.Tables("DefaultValues").Rows(0).Item("ISPWDPROMPTREQUIRED")) Then
                                intPWDpromptRequired = dsTemp.Tables("DefaultValues").Rows(0).Item("ISPWDPROMPTREQUIRED")
                            End If
                            If intPWDpromptRequired = 1 Then 'First time login
                                logECWebSessionAction(2729, -1, "First time login, Logged from CheckUserCredentials().")
                                enResult = enAuthenticateResult.PassswordPrompt
                                Session("ShowPasssordChangeScreen") = True
                            ElseIf intPWDpromptRequired = 2 Then 'Handeled Diff between first time and Reset password
                                logECWebSessionAction(2729, -1, "Reset password, Logged from CheckUserCredentials().")
                                enResult = enAuthenticateResult.PasswordChange
                                Session("ShowPasssordChangeScreen") = True
                            End If
                            If Not IsDBNull(dsTemp.Tables("DefaultValues").Rows(0).Item("PrivilegedForms")) Then
                                blnForcePasswordChange = dsTemp.Tables("DefaultValues").Rows(0).Item("PrivilegedForms")
                            End If
                            If Not IsDBNull(dsTemp.Tables("DefaultValues").Rows(0).Item("Usr_Email")) Then
                                IsValidateEmail = isValidEmail(dsTemp.Tables("DefaultValues").Rows(0).Item("Usr_Email").ToString())
                            End If
                            If Not IsDBNull(dsTemp.Tables("DefaultValues").Rows(0).Item("QRCode")) Then
                                Dim data As Byte()
                                Dim strsecretKey As String
                                JSonMFAResult = JsonConvert.DeserializeObject(Of Object)(dsTemp.Tables("DefaultValues").Rows(0).Item("QRCode"))
                                If JSonMFAResult("QRCode") <> "" Then
                                    data = System.Convert.FromBase64String(JSonMFAResult("QRCode"))
                                    strsecretKey = System.Text.ASCIIEncoding.ASCII.GetString(data)
                                    Session("QRCode") = strsecretKey
                                    logECWebSessionAction(2039, -1, "CheckUserCredential QRCode:" & Session("QRCode").ToString())
                                End If

                                If JSonMFAResult("IsMFAEnabled") = 1 Then
                                    UMFAEnabled = JSonMFAResult("IsMFAEnabled").ToString()
                                Else
                                    UMFAEnabled = JSonMFAResult("IsMFAEnabled").ToString()
                                End If

                            End If
                            Dim ispasswordexp As Integer = clsSysDefault.GetSysDefaultValue(1001)
                            If ispasswordexp > 0 Then
                                blnISPASSWORDEXPIRED = dsTemp.Tables("DefaultValues").Rows(0).Item("ISPASSWORDEXPIRED")
                                If Not blnForcePasswordChange = True AndAlso blnISPASSWORDEXPIRED = True AndAlso intPWDpromptRequired = 0 Then
                                    enResult = enAuthenticateResult.PasswordExpired
                                    Session("ShowPasssordChangeScreen") = True
                                End If
                                intRemainderDays = dsTemp.Tables("DefaultValues").Rows(0).Item("REMainderDays")
                                If Not IsDBNull(dsTemp.Tables("DefaultValues").Rows(0).Item("USRHBoard_ID")) Then
                                    intUSRHBoard_ID = dsTemp.Tables("DefaultValues").Rows(0).Item("USRHBoard_ID")
                                End If
                                If Not blnForcePasswordChange = True AndAlso intRemainderDays > 0 AndAlso intPWDpromptRequired = 0 Then
                                    enResult = enAuthenticateResult.RemainderDays
                                    enResult = enResult & "," & intRemainderDays
                                End If
                            End If
                        End If
                    End If

                    If dsTemp.Tables(0).Rows.Count > 0 Then
                        int64USR_ID = dsTemp.Tables(0).Rows(0).Item(0)
                        Session("TempUserID") = int64USR_ID
                    End If
                    blnshowForgotPwdLink = clsSysDefault.GetSysDefaultValue(2397)
                    If int64USR_ID <> 0 AndAlso strUid <> "" Then
                        intSSOID = objBizlECSession.fnECMappingSsoUID(strUid, int64USR_ID)
                    End If
                    If intPWDpromptRequired = 1 OrElse intPWDpromptRequired = 2 OrElse blnISPASSWORDEXPIRED = True Then
                        Session("IsPWDpromptRequired") = 1
                        'ElseIf blnISPASSWORDEXPIRED = True Then
                        'Session("IsPWDpromptRequired") = 1
                    End If

                    If int64USR_ID > 0 Then
                        dtQstns = New DataSet
                        dtQstns = objBizlECSession.GetUserSecurityQuestions(int64USR_ID)
                        If dtQstns.Tables.Count = 0 AndAlso IsNothing(Session("ShowPasssordChangeScreen")) = True Then
                            enResult = enAuthenticateResult.SecurityQuestionsPrompt
                            If blnshowForgotPwdLink = True Then
                                Session("IsPWDpromptRequired") = 2
                            End If

                        ElseIf dtQstns.Tables.Count > 0 AndAlso dtQstns.Tables(0).Rows.Count > 0 AndAlso intSecondLevelVerification = 1 Then
                            For intIndex = 0 To dtQstns.Tables(0).Rows.Count - 1
                                If JsonResult = "" Then
                                    JsonResult = JsonResult & dtQstns.Tables(0).Rows(intIndex).Item(0) & Chr(181) & dtQstns.Tables(0).Rows(intIndex).Item(1)
                                Else
                                    JsonResult = JsonResult & Chr(182) & dtQstns.Tables(0).Rows(intIndex).Item(0) & Chr(181) & dtQstns.Tables(0).Rows(intIndex).Item(1)
                                End If
                            Next
                        End If

                    End If




                    If int64USR_ID > 0 Then
                        If (AppSettings("SSI") & "" <> "0" AndAlso strSecurityText.Length <> 6) Then
                            blnCheckSecurityText = False
                        ElseIf Not AppSettings("SSI") Is Nothing AndAlso AppSettings("SSI") & "" = "0" Then
                            blnCheckSecurityText = True
                        ElseIf Not Session("code") Is Nothing AndAlso strSecurityText.Trim.Length > 0 AndAlso strSecurityText.ToLower = Session("code") Then
                            blnCheckSecurityText = True
                        Else
                            RecordUserFailedLogin(UserName, Password)
                        End If
                        If blnCheckSecurityText = False Then
                            enResult = enAuthenticateResult.Fail
                            logECWebSessionAction(2575, -1, "Excelicare User Login Fails")
                            strReturnValue = intActiveSessionCount & Chr(182) & enResult
                            Return objclsSecurity.ECEncode(strReturnValue)
                        End If
                    End If


                    strReturnValue = intSessionIDCount & Chr(182) & enResult
                    'If blnStartSession = False AndAlso intSessionIDCount > 0 Then
                    '    Return strReturnValue & Chr(186) & strRedirectURL & Chr(186) & int64USR_ID
                    'End If

                    If intADAuthentication = 0 Then
                        If dsTemp.Tables("SysDefaults").Rows.Count > 0 Then
                            intSysPreferenceValue = IIf(IsDBNull(dsTemp.Tables("SysDefaults").Rows(0).Item("value")), 0, dsTemp.Tables("SysDefaults").Rows(0).Item("value"))
                        End If
                        If dsTemp.Tables("SysDefaultValue").Rows.Count > 0 Then
                            If dsTemp.Tables("SysDefaultValue").Rows(0).Item("Id") <> 1202 Then
                                int16MaxLoginAttempts = dsTemp.Tables("SysDefaultValue").Rows(0).Item("Value")
                                int16RecordFailedLoginAttempts = dsTemp.Tables("SysDefaultValue").Rows(1).Item("Value")
                            Else
                                int16MaxLoginAttempts = dsTemp.Tables("SysDefaultValue").Rows(1).Item("Value")
                                int16RecordFailedLoginAttempts = dsTemp.Tables("SysDefaultValue").Rows(0).Item("Value")
                            End If

                        End If
                    End If
                End If
                If int64USR_ID > 0 Then 'Or CInt(hdnUserId.Value) > 0 Then
                    Session("UserDetails") = dsTemp.Tables("UserDetails")
                    If intADAuthentication = 0 Then
                        intIsOfflineOfficeAdmin = dsTemp.Tables("UserDetails").Rows(0)("IsOfflineDBAdmin")
                    End If
                    If intIsOfflineOfficeAdmin <> 0 Then
                        Session("IsOfflineDBAdmin") = "true"
                    Else
                        Session("IsOfflineDBAdmin") = "false"
                    End If
                End If

                '  Else ' if login failed Check number of login attempts not exceeded.
                If (int64USR_ID = 0) Then   ' 1 for record and 0 for not
                    'Record failed login
                    'objClsLogin = New clsLogin
                    'objClsLogin.RecordFailedLogin(HttpContext.Current.Request.UserHostName, HttpContext.Current.Request.UserHostAddress, UserName, Password)
                    RecordUserFailedLogin(UserName, Password)
                    enResult = enAuthenticateResult.Fail
                    logECWebSessionAction(2575, -1, "Excelicare User Login Fails")
                    strReturnValue = intActiveSessionCount & Chr(182) & enResult
                End If
                'Track the number of login attempts
                If (Session("LoginAttempts") >= int16MaxLoginAttempts) Then
                    ' Report maximum number of attempts exceded
                    blnMaximumNoOfLoginsReached = True
                Else
                    Session("LoginAttempts") += 1
                End If
                If int64USR_ID > 0 Then
                    strToken = RegisterToken(UserName)
                End If
                Return objclsSecurity.ECEncode(strReturnValue & Chr(186) & strRedirectURL & Chr(186) & int64USR_ID & Chr(190) & JsonResult & Chr(190) & UMFAEnabled & Chr(190) & IsValidateEmail.ToString() & Chr(190) & strToken)
            Else
                clsECSession.LogWebSessionAction("Login", Session.SessionID, -1, -1, "Session is not same as sent from browser, Original sessionid: " & strSession_ID & ", Sessionid sent from browser: " & Session.SessionID)
                Return objclsSecurity.ECEncode("Invalid Session")
            End If
            '    End If
        Catch SqlEx As SqlException
            If SqlEx.Number = 17 Then
                ' lblMessage.Text = "SQL Server does not exist or access denied."
            End If
        Catch ex As Exception
            LogException(ex)
            Throw ex
            'If ex.Message = "Security/Data breach identified. Please contact Excelicare Administrator." Then
            '    Return objclsSecurity.ECEncode("XSS content found")
            'End If
        Finally '' Added by Suneetha on 13.07.2005 to clean up objects Begin
            'clean up objects
            objclsSecurity = Nothing
            jsResult = Nothing
            If IsNothing(objSecurityProxy) = False Then
                objSecurityProxy.Close()
            End If
            arrStrSysDefaultNames = Nothing
            int16MaxLoginAttempts = Nothing
            int16RecordFailedLoginAttempts = Nothing
            intSysPreferenceValue = Nothing
            strActiveSessionIdsCount = Nothing
            If Not dsTemp Is Nothing Then
                dsTemp.Dispose()
                dsTemp = Nothing
            End If
            intRowIndex = Nothing
            objClsLogin = Nothing
            objClsECSession = Nothing
            objBizlECSession = Nothing
            intIsOfflineOfficeAdmin = Nothing
            blnForcePasswordChange = Nothing
            intSessionIDCount = Nothing
            blnISPASSWORDEXPIRED = Nothing
            intRemainderDays = Nothing
            intUSRHBoard_ID = Nothing
            intSysModId = Nothing
            strRedirectURL = Nothing
            strLoginURL = Nothing
            strDialogDomainName = Nothing
            strVerNo = Nothing
            intPWDpromptRequired = Nothing
            int64USR_ID = Nothing
            blnMaximumNoOfLoginsReached = Nothing
            strReturnValue = Nothing
            blnCheckSecurityText = Nothing
            intActiveSessionCount = Nothing
            enResult = Nothing
            dtQstns = Nothing

        End Try '' Added by Suneetha on 13.07.2005 to clean up objects End
    End Function

    <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
    Public Function ValidateSecondaryLogin(ByVal strData As String) As String
        Dim objBiz As clsBizlECSession
        Dim dsCreds As DataSet
        Dim objClsLogin As clsLogin
        Dim strStatus As String = ""
        Dim struserId As Integer
        Dim strQuestion As Integer
        Dim strAnswer As String
        Dim blnInvoke As Boolean
        Dim jsonResult As Object
        Try
            logECWebSessionAction(2039, -1, "Secondary level authentication - Begin ")
            objBiz = New clsBizlECSession
            objclsSecurity = New clsSecurity
            strData = objclsSecurity.DecryptData(strData)
            jsonResult = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(strData)
            struserId = jsonResult("iud")
            strQuestion = jsonResult("squ")
            strAnswer = jsonResult("san").ToString
            blnInvoke = jsonResult("biv")
            strStatus = objBiz.AuthenticateSecondaryLogin(struserId, strQuestion, HttpUtility.UrlDecode(strAnswer))
            If strStatus.ToLower = "success" Then
                logECWebSessionAction(2037, -1, "Login - Successful")
                Return "true"
            Else
                logECWebSessionAction(2575, -1, "Login - Failed")
                If blnInvoke = True Then
                    'RecordInvalidAnswerCount(struserId)

                    dsCreds = objBiz.GetUserCredentials(struserId)
                    If Not dsCreds Is Nothing AndAlso dsCreds.Tables.Count > 0 AndAlso dsCreds.Tables(0).Rows.Count > 0 Then
                        If Not IsDBNull(dsCreds.Tables(0).Rows(0)("USR_LoginName")) AndAlso Not IsDBNull(dsCreds.Tables(0).Rows(0)("USR_Pswd")) Then
                            'objClsLogin = New clsLogin
                            'objClsLogin.RecordFailedLogin(HttpContext.Current.Request.UserHostName, HttpContext.Current.Request.UserHostAddress, dsCreds.Tables(0).Rows(0)("USR_LoginName"), dsCreds.Tables(0).Rows(0)("USR_Pswd"))
                            RecordUserFailedLogin(dsCreds.Tables(0).Rows(0)("USR_LoginName"), dsCreds.Tables(0).Rows(0)("USR_Pswd"))
                        End If
                    End If
                End If

                Return "false" & Chr(186) & "Invalid answer"
            End If
        Catch ex As Exception
            Throw ex
        Finally
            objBiz = Nothing
            strStatus = Nothing
            objClsLogin = Nothing
            dsCreds = Nothing
            jsonResult = Nothing
            logECWebSessionAction(2039, -1, "Secondary level authentication - End ")
        End Try
    End Function

    <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
    Public Function fnSaveDisclaimer(ByVal strData As String) As String
        Dim objBizEcsession As clsBizlECSession
        Dim objSession As clsSessionManager
        Dim objSessionData As clsSessionData
        Dim UserID As Long
        Dim DisclaimerIds As String
        Dim objclsSecurity As New clsSecurity
        Dim jsonResult As Object
        Try
            objSession = New clsSessionManager
            objSessionData = New clsSessionData
            objSessionData = objSession.GetSessionData(Session.SessionID, "APPDATA")
            UserID = objSessionData.UserID
            strData = objclsSecurity.DecryptData(strData)
            jsonResult = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(strData)
            DisclaimerIds = jsonResult("did")
            objBizEcsession = New clsBizlECSession
            objBizEcsession.fnSaveDisclaimer(UserID, DisclaimerIds)
        Catch ex As Exception
            LogException(ex)
            Throw ex
        Finally
            objSession = Nothing
            objSessionData = Nothing
            jsonResult = Nothing
        End Try
    End Function

    Public Function RecordInvalidAnswerCount(ByVal UserId As Integer)
        Dim objBiz As clsBizlECSession
        Dim strStatus As String = ""
        Try
            objBiz = New clsBizlECSession
            objBiz.RecordInvalidAnswerCount(UserId)
        Catch ex As Exception
            Throw
        Finally
            objBiz = Nothing
            strStatus = Nothing
        End Try
    End Function
    <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
    Public Function StartSession(ByVal strData As String) As Boolean
        Dim objClsECSession As New clsECSession
        'Getting Request User Machine Name - Start
        '  Dim host As System.Net.IPHostEntry
        Dim strMachineName As String
        Dim intUserId As Integer
        Dim intType As Int16
        Dim intSSOLOCID As Int64
        Dim objBizEcsession As clsBizlECSession
        Dim jsonResult As Object
        'From35
        Try
            objBizEcsession = New clsBizlECSession
            objclsSecurity = New clsSecurity
            strData = objclsSecurity.DecryptData(strData)
            jsonResult = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(strData)
            intUserId = jsonResult("uid")
            intType = jsonResult("rev")
            intSSOLOCID = jsonResult("sli")
            'If objBizEcsession.IsSessionDuplicate(Session.SessionID) Then
            'logECWebSessionAction(2039, -1, "Duplicate ASP Session")
            'Return False
            'End If
            strMachineName = HttpContext.Current.Request.UserHostName
            If intType = 6 Then
                EndActiveSessionsByUserID(True)
                logECWebSessionAction(2039, -1, "Open new session / end other session(s)")
            ElseIf intType = 7 Then
                logECWebSessionAction(2039, -1, "Open new session / retain other session(s)")
            End If
            objClsECSession.StartSession(intUserId, Session.SessionID, strMachineName, HttpContext.Current.Request.UserHostAddress, "", 0, intSSOLOCID)
            StartUserSession(Session("UserDetails"), intSSOLOCID)
            Return True
        Catch ex As Exception
            LogException(ex)
            Throw ex
        Finally
            strMachineName = Nothing
            objClsECSession = Nothing
            Session("UserDetails") = Nothing
            objBizEcsession = Nothing
            jsonResult = Nothing
        End Try
    End Function


    Public Sub RecordUserFailedLogin(ByVal UserName As String, ByVal Password As String)
        Dim objUserProxy As AxRSUserManagerClient
        Try
            objUserProxy = New AxRSUserManagerClient
            objUserProxy.RecordUserFailedLogin(HttpContext.Current.Request.UserHostName, HttpContext.Current.Request.UserHostAddress, UserName.Trim, Password.Trim, 16302)
            objUserProxy.Close()
        Catch ex As Exception
            LogException(ex)
        Finally
            'objUserProxy.Close()
        End Try
    End Sub

    ' -----------------------------------------------------------------------------
    ' <summary>
    '      Used to check the user HBID with the web ser HBID List 
    ' </summary>
    ' <remarks>
    ' </remarks>
    ' <history>
    ' 	  [Suneetha B] 06/10/2006
    ' </history>
    ' -----------------------------------------------------------------------------

    Public Function IsUserHBIDFailed(ByVal intUserHBID As Int64) As Boolean
        'Dim objBizclsLogin As New AxSys.Bizl.Login.clsBizlECSession
        Try
            'Dim intUserHBID As Integer = objBizclsLogin.GetUserHealthBoardID(int64USR_ID)
            If Not ConfigurationSettings.AppSettings("HB_ID") Is Nothing Then
                If intUserHBID > 0 And ConfigurationSettings.AppSettings("HB_ID").ToString <> "" Then
                    If ConfigurationSettings.AppSettings("HB_ID").ToString.IndexOf("," & intUserHBID & ",") = -1 Then
                        blnUserHBIDFailed = True
                        Return True
                    End If
                End If

            End If

            Return False
        Catch ex As Exception
            LogException(ex)
        Finally
            'objBizclsLogin = Nothing

        End Try
    End Function


    <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
    Public Function SetLocation(ByVal strData As String) As Boolean
        Dim lngLocationValue As Long
        Dim jsonResult As Object
        Try
            objclsSecurity = New clsSecurity
            strData = objclsSecurity.DecryptData(strData)
            jsonResult = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(strData)
            lngLocationValue = jsonResult("loc")
            If lngLocationValue > 0 Then
                Session("UserLocationID") = lngLocationValue
            End If
        Catch ex As Exception
            Throw ex
        Finally
            jsonResult = Nothing
        End Try
    End Function


    <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
    Public Function CheckSecurity(ByVal strData As String) As Boolean
        Dim strSecurityText As String
        Dim jsonResult As Object
        Try
            objclsSecurity = New clsSecurity
            strData = objclsSecurity.DecryptData(strData)
            jsonResult = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(strData)
            strSecurityText = jsonResult("scv")
            If Not AppSettings("SSI") Is Nothing AndAlso AppSettings("SSI") & "" = "0" Then
                Return True
            ElseIf Not Session("code") Is Nothing AndAlso strSecurityText.ToLower = Session("code") Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Throw ex
        Finally
            jsonResult = Nothing
        End Try
    End Function
    <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
    Public Sub logECWebSessionAction(ByVal lngEventId As Long, ByVal lngPatId As Long, ByVal strEventDet As String)
        Try
            clsECSession.LogWebSessionAction("Login ", Session.SessionID, lngPatId, lngEventId, strEventDet, 1030, 0)
        Catch ex As Exception
            LogException(ex)
        End Try
    End Sub
    <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
    Public Function EndActiveSessionsByUserID(ByVal blnTerminateActiveSessions As Boolean) As Boolean
        Dim objBizlECSession As clsBizlECSession
        Dim lngUSR_ID As Long
        Try
            objBizlECSession = New clsBizlECSession
            If Not Session("TempUserID") Is Nothing Then
                lngUSR_ID = Session("TempUserID")
            End If
            If lngUSR_ID > 0 Then
                If blnTerminateActiveSessions = True Then
                    objBizlECSession.EndActiveSessionsByUserID(lngUSR_ID)
                End If
            End If
            Session("mdiloaded") = Nothing

        Catch ex As Exception
            LogException(ex)
            If CanShowScriptError() = "True" Then
                Throw ex
            End If
        Finally
            objBizlECSession = Nothing
        End Try
    End Function

    <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
    Public Function GetUserLocations(ByVal strData As String) As String
        'Dim strText As String = String.Empty
        Dim sbText As New StringBuilder
        Dim objLogin As Excelicare.Bizl.Login.clsBizlECSession
        Dim dtLocations As DataTable
        Dim UserName As String
        Dim PassWord As String
        Dim strSecurityText As String
        Dim strCalledFrom As String
        Dim intUserId As Integer
        Dim jsonResult As Object
        Try
            objclsSecurity = New clsSecurity
            strData = objclsSecurity.DecryptData(strData)
            jsonResult = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(strData)
            UserName = jsonResult("snm").ToString
            PassWord = jsonResult("spd").ToString
            strSecurityText = jsonResult("ssc").ToString
            strCalledFrom = jsonResult("scf").ToString
            intUserId = jsonResult("iud").ToString
            UserName = HttpUtility.UrlDecode(UserName)
            strSecurityText = HttpUtility.UrlDecode(strSecurityText)
            If strSecurityText.Length <> 6 Then
                'strText = ""
                sbText.Append("") 'added by sunil
            ElseIf Not ((AscW(UserName.Chars(0)) > 64 AndAlso AscW(UserName.Chars(0)) < 91) OrElse (AscW(UserName.Chars(0)) > 96 AndAlso AscW(UserName.Chars(0)) < 123)) Then
                ' strText = ""
                sbText.Append("") 'added by sunil
            ElseIf UserName.Length > 0 AndAlso PassWord.Length > 0 Then
                objLogin = New Excelicare.Bizl.Login.clsBizlECSession

                'If UserName.Length > 0 AndAlso PassWord.Length > 0 Then

                dtLocations = objLogin.GetUserLocations(intUserId)

                'strText = "<Locations>"
                sbText.Append("<Locations>") 'added by sunil
                For Each row As DataRow In dtLocations.Rows
                    'strText = strText & "<Loc>"
                    sbText.Append("<Loc>")
                    'strText = strText & "<ID>" & row("ID") & "</ID>"
                    sbText.Append("<ID>" & row("ID") & "</ID>")
                    'strText = strText & "<Name>" & row("Name") & "</Name>"
                    sbText.Append("<Name>" & row("Name") & "</Name>")
                    'strText = strText & "<IsPrimary>" & row("IsPrimary") & "</IsPrimary>"
                    sbText.Append("<IsPrimary>" & row("IsPrimary") & "</IsPrimary>")
                    'strText = strText & "</Loc>"
                    sbText.Append("</Loc>")
                Next
                'strText = strText & "</Locations>"
                sbText.Append("</Locations>")
                'End If

                Return objclsSecurity.ECEncode(sbText.ToString)
            End If
            Return objclsSecurity.ECEncode(sbText.ToString)
        Catch ex As Exception
            LogException(ex)
            Throw ex
            If CanShowScriptError() = "True" Then
                Throw ex
            End If
        Finally
            objLogin = Nothing
            sbText = Nothing
            jsonResult = Nothing
        End Try
        Return String.Empty
    End Function



    Private Sub LogException(ByVal objExcep As Exception)
        Dim objClsExceptionHandler As clsExceptionHandler
        Try
            objClsExceptionHandler = New clsExceptionHandler(objExcep)
            If Not IsNothing(Page) Then
                objClsExceptionHandler.LogException(Page)
            Else
                objClsExceptionHandler.LogException()
            End If
        Catch ex As Exception
        Finally
            objClsExceptionHandler = Nothing
        End Try
    End Sub
    Private Function fnSessionExist() As Boolean
        Dim objClsSessionManager As clsSessionManager
        Try
            objClsSessionManager = New clsSessionManager
            If objClsSessionManager.IsSessionExists(Session.SessionID) Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            LogException(ex)
        Finally
            objClsSessionManager = Nothing
        End Try
    End Function
    <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
    Public Function GetSysBroadcastDetails() As String
        Dim objLogin As Excelicare.Bizl.Login.clsBizlECSession
        Dim strBroadCastDetailsXml As String = ""

        Try
            objLogin = New Excelicare.Bizl.Login.clsBizlECSession
            strBroadCastDetailsXml = objLogin.GetSysBroadcastDetails()
            If strBroadCastDetailsXml <> "<DataSet />" Then
                Session("SysBroadcastDetails") = strBroadCastDetailsXml
            End If

            Return strBroadCastDetailsXml
        Catch ex As Exception
            LogException(ex)
            If CanShowScriptError() = "True" Then
                Throw ex
            End If
        Finally
            objLogin = Nothing
            strBroadCastDetailsXml = Nothing
        End Try
    End Function
    Public Shared Function GetClientuserIP(ByVal strIP As String) As String
        Dim ip As String = ""
        Try
            If HttpContext.Current.Request.ServerVariables("HTTP_X_FORWARDED_FOR") <> "" AndAlso Not HttpContext.Current.Request.ServerVariables("HTTP_X_FORWARDED_FOR") Is Nothing Then



                ip = HttpContext.Current.Request.ServerVariables("HTTP_X_FORWARDED_FOR")
            Else
                ip = "0.0.0.0"
            End If
            clsECSession.LogWebSessionAction("GetClientuserIP ", "", -1, 2039, "HTTP_X_FORWARDED_FOR:" & ip, 1030, 0)
            If ip.Contains(",") Then
                ip = ip.Split(","c).First().Trim()
            End If
            If strIP.Contains(",") AndAlso strIP.Contains(ip & ",") Then
                Return True
            ElseIf strIP.Contains(ip) Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Throw ex
        End Try

    End Function
    Private Function CanShowScriptError() As String
        Return AppSettings("ShowScriptErrors")

    End Function

    'Purpose         :To get UserDisclaimer status
    'Method Name     : GetDisclaimerStatus
    'InputParameter  : UserId
    'Output Parameter: status
    'Created By      : Narendra Chary --26/08/2019
    'Modified By     :


    <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
    Public Function fnGetUserDisclaimerStatus(ByVal strData As String) As DataSet
        Dim objBizEcsession As clsBizlECSession
        Dim UserId As Int32
        Dim jsonResult As Object
        Try
            objclsSecurity = New clsSecurity
            strData = objclsSecurity.DecryptData(strData)
            jsonResult = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(strData)
            UserId = jsonResult("iud").ToString
            objBizEcsession = New clsBizlECSession
            Return objBizEcsession.GetDisclaimerStatus(UserId)

        Catch ex As Exception
            Throw ex
        Finally
            jsonResult = Nothing
        End Try
    End Function


    'Purpose         :To check Valid username
    'Method Name     : validateUsername
    'InputParameter  : userName
    'Output Parameter: ValidUser and Failedcount
    'Created By      : Ashok
    'Modified By     :
    <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
    Public Function validateUsername(ByVal strData As String) As String
        Dim objBizEcsession As clsBizlECSession
        Dim objArray As ArrayList
        Dim username As String
        Dim Reason_Lu As Long
        Dim jsonResult As Object
        Try
            objBizEcsession = New clsBizlECSession
            objclsSecurity = New clsSecurity
            strData = objclsSecurity.DecryptData(strData)
            jsonResult = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(strData)
            username = jsonResult("usn").ToString
            Reason_Lu = jsonResult("rlu")
            objArray = objBizEcsession.validUserName(username, Reason_Lu)
            Dim strReturnValue As String = String.Empty
            If Not objArray Is Nothing Then
                For Each strResult As String In objArray
                    If strReturnValue = String.Empty Then
                        strReturnValue = strResult
                    Else
                        strReturnValue = strReturnValue & "," & strResult
                    End If

                Next
            End If
            Return strReturnValue
        Catch ex As Exception
            LogException(ex)
            Throw ex
        Finally
            jsonResult = Nothing
        End Try
    End Function

    Public Function RegisterToken(ByVal userName As String) As String
        Dim objToken As JObject
        Dim serviceURL As String
        Dim strURL As String
        Dim client As RestClient
        Dim request As RestRequest
        Dim response As RestResponse
        Try
            objToken = New JObject(New JProperty("Username", userName), New JProperty("Password", ""), New JProperty("resource", ""), New JProperty("Eckey", ConfigurationSettings.AppSettings("Apikey_healthcheck")))
            If System.Configuration.ConfigurationSettings.AppSettings("ExcelicareWebServiceURL") IsNot Nothing Then
                serviceURL = System.Configuration.ConfigurationSettings.AppSettings("ExcelicareWebServiceURL")
            End If
            strURL = serviceURL & "/api/register"
            client = New RestClient(strURL)
            request = New RestRequest(strURL, RestSharp.Method.Post)
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12
            request.AddHeader("content-type", "application/json")
            request.AddParameter("application/json", objToken.ToString(), ParameterType.RequestBody)
            response = client.Execute(request)
            Return response.Content
        Catch ex As Exception
            LogException(ex)
            Throw ex
        Finally
            objToken = Nothing
            serviceURL = Nothing
            strURL = Nothing
            client = Nothing
            request = Nothing
            response = Nothing
        End Try
    End Function

End Class
Public Enum enAuthenticateResult As Short
    Fail = 0                'Login fail
    Success = 1             'Login directly
    PassswordPrompt = 2     'New User
    PasswordExpired = 3     'Password Expired, ask user to change the password
    RemainderDays = 4       'Remind user about password expiry 
    SecurityQuestionsPrompt = 5 'Security Questions not enterd,user has to enter security qtns
    PasswordChange = 6         'Password Changed from Changepassword  
End Enum
