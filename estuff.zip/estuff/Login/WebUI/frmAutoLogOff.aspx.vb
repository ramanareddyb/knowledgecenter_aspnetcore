﻿'Imports AxExceliCareICEProxy
Imports Ajax
Imports Excelicare.ServiceProxy.AxWSSecurityService
Imports Excelicare.Bizl.Login
Imports System.Web.SessionState
Imports Excelicare.Framework.AppSupport
Imports Excelicare.ServiceProxy
Imports Newtonsoft.Json
Imports System.Collections.Generic

Partial Public Class frmAuthenticationLock
    Inherits System.Web.UI.Page
    Public strLockAuth As String
    Public strLockCtrlname As String
    Public strLockStatus As String
    Public lngUserId As Long = 0
    Public objClsSecurity As New clsSecurity
    Protected strAxDialogVirFolderName As String = ""
    Protected strVerNo As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim objAppSetttings As New clsAppSettings
        Try
            Response.Expires = -1
            Response.Cache.SetNoServerCaching()
            Response.Cache.SetAllowResponseInBrowserHistory(False)
            Response.CacheControl = "no-cache"
            Response.Cache.SetNoStore()
            Ajax.Utility.RegisterTypeForAjax(GetType(frmAuthenticationLock))
            GetSessionData()
            strAxDialogVirFolderName = objAppSetttings.GetVirtualFolderPath("1034")
            strVerNo = objAppSetttings.GetModuleVersion("1030")
            If Not (Session("UserLoginName") Is Nothing) Then
                txtUName.Value = Session("UserLoginName").ToString()
            Else
                txtUName.Value = ""
            End If
        Catch ex As Exception
            WriteException(ex)
            Throw
        End Try
    End Sub
    <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.Read)>
    Public Function CheckUserAuthentication(ByVal strData As String) As Boolean
        Dim objUserProxy As AxRSUserManagerClient
        Dim intUsrexists As Integer
        Dim blnUsrAuth As Boolean
        Dim strDomainName As String
        Dim dsTemp As DataSet
        Dim objSecurityProxy As AxRSSecurityService.AxRSSecurityClient
        Dim lngUsrID As Integer
        Dim strUName As String
        Dim strUPswd As String
        Dim strLockControl As String
        Dim strFormName As String
        Dim strLockStatus As String
        Dim lngDataID As Long
        Dim lngPatID As Long
        Dim jsonResult As Object
        Try
            GetSessionData()
            strData = objClsSecurity.DecryptData(strData)
            jsonResult = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(strData)
            lngUsrID = lngUserId
            strUName = jsonResult("sun").ToString
            strUPswd = jsonResult("sup").ToString
            strLockControl = jsonResult("slc").ToString
            strFormName = jsonResult("sfn").ToString
            strLockStatus = jsonResult("sls").ToString
            lngDataID = jsonResult("ldi")
            lngPatID = jsonResult("lpi")
            If Not IsNothing(Session("ADUser")) AndAlso Session("ADUser").ToString() = "True" Then
                objSecurityProxy = New AxRSSecurityService.AxRSSecurityClient
                strDomainName = Session("UserDomainName")
                dsTemp = objSecurityProxy.AuthenticateECUser(strUName, strUPswd, strDomainName)
                If dsTemp.Tables.Count > 0 AndAlso dsTemp.Tables(0).Rows.Count > 0 Then
                    blnUsrAuth = True
                End If
                ' objSecurityProxy.Close()
            Else

                objUserProxy = New AxRSUserManagerClient
                intUsrexists = objUserProxy.AuthenticateUser(lngUsrID, strUName, strUPswd)
                If intUsrexists > 0 Then
                    blnUsrAuth = True
                End If
                objUserProxy.Close()
            End If

            If blnUsrAuth = True Then
                clsECSession.LogWebSessionAction("Auto LogOff", clsNavigation.GetSession_ID(Page.Session), lngPatID, 2577, "Auto LogOff - ReLogin", 1030, lngDataID)
                CheckUserAuthentication = True
            Else
                If UCase(strLockControl) = "LOCK" Then
                    clsECSession.LogWebSessionAction("AutoLogOff", clsNavigation.GetSession_ID(Page.Session), lngPatID, 2577, "Auto LogOff - ReLogin", 1030, lngDataID)
                Else
                    clsECSession.LogWebSessionAction("AutoLogOff", clsNavigation.GetSession_ID(Page.Session), lngPatID, 2578, "Auto LogOff - Login Failed", 1030, lngDataID)
                End If
            End If


        Catch ex As Exception
            WriteException(ex)
            Throw ex
        Finally
            jsonResult = Nothing
            If Not IsNothing(objSecurityProxy) Then
                objSecurityProxy.Close()
            End If
            If Not IsNothing(objUserProxy) Then
                objUserProxy.Close()
            End If
            objUserProxy = Nothing
            objSecurityProxy = Nothing
        End Try
    End Function

    Public Function EncryptPassword(ByVal strUserPassWord As String) As String
        Dim objclsSecurity As clsSecurity
        Try
            objclsSecurity = New clsSecurity
            EncryptPassword = objclsSecurity.SHA256(strUserPassWord)
        Catch ex As Exception
            WriteException(ex)
        Finally
            objclsSecurity = Nothing
        End Try
    End Function

    Public Sub WriteException(ByVal ex As Exception)
        Dim objClsExceptionHandler As New clsExceptionHandler(ex)
        objClsExceptionHandler.LogException(Page)
        objClsExceptionHandler = Nothing
    End Sub

    <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.Read)>
    Public Function CancelUserAuthentication(ByVal strData As String) As Boolean
        Dim strLockControl As String
        Dim strFormName As String
        Dim lngDataID As Long
        Dim lngPatID As Long
        Dim strEvent As String
        Dim jsonResult As Object
        Try
            strData = objClsSecurity.DecryptData(strData)
            jsonResult = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(strData)
            strLockControl = jsonResult("slc").ToString
            strFormName = jsonResult("sfn").ToString
            lngDataID = jsonResult("ldi").ToString
            lngPatID = jsonResult("lpi").ToString
            strEvent = jsonResult("sev").ToString
            If UCase(strEvent) = "CLOSE" Then
                clsECSession.LogWebSessionAction("Auto LogOff", clsNavigation.GetSession_ID(Page.Session), lngPatID, 2034, "Close", 1030, lngDataID)
            Else
                clsECSession.LogWebSessionAction("Auto LogOff", clsNavigation.GetSession_ID(Page.Session), lngPatID, 2034, "Cancel", 1030, lngDataID)
            End If

        Catch ex As Exception
            WriteException(ex)
            Throw ex
        Finally
            jsonResult = Nothing
        End Try
    End Function

    Private Sub GetSessionData()
        Dim objClsSessionData As clsSessionData
        Dim objClsSessionManager As clsSessionManager
        Dim objClsAppSettings As clsAppSettings
        Try
            If frmDisclaimer.IsSessionExists() = False Then
                clsECSession.LogWebSessionAction("Login", "", 0, 2729, "Redirecting to login page as session not found.", 1030, 0)
                Response.Redirect("../AxWebUILogin/", False)
                Exit Sub
            End If
            objClsSessionManager = New clsSessionManager
            objClsAppSettings = New clsAppSettings
            objClsSessionData = objClsSessionManager.GetSessionData(Session.SessionID, "APPDATA")
            lngUserId = objClsSessionData.UserID
        Catch ex As Exception
            Throw ex
        Finally
            objClsSessionData = Nothing
            objClsSessionManager = Nothing
        End Try
    End Sub
    <Ajax.AjaxMethod(HttpSessionStateRequirement.ReadWrite)> _
    Public Function Logoff() As Boolean
        Dim objClsECSession As clsECSession
        Dim objClsSessionData As clsSessionData
        Dim objClsSessionManager As clsSessionManager
        Try
            objClsECSession = New clsECSession

            objClsSessionManager = New clsSessionManager
            Dim strTempDirectorypath As String = ConfigurationSettings.AppSettings("AxServerTempFolder") & Session.SessionID
            If IO.Directory.Exists(strTempDirectorypath) Then
                IO.Directory.Delete(strTempDirectorypath, True)
            End If
            objClsSessionData = objClsSessionManager.GetSessionData(Session.SessionID, "APPDATA")
            logECWebSessionAction(2038, objClsSessionData.PatientID, "Excelicare ACE MDI Log Out Clicked")

            objClsECSession.EndSession(Session.SessionID, objClsSessionData.UserID)
            Dim Manager As New SessionIDManager
            Dim NewID As String = Manager.CreateSessionID(Context)
            Dim OldID As String = Context.Session.SessionID
            Dim redirected As Boolean = False
            Dim IsAdded As Boolean = False
            Manager.SaveSessionID(Context, NewID, redirected, IsAdded)

            Return True
        Catch ex As Exception
            Return False
        Finally
            Session.Clear()
            Session.RemoveAll()
            Session.Abandon()
            objClsSessionManager = Nothing
            objClsSessionData = Nothing
            objClsECSession = Nothing
        End Try
    End Function

    <Ajax.AjaxMethod(HttpSessionStateRequirement.Read)> _
    Public Sub logECWebSessionAction(ByVal lngEventId As Long, ByVal lngPatId As Long, ByVal strEventDet As String)
        Try
            clsECSession.LogWebSessionAction("AutoLogOff", Session.SessionID, lngPatId, lngEventId, strEventDet, 1031, 0)
        Catch ex As Exception
        End Try
    End Sub

    <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.Read)> _
    Public Function CheckIsSessionExists() As Boolean
        Dim objClsSessionManager As clsSessionManager
        Try
            objClsSessionManager = New clsSessionManager
            If Not objClsSessionManager.IsSessionExists(Session.SessionID) Then
                Return False
            Else
                Return True
            End If

        Catch ex As Exception
            WriteException(ex)
            Throw
        End Try
    End Function
End Class