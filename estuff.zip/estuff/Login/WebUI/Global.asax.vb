Imports System.Web
Imports System.Web.SessionState
Imports Excelicare.Framework.AppSupport

Namespace AxSys.UI.Web.Login

    '****************************************************************************************************
    'Class/Interface Name : Global
    'PURPOSE    : Consists of application,session level events 
    '
    'MODIFICATION LOG  :
    '
    'AUTHOR                      Ver#       Date        Reason/Changes
    '----------------------------------------------------------------------------------------------------
    'Nagodaya Bhaskar KR.      1.0.000    25/02/2004    First version.
    '****************************************************************************************************
    Public Class [Global]
        Inherits System.Web.HttpApplication

        'Class member variables
        Private objschedulerThread As System.Threading.Thread = Nothing

#Region " Component Designer Generated Code "

        Public Sub New()
            MyBase.New()

            'This call is required by the Component Designer.
            InitializeComponent()

            'Add any initialization after the InitializeComponent() call

        End Sub

        'Required by the Component Designer
        Private components As System.ComponentModel.IContainer

        'NOTE: The following procedure is required by the Component Designer
        'It can be modified using the Component Designer.
        'Do not modify it using the code editor.
        <System.Diagnostics.DebuggerStepThrough()> _
        Private Sub InitializeComponent()
            components = New System.ComponentModel.Container
        End Sub

#End Region

        Sub Application_Start(ByVal sender As Object, ByVal e As EventArgs)

        End Sub

        Sub Session_Start(ByVal sender As Object, ByVal e As EventArgs)
            'Session("LoginAttempts") = 1
        End Sub

        Sub Application_BeginRequest(ByVal sender As Object, ByVal e As EventArgs)
            ' Fires at the beginning of each request
        End Sub

        Sub Application_AuthenticateRequest(ByVal sender As Object, ByVal e As EventArgs)
            ' Fires upon attempting to authenticate the use
        End Sub

        Sub Application_Error(ByVal sender As Object, ByVal e As EventArgs)
            ' Fires when an error occurs

            Dim objAxException As New clsExceptionHandler(Server.GetLastError, Session, Request)
            objAxException.LogException()
            Response.Redirect("../../frmCustomMessage.aspx")

            'Insert optional email notification here...
        End Sub
        ' -----------------------------------------------------------------------------
        ' <summary>
        '   Session End Event
        ' </summary>
        ' <param name="sender"></param>
        ' <param name="e"></param>
        ' <remarks>
        ' </remarks>
        ' <history>
        ' 	[kumar]	07/12/2005	Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Sub Session_End(ByVal sender As Object, ByVal e As EventArgs)
            Dim objECSession As clsECSession
            Try
                objECSession = New clsECSession
                objECSession.EndSession(Session.SessionID)
            Catch ex As Exception
                Dim objExceptionHandler As New clsExceptionHandler(ex)
                objExceptionHandler.LogException()
            End Try
        End Sub

        Sub Application_End(ByVal sender As Object, ByVal e As EventArgs)

        End Sub
    End Class
End Namespace