Imports Ajax
Imports Excelicare.Framework.AppSupport
Imports System.Net
Imports System.Text
Imports System.IO
Imports System.Configuration

Namespace AxSys.UI.Web.Login
    Partial Class _default
        Inherits System.Web.UI.Page
        Public blnEnableSSOlogin As Boolean = False
        Public strVersionNumber As String = ""

#Region " Web Form Designer Generated Code "

        ' ''This call is required by the Web Form Designer.
        ''<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        ''End Sub
        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        ''Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        ''    'CODEGEN: This method call is required by the Web Form Designer
        ''    'Do not modify it using the code editor.
        ''    InitializeComponent()
        ''End Sub

#End Region

        ' -----------------------------------------------------------------------------
        ' <summary>
        '     The strURL is used to store the URL address
        ' </summary>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Nagodaya Bhaskar KR]   25/02/2004   Created
        ' 	    [Ram R]	                15/06/2005	 Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------



        ' -----------------------------------------------------------------------------
        ' <summary>
        '     The page load contains the methods to call the frmLogin.aspx
        ' </summary>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Nagodaya Bhaskar KR]   25/02/2004   Created
        ' 	    [Ram R]	                15/06/2005	 Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Dim objClsAppSettings As New clsAppSettings
            Try
				Response.Expires = -1
                Response.Cache.SetNoServerCaching()
                Response.Cache.SetAllowResponseInBrowserHistory(False)
                Response.CacheControl = "no-cache"
                Response.Cache.SetNoStore()
                Ajax.Utility.RegisterTypeForAjax(GetType(_default))
                blnEnableSSOlogin = clsSysDefault.GetSysDefaultValue(2396)
                strVersionNumber = objClsAppSettings.GetModuleVersion("1030")
            Catch ex As Exception
                LogException(ex)
            Finally
                objClsAppSettings = Nothing
            End Try
        End Sub
        Private Sub LogException(ByVal objExcep As Exception)
            Dim objClsExceptionHandler As clsExceptionHandler
            Try
                objClsExceptionHandler = New clsExceptionHandler(objExcep)
                If Not IsNothing(Page) Then
                    objClsExceptionHandler.LogException(Page)
                Else
                    objClsExceptionHandler.LogException()
                End If
            Catch ex As Exception
            Finally
                objClsExceptionHandler = Nothing
            End Try
        End Sub

        Dim intCount As Integer = 0
        ''' <summary>
        '''fnMakeAPIRequest function makes API request to get the desired response of smartcard details
        ''' </summary>
        ''' <param name="strNHSAPIURL"></param>
        ''' <returns>it returns HttpWebResponse object</returns>
        Public Function fnMakeAPIRequest(strNHSAPIURL As String) As HttpWebResponse
            Dim BypassCRL As Boolean = False
            Dim objWebreq As HttpWebRequest
            Dim resp As HttpWebResponse = Nothing
            Dim response As WebResponse
            Try
                logECWebSessionAction(2039, -1, "NHS API URL Calling Request Start -" + strNHSAPIURL)
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12
                objWebreq = HttpWebRequest.Create(strNHSAPIURL)
                objWebreq.KeepAlive = False
                objWebreq.Accept = "*/*"
                objWebreq.Method = "GET"
                objWebreq.Connection = Nothing
                objWebreq.Proxy = Nothing
                objWebreq.ContentType = "application/x-www-form-urlencoded"
                objWebreq.ServicePoint.ConnectionLimit = 20
                '' SSL Certifictate Revocation List Check ByPass Condition
                If Not ConfigurationManager.AppSettings("BypassCRL") Is Nothing Then BypassCRL = ConfigurationManager.AppSettings("BypassCRL")
                If BypassCRL = True Then
                    ServicePointManager.CheckCertificateRevocationList = False
                    objWebreq.ServerCertificateValidationCallback = AddressOf SSLFunction
                End If
                logECWebSessionAction(2039, -1, "NHS API Calling URL END -" + strNHSAPIURL)
                Try
                    response = objWebreq.GetResponse()
                    Return response
                Catch ex As WebException
                    Dim ReceiveStream As Stream
                    Using errorResponse = ex.Response
                        If errorResponse IsNot Nothing Then
                            ReceiveStream = errorResponse.GetResponseStream()
                            Using errorReader As New StreamReader(ReceiveStream)
                                logECWebSessionAction(2093, -1, errorReader.ToString())
                            End Using
                        End If
                    End Using
                End Try
            Catch ex As TimeoutException
                If intCount >= 3 Then Return resp           '' Re-connecting to NHS Api will execute/call 3 times
                logECWebSessionAction(2039, -1, "TimeoutException occured while making NHS API Request.So,Re-Connecting again -" + strNHSAPIURL)
                intCount = intCount + 1
                Return fnMakeAPIRequest(strNHSAPIURL)
            Catch ex As WebException
                If (ex.Status = WebExceptionStatus.Timeout) Then
                    If intCount >= 3 Then Return resp           '' Re-connecting to NHS Api will execute/call 3 times
                    logECWebSessionAction(2039, -1, "WebExceptionStatus is Timeout while making NHS API Request.So,Re-Connecting again -" + strNHSAPIURL)
                    intCount = intCount + 1
                    Return fnMakeAPIRequest(strNHSAPIURL)
                Else
                    If intCount >= 3 Then Return resp           '' Re-connecting to NHS Api will execute/call 3 times
                    logECWebSessionAction(2039, -1, "WebException occured while making NHS API Request.So,Re-Connecting again -" + strNHSAPIURL)
                    intCount = intCount + 1
                    Return fnMakeAPIRequest(strNHSAPIURL)
                End If
            Catch ex As Exception
                logECWebSessionAction(2039, -1, "General Exception occured while making NHS API Request:" + strNHSAPIURL)
                LogException(ex)
                Return resp
            Finally
                objWebreq = Nothing
            End Try
        End Function
        ''' <summary>
        ''' fnGetSmartCardUserDetails, it is a Ajax function which will accept tokenId as input param and process the NHS Api url along with token id and get the user details
        ''' </summary>
        ''' <param name="strTokenID"></param>
        ''' <returns> returns user details</returns>
        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Function fnGetSmartCardUserDetails(ByVal strTokenID As String) As String


            Dim resp As HttpWebResponse
            Dim data As Stream
            Dim reader As StreamReader
            Dim responseFromServer As String = String.Empty
            Dim strNHSApiUrl As String = String.Empty
            Dim objRetXmlDOm As New System.Xml.XmlDocument
            Dim UserId As String = String.Empty
            Dim roleId As String = String.Empty
            Dim strLocID As String = String.Empty



            Dim xmlString As String = String.Empty
            Dim intLoop As Integer = 0
            Try
                intCount = 0
                logECWebSessionAction(2039, -1, "SSO Excelicare URL WebServer.-" & UCase(HttpContext.Current.Request.ServerVariables.Item("SERVER_NAME")))
                logECWebSessionAction(2039, -1, "GetSmartCardUserDetails Calling- Begin")
                If Not String.IsNullOrWhiteSpace(strTokenID) AndAlso Not strTokenID.ToUpper = "undefined".ToUpper Then
                    strTokenID = HttpUtility.UrlDecode(strTokenID)
                    If Not ConfigurationManager.AppSettings("NHSAPIURL") Is Nothing Then
                        strNHSApiUrl = ConfigurationManager.AppSettings("NHSAPIURL") + HttpUtility.UrlEncode(strTokenID)
                    Else
                        strNHSApiUrl = "https://sbapi.national.ncrs.nhs.uk/saml/RoleAssertion?token=" + HttpUtility.UrlEncode(strTokenID)
                    End If
                    logECWebSessionAction(2039, -1, "NHS Api Url construction with TokenId:" & strNHSApiUrl)
                    '' NHS API URL Calling
                    resp = fnMakeAPIRequest(strNHSApiUrl)
                    Try
                        If Not resp Is Nothing Then
                            data = resp.GetResponseStream()
                            reader = New StreamReader(data)
                            responseFromServer = reader.ReadToEnd()
                        Else
                            Return "Failed"
                        End If
                    Catch ex As Exception
                        logECWebSessionAction(2401, -1, "Getting the exception while getting stream object from the response of NHS API URL request object." + ex.Message())
                        logECWebSessionAction(2401, -1, "Re-connecting again NHS API because of not getting proper response.")
                        resp = fnMakeAPIRequest(strNHSApiUrl)
                        data = Nothing
                        reader = Nothing
                        responseFromServer = Nothing
                        If Not resp Is Nothing Then
                            data = resp.GetResponseStream()
                            reader = New StreamReader(data)
                            responseFromServer = reader.ReadToEnd()
                        Else
                            Return "Failed"
                        End If
                        LogException(ex)
                    Finally
                        If Not resp Is Nothing Then resp.Close()
                    End Try
                    Try
                        logECWebSessionAction(2039, -1, "SAML string fetching from the response-Begin")
                        xmlString = responseFromServer.Replace("<saml:", "<").Replace("</saml:", "</").Replace("<samlp:", "<").Replace("</samlp:", "</")
                        logECWebSessionAction(2039, -1, "SAML string fetching from the response-End")
                        objRetXmlDOm.LoadXml(xmlString)
                    Catch ex As Exception
                        logECWebSessionAction(2039, -1, "Getting exception while loading SAML into xml object." + ex.Message)







                        LogException(ex)
                    End Try
                    WriteToTrace("SSO Login", "SSO Login - Getting the Smartcard SAML", objRetXmlDOm.InnerXml)     '' Placing SAML xml into AxTrace file
                    UserId = objRetXmlDOm.SelectSingleNode("Response/Assertion/AttributeStatement/Attribute[@AttributeName='uid']").InnerText





                    logECWebSessionAction(2039, -1, "Smartcard User ID:" + UserId)
                    roleId = objRetXmlDOm.SelectSingleNode("Response/Assertion/AttributeStatement/Attribute[@AttributeName='ssbSessionRoleUid']").InnerText
                    logECWebSessionAction(2039, -1, "Smartcard User RoleID:" + roleId)
                    For intLoop = 0 To objRetXmlDOm.SelectNodes("Response/Assertion/AttributeStatement/Attribute[@AttributeName='nhsIdCode']").Count - 1
                        If objRetXmlDOm.SelectNodes("Response/Assertion/AttributeStatement/Attribute[@AttributeName='uniqueIdentifier']")(intLoop).InnerText = roleId Then
                            strLocID = objRetXmlDOm.SelectNodes("Response/Assertion/AttributeStatement/Attribute[@AttributeName='nhsIdCode']")(intLoop).InnerText
                            Exit For
                        End If
                    Next
                    logECWebSessionAction(2039, -1, "Smartcard User Location ID:" + strLocID)



                    Return UserId + Chr(181) + strLocID
                Else
                    logECWebSessionAction(2039, -1, "Invalid Smartcard Token ID:" + strTokenID)
                    Return "Failed"
                End If
























            Catch ex As Exception
                LogException(ex)
                Return "Failed"


            Finally
                objRetXmlDOm = Nothing
                data = Nothing
                reader = Nothing
                responseFromServer = Nothing
                logECWebSessionAction(2039, -1, "GetSmartCardUserDetails Calling-End")
            End Try
        End Function

        <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
        Public Sub logECWebSessionAction(ByVal lngEventId As Long, ByVal lngPatId As Long, ByVal strEventDet As String)
            Try
                clsECSession.LogWebSessionAction("Login ", Session.SessionID, lngPatId, lngEventId, strEventDet, 1030, 0)
            Catch ex As Exception
                LogException(ex)
            End Try
        End Sub

        Public Function SSLFunction(ByVal obj As Object, ByVal certificate As System.Security.Cryptography.X509Certificates.X509Certificate, ByVal chain As System.Security.Cryptography.X509Certificates.X509Chain, ByVal errors As System.Net.Security.SslPolicyErrors) As Boolean
            Try
                Return True
            Catch ex As Exception
                Throw ex
            End Try
        End Function


        Public Function WriteToTrace(ByVal strProcName As String, ByVal strPageName As String, ByVal strMessage As String)
            Dim strTraceFile As String
            Dim strCanWrite As String
            Dim objTraceFile As System.IO.StreamWriter
            Dim strMessageFooter As String
            Try
                strCanWrite = System.Configuration.ConfigurationSettings.AppSettings.Get("IsTraceWriteToFile")

                If Not strMessage Is Nothing Then
                    If strCanWrite.ToUpper = "TRUE" And strMessage <> "" Then
                        strTraceFile = HttpContext.Current.Request.PhysicalApplicationPath & System.Configuration.ConfigurationSettings.AppSettings.Get("TraceFileName")
                        objTraceFile = New System.IO.StreamWriter(strTraceFile, True)

                        strMessageFooter = vbCrLf
                        objTraceFile.Write("Form Name:" & strPageName & " | Method Name: " & strProcName & " | " & strMessage)
                        objTraceFile.Write(strMessageFooter)
                    End If
                End If
            Catch ex As Exception
            Finally
                If Not objTraceFile Is Nothing Then
                    objTraceFile.Flush()
                    objTraceFile.Close()
                End If
                strTraceFile = Nothing
                strCanWrite = Nothing
                strMessageFooter = Nothing
            End Try
        End Function
    End Class
End Namespace
