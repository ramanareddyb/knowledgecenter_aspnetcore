﻿Imports Ajax
Imports System.Configuration.ConfigurationManager
Imports Excelicare.ServiceProxy
Imports Excelicare.Bizl.Login
Imports System.Net
Imports System.Text
Imports System.IO
Imports System.Web.Script.Serialization
Imports Excelicare.Framework.AppSupport
Imports Newtonsoft.Json



Public Class frmMFA
    Inherits System.Web.UI.Page
    Public m_strLoginDefaults As String = ""
    Public ServiceURL As String = ""
    Public lngUser_ID As Long
    Protected strModuleVersionNo As String = ""
    Protected maxattempts As Long = 0
    Public objclsSecurity As clsSecurity
	
    '**************************************************************************************
    'Version        Author                          Date              Remarks      
    '               RK                         		16/11/2021        ignore scan
    '**************************************************************************************
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim arrResult As Hashtable
        Dim arrDefaultIds() As Int64 = {2081}
        Dim objClsAppSettings As clsAppSettings = New clsAppSettings
        Try
			Response.Expires = -1
            Response.Cache.SetNoServerCaching()
            Response.Cache.SetAllowResponseInBrowserHistory(False)
            Response.CacheControl = "no-cache"
            Response.Cache.SetNoStore()
            Ajax.Utility.RegisterTypeForAjax(GetType(frmMFA))
            arrResult = clsSysDefault.GetSysDefaultValues(arrDefaultIds)
            m_strLoginDefaults = Server.UrlEncode(arrResult(2081).value.ToString)
            m_strLoginDefaults = m_strLoginDefaults.Replace("+", " ")
            ServiceURL = System.Configuration.ConfigurationManager.AppSettings("ExcelicareWebServiceURL")
            lngUser_ID = Session("TempUserID")
            strModuleVersionNo = objClsAppSettings.GetModuleVersion("1030")
			maxattempts = clsSysDefault.GetSysDefaultValue(1215)													
        Catch ex As Exception
            LogException(ex)
        End Try

    End Sub
    '*********************************************************************************************
    'Purpose        :   To ValidateTOTP
    'Layer	        :   UI
    'Name		    :	ValidateTOTP
    'Parameters     :   
    'Return Values  :   
    '-------------------------------------------------------------------------------------
    'Version        Author :           Date:              Remarks      
    '---------------------------------------------------------------------------------------
    '7.1           Seshu kumar           26/11/2019           Initial development          
    '*********************************************************************************************
    <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
    Public Function ValidateTOTP(ByVal OTP As String) As String
        Dim strURL As String = String.Empty
        Dim resp As String = Nothing
        ServiceURL = System.Configuration.ConfigurationManager.AppSettings("ExcelicareWebServiceURL")
        Dim strPTOP As String
        Dim data As Byte()
        Dim strsecretKey As String
		Dim JSonMFAResult As Object						   

        Try
            logECWebSessionAction(2039, -1, "ValidateTOTP start")
            data = System.Convert.FromBase64String(OTP)
            strPTOP = System.Text.ASCIIEncoding.ASCII.GetString(data)
            If Session("QRCode") <> "" Then
                strsecretKey = Session("QRCode")
                If HttpContext.Current.Request.Url.Scheme = "https" AndAlso Not ServiceURL.Contains("https") Then
                    ServiceURL = ServiceURL.Replace("http", "https")
                End If
                strURL = ServiceURL & "AxRSMFA.svc/ValidateOTP?OTP=" & strPTOP & "&secretKey=" & strsecretKey & ""
                resp = fnHttpGetRequest(strURL)
                logECWebSessionAction(2039, -1, "ValidateTOTP END")
                JSonMFAResult = JsonConvert.DeserializeObject(Of Object)(resp)
                If (JSonMFAResult("data").ToString() = "3") Then
                    RecordUserFailedLogin()
                    resp = GetFailedOTPCount(Session("UserLoginName"), 16303)
                End If
            End If
            Return resp
        Catch ex As Exception
            LogException(ex)
        End Try
    End Function
    '*********************************************************************************************
    'Purpose        :   To Save QRCode 
    'Layer	        :   UI
    'Name		    :	SaveQRCode
    'Parameters     :   
    'Return Values  :   
    '-------------------------------------------------------------------------------------
    'Version        Author :           Date:              Remarks      
    '---------------------------------------------------------------------------------------
    '7.1           Seshu kumar           26/11/2019           Initial development          
    '*********************************************************************************************
    <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
    Public Function SaveQRCode(ByVal strData As String, ByVal strUserData As String) As String
        Dim objBizlECSession As clsBizlECSession
        Dim StrMFASaveSetting As String = ""
        Dim JSonMFAResult As Object
        Dim data As Byte()
        Dim QRCode As String = ""
        Dim strSaveQRCode As String
        Dim lngUserId As Long
        Dim setting As String
        Dim jsonResult As Object
        Try
            objBizlECSession = New clsBizlECSession
            objclsSecurity = New clsSecurity
            setting = objclsSecurity.DecryptData(strUserData)
            strData = objclsSecurity.DecryptData(strData)
            jsonResult = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(strData)
            lngUserId = jsonResult("iun")
            logECWebSessionAction(2039, -1, "Save QRCode Start")
            If Not setting Is Nothing Then
                JSonMFAResult = JsonConvert.DeserializeObject(Of Object)(setting)
                If JSonMFAResult("QRCode") <> "" Then
                    data = System.Convert.FromBase64String(JSonMFAResult("QRCode").ToString())
                    QRCode = System.Text.ASCIIEncoding.ASCII.GetString(data)
                End If
            End If
            strSaveQRCode = objBizlECSession.SaveQRcode(lngUserId, setting, QRCode)
            logECWebSessionAction(2039, -1, "Save QRCode END")
            Return strSaveQRCode
        Catch ex As Exception
            LogException(ex)
            Throw ex
        Finally
            jsonResult = Nothing
        End Try

    End Function
    '*********************************************************************************************
    'Purpose        :   To Get HttpGetRequest
    'Layer	        :   UI
    'Name		    :	fnHttpGetRequest
    'Parameters     :   
    'Return Values  :   
    '-------------------------------------------------------------------------------------
    'Version        Author :           Date:              Remarks      
    '---------------------------------------------------------------------------------------
    '7.1           Seshu kumar           26/11/2019           Initial development          
    '*********************************************************************************************
    Private Function fnHttpGetRequest(URL As String) As String
        Dim objWebreq As HttpWebRequest
        Dim response As WebResponse
        Dim res As String = ""
        Try
            logECWebSessionAction(2039, -1, "fnHttpGetRequest start URL:" & URL)
            objWebreq = HttpWebRequest.Create(URL)
            objWebreq.KeepAlive = False
            objWebreq.Accept = "*/*"
            objWebreq.Method = "GET"
            objWebreq.Connection = Nothing
            objWebreq.Proxy = Nothing
            objWebreq.ContentType = "application/x-www-form-urlencoded"
            response = objWebreq.GetResponse()
            Using webStream As Stream = response.GetResponseStream()

                If webStream IsNot Nothing Then

                    Using responseReader As StreamReader = New StreamReader(webStream)
                        res = responseReader.ReadToEnd()

                    End Using
                End If
            End Using
            logECWebSessionAction(2039, -1, "fnHttpGetRequest END")
            Return res
        Catch ex As Exception
            LogException(ex)
        End Try
    End Function
    '*********************************************************************************************
    'Purpose        :   To RecordUserFailedLogin
    'Layer	        :   UI
    'Name		    :	RecordUserFailedLogin
    'Parameters     :   
    'Return Values  :   
    '-------------------------------------------------------------------------------------
    'Version        Author :           Date:              Remarks      
    '---------------------------------------------------------------------------------------
    '7.1           Seshu kumar           26/11/2019           Initial development          
    '*********************************************************************************************
    Private Sub RecordUserFailedLogin()
        Dim MachineName As String
        Dim MachineIP As String
        Dim UserName As String
        Dim strURL As String
        Dim resp As String
        Try
            logECWebSessionAction(2039, -1, "RecordUserFailedLogin Start")
            MachineName = HttpContext.Current.Request.UserHostName
            MachineIP = HttpContext.Current.Request.UserHostAddress
            UserName = Session("UserLoginName")
            If HttpContext.Current.Request.Url.Scheme = "https" AndAlso Not ServiceURL.Contains("https") Then
                ServiceURL = ServiceURL.Replace("http", "https")
            End If
            strURL = ServiceURL & "/AxRSUserDetails.svc/RecordUserFailedLogin?UserHostName=" & MachineName & "&HostIPAddress=" & MachineIP & "&LoginName=" & UserName & "&Password=" & "" & "&Reason=" & 16303
            resp = fnHttpGetRequest(strURL)
            logECWebSessionAction(2039, -1, "RecordUserFailedLogin END")
        Catch ex As Exception
            LogException(ex)
        End Try
    End Sub
    '*********************************************************************************************
    'Purpose        :   To GetFailedOTPCount
    'Layer	        :   UI
    'Name		    :	GetFailedOTPCount
    'Parameters     :   
    'Return Values  :   
    '-------------------------------------------------------------------------------------
    'Version        Author :           Date:              Remarks      
    '---------------------------------------------------------------------------------------
    '7.1           Seshu kumar           26/11/2019           Initial development          
    '*******************************************************************************************

    Private Function GetFailedOTPCount(ByVal username As String, ByVal Reason_LU As Long) As String
        Dim objBizEcsession As clsBizlECSession
        Dim objArray As ArrayList
        Try
            logECWebSessionAction(2039, -1, "GetFailedOTPCount Start")
            objBizEcsession = New clsBizlECSession
            objArray = objBizEcsession.validUserName(username, Reason_LU)
            Dim strReturnValue As String = String.Empty
            If Not objArray Is Nothing Then
                For Each strResult As String In objArray
                    If strReturnValue = String.Empty Then
                        strReturnValue = strResult
                    Else
                        strReturnValue = strReturnValue & "," & strResult
                    End If

                Next
            End If
            logECWebSessionAction(2039, -1, "GetFailedOTPCount End")
            Return strReturnValue
        Catch ex As Exception
            LogException(ex)
        End Try
    End Function
    '*********************************************************************************************
    'Purpose        :  LogException
    'Layer	        :   UI
    'Name		    :	LogException
    'Parameters     :   
    'Return Values  :   
    '-------------------------------------------------------------------------------------
    'Version        Author :           Date:              Remarks      
    '---------------------------------------------------------------------------------------
    '7.1           Seshu kumar           26/11/2019           Initial development          
    '*********************************************************************************************
    Private Sub LogException(ByVal objExcep As Exception)
        Dim objClsExceptionHandler As clsExceptionHandler
        Try
            objClsExceptionHandler = New clsExceptionHandler(objExcep)
            If Not IsNothing(Page) Then
                objClsExceptionHandler.LogException(Page)
            Else
                objClsExceptionHandler.LogException()
            End If
        Catch ex As Exception
        Finally
            objClsExceptionHandler = Nothing
        End Try
    End Sub
    '*********************************************************************************************
    'Purpose        :  To Log EcSession Action
    'Layer	        :   UI
    'Name		    :	LogEcWebSession Action
    'Parameters     :   
    'Return Values  :   
    '-------------------------------------------------------------------------------------
    'Version        Author :           Date:              Remarks      
    '---------------------------------------------------------------------------------------
    '7.1           Seshu kumar           26/11/2019           Initial development          
    '*********************************************************************************************
    <Ajax.AjaxMethod(Ajax.HttpSessionStateRequirement.ReadWrite)>
    Public Sub logECWebSessionAction(ByVal lngEventId As Long, ByVal lngPatId As Long, ByVal strEventDet As String)
        Try
            clsECSession.LogWebSessionAction("MFA ", Session.SessionID, lngPatId, lngEventId, strEventDet, 1030, 0)
        Catch ex As Exception
            LogException(ex)
        End Try
    End Sub
End Class