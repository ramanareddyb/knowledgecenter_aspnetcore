Option Explicit On 

Imports Excelicare.Framework.AppDataSupport  ' To access sql helper functions
'Imports AxSys.AppSupport

' -----------------------------------------------------------------------------
' <summary>
'      To access sql helper functions
' </summary>
' <remarks>
' </remarks>
' <history>
' 	    [Ram R]	 15/06/2005	 Added Comments
' </history>
' -----------------------------------------------------------------------------

'Imports AxSys.AppSupport    ' To access exception handling functions
' -----------------------------------------------------------------------------
' <summary>
'      To access exception handling functions
' </summary>
' <remarks>
' </remarks>
' <history>
' 	    [Ram R]	  15/06/2005	 Added Comments
' </history>
' -----------------------------------------------------------------------------

Imports System.Text

Namespace Excelicare.Dal.Login
    '****************************************************************************************************
    'Class Name : clsDalECSessionDan
    'PURPOSE    : Exposes ECSession Dan functionality to BIZL
    '
    'MODIFICATION LOG  :
    '
    'AUTHOR                      Ver#       Date        Reason/Changes
    '----------------------------------------------------------------------------------------------------
    'Nagodaya Bhaskar KR.      1.0.000    05/04/2004    First version.
    '****************************************************************************************************
    ' -----------------------------------------------------------------------------
    ' <summary>
    '      Exposes ECSession Dan functionality to BIZ Layer
    ' </summary>
    ' <remarks>
    '      First version.
    ' </remarks>
    ' <history>
    '       [Nagodaya Bhaskar KR]   05/04/2004   Created
    ' 	    [Ram R]	                15/06/2005	 Added Comments
    ' </history>
    ' -----------------------------------------------------------------------------
    Public Class clsDalEcSessionDan
        '************************************************************************************************
        'Sub/Function/Property Name : IsUserSessionExists
        'Parameters   : LoginId
        'Return Values: True or False
        'Purpose      : This is a function to check whether the login user has a session exists or not
        '
        'Other relevant sources: None
        '     
        'Author            : Nagodaya Bhaskar KR
        'Created Date      : 05/04/2004    
        'Last Modified Date: 00/00/0000
        'Modification Log  :
        'Author                 Date           Reason
        '------------------------------------------------------------------------------------------------
        '************************************************************************************************

        ' -----------------------------------------------------------------------------
        ' <summary>
        '      This is a function to check whether the login user has a session exists or not
        ' </summary>
        ' <param name="LoginName"> To get the  UserId when LoginName is specified</param>
        ' <returns> String </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Nagodaya Bhaskar KR]   05/04/2004   Created
        ' 	    [Ram R]	                15/06/2005	 Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Function IsUserSessionExists(ByVal LoginName As String) As String
            Dim objClsDataAccess As clsDataAccess
            Dim objSbQuery As StringBuilder
            Try
                objSbQuery = New StringBuilder
                objSbQuery.Append("Select ID from tblEcSession where LoginName = ")
                objSbQuery.Append("'" & LoginName & "'")
                objSbQuery.Append(" and SystemLogout = 0")

                objClsDataAccess = New clsDataAccess
                Return Convert.ToString(objClsDataAccess.ExecuteScalar(objSbQuery.ToString(), CommandType.Text))
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                objSbQuery = Nothing
            End Try
        End Function

        Public Shared Function GetDomainNames() As DataSet
            Dim objClsDataAccess As clsDataAccess
            Try
                objClsDataAccess = New clsDataAccess
                Return objClsDataAccess.ExecuteDataSet("SELECT ID, LookupValue FROM tblLookUp WHERE LookupCategory_SLU = 3107 AND IsActive = 1    ", CommandType.Text)
            Catch ex As Exception
                Throw ex
            End Try
        End Function

        Public Function fnGetSSOUserDetails(ByVal UID As String, Optional RoleId As String = "") As String
            Dim objClsDataAccess As clsDataAccess
            Dim strUserName As String
            Dim arrParamStruct(1) As ParamStruct
            Try
                objClsDataAccess = New clsDataAccess

                arrParamStruct(0).ParamName = "@UID"
                arrParamStruct(0).direction = ParameterDirection.Input
                arrParamStruct(0).DataType = DbType.String
                arrParamStruct(0).value = UID
                arrParamStruct(0).size = 500

                arrParamStruct(1).ParamName = "@RoleID"
                arrParamStruct(1).direction = ParameterDirection.Input
                arrParamStruct(1).DataType = DbType.String
                arrParamStruct(1).value = RoleId
                arrParamStruct(1).size = 500

                strUserName = objClsDataAccess.ExecuteScalar("AxSP_GetSSOUserDetails", CommandType.StoredProcedure, arrParamStruct)
                Return strUserName
            Catch ex As Exception
                Throw ex
            End Try
        End Function

        'This method is not using anywhere.
        '*********************************************************************************************
        'Sub/Function/Property Name : GetConcurrentUserCount
        'Parameters   : None
        'Return Values: Concurrent user count at a particular time
        'Purpose      : This is a function to get concurrent user count connected to EC System
        '
        'Other relevant sources:
        '     
        'Author            : Nagodaya Bhaskar KR
        'Created Date      : 27/02/2004    
        'Last Modified Date: 00/00/0000
        'Modification Log  :
        'Author                 Date           Reason
        '---------------------------------------------------------------------------------------------
        'Nagodaya Bhaskar KR    26/03/2004     Added exception handling
        '*********************************************************************************************

        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This is a function to Get Concurrent User Count connected to EC System
        ' </summary>
        ' <returns> Int16 </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Nagodaya Bhaskar KR]   27/02/2004   Created
        '       [Nagodaya Bhaskar KR]   26/03/2004   Modified Date. Reason: Added exception handling
        ' 	    [Ram R]	                15/06/2005	 Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------

        Public Shared Function GetConcurrentUserCount() As Int16
            Dim objClsDataAccess As clsDataAccess
            Dim strQuery As String = ""
            Try
                objClsDataAccess = New clsDataAccess
                strQuery = "Select [Count] as 'Count' from tblConcurrentUserCount"
                Return Convert.ToInt16(objClsDataAccess.ExecuteScalar(strQuery, CommandType.Text))

            Catch ex As Exception
                Throw
            Finally
                strQuery = Nothing
                objClsDataAccess = Nothing
            End Try

        End Function 'GetConcurrentUserCount



        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This procedure is used to get the active session ID of the active account of the supplied user ID
        ' </summary>
        ' <param name="intUsrID"> Retrieves the Session_ID value for the logged in user</param>
        ' <returns>String </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]   01/08/2005   Created
        ' 	    [Suneetha B]   01/08/2005   Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function GetActiveSessionIDoftheUser(ByVal intUsr_ID As Int32) As String
            Dim objClsDataAccess As clsDataAccess
            Dim strQuery As String
            Try
                objClsDataAccess = New clsDataAccess
                strQuery = "select isnull(ID,'') from tblECSession  where SystemLogout = 0 and  USR_ID = " & intUsr_ID
                GetActiveSessionIDoftheUser = objClsDataAccess.ExecuteScalar(strQuery, CommandType.Text)
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strQuery = Nothing
            End Try
        End Function 'EndSession

        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This procedure is used to know the user session has expired or not
        ' </summary>
        ' <param name="strSessionID">  Session_ID of the logged in user</param>
        ' <returns>Boolean </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Suneetha B]   12/08/2005   Created
        ' 	    [Suneetha B]   12/08/2005   Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------

        Public Function IsUserSessionExpired(ByVal strSessionID As String) As Boolean
            Dim objClsDataAccess As clsDataAccess
            Dim strQuery As String
            Try
                objClsDataAccess = New clsDataAccess
                strQuery = "select count(ID) from tblECSession  where SystemLogout = 1 and  ID = '" & strSessionID & "'"
                If objClsDataAccess.ExecuteScalar(strQuery, CommandType.Text) > 0 Then
                    IsUserSessionExpired = True
                Else
                    IsUserSessionExpired = False
                End If
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strQuery = Nothing
            End Try
        End Function 'EndSession



        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This procedure is used to get the active session ID of the active account of the supplied user ID
        ' </summary>
        ' <param name="intUsrID"> Retrieves the Session_IDs value for the logged in user</param>
        ' <returns>Dataset </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [K Bhavani]   18/11/2005   Created
        ' 	    [K Bhavani]   18/11/2005   Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function GetActiveSessionIDsoftheUser(ByVal intUsr_ID As Int32) As DataSet
            Dim objClsDataAccess As clsDataAccess
            Dim strQuery As String
            Try
                objClsDataAccess = New clsDataAccess
                strQuery = "select isnull(ID,'') as SessionID from tblECSession  where SystemLogout = 0 and  USR_ID = " & intUsr_ID
                Return objClsDataAccess.ExecuteDataSet(strQuery, CommandType.Text)
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strQuery = Nothing
            End Try
        End Function 'EndSession
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This procedure is used to get the count active session IDs of the active account of the supplied user ID
        ' </summary>
        ' <param name="intUsrID"></param>
        ' <returns>String </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [K Bhavani]   18/11/2005   Created
        ' 	    [K Bhavani]   18/11/2005   Added Comments
        '       [K Bhavani]   17/01/2006   Modified query to added  LoggedFrom = 'Web'
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function GetActiveSessionIDsCountByUserID(ByVal intUsr_ID As Int32) As String
            Dim objClsDataAccess As clsDataAccess
            Dim strQuery As String
            Try
                objClsDataAccess = New clsDataAccess
                strQuery = "select count(ID) as SessionID from tblECSession  where SystemLogout = 0 and  LoggedFrom = 'Web' and USR_ID = " & intUsr_ID
                Return objClsDataAccess.ExecuteScalar(strQuery, CommandType.Text)
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strQuery = Nothing
            End Try
        End Function 'EndSession
        Public Shared Function RecordInvalidAnswerCount(ByVal UserId As Integer)
            Dim objClsDataAccess As clsDataAccess
            Dim strQuery As String
            Try
                objClsDataAccess = New clsDataAccess
                strQuery = "UPDATE tblUser SET ProfileActivated = 0, LastModified_User_ID = 3, LastModifiedDate = GetDate() WHERE USR_ID =" & UserId
                Return objClsDataAccess.ExecuteScalar(strQuery, CommandType.Text)
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strQuery = Nothing
            End Try
        End Function
        '*************************************************************************************************
        'Sub/Function/Property Name : AuthenticateLogin
        'Parameters   : strLoginName,strPassword
        'Return Values: Returns DataSet having USR_ID,IsActive and ProfileActivated
        'Purpose      : This is a function to authenticate login based on the credentials supplied
        '
        'Other relevant sources: None
        '     
        'Author            : Nagodaya Bhaskar KR
        'Created Date      : 25/02/2004    
        'Last Modified Date: 21/04/2004
        'Modification Log  :
        'Author                 Date           Reason
        '-------------------------------------------------------------------------------------------------
        'Nagodaya Bhaskar KR    26/03/2004     Added exception  handling
        'Nagodaya Bhaskar KR    20/04/2004     Used parameterized query inseated of normal query
        '*************************************************************************************************
        ' -----------------------------------------------------------------------------
        ' <summary>
        '      This is a function to authenticate login based on the credentials supplied
        ' </summary>
        ' <param name="strLoginName"> To get the LoginName of the user</param>
        ' <param name="strPassword">to authenticate login based on the credentials supplied </param>
        ' <returns> DataSet </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Nagodaya Bhaskar KR]    25/02/2004   Created
        '       [Nagodaya Bhaskar KR]    20/04/2004   Modified Date. Reason: Used parameterized query inseated of normal query and Added exception handling
        ' 	    [Ram R]	                 15/06/2005	 Added Comments
        '       [Narendra]               24/07/2006  moved from clslogindan and also added few queries to get the data required for pageload.
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Function AuthenticateLogin(ByVal strLoginName As String, ByVal strPassword As String, Optional ByVal strMID As String = "", Optional ByVal strSysDefaultsIDs As String = "", Optional ByVal strFailedLogins As String = "") As DataSet
            Dim objClsDataAccess As clsDataAccess
            Dim arrParamStruct(1) As ParamStruct
            'Dim strQuery As String
            'Dim objclsSecurity As clsSecurity
            Dim intDays As Integer = 0
            Dim intRemainingDays As Integer = 0
            Dim strRetVal As String = String.Empty
            Try
                'dsTemp = New DataSet
                objClsDataAccess = New clsDataAccess
                'objclsSecurity = New clsSecurity
                'strPassword = objclsSecurity.SHA256(strPassword)
                ''strPassword = clsSecurity.EnCrypt(strPassword)

                'strQuery = "SELECT USR_ID,ProfileActivated FROM  tblUser  WHERE  USR_LoginName = @USR_LoginName AND USR_Pswd = @USR_Pswd and IsActive=@IsActive"
                'strQuery = "SELECT USR_ID,ProfileActivated FROM  tblUser  WHERE  USR_LoginName = '" & strLoginName & "' AND USR_Pswd = '" & strPassword & "' And IsActive=1"

                'arrParamStruct = New ParamStruct(2) {}

                arrParamStruct(0).ParamName = "@USR_LoginName"
                arrParamStruct(0).direction = ParameterDirection.Input
                arrParamStruct(0).DataType = DbType.String
                arrParamStruct(0).value = strLoginName
                arrParamStruct(0).size = 200

                arrParamStruct(1).ParamName = "@USRPWD"
                arrParamStruct(1).direction = ParameterDirection.Input
                arrParamStruct(1).DataType = DbType.String
                arrParamStruct(1).value = strPassword
                arrParamStruct(1).size = 200

                'arrParamStruct(2).ParamName = "@IsActive"
                'arrParamStruct(2).direction = ParameterDirection.Input
                'arrParamStruct(2).DataType = DbType.Byte
                'arrParamStruct(2).value = 1

                'objClsDataAccess.ExecuteDataSet(dsTemp, strQuery, CommandType.Text)
                AuthenticateLogin = objClsDataAccess.ExecuteDataSet("AxSp_AuthenticateUser", CommandType.StoredProcedure, arrParamStruct)

                ' Replacing the Login name with double quote when it contains single quote

                ' Commented By Aruna
                'If strLoginName.IndexOf("'") > 0 Then
                '    strLoginName = strLoginName.Replace("'", "''")
                'End If

                'If strLoginName <> "" Then
                '    If InStr(1, strLoginName, "'") > 0 Then strLoginName = (Replace(strLoginName, "'", "''"))
                '    strLoginName = Replace(strLoginName, "*", "%")

                '    'If InStr(strLoginName, "%") = 0 Then
                '    '    strLoginName = strLoginName + "%"
                '    'End If
                'End If

                'strQuery = "Set NOCOUNT ON; SELECT USR_ID,ProfileActivated FROM  tblUser  WHERE  USR_LoginName = '" & strLoginName & "' AND USR_Pswd = '" & strPassword & "' And IsActive=1 and ProfileActivated <> 0" _
                '            & "; select id,IsNull(DomainName,'') + IsNull(TargetURL,'') from tblsysmodule where id in (" & strMID & ")" _
                '            & "; Select id, Name, Value,ListValues From tblSysDefault where id=" & strSysDefaultsIDs _
                '            & "; select Id,Name,Value from tblSysDefault where Name in(" & strFailedLogins & ")" _
                '            & "; SELECT U.Usr_ID,U.Usr_ForeName,U.Usr_SurName,U.CanDelete,U.ShowInactiveRecords,U.CLN_ID,case(U.Usr_Authority) 	when 4 then 1 	when 5 then 0 when 6 then 2 end as TypeOfUser,U.usr_identifier_LU,U.IdentifierType, U.USR_SECURITY_LEVEL  FROM	tblUser As U where U.Usr_Loginname = '" & strLoginName & "'"
                'AuthenticateLogin = objClsDataAccess.ExecuteDataSet(strQuery, CommandType.Text)

                'AuthenticateLogin.Tables(1).TableName = "Domains"
                'AuthenticateLogin.Tables(2).TableName = "SysDefaults"
                'AuthenticateLogin.Tables(3).TableName = "SysDefaultValue"
                'AuthenticateLogin.Tables(4).TableName = "UserDetails"
                'select * from tblsyslookup where id in (select Value from tblsysdefault where id in (30,41,46))
                If AuthenticateLogin.Tables.Count = 3 Then
                    AuthenticateLogin.Tables(1).TableName = "SysDefaults"
                    AuthenticateLogin.Tables(2).TableName = "SysDefaultValue"
                Else
                    AuthenticateLogin.Tables(1).TableName = "Domains"
                    AuthenticateLogin.Tables(2).TableName = "SysDefaults"
                    AuthenticateLogin.Tables(3).TableName = "SysDefaultValue"
                    AuthenticateLogin.Tables(4).TableName = "UserDetails"
                    AuthenticateLogin.Tables(5).TableName = "DefaultValues"
                    strRetVal = AuthenticateLogin.Tables(5).Rows(0).Item("REMainderDays")
                    If strRetVal <> "" Then
                        If strRetVal.IndexOf(Chr(22)) <> -1 Then
                            Dim strRetarray As String() = strRetVal.Split(Chr(22))
                            If strRetarray.Length = 3 Then
                                intDays = strRetarray(0)
                                intRemainingDays = strRetarray(1)
                                If intDays >= intRemainingDays Then
                                    AuthenticateLogin.Tables(5).Rows(0).Item("REMainderDays") = strRetarray(2) - intDays
                                Else
                                    AuthenticateLogin.Tables(5).Rows(0).Item("REMainderDays") = 0
                                End If
                            End If
                        End If
                    End If
                End If
                Return AuthenticateLogin
            Catch Ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                'strQuery = Nothing
            End Try
        End Function 'AuthenticateLogin
        ' -----------------------------------------------------------------------------
        ' <summary>
        '      To Authenticate Secondary Login Details
        ' </summary>
        ' <param name="srtuserId"> User ID</param>
        ' <param name="strQuestion">  Question</param>
        ' <param name="stranswer">   answer</param>
        ' <returns> String </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [UdayKirna A]   24/02/2016     Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Function AuthenticateSecondaryLogin(ByVal srtuserId As Integer, ByVal strQuestion As Integer, ByVal stranswer As String) As String
            Dim objClsDataAccess As clsDataAccess
            Dim arrParamStruct(2) As ParamStruct
            Try
                objClsDataAccess = New clsDataAccess

                arrParamStruct(0).ParamName = "@USR_ID"
                arrParamStruct(0).direction = ParameterDirection.Input
                arrParamStruct(0).DataType = DbType.String
                arrParamStruct(0).value = srtuserId
                arrParamStruct(0).size = 50

                arrParamStruct(1).ParamName = "@intQuestion"
                arrParamStruct(1).direction = ParameterDirection.Input
                arrParamStruct(1).DataType = DbType.String
                arrParamStruct(1).value = strQuestion
                arrParamStruct(1).size = 200

                arrParamStruct(2).ParamName = "@strAnswer"
                arrParamStruct(2).direction = ParameterDirection.Input
                arrParamStruct(2).DataType = DbType.String
                arrParamStruct(2).value = stranswer

                Return objClsDataAccess.ExecuteScalar("AxSp_ValidateSecondaryLogin", CommandType.StoredProcedure, arrParamStruct)

            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                arrParamStruct = Nothing
            End Try
        End Function

        ' -----------------------------------------------------------------------------
        ' <summary>
        '      To Get User Security Questions
        ' </summary>
        ' <param name="intSecUserid"> User ID</param>
        ' <returns> DataSet </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [UdayKirna A]   24/02/2016     Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Function GetUserSecurityQuestions(intSecUserid As Integer) As DataSet
            Dim objClsDataAccess As clsDataAccess
            Dim arrParamStruct(0) As ParamStruct
            Dim dtQstn As DataSet

            Try
                objClsDataAccess = New clsDataAccess
                dtQstn = New DataSet
                arrParamStruct(0).ParamName = "@intUser_ID"
                arrParamStruct(0).direction = ParameterDirection.Input
                arrParamStruct(0).DataType = DbType.Int32
                arrParamStruct(0).value = intSecUserid
                dtQstn = objClsDataAccess.ExecuteDataSet("AxSP_GetUserSecurityQuestionsList", CommandType.StoredProcedure, arrParamStruct)
                If Not dtQstn Is Nothing Then
                    Return dtQstn
                End If
            Catch
                Throw
            Finally
                objClsDataAccess = Nothing
                arrParamStruct = Nothing
                dtQstn = Nothing
            End Try
        End Function


        ' -----------------------------------------------------------------------------
        ' <summary>
        '      To Get the user HBID
        ' </summary>
        ' <param name="lngUserId"> User ID</param>
        ' <returns> integer </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Suneetha B]   06/10/2006     Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function GetUserHealthBoardID(ByVal lngUserId As Long) As Integer
            Dim strSql As New System.Text.StringBuilder
            Dim objClsDataAccess As clsDataAccess = New clsDataAccess
            Try
                strSql.Append(" DECLARE @USR_ID AS INT ")
                strSql.Append(" SET @USR_ID = ")

                strSql.Append(lngUserId)
                strSql.Append(" IF ( SELECT USR_AUTHORITY FROM TBLUSER WHERE USR_ID = @USR_ID) = 4 ")
                strSql.Append(" BEGIN ")
                strSql.Append(" SELECT ISNULL(HB_ID,0) AS HB_ID FROM LOCATION WHERE LOC_ID = ( SELECT LOC_ID FROM TBLOTHERSTAFF WHERE ID = (SELECT CLN_ID FROM TBLUSER WHERE USR_ID = @USR_ID) ) ")
                strSql.Append(" END ")
                strSql.Append(" ELSE ")
                strSql.Append(" IF ( SELECT USR_AUTHORITY FROM TBLUSER WHERE USR_ID = @USR_ID  ) = 5  ")
                strSql.Append(" BEGIN ")
                strSql.Append(" SELECT ISNULL(HB_ID,0) AS HB_ID FROM LOCATION WHERE LOC_ID = ( SELECT LOC_ID FROM CLINICIAN WHERE CLN_ID = (SELECT CLN_ID FROM TBLUSER WHERE USR_ID = @USR_ID  ) ) ")
                strSql.Append(" END ")
                Return objClsDataAccess.ExecuteScalar(strSql.ToString, CommandType.Text)
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strSql = Nothing
            End Try

        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '      To check the DB connection 
        ' </summary>
        ' <returns> Boolean </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Mallika]   06/10/2006     Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function IsDBConnectionActive() As Boolean
            Dim objClsDataAccess As clsDataAccess
            Try
                objClsDataAccess = New clsDataAccess
                objClsDataAccess.BeginTrans(System.Data.IsolationLevel.ReadCommitted)
                objClsDataAccess.CommitTrans()
            Catch ex As Exception
                Throw ex
            Finally
                objClsDataAccess = Nothing
            End Try
        End Function

        ''Protected Overrides Sub Finalize()
        ''    MyBase.Finalize()
        ''End Sub

        ' -----------------------------------------------------------------------------
        ' <summary>
        '     whether to prompt the new user for the pwd change in Login or not 
        ' </summary>
        '<param Name="lngUserId"> user ID as long</param>
        ' <returns> Boolean </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [PVP Mohan]   21/11/2006     Created
        ' </history>
        ' -----------------------------------------------------------------------------

        Public Function IsPasswordPromptRequired(ByVal lngUserId As Long) As Boolean
            Dim strQuery As String = String.Empty
            Dim objClsDataAccess As clsDataAccess
            Try
                strQuery = " SELECT ISNULL(ISPWDPROMPTREQUIRED,0) as ISPWDPROMPTREQUIRED FROM tbluser WHERE USR_ID = " & lngUserId
                objClsDataAccess = New clsDataAccess
                Return objClsDataAccess.ExecuteScalar(strQuery, CommandType.Text)
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strQuery = Nothing
            End Try

        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '     whether to prompt the user for the pwd expiry
        ' </summary>
        '<param Name="lngUserId"> user ID as long</param>
        ' <returns> Boolean </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [PVP Mohan]   21/11/2006     Created
        ' </history>
        ' -----------------------------------------------------------------------------

        Public Function IsForcePasswordChange(ByVal lngUserId As Long) As Boolean
            Dim strQuery As String = String.Empty
            Dim objClsDataAccess As clsDataAccess
            Try
                objClsDataAccess = New clsDataAccess
                strQuery = " SELECT  substring(PrivilegedForms,16,1) from tbluser where usr_ID = " & lngUserId
                Dim retval As Boolean = objClsDataAccess.ExecuteScalar(strQuery, CommandType.Text)
                If retval Then
                    Return False
                Else
                    Return True
                End If

            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
            End Try

        End Function
        ' -----------------------------------------------------------------------------
        ' <summary>
        '    Used to check the user password has expired or not 
        ' </summary>
        '<param Name="lngUserId"> user ID as long</param>
        ' <returns> Boolean </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [PVP Mohan]   21/11/2006     Created
        ' </history>
        ' -----------------------------------------------------------------------------

        Public Function IsPasswordExpired(ByVal lngUserId As Long, ByVal strPwd As String) As Boolean
            'Dim strQuery As String = String.Empty
            Dim objClsDataAccess As clsDataAccess
            Dim strDate As String = String.Empty
            Dim SbQuery As New StringBuilder
            Try
                objClsDataAccess = New clsDataAccess(EnumDataBaseType.Audit)
                ''strQuery = " select  convert(datetime,Max(ISNULL(LastModifiedDate,getDate())),113) from tbluserpreviouspasswords where user_ID =  " & lngUserId
                '''strQuery = " select  convert(datetime,ISNULL(max(LastModifiedDate),getDate()),113)  from tbluserpreviouspasswords where user_ID =  " & lngUserId
                SbQuery.Append(" select  convert(datetime,ISNULL(max(LastModifiedDate),getDate()),113)  from tbluserpreviouspasswords where user_ID =  " & lngUserId)
                ''& " AND Password='" & strPwd & "'"
                strDate = objClsDataAccess.ExecuteScalar(SbQuery.ToString, CommandType.Text)
                objClsDataAccess = New clsDataAccess
                '''strQuery = " if ( (SELECT ISNULL(value,0)  FROM tblsysdefault   WHERE id = 1001) = '0' ) select '0' else Begin IF ( DATEDIFF(d,'" & strDate & "',convert( datetime, getdate(),113) ) >=  (SELECT value* 30  FROM tblsysdefault  WHERE id = 1001)  )  SELECT '1'  else  SELECT '0' end "
                SbQuery.Append(" if ( (SELECT ISNULL(value,0)  FROM tblsysdefault   WHERE id = 1001) = '0' ) select '0' else Begin IF ( DATEDIFF(d,'" & strDate & "',convert( datetime, getdate(),113) ) >=  (SELECT value* 30  FROM tblsysdefault  WHERE id = 1001)  )  SELECT '1'  else  SELECT '0' end ")
                Return objClsDataAccess.ExecuteScalar(SbQuery.ToString, CommandType.Text)


            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                SbQuery = Nothing
                strDate = Nothing
            End Try


        End Function

        ' -----------------------------------------------------------------------------
        ' <summary>
        '    Used to get the remaining days for the user pwd to be expired 
        ' </summary>
        '<param Name="lngUserId"> user ID as long</param>
        ' <returns> Boolean </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [PVP Mohan]   21/11/2006     Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function GetRemainingDaysToExpirePwd(ByVal lngUserId As Long, ByVal strPwd As String) As Integer
            'Dim strQuery As String = String.Empty
            Dim objClsDataAccess As clsDataAccess
            Dim strDate As String = String.Empty
            Dim intDays As Integer = 0
            Dim intRemainingDays As Integer = 0
            Dim strRetVal As String = String.Empty
            Dim SbQuery As New StringBuilder
            Try
                objClsDataAccess = New clsDataAccess(EnumDataBaseType.Audit)
                ''strQuery = " select  convert(datetime,Max(LastModifiedDate),113) from tbluserpreviouspasswords where user_ID =  " & lngUserId
                '''strQuery = " select  convert(datetime,ISNULL(max(LastModifiedDate),getDate()),113)  from tbluserpreviouspasswords where user_ID =  " & lngUserId '''& " AND Password='" & strPwd & "'"
                SbQuery.Append(" select  convert(datetime,ISNULL(max(LastModifiedDate),getDate()),113)  from tbluserpreviouspasswords where user_ID =  " & lngUserId)
                strDate = objClsDataAccess.ExecuteScalar(SbQuery.ToString, CommandType.Text)
                objClsDataAccess = New clsDataAccess
                '' strQuery = " SELECT DATEDIFF(d,'" & strDate & "',convert( datetime, getdate(),113) )+ char(22) + select ( (select value*30  from tblsysdefault where id = 1001 )-(select value  from tblsysdefault where id = 1003)) + char(22) + ((select value*30  from tblsysdefault where id = 1001) ) "
                '''strQuery = " SELECT cast(DATEDIFF(d,'" & strDate & "',convert( datetime, getdate(),113) ) as varchar(10) ) + char(22) + cast((select value*30  from tblsysdefault where id = 1001 )-(select value  from tblsysdefault where id = 1003)  as varchar(10) ) + char(22) +   cast( (select value*30  from tblsysdefault where id = 1001) as varchar(10) ) "
                SbQuery.Append(" SELECT cast(DATEDIFF(d,'" & strDate & "',convert( datetime, getdate(),113) ) as varchar(10) ) + char(22) + cast((select value*30  from tblsysdefault where id = 1001 )-(select value  from tblsysdefault where id = 1003)  as varchar(10) ) + char(22) +   cast( (select value*30  from tblsysdefault where id = 1001) as varchar(10) ) ")
                strRetVal = objClsDataAccess.ExecuteScalar(SbQuery.ToString, CommandType.Text)
                If strRetVal <> "" Then
                    If strRetVal.IndexOf(Chr(22)) <> -1 Then
                        Dim strRetarray As String() = strRetVal.Split(Chr(22))
                        If strRetarray.Length = 3 Then
                            intDays = strRetarray(0)
                            intRemainingDays = strRetarray(1)
                            If intDays >= intRemainingDays Then
                                GetRemainingDaysToExpirePwd = strRetarray(2) - intDays
                            End If
                        End If
                    End If
                End If



            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                SbQuery = Nothing
                strDate = Nothing
                strRetVal = Nothing
                intRemainingDays = Nothing
                intDays = Nothing
            End Try
        End Function

        ' -----------------------------------------------------------------------------
        ' <summary>
        '    Used to get the user details of the User
        ' </summary>
        '<param Name="strMID"> Module IDs as String</param>
        '<param Name="intUserId"> user ID as Integer</param>
        ' <returns> Dataset </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [PVP Mohan]   20/01/2007     Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Function GetUserDetails(ByVal strMID As String, ByVal intUserId As Integer) As DataSet
            Dim strQuery As String = String.Empty
            Dim objClsDataAccess As clsDataAccess
            Dim arrParamStruct(0) As ParamStruct
            Dim intDays As Integer = 0
            Dim intRemainingDays As Integer = 0
            Dim strRetVal As String = String.Empty

            'dsTemp = New DataSet

            Try
                'strQuery = "Set NOCOUNT ON;select id,IsNull(DomainName,'') + IsNull(TargetURL,'') from tblsysmodule where id in (" & strMID & ")" _
                '& ";SELECT U.Usr_ID,U.Usr_ForeName,U.Usr_SurName,U.CanDelete,U.ShowInactiveRecords,U.CLN_ID,case(U.Usr_Authority) 	when 4 then 1 	when 5 then 0 when 6 then 2 end as TypeOfUser,U.usr_identifier_LU,U.IdentifierType, U.USR_SECURITY_LEVEL  FROM	tblUser As U where U.Usr_id = " & intUserId
                objClsDataAccess = New clsDataAccess
                'GetUserDetails = objClsDataAccess.ExecuteDataSet(strQuery, CommandType.Text)
                'GetUserDetails.Tables(0).TableName = "Domains"
                'GetUserDetails.Tables(1).TableName = "UserDetails"
                arrParamStruct(0).ParamName = "@USRID"
                arrParamStruct(0).direction = ParameterDirection.Input
                arrParamStruct(0).DataType = DbType.Int64
                arrParamStruct(0).value = intUserId
                GetUserDetails = objClsDataAccess.ExecuteDataSet("AxSp_GetLoginPageLoadInfo", CommandType.StoredProcedure, arrParamStruct)
                If GetUserDetails.Tables.Count > 0 Then
                    GetUserDetails.Tables(0).TableName = "Domains"
                    GetUserDetails.Tables(1).TableName = "SysDefaults"
                    GetUserDetails.Tables(2).TableName = "SysDefaultValue"
                    GetUserDetails.Tables(3).TableName = "UserDetails"
                    GetUserDetails.Tables(4).TableName = "DefaultValues"
                    strRetVal = GetUserDetails.Tables(4).Rows(0).Item("REMainderDays")
                    If strRetVal <> "" Then
                        If strRetVal.IndexOf(Chr(22)) <> -1 Then
                            Dim strRetarray As String() = strRetVal.Split(Chr(22))
                            If strRetarray.Length = 3 Then
                                intDays = strRetarray(0)
                                intRemainingDays = strRetarray(1)
                                If intDays >= intRemainingDays Then
                                    GetUserDetails.Tables(4).Rows(0).Item("REMainderDays") = strRetarray(2) - intDays
                                Else
                                    GetUserDetails.Tables(4).Rows(0).Item("REMainderDays") = 0
                                End If
                            End If
                            strRetarray = Nothing
                        End If
                    End If
                End If
                Return GetUserDetails
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                arrParamStruct = Nothing
            End Try


        End Function
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[madhavi]	22/05/2008	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetGUID() As String
            Dim strQuery As String = String.Empty
            Dim objClsDataAccess As clsDataAccess
            Try
                objClsDataAccess = New clsDataAccess
                strQuery = "SELECT Lookupvalue FROM TBLSYSLOOKUP where id = 2421 AND IsActive=1"
                Return objClsDataAccess.ExecuteScalar(strQuery, CommandType.Text)
            Catch ex As Exception
                Throw ex
            Finally
                objClsDataAccess = Nothing
            End Try
        End Function
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="strGUID"></param>
        ''' <returns>String</returns>
        ''' <remarks>
        '''     Method to check if the GUID is active
        ''' </remarks>
        ''' <history>
        ''' 	[madhavi]	10/07/2008	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function IsGUIDActive(ByVal strGUID As String) As String
            Dim strQuery As String = String.Empty
            Dim objClsDataAccess As clsDataAccess

            Try
                objClsDataAccess = New clsDataAccess
                strQuery = "SELECT OfflineMachineGUID FROM tblEOSOfflineDBRegistration WHERE OfflineMachineGUID = '" & strGUID & "' AND IsActive = 1"
                Return Convert.ToString(objClsDataAccess.ExecuteScalar(strQuery, CommandType.Text))

            Catch ex As Exception
                Throw ex
            Finally
                objClsDataAccess = Nothing
                strQuery = Nothing
            End Try
        End Function

        Public Function IsSessionDuplicate(ByVal strSessionID As String) As Int16
            Dim objClsDataAccess As clsDataAccess
            Dim strQuery As String
            Try
                objClsDataAccess = New clsDataAccess
                strQuery = "select Case When SystemLogout = 0 then 2 else 1 end As Logout  from tblECSession where ID ='" & strSessionID & "'"
                Return objClsDataAccess.ExecuteScalar(strQuery, CommandType.Text)
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strQuery = Nothing
            End Try
        End Function 'EndSess

        ' -----------------------------------------------------------------------------------------------
        ' <summary>
        '       This get the user location details.
        ' </summary>
        ' <remarks>
        '       First version.
        ' </remarks>
        ' <history>
        '      [Harish Lalwani]      01/03/2010  Created
        ' </history>
        ' -----------------------------------------------------------------------------------------------
        Public Function GetUserLocations(ByVal lngUserID As Long) As DataTable
            Dim objDataAcess As clsDataAccess
            Dim arrParamStruct() As ParamStruct
            Dim dsLocations As DataSet

            Try
                arrParamStruct = New ParamStruct(0) {}

                arrParamStruct(0).direction = ParameterDirection.Input
                arrParamStruct(0).ParamName = "@USRID"
                arrParamStruct(0).DataType = DbType.Int64
                arrParamStruct(0).value = lngUserID

                objDataAcess = New clsDataAccess
                dsLocations = objDataAcess.ExecuteDataSet("AxSP_GetUserLocationBasedOnUserID", CommandType.StoredProcedure, arrParamStruct)

                If Not dsLocations Is Nothing AndAlso dsLocations.Tables.Count > 0 Then
                    Return dsLocations.Tables(0)
                Else
                    Return Nothing
                End If


            Catch ex As Exception
                Throw ex
            Finally
                objDataAcess = Nothing
                dsLocations = Nothing
                arrParamStruct = Nothing
            End Try
        End Function
        'Added By Pavani to show message board
        Public Function GetSysBroadcastDetails() As DataSet
            Dim strSql As String = String.Empty
            Dim objclsDataAccess As clsDataAccess
            Dim objResultDS As DataSet
            Try
                strSql = "Select * from AxView_SB_GetBroadcastMessages"
                objclsDataAccess = New clsDataAccess
                objResultDS = New DataSet()
                objResultDS = objclsDataAccess.ExecuteDataSet(strSql, CommandType.Text)
                Return objResultDS
            Catch ex As Exception
                Throw
                Return Nothing
            Finally
                objResultDS = Nothing
                objclsDataAccess = Nothing
                strSql = Nothing
            End Try
        End Function
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="lgnUSerID"></param>
        ''' <returns>
        '''</returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[madhavi]	22/05/2008	Created
        '''     [madhavi]	 25/11/2008	 This data is obtained along with other user details - Hence commented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        'Public Function IsOfflineDBAdmin(ByVal lgnUSerID As Long) As Int16
        '    Dim strQuery As String = String.Empty
        '    Dim objClsDataAccess As clsDataAccess
        '    Dim blnTemp As Boolean

        '    Try
        '        objClsDataAccess = New clsDataAccess
        '        strQuery = "SELECT IsOfflineDBAdmin FROM tblUSer WHERE USR_ID =" & lgnUSerID & " AND IsActive=1"
        '        blnTemp = objClsDataAccess.ExecuteScalar(strQuery, CommandType.Text)
        '        If blnTemp = True Then
        '            Return 1
        '        Else
        '            Return 0
        '        End If
        '    Catch ex As Exception
        '        Throw ex
        '    Finally
        '        objClsDataAccess = Nothing
        '        blnTemp = Nothing
        '        strQuery = Nothing
        '    End Try
        'End Function

        ' -----------------------------------------------------------------------------
        ' <summary>
        ' fnECMappingSsoUID
        ' </summary>
        ' <param name="strUid"> strUid</param>
        ' <param name="int64UserID"> int64UserID</param>
        ' <returns> Long </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [UdayKirna A]   01/06/2017     Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Function fnECMappingSsoUID(ByVal strUid As String, ByVal int64UserID As Integer) As Long
            Dim objDataAcess As clsDataAccess
            Dim arrParamStruct() As ParamStruct
            Dim dsLocations As DataSet

            Try
                arrParamStruct = New ParamStruct(1) {}

                arrParamStruct(0).direction = ParameterDirection.Input
                arrParamStruct(0).ParamName = "@USERID"
                arrParamStruct(0).DataType = DbType.Int64
                arrParamStruct(0).value = int64UserID

                arrParamStruct(1).direction = ParameterDirection.Input
                arrParamStruct(1).ParamName = "@UID"
                arrParamStruct(1).DataType = DbType.String
                arrParamStruct(1).value = strUid



                objDataAcess = New clsDataAccess
                dsLocations = objDataAcess.ExecuteScalar("AxSP_ECMappingSSOUID", CommandType.StoredProcedure, arrParamStruct)

            Catch ex As Exception
                Throw ex
            Finally
                objDataAcess = Nothing
                dsLocations = Nothing
                arrParamStruct = Nothing
            End Try
        End Function
		  Public Function fnGetSSOLocations(ByVal strSSOLOCASIDCode As String) As Integer
            Dim objDataAcess As clsDataAccess
            Dim strQuery As String = String.Empty
            Try
                objDataAcess = New clsDataAccess
                strQuery = "select ID from tblUDFLookupValue  where tblUDFLookupGroup_ID=9326128 And Isactive =1 And ShortDescription='" & strSSOLOCASIDCode & "'"
                Return objDataAcess.ExecuteScalar(strQuery, CommandType.Text)


            Catch ex As Exception
                Throw ex
            Finally
                objDataAcess = Nothing

            End Try
        End Function

        'Purpose         :To Save user entry in tbluserdisclaimer table
        'Method Name     : fnSaveDisclaimer
        'InputParameter  :UserId , DisclaimerIds
        'Output Parameter: --
        'Created By      : Narendra Chary --26/08/2019
        'Modified By     :

        Public Function fnSaveDisclaimer(ByVal UserId As Int64, ByVal DisclaimerIds As String) As String
            Dim objClsDataAccess As clsDataAccess
            Try
                Dim m_objDataAccess As clsDataAccess
                Dim m_prmStructure() As ParamStruct
                m_objDataAccess = New clsDataAccess
                m_prmStructure = New ParamStruct(2) {}

                m_prmStructure(0).DataType = DbType.Int64
                m_prmStructure(0).ParamName = "@intUser_ID"
                m_prmStructure(0).direction = ParameterDirection.Input
                m_prmStructure(0).value = UserId

                m_prmStructure(1).ParamName = "@intDisclaimerStatus"
                m_prmStructure(1).direction = ParameterDirection.Input
                m_prmStructure(1).DataType = DbType.Int32
                m_prmStructure(1).value = 1

                m_prmStructure(2).DataType = DbType.String
                m_prmStructure(2).ParamName = "@strDisclaimerType_SLU"
                m_prmStructure(2).direction = ParameterDirection.Input
                m_prmStructure(2).value = DisclaimerIds


                m_objDataAccess.ExecuteScalar("AxSp_SaveUserDisclaimer", CommandType.StoredProcedure, m_prmStructure)
            Catch ex As Exception
                Throw ex
            Finally
                objClsDataAccess = Nothing
            End Try
        End Function

        'Purpose         :To get UserDisclaimer status
        'Method Name     : GetDisclaimerStatus
        'InputParameter  : UserId
        'Output Parameter: status
        'Created By      : Narendra Chary --26/08/2019
        'Modified By     :

        Public Function GetDisclaimerStatus(ByVal intUser_ID As Int32) As DataSet
            Dim objClsDataAccess As clsDataAccess
            Dim result As DataSet
            Try
                Dim m_objDataAccess As clsDataAccess
                Dim m_prmStructure() As ParamStruct
                m_objDataAccess = New clsDataAccess
                m_prmStructure = New ParamStruct(2) {}

                m_prmStructure(0).ParamName = "@intUser_ID"
                m_prmStructure(0).DataType = DbType.Int64
                m_prmStructure(0).direction = ParameterDirection.Input
                m_prmStructure(0).value = intUser_ID

                m_prmStructure(1).ParamName = "@strDisclaimerIDs"
                m_prmStructure(1).DataType = DbType.String
                m_prmStructure(1).direction = ParameterDirection.Input
                m_prmStructure(1).value = "4,5"

                m_prmStructure(2).ParamName = "@intDisclaimerMsgStatus"
                m_prmStructure(2).DataType = DbType.Int64
                m_prmStructure(2).direction = ParameterDirection.Output

                result = m_objDataAccess.ExecuteDataSet("AxSp_GetUserDisclaimerStatus", CommandType.StoredProcedure, m_prmStructure)
                Return result
            Catch ex As Exception
                Throw ex
            Finally
                objClsDataAccess = Nothing
            End Try
        End Function

        'Purpose         :To get Disclaimer text
        'Method Name     : GetDisclaimers
        'InputParameter  : UserId,DisclaimerID
        'Output Parameter: Disclaimer text as String
        'Created By      : Narendra Chary --26/08/2019
        'Modified By     :
        Public Function GetDisclaimers(ByVal intUser_ID As Int32, ByVal intDisclaimerID As Int32) As String
            Dim objClsDataAccess As clsDataAccess
            Dim result As String
            Try
                Dim m_objDataAccess As clsDataAccess
                Dim m_prmStructure() As ParamStruct
                m_objDataAccess = New clsDataAccess
                m_prmStructure = New ParamStruct(2) {}

                m_prmStructure(0).DataType = DbType.Int64
                m_prmStructure(0).ParamName = "@intUser_ID"
                m_prmStructure(0).direction = ParameterDirection.Input
                m_prmStructure(0).value = intUser_ID

                m_prmStructure(1).ParamName = "@intDisclaimerID"
                m_prmStructure(1).direction = ParameterDirection.Input
                m_prmStructure(1).DataType = DbType.String
                m_prmStructure(1).value = intDisclaimerID

                m_prmStructure(2).DataType = DbType.Int64
                m_prmStructure(2).ParamName = "@intDisclaimerMsgStatus"
                m_prmStructure(2).direction = ParameterDirection.Output
                result = m_objDataAccess.ExecuteScalar("AxSp_GetDisclaimers", CommandType.StoredProcedure, m_prmStructure)
                Return result
            Catch ex As Exception
                Throw ex
            Finally
                objClsDataAccess = Nothing
            End Try
        End Function
        Public Function IsSSOSessionExist(ByVal strUser_ID As String) As Int16
            Dim objClsDataAccess As clsDataAccess

            Dim strQuery As String
            Try
                objClsDataAccess = New clsDataAccess
                strQuery = "select count(ID) from tblECSession where SystemLogout=0 and  USr_ID ='" & strUser_ID & "'"
                Return objClsDataAccess.ExecuteScalar(strQuery, CommandType.Text)
            Catch ex As Exception

                Throw
            Finally
                objClsDataAccess = Nothing
                strQuery = Nothing
            End Try
        End Function
		'Purpose         :To check Valid username
        'Method Name     : validUserName
        'InputParameter  : userName
        'Output Parameter: ValidUser and Failedcount
        'Created By      : Ashok
        'Modified By     :

        Public Function validUserName(ByVal usrName As String, ByVal Reason_Lu As Long) As ArrayList
            Dim m_objDataAccess As clsDataAccess
            Dim result As ArrayList
            Try

                Dim m_prmStructure() As ParamStruct
                m_objDataAccess = New clsDataAccess
                m_prmStructure = New ParamStruct(4) {}

                m_prmStructure(0).DataType = DbType.String
                m_prmStructure(0).ParamName = "@nvarUSR_LoginName"
                m_prmStructure(0).direction = ParameterDirection.Input
                m_prmStructure(0).value = usrName

                m_prmStructure(1).DataType = DbType.Int64
                m_prmStructure(1).ParamName = "@intReason_LU"
                m_prmStructure(1).direction = ParameterDirection.Input
                m_prmStructure(1).value = Reason_Lu

                m_prmStructure(2).DataType = DbType.Int64
                m_prmStructure(2).ParamName = "@bitUserExists"
                m_prmStructure(2).direction = ParameterDirection.Output

                m_prmStructure(3).DataType = DbType.Int64
                m_prmStructure(3).ParamName = "@intFailedCount"
                m_prmStructure(3).direction = ParameterDirection.Output

                m_prmStructure(4).DataType = DbType.Int64
                m_prmStructure(4).ParamName = "@bitUserProfileActivatedOut"
                m_prmStructure(4).direction = ParameterDirection.Output
                result = m_objDataAccess.ExecutePreparedSQL("Axsp_GetValidUserStatus", CommandType.StoredProcedure, m_prmStructure)
                Return result
                'If result.Count > 0 Then
                '    If IsDBNull(result(0)) Then
                '        Return 0
                '    Else
                '        Return result(0)
                '    End If

                'End If
            Catch ex As Exception
                Throw ex
            End Try

        End Function
        'Purpose         :To Get Credentials of user
        'Method Name     : GetUserCredentials
        'InputParameter  : userId
        'Output Parameter: UserName and Password
        'Created By      : Ashok
        'Modified By     :
        Public Function GetUserCredentials(ByVal intSecUserid As Integer) As DataSet
            Dim objClsDataAccess As clsDataAccess
            Dim arrParamStruct(0) As ParamStruct
            Dim dsUsrCreds As DataSet

            Try
                objClsDataAccess = New clsDataAccess
                arrParamStruct(0).ParamName = "@UserId"
                arrParamStruct(0).direction = ParameterDirection.Input
                arrParamStruct(0).DataType = DbType.Int32
                arrParamStruct(0).value = intSecUserid
                dsUsrCreds = objClsDataAccess.ExecuteDataSet("AxSp_GetUserLoginPwd", CommandType.StoredProcedure, arrParamStruct)
                If Not dsUsrCreds Is Nothing Then
                    Return dsUsrCreds
                Else
                    Return Nothing
                End If
            Catch
                Throw
            Finally
                objClsDataAccess = Nothing
                arrParamStruct = Nothing
                dsUsrCreds = Nothing
            End Try
        End Function
    End Class

End Namespace