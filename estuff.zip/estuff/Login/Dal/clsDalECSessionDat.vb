Option Explicit On 

Imports Excelicare.Framework.AppDataSupport  ' To access sql helper functions
' -----------------------------------------------------------------------------
' <summary>
'      To access sql helper functions
' </summary>
' <remarks>
' </remarks>
' <history>
' 	    [Ram R]	 15/06/2005	 Added Comments
' </history>
' -----------------------------------------------------------------------------
'Imports AxSys.AppSupport    ' To access exception handling functions
' -----------------------------------------------------------------------------
' <summary>
'      To access exception handling functions
' </summary>
' <remarks>
' </remarks>
' <history>
' 	    [Ram R]	  15/06/2005	 Added Comments
' </history>
' -----------------------------------------------------------------------------
Imports System.Text

Namespace Excelicare.Dal.Login
    '****************************************************************************************************
    '''Class Name : clsDalECSessionDat
    '''PURPOSE    : Exposes ECSession Dat functionality to BIZL
    '''
    '''MODIFICATION LOG  :
    '''
    '''AUTHOR                      Ver#       Date        Reason/Changes
    '''----------------------------------------------------------------------------------------------------
    '''Nagodaya Bhaskar KR.      1.0.000    27/02/2004    First version.
    '''****************************************************************************************************
    ''' -----------------------------------------------------------------------------
    ''' <summary>
    '''       Exposes ECSession Dan functionality to BIZ Layer
    ''' </summary>
    ''' <remarks>
    '''       First version.
    ''' </remarks>
    ''' <history>
    '''       [Nagodaya Bhaskar KR]   27/02/2004   Created
    ''' 	    [Ram R]	                15/06/2005	 Added Comments
    ''' </history>
    ''' -----------------------------------------------------------------------------

    Public Class clsDalECSessionDat
        '************************************************************************************************
        'Sub/Function/Property Name : StartSession
        'Parameters   : strLoginName,strMacnineName,strMachineIP
        'Return Values: Returns the 32 bit session id
        'Purpose      : This is a function to insert login details into the db
        '
        'Other relevant sources: 
        '       +AxSP_InsertNewSession
        '     
        'Author            : Nagodaya Bhaskar KR
        'Created Date      : 27/02/2004    
        'Last Modified Date: 00/00/0000
        'Modification Log  :
        'Author                 Date           Reason
        '----------------------------------------------------------------------------------------------------
        'Nagodaya Bhaskar KR    26/03/2004     Added exception handling
        '****************************************************************************************************
        ' -----------------------------------------------------------------------------
        ' <summary>
        '      This is a function to insert login details into the db
        ' </summary>
        ' <param name="strLoginName"> To get the LoginName of the user</param>
        ' <param name="strSession_ID">Retrieves the Session_ID value for the logged in user </param>
        ' <param name="strMachineName"> To get the Machine Name </param>
        ' <param name="strMachineIP"> To get the IP address of Machine</param>
        ' <returns> Int16 </returns>
        ' <remarks>
        '      Added exception handling
        '      Other relevant sources:      +AxSP_InsertNewSession
        ' </remarks>
        ' <history>
        '       [Nagodaya Bhaskar KR]   26/03/2004   Created
        ' 	    [Ram R]	                15/06/2005	 Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Function StartSession(ByVal strLoginName As String, ByVal strSession_ID As String, ByVal strMachineName As String, ByVal strMachineIP As String) As Int16
            Dim objClsDataAccess As clsDataAccess
            Dim arrParamStruct() As ParamStruct
            Try
                objClsDataAccess = New clsDataAccess
                arrParamStruct = New ParamStruct(3) {}
                arrParamStruct(0).direction = ParameterDirection.Input
                arrParamStruct(0).ParamName = "@LoginName"
                arrParamStruct(0).DataType = DbType.String
                arrParamStruct(0).sourceColumn = "LoginName"
                arrParamStruct(0).value = strLoginName

                arrParamStruct(1).direction = ParameterDirection.Input
                arrParamStruct(1).ParamName = "@Session_ID"
                arrParamStruct(1).DataType = DbType.String
                arrParamStruct(1).sourceColumn = "Session_ID"
                arrParamStruct(1).value = strSession_ID

                arrParamStruct(2).direction = ParameterDirection.Input
                arrParamStruct(2).ParamName = "@MachineName"
                arrParamStruct(2).DataType = DbType.String
                arrParamStruct(2).sourceColumn = "MachineName"
                arrParamStruct(2).value = strMachineName

                arrParamStruct(3).direction = ParameterDirection.Input
                arrParamStruct(3).ParamName = "@MachineIP"
                arrParamStruct(3).DataType = DbType.String
                arrParamStruct(3).sourceColumn = "MachineIP"
                arrParamStruct(3).value = strMachineIP

                Return objClsDataAccess.ExecuteNonQuery("AxSP_InsertNewSession", CommandType.StoredProcedure, arrParamStruct)
            Catch ex As Exception
                Throw
            Finally
                arrParamStruct = Nothing
                objClsDataAccess = Nothing
            End Try
        End Function 'StartSession


        '****************************************************************************************************
        'Sub/Function/Property Name : EndSession
        'Parameters   : Session_ID
        'Return Values: None
        'Purpose      : This is a sub to to end the session that has already active
        '
        'Other relevant sources: 
        '     
        'Author            : Nagodaya Bhaskar KR
        'Created Date      : 27/02/2004    
        'Last Modified Date: 00/00/0000
        'Modification Log  :
        'Author                 Date           Reason
        '----------------------------------------------------------------------------------------------------
        'Nagodaya Bhaskar KR    26/03/2004     Added exception handling
        '****************************************************************************************************

        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This function is used to end the session that has already active
        ' </summary>
        ' <param name="strSession_ID"> Retrieves the Session_ID value for the logged in user</param>
        ' <returns> </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [Nagodaya Bhaskar KR]   27/02/2004   Created
        ' 	    [Ram R]	                15/06/2005	 Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Sub EndSession(ByVal strSession_ID As String)
            Dim objClsDataAccess As clsDataAccess
            Dim strQuery As String
            Try
                objClsDataAccess = New clsDataAccess
                strQuery = "SET NOCOUNT ON; update tblECSession set SystemLogout = 1,EndTime= '" & DateTime.UtcNow() & "' where [ID] = '" & strSession_ID & "'; EXEC AxSP_DecrementConcurrentUserCount"
                objClsDataAccess.ExecuteNonQuery(strQuery, CommandType.Text)
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strQuery = Nothing
            End Try
        End Sub 'EndSession

        '*************************************************************************************************
        'Sub/Function/Property Name : IncrementConcurrentUserCount
        'Parameters   : None
        'Return Values: None
        'Purpose      : This is a sub to increment concurrent user count
        '
        'Other relevant sources: 
        '       ' + AxSP_IncrementConcurrentUserCount     
        'Author            : Nagodaya Bhaskar KR
        'Created Date      : 27/02/2004    
        'Last Modified Date: 00/00/0000
        'Modification Log  :
        'Author                 Date           Reason
        '-------------------------------------------------------------------------------------------------
        '*************************************************************************************************
        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This is a sub to increment concurrent user count
        ' </summary>
        ' <returns> </returns>
        ' <remarks>
        '       Other relevant sources:  AxSP_IncrementConcurrentUserCount   
        ' </remarks>
        ' <history>
        '       [Nagodaya Bhaskar KR]   27/02/2004  Created
        ' 	    [Ram R]	                15/06/2005	Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Sub IncrementConcurrentUserCount()
            Dim objClsDataAccess As clsDataAccess

            Try
                objClsDataAccess = New clsDataAccess
                objClsDataAccess.ExecuteNonQuery("AxSP_IncrementConcurrentUserCount", CommandType.StoredProcedure)
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
            End Try
        End Sub      'IncrementConcurrentUserCount

        '*************************************************************************************************
        'Sub/Function/Property Name : DecrementConcurrentUserCount
        'Parameters   : None
        'Return Values: None
        'Purpose      : This is a sub to decrement concurrent user count
        '
        'Other relevant sources: 
        '       + AxSP_DecrementConcurrentUserCount
        '     
        'Author            : Nagodaya Bhaskar KR
        'Created Date      : 27/02/2004    
        'Last Modified Date: 00/00/0000
        'Modification Log  :
        'Author                 Date           Reason
        '-------------------------------------------------------------------------------------------------
        'Nagodaya Bhaskar KR    26/03/2004     Added exception handling
        '*************************************************************************************************
        ' -----------------------------------------------------------------------------
        ' <summary>
        '      This is a sub to Decrement concurrent user count
        ' </summary>
        ' <returns> </returns>
        ' <remarks>
        '      Other relevant sources: AxSP_DecrementConcurrentUserCount   
        ' </remarks>
        ' <history>
        '      [Nagodaya Bhaskar KR]    26/03/2004  Created
        ' 	   [Ram R]	                15/06/2005	Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Sub DecrementConcurrentUserCount()
            Dim objClsDataAccess As clsDataAccess
            Try
                objClsDataAccess = New clsDataAccess
                objClsDataAccess.ExecuteNonQuery("AxSP_DecrementConcurrentUserCount", CommandType.StoredProcedure)
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
            End Try
        End Sub      'DecrementConcurrentUserCount

        '*************************************************************************************************
        'Sub/Function/Property Name : StillActive
        'Parameters   : None
        'Return Values: returns number of rows affected
        'Purpose      : This is a function to update still connected time of the user
        '
        'Other relevant sources: 
        '     
        'Author            : Nagodaya Bhaskar KR
        'Created Date      : 05/04/2004    
        'Last Modified Date: 00/00/0000
        'Modification Log  :
        'Author                 Date           Reason
        '-------------------------------------------------------------------------------------------------
        '*************************************************************************************************
        ' -----------------------------------------------------------------------------
        ' <summary>
        '      This is a function to update still connected time of the user
        ' </summary>
        ' <param name="strSession_ID"> Retrieves the Session_ID value for the logged in user</param>
        ' <param name="dt"> Retrieves the date and time of current logged in user</param>
        ' <returns>Int16 </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Nagodaya Bhaskar KR]    05/04/2004  Created
        ' 	   [Ram R]	                15/06/2005	Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Function StillActive(ByVal strSession_ID As String, ByVal dt As DateTime) As Int16
            Dim objClsDataAccess As clsDataAccess
            Dim objSBQuery As StringBuilder
            Try
                objClsDataAccess = New clsDataAccess
                objSBQuery = New StringBuilder
                objSBQuery.Append("Update tblECSession set TimeLastSeenConnected = ")
                objSBQuery.Append("'" & dt.UtcNow.ToString() & "'")
                objSBQuery.Append(" where ID = ")
                objSBQuery.Append("'" & strSession_ID & "'")
                Return objClsDataAccess.ExecuteNonQuery(objSBQuery.ToString, CommandType.Text)
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                objSBQuery = Nothing
            End Try
        End Function

        '*************************************************************************************************
        'Sub/Function/Property Name : TerminateLeftOverSessions
        'Parameters   : None
        'Return Values: returns number of rows affected
        'Purpose      : This function terminates all the left over sessions
        '
        'Other relevant sources: 
        '     
        'Author            : Nagodaya Bhaskar KR
        'Created Date      : 07/04/2004    
        'Last Modified Date: 00/00/0000
        'Modification Log  :
        'Author                 Date           Reason
        '-------------------------------------------------------------------------------------------------
        '*************************************************************************************************
        ' -----------------------------------------------------------------------------
        ' <summary>
        '      This function terminates all the left over sessions
        ' </summary>
        ' <returns>Int16 </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Nagodaya Bhaskar KR]    07/04/2004  Created
        ' 	   [Ram R]	                15/06/2005	Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        'Public Shared Function TerminateLeftOverSessions() As Int16
        '    Dim objClsDataAccess As clsDataAccess
        '    Try
        '        objClsDataAccess = New clsDataAccess
        '        Return objClsDataAccess.ExecuteNonQuery("AxSP_TerminateLeftOverSessions", CommandType.StoredProcedure)
        '    Catch ex As Exception
        '        Throw
        '    Finally
        '        objClsDataAccess = Nothing
        '    End Try
        'End Function

        ' -----------------------------------------------------------------------------
        ' <summary>
        '       This function is used to end the session that has already active and deletes the Sessiondata of already active sessions
        ' </summary>
        ' <param name="lngUser_ID"></param>
        ' <returns> </returns>
        ' <remarks>
        ' </remarks>
        ' <history>
        '       [K.Bhavani]   18/11/2005   Created
        ' 	    [K.Bhavani]	  18/11/2005   Added Comments
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Shared Sub EndActiveSessionsByUserID(ByVal lngUser_ID As Int64)
            Dim objClsDataAccess As clsDataAccess
            'Dim objClsEcSession As clsDalEcSessionDan
            'Dim dsActiveSessionIds As DataSet
            'Dim drActiveSessionIds As DataRow
            Dim strQuery As String
            Try
                objClsDataAccess = New clsDataAccess
                'objClsEcSession = New clsDalEcSessionDan
                'dsActiveSessionIds = New DataSet
                'objClsDataAccess.ExecuteDataSet(dsActiveSessionIds, strSql, CommandType.Text, "UserActiveSessions") 'objClsEcSession.GetActiveSessionIDsoftheUser(lngUser_ID)
                'If dsActiveSessionIds.Tables(0).Rows.Count > 0 Then
                'For Each drActiveSessionIds In dsActiveSessionIds.Tables(0).Rows
                strQuery = "SET NOCOUNT ON; update tblECSession set SystemLogout = 1,EndTime= getdate() where [USR_ID] = " & lngUser_ID & "AND LoggedFrom = 'Web' AND SystemLogout = 0" _
                            & ";DELETE from tblSessionData WHERE SessionID IN(select SessionID  from tblECSession where USR_ID= " & lngUser_ID & ")" '" & drActiveSessionIds.Item("SessionID") & "'"
                'objClsDataAccess.ExecuteNonQuery(strQuery, CommandType.Text)
                'strQuery = "DELETE from tblSessionData WHERE SessionID IN(select SessionID  from tblECSession where USR_ID= " & lngUser_ID & ")" '" & drActiveSessionIds.Item("SessionID") & "'"
                objClsDataAccess.ExecuteNonQuery(strQuery, CommandType.Text)
                'Next
                'End If
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strQuery = Nothing
            End Try
        End Sub 'EndSession
        ' -----------------------------------------------------------------------------
        ' <summary>
        '   This function inserts data into tblSHCFailedLoginData table
        ' </summary>
        '<param Name="strMachineName"> Machine Name </param>
        '<param Name="strMachineIP"> Machine IP</param>
        '<param Name="strLoginNameGiven"> Login Name</param>
        '<param Name="strSHCSettings"> SHC Settins</param>
        ' <remarks>
        ' </remarks>
        ' <history>
        '      [Manohar]   10/05/2008     Created
        ' </history>
        ' -----------------------------------------------------------------------------
        Public Function fnInsertSHCFailedLoginData(ByVal strMachineName As String, ByVal strMachineIP As String, _
             ByVal strLoginNameGiven As String, ByVal strSHCSettings As String) As Int16
            Dim strQuery As String = String.Empty
            Dim objClsDataAccess As clsDataAccess
            Try
                objClsDataAccess = New clsDataAccess
                strLoginNameGiven = strLoginNameGiven.Replace("'", "''")
                strQuery = "Insert into TblSHCFailedLogin(MachineName, MachineIP, LoginNameGiven, SHCSettings, IsActive, LastModifiedDate) Values (" _
                           & "'" & strMachineName & "'" & ", " & "'" & strMachineIP & "'" & ", " & "'" & strLoginNameGiven & "'" & ", " & "'" & strSHCSettings & "'" & ", 1 , getDate()) "
                Return objClsDataAccess.ExecuteNonQuery(strQuery, CommandType.Text)
            Catch ex As Exception
                Throw
            Finally
                objClsDataAccess = Nothing
                strQuery = Nothing
            End Try
        End Function

        ''Protected Overrides Sub Finalize()
        ''    MyBase.Finalize()
        ''End Sub
        Public Function InsertSHCSessionLog(ByVal strSessionID As String, _
                                ByVal strIEVersion As String, ByVal strCookiesEnabled As String, _
                                ByVal strScreenResol As String, ByVal strOSVersion As String, ByVal strTextSize As String, _
                                ByVal strTrustedSites As String, ByVal strDAX As String, ByVal strApac As String, ByVal strDsac As String, _
                                ByVal strRacp As String, ByVal strSacmss As String, ByVal strFD As String, ByVal strAmr As String, _
                                ByVal strActiveScript As String, ByVal strActiveXInstalled As String, ByVal strAdobeReader As String, _
                                ByVal strMsExcel As String, ByVal strMsxml As String, ByVal strRWTempFolder As String, _
                                ByVal strRWTempFile As String) As Int32
            Dim objClsDataAccess As clsDataAccess
            Dim arrParams() As ParamStruct
            Try
                arrParams = New ParamStruct(20) {}

                With arrParams(0)
                    .ParamName = "@ECSession_ID"
                    .direction = ParameterDirection.Input
                    .DataType = DbType.String
                    .value = strSessionID
                End With

                With arrParams(1)
                    .ParamName = "@IEVersion"
                    .direction = ParameterDirection.Input
                    .DataType = DbType.String
                    .value = strIEVersion
                End With

                With arrParams(2)
                    .ParamName = "@CookiesEnabled"
                    .direction = ParameterDirection.Input
                    .DataType = DbType.String
                    .value = strCookiesEnabled
                End With

                With arrParams(3)
                    .ParamName = "@ScreenResol"
                    .direction = ParameterDirection.Input
                    .DataType = DbType.String
                    .value = strScreenResol
                End With

                With arrParams(4)
                    .ParamName = "@OSVersion"
                    .direction = ParameterDirection.Input
                    .DataType = DbType.String
                    .value = strOSVersion
                End With

                With arrParams(5)
                    .ParamName = "@TextSize"
                    .direction = ParameterDirection.Input
                    .DataType = DbType.String
                    .value = strTextSize
                End With

                With arrParams(6)
                    .ParamName = "@TrustedSites"
                    .direction = ParameterDirection.Input
                    .DataType = DbType.String
                    .value = strTrustedSites
                End With

                With arrParams(7)
                    .ParamName = "@DAX"
                    .direction = ParameterDirection.Input
                    .DataType = DbType.String
                    .value = strDAX
                End With

                With arrParams(8)
                    .ParamName = "@APAC"
                    .direction = ParameterDirection.Input
                    .DataType = DbType.String
                    .value = strApac
                End With

                With arrParams(9)
                    .ParamName = "@DSAC"
                    .direction = ParameterDirection.Input
                    .DataType = DbType.String
                    .value = strDsac
                End With

                With arrParams(10)
                    .ParamName = "@RACP"
                    .direction = ParameterDirection.Input
                    .DataType = DbType.String
                    .value = strRacp
                End With

                With arrParams(11)
                    .ParamName = "@SACMSS"
                    .direction = ParameterDirection.Input
                    .DataType = DbType.String
                    .value = strSacmss
                End With

                With arrParams(12)
                    .ParamName = "@FD"
                    .direction = ParameterDirection.Input
                    .DataType = DbType.String
                    .value = strFD
                End With

                With arrParams(13)
                    .ParamName = "@AMR"
                    .direction = ParameterDirection.Input
                    .DataType = DbType.String
                    .value = strAmr
                End With

                With arrParams(14)
                    .ParamName = "@ActiveScript"
                    .direction = ParameterDirection.Input
                    .DataType = DbType.String
                    .value = strActiveScript
                End With

                With arrParams(15)
                    .ParamName = "@ActiveXInstalled"
                    .direction = ParameterDirection.Input
                    .DataType = DbType.String
                    .value = strActiveXInstalled
                End With

                With arrParams(16)
                    .ParamName = "@AdobeReader"
                    .direction = ParameterDirection.Input
                    .DataType = DbType.String
                    .value = strAdobeReader
                End With

                With arrParams(17)
                    .ParamName = "@MSEXCEL"
                    .direction = ParameterDirection.Input
                    .DataType = DbType.String
                    .value = strMsExcel
                End With

                With arrParams(18)
                    .ParamName = "@MSXML"
                    .direction = ParameterDirection.Input
                    .DataType = DbType.String
                    .value = strMsxml
                End With

                With arrParams(19)
                    .ParamName = "@RWTempFolder"
                    .direction = ParameterDirection.Input
                    .DataType = DbType.String
                    .value = strRWTempFolder
                End With

                With arrParams(20)
                    .ParamName = "@RWTempFile"
                    .direction = ParameterDirection.Input
                    .DataType = DbType.String
                    .value = strRWTempFile
                End With

                objClsDataAccess = New clsDataAccess

                Return objClsDataAccess.ExecuteNonQuery("AxSP_WebSHCLogSession", CommandType.StoredProcedure, arrParams)
            Catch ex As Exception
                Throw ex
            Finally
                objClsDataAccess = Nothing
                arrParams = Nothing
            End Try
        End Function
        Public Function SaveQRCode(ByVal lngUserId As Long, ByVal setting As String, ByVal QRCode As String) As String
            Dim objClsDataAccess As clsDataAccess
            Dim arrParamStruct() As ParamStruct
            Dim dsMFAEnabled As DataSet = New DataSet
            Dim strReturnvalue As String = String.Empty
            Try

                objClsDataAccess = New clsDataAccess
                arrParamStruct = New ParamStruct(5) {}
                arrParamStruct(0).direction = ParameterDirection.Input
                arrParamStruct(0).ParamName = "@intUserID"
                arrParamStruct(0).DataType = DbType.Int64
                arrParamStruct(0).value = lngUserId

                arrParamStruct(1).direction = ParameterDirection.Input
                arrParamStruct(1).ParamName = "@strSettings"
                arrParamStruct(1).DataType = DbType.String
                arrParamStruct(1).value = setting

                arrParamStruct(2).direction = ParameterDirection.Input
                arrParamStruct(2).ParamName = "@intControltype_slu"
                arrParamStruct(2).DataType = DbType.Int64
                arrParamStruct(2).value = 5534

                arrParamStruct(3).direction = ParameterDirection.Input
                arrParamStruct(3).ParamName = "@intSysECform_id"
                arrParamStruct(3).DataType = DbType.Int64
                arrParamStruct(3).value = 15

                arrParamStruct(4).direction = ParameterDirection.Input
                arrParamStruct(4).ParamName = "@varQRCode"
                arrParamStruct(4).DataType = DbType.String
                arrParamStruct(4).value = QRCode

                arrParamStruct(5).direction = ParameterDirection.Input
                arrParamStruct(5).ParamName = "@bitIsUserPreferences"
                arrParamStruct(5).DataType = DbType.String
                arrParamStruct(5).value = False
                dsMFAEnabled = objClsDataAccess.ExecuteDataSet("Axsp_SaveUserPreferencesForMFA", CommandType.StoredProcedure, arrParamStruct)
                If dsMFAEnabled.Tables.Count > 0 Then
                    strReturnvalue = dsMFAEnabled.Tables(0).Rows(0).Item(0).ToString()
                Else
                    strReturnvalue = "1"
                End If

                Return strReturnvalue
            Catch ex As Exception
                Throw ex
            Finally
                arrParamStruct = Nothing
                objClsDataAccess = Nothing
            End Try
        End Function
    End Class 'clsDalECSessionDat
End Namespace