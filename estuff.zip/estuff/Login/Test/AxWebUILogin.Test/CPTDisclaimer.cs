﻿using System;
using System.Web;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using Excelicare.Bizl.Login;
using Excelicare.Dal.Login;

namespace AxWebUILogin.Test
{
	[TestFixture]
    public class CPTDisclaimer
    {
		clsDalEcSessionDan clsDalEcSession = new clsDalEcSessionDan();
		frmsignon frmsignon = new frmsignon();
		

		//[TestCase]
		//public void GetDisclaimerText()
		//{
		//	string CPTText = string.Empty;
		//	CPTText = clsDalEcSession.GetCPTDisclaimerText();
		//	Assert.IsNotEmpty(CPTText);
		//}

		[TestCase(104)]
		[TestCase(-1)]
		public void fnGetUserDisclaimerStatus(int userID)
		{
			//string cptMessage = frmsignon.fnGetUserDisclaimerStatus(userID);
			//Assert.IsNotEmpty(cptMessage.ToString());
		}

		//[TestCase(104)]
		//[TestCase(-1)]
		//[TestCase(0)]
		//public void fnSaveUserDisclaimerStatus(int userID)
		//{
		//	try
		//	{
		//		frmsignon.fnSaveDisclaimer(userID);
		//		Assert.Pass();
		//	}
		//	catch (Exception ex) { }
		//}
	}
}
