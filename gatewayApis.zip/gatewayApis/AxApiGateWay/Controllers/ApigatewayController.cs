﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Web.Http;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Reflection;
using AxApigateway.Models;

namespace apigateway.Controllers
{
    /// <summary>
    /// apigateway for apigateway for Excelicare ApiGateWay
    /// created by: BRR
    /// created datetime: 21-Nov-2023 12:55PM
    /// </summary>

    public class ApigatewayController : ApiController
    {

        #region Globalvariables
        
        string strApiUrl = ConfigurationManager.AppSettings["ApiGateWayUrl"];     

        #endregion

        #region StaffRegistration

        /// <summary>
        /// to get all staff details
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/user")]
        //[Throttle("GetListOfUsers", "", 20)]
        public IHttpActionResult GetListofUsers()
        {
            HttpClient client;
            HttpResponseMessage response;
            JArray jsonArray;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("apigateway/user").Result;
                if (response.IsSuccessStatusCode)
                {
                    jsonArray = JArray.Parse(response.Content.ReadAsStringAsync().Result);
                    return Ok(jsonArray);
                }
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
                jsonArray = null;
            }
        }

        /// <summary>
        /// to get user details
        /// </summary>
        /// <param name="usertype">mandatory</param>
        /// <param name="userid">mandatory</param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/user/{usertype}/{userid}")]
        public IHttpActionResult GetUserDetails(int usertype, long userid)
        {
            HttpClient client;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/user/" + usertype + "/" + userid).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(JObject.Parse(response.Content.ReadAsStringAsync().Result));

                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }

        /// <summary>
        /// to register/ update staff
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/user/register")]
        public IHttpActionResult SaveUser(object general)
        {
            string staffData = string.Empty;
            StringContent staffDataContent = null;
            HttpClient client = null;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();         
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));               


                response = client.PostAsync("api/user/register", new StringContent(JsonConvert.SerializeObject(staffDataContent))).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                staffData = null;
                staffDataContent = null;
                client = null;
                response = null;     
            }
        }

        /// <summary>
        /// to inactivate/ reactivate staff
        /// </summary>
        /// <param name="objDeleteInfo"></param>
        /// <returns></returns>
        [HttpDelete]
        [Route("apigateway/user")]
        public IHttpActionResult DeleteUser([FromBody] object objDeleteInfo)
        {
            HttpClient client = null;
            HttpResponseMessage response;
            string deleteInfo = string.Empty;
            StringContent deleteInfoContent = null;
            try
            {
                client = new HttpClient();      
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.SendAsync(new HttpRequestMessage(new HttpMethod("DELETE"), "api/user")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(deleteInfoContent))
                }).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
                deleteInfo = null;
                deleteInfoContent = null;   
            }
        }

        /// <summary>
        /// to get given staff id user profile data
        /// </summary>
        /// <param name="userID">mandatory</param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/user/{userID}")]       
        public IHttpActionResult GetUserProfile(long userID)
        {
            HttpClient client = null;
            HttpResponseMessage response = null;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/user/" + userID).Result;

                if (response.IsSuccessStatusCode)

                    return Ok(JObject.Parse(response.Content.ReadAsStringAsync().Result));
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));

            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }

        /// <summary>
        /// to save user profile data
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/user/profile")] 
        public IHttpActionResult SaveUserProfile(object userProfiles)
        {
            string userData = string.Empty;
            HttpClient client = null;
            HttpResponseMessage response;

            try
            {
                client = new HttpClient();     
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
               
                response = client.PostAsync("api/user/profile/", new StringContent(JsonConvert.SerializeObject(userProfiles))).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                userData = null;  
                client = null;
                response = null;     
            }
        }

        /// <summary>
        /// Reset security questions for user
        /// </summary>
        /// <returns></returns>
        [HttpDelete]
        [Route("apigateway/user/resetsecurityquestions/{UserID}")]
        public IHttpActionResult ResetSecurityQuestions(long userID)
        {
            HttpClient client = null;
            HttpResponseMessage response;

            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.SendAsync(new HttpRequestMessage(new HttpMethod("DELETE"), "api/user/resetsecurityquestions/" + userID)).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }

        /// <summary>
        /// to get given user id account information
        /// </summary>
        /// <param name="userID">mandatory</param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/manageaccount/{userID}")]   
        public IHttpActionResult GetUserAccountDetails(long userID)
        {
            HttpClient client = null;
            HttpResponseMessage response = null;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/manageaccount/" + userID).Result;

                if (response.IsSuccessStatusCode)

                    return Ok(JObject.Parse(response.Content.ReadAsStringAsync().Result));
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));

            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }

        /// <summary>
        /// to create/update user account
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/manageaccount")]    
        public IHttpActionResult AddUserAccount([FromBody] object manageAccount)
        {
            string userAccountData = string.Empty;
            StringContent userAccountContent = null;
            HttpClient client = null;
            HttpResponseMessage response;

            try
            {
                client = new HttpClient();    
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                if (userAccountData == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");

                userAccountContent = new StringContent(userAccountData, UnicodeEncoding.UTF8, "application/json");
                response = client.PostAsync("api/manageaccount/", new StringContent(JsonConvert.SerializeObject(userAccountData))).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(JObject.Parse(response.Content.ReadAsStringAsync().Result));
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                userAccountData = null;
                userAccountContent = null;
                client = null;
                response = null;       
            }
        }

        /// <summary>
        /// to inactivate/ reactivate user account
        /// </summary>
        /// <param name="objDeleteInfo">mandatory</param>
        /// <returns></returns>
        [HttpDelete]
        [Route("apigateway/manageaccount")]
        public IHttpActionResult DeleteUserAccount([FromBody] object objDeleteInfo)
        {

            HttpClient client = null;
            HttpResponseMessage response;
            string deleteInfo = string.Empty;
            StringContent deleteInfoContent = null;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                deleteInfo = JObject.FromObject(objDeleteInfo).ToString();
                deleteInfoContent = new StringContent(deleteInfo, UnicodeEncoding.UTF8, "application/json");
                response = client.SendAsync(new HttpRequestMessage(new HttpMethod("DELETE"), "api/manageaccount")
                {
                    Content = deleteInfoContent
                }).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
                deleteInfo = null;
                deleteInfoContent = null;
            }
        }

        /// <summary>
        /// to get default configuration details of given userid
        /// </summary>
        /// <param name="userID">mandatory</param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/user/defaultconfiguration/{Userid}")]
        public IHttpActionResult GetDefaultConfigurations(long userID)
        {
            HttpClient client = null;
            HttpResponseMessage response = null;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/user/defaultconfiguration/" + userID).Result;

                if (response.IsSuccessStatusCode)

                    return Ok(JObject.Parse(response.Content.ReadAsStringAsync().Result));
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));

            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }


        //Staff registration MCN tab end points

        /// <summary>
        /// to get user mcn data
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="staffType"></param>
        /// <param name="Mode"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/user/MCN/{userID}/{staffType}/{Mode}")]
        
        
        public IHttpActionResult GetUserMCN(long userID, int staffType, int Mode)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/user/MCN/" + userID + "/" + staffType + "/" + Mode).Result;
                if (response.IsSuccessStatusCode)
                {
                    return Ok(response.Content.ReadAsStringAsync().Result);
                }
                else
                {
                    return Content(HttpStatusCode.BadRequest, response.Content.ReadAsStringAsync().Result);
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }


        /// <summary>
        /// to save user mcn data
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/User/UserMCN")]   
        public IHttpActionResult SaveUserMCN([FromBody] object request)
        {
            try
            {
      
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //var content = JsonConvert.SerializeObject(request);
    
                HttpResponseMessage response = client.PostAsync("api/User/AddUserMCN", new StringContent(JsonConvert.SerializeObject(request))).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    //return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                    return Content(HttpStatusCode.BadRequest, response.Content.ReadAsStringAsync().Result);
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }

        //Staff registration ACL tab end points

        /// <summary>
        ///  to get acl details
        /// </summary>
        /// <param name="Userid"></param>
        /// <param name="mode"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/user/ACLDetails/{Userid}/{mode}")]
        public IHttpActionResult GetACLDetails(long Userid, int mode)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/User/ACLDetails/" + Userid + "/" + mode).Result;
                if (response.IsSuccessStatusCode)
                {
                    return Ok(response.Content.ReadAsStringAsync().Result);
                }
                else
                {
                    return Content(HttpStatusCode.BadRequest, response.Content.ReadAsStringAsync().Result);
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }

        /// <summary>
        /// to save user acl details
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/user/ACLDetails")]
        public IHttpActionResult SaveUserACLDetails([FromBody] object request)
        {
            try
            {
     
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //  var content = JsonConvert.SerializeObject(request);
               
                HttpResponseMessage response = client.PostAsync("api/user/ACLDetails", new StringContent(JsonConvert.SerializeObject(request))).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    //return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                    return Content(HttpStatusCode.BadRequest, response.Content.ReadAsStringAsync().Result);
                }
            }
            catch (Exception ex) { throw ex; }
            finally {  }
        }
        #endregion

        #region LocationRegistration

        /// <summary>
        /// to get location details of given locationid
        /// </summary>
        /// <param name="locationId">mandatory</param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/location/{locationId}")]    
        
             
        public IHttpActionResult GetLocationDetails(int locationId)
        {
            HttpClient client;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/location/" + locationId).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(JObject.Parse(response.Content.ReadAsStringAsync().Result));

                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }

        /// <summary>
        /// to fetch location registration config data
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/location/LocationConfigData")]  
        public IHttpActionResult GetLocationConfigData()
        {
            HttpClient client;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/location/LocationConfigData").Result;

                if (response.IsSuccessStatusCode)
                    return Ok(JObject.Parse(response.Content.ReadAsStringAsync().Result));

                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }

        /// <summary>
        /// to reactive location
        /// </summary>
        /// <param name="locationId">mandatory</param>
        /// <param name="userId">mandatory</param>
        /// <returns></returns>
		[HttpPatch]
        [Route("apigateway/locationreactive/{locationId}/{userId}")]
        public IHttpActionResult ReactiveLocation(int locationId, int userId)
        {
            HttpClient client;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.SendAsync(new HttpRequestMessage(new HttpMethod("PATCH"), "api/location/" + locationId + "/" + userId)).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));

            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }

        /// <summary>
        /// to create a new location
        /// </summary>
        /// <param name="locationDetails">mandatory</param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/location/Savelocation")]
        
        
        public IHttpActionResult SaveLocationDetails([FromBody] object locationDetails)
        {
            HttpClient client;
            string LocationData = string.Empty;  
            HttpResponseMessage response = null;
            try
            {          
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.PostAsync("api/location", new StringContent(JsonConvert.SerializeObject(locationDetails))).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Content(HttpStatusCode.BadRequest, response.Content.ReadAsStringAsync().Result);

            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                LocationData = null;       
                response = null;       
            }

        }

        /// <summary>
        /// to inactivate location
        /// </summary>
        /// <param name="locationId">mandatory</param>
        /// <param name="userId">mandatory</param>
        /// <returns></returns>
        [HttpDelete]
        [Route("apigateway/location/{locationId}/{userId}")]
        
        
        public IHttpActionResult DeleteLocationDetails(int locationId, int userId)
        {
            HttpClient client;
            HttpResponseMessage response = null;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.DeleteAsync("api/location/" + locationId + "/" + userId).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Content(HttpStatusCode.BadRequest, response.Content.ReadAsStringAsync().Result);

            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }


        #endregion

        #region Locations
        /// <summary>
        /// to get locations
        /// </summary>
        /// <returns></returns>

        [HttpGet]
        [Route("apigateway/Locations")]
        
        public IHttpActionResult Locations()
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage response = client.GetAsync("api/v1.0/Locations").Result;
                if (response.IsSuccessStatusCode)
                {
                    //var data = response.Content.ReadAsAsync<IEnumerable<apigatewayController>>().Result;                    

                    JArray jsonArray = JArray.Parse(response.Content.ReadAsStringAsync().Result);

                    return Ok(jsonArray);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }
        #endregion

        #region Mcnmanagement
        /// <summary>
        /// to get mcn details
        /// </summary>
        /// <param name="mcnId">mandatory</param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/MCN/Details/{mcnId}")]
        
        
        public IHttpActionResult GetMcnManagementDetails(int mcnId)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/MCN/Details/" + mcnId).Result;
                if (response.IsSuccessStatusCode)
                {
                    return Ok(response.Content.ReadAsStringAsync().Result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex)
            {
                return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message));
            }
            finally { }
        }

        /// <summary>
        /// to delete MCN
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/MCN/InactivateMCN")]
        
        
        public IHttpActionResult DeleteMCN([FromBody] object request)
        {
            try
            {
    
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
               
                HttpResponseMessage response = client.PostAsync("api/MCN/Delete", new StringContent(JsonConvert.SerializeObject(request))).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    //return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                    return Content(HttpStatusCode.BadRequest, response.Content.ReadAsStringAsync().Result);
                }
            }
            catch (Exception ex) { return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message)); }
            finally {         }
        }
        /// <summary>
        /// to add mcn details
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/MCN")]
        
        
        public IHttpActionResult AddMCN([FromBody] object request)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage response = client.PostAsync("api/MCN/AddMCN", new StringContent(JsonConvert.SerializeObject(request))).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Content(HttpStatusCode.BadRequest, response.Content.ReadAsStringAsync().Result);
                }
            }
            catch (Exception ex) { return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message)); }
            finally { }
           
        }
        /// <summary>
        /// to check mcn cachement have patient or not
        /// </summary>
        /// <param name="catchments"></param>
        /// <param name="Id"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/MCN/CatchPatCount/{catchments}/{Id}")]
        
        
        public IHttpActionResult MCNCatchmentHavePatients(string catchments, int Id)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/MCN/CatchPatCount/" + catchments + "/" + Id).Result;
                if (response.IsSuccessStatusCode)
                {
                    return Ok(response.Content.ReadAsStringAsync().Result);
                }
                else
                {
                    return Content(HttpStatusCode.BadRequest, response.Content.ReadAsStringAsync().Result);
                }
            }
            catch (Exception ex) { return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message)); }
            finally { }
        }

        /// <summary>
        ///  to check mcn rol have paitent or not
        /// </summary>
        /// <param name="roles"></param>
        /// <param name="StaffId"></param>
        /// <param name="staffType"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/MCN/RolePatCount/{roles}/{StaffId}/{staffType}")]
        
        
        public IHttpActionResult MCNRoleHavePatients(string roles, long StaffId, int staffType)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/MCN/RolePatCount/" + roles + "/" + StaffId + "/" + staffType).Result;
                if (response.IsSuccessStatusCode)
                {
                    return Ok(response.Content.ReadAsStringAsync().Result);
                }
                else
                {
                    return Content(HttpStatusCode.BadRequest, response.Content.ReadAsStringAsync().Result);
                }
            }
            catch (Exception ex) { return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message)); }
            finally { }
        }

        /// <summary>
        /// to get default mcn configuration details
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>

        [HttpGet]
        [Route("apigateway/mcn/defaultconfiguration/{Userid}")]
        
        
        public IHttpActionResult GetMCNDefaultConfigurations(long userID)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/mcn/defaultconfiguration/" + userID).Result;
                if (response.IsSuccessStatusCode)
                {
                    return Ok(response.Content.ReadAsStringAsync().Result);
                }
                else
                {
                    return Content(HttpStatusCode.BadRequest, response.Content.ReadAsStringAsync().Result);
                }
            }
            catch (Exception ex) { return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message)); }
            finally { }
        }

        #endregion "mcnmanagement"

        #region AdhocReports


        /// <summary>
        /// to active patient details
        /// </summary>       
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/adhocreports/patients")]
        
        public IHttpActionResult GetActivePatients()
        {

            HttpClient client = new HttpClient();
            try
            {
                client.BaseAddress = new Uri("http://localhost:57573/");
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/adhocreports/patient").Result;
                if (response.IsSuccessStatusCode)
                {

                    JArray jsonArray = JArray.Parse(response.Content.ReadAsStringAsync().Result);
                    return Ok(jsonArray);
                }
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally { client = null; }


        }

        /// <summary>
        /// to get all patient details
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/adhocreports/patients/{startindex}/{endindex}")]
        
        public IHttpActionResult GetAllPatients(int startindex, int endindex)
        {

            HttpClient client = new HttpClient();
            try
            {
                client.BaseAddress = new Uri("http://localhost:57573/");
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/adhocreports/patient/" + startindex + "/" + endindex).Result;
                if (response.IsSuccessStatusCode)
                {

                    JArray jsonArray = JArray.Parse(response.Content.ReadAsStringAsync().Result);
                    return Ok(jsonArray);
                }
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally { client = null; }


        }

        /// <summary>
        /// to get all mcn details
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/adhocreports/mcnlist")]
        
        public IHttpActionResult GetMCNList()
        {
            HttpClient client = new HttpClient();
            try
            {
                client.BaseAddress = new Uri("http://localhost:57573/");
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/adhocreports/mcnlist").Result;
                if (response.IsSuccessStatusCode)
                {

                    JArray jsonArray = JArray.Parse(response.Content.ReadAsStringAsync().Result);
                    return Ok(jsonArray);
                }
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally { client = null; }
        }

        /// <summary>
        /// to get all patient address details
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/adhocreports/patientaddress")]
        
        public IHttpActionResult GetAllPatientAddress()
        {
            HttpClient client = new HttpClient();
            try
            {
                client.BaseAddress = new Uri("http://localhost:57573/");
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/adhocreports/patientaddress").Result;
                if (response.IsSuccessStatusCode)
                {

                    JArray jsonArray = JArray.Parse(response.Content.ReadAsStringAsync().Result);
                    return Ok(jsonArray);
                }
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally { client = null; }
        }

        /// <summary>
        /// to get specialform data based on given customformid
        /// </summary>
        /// <param name="formId">mandatory</param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/adhocreports/specialform/{formid}")]
        
        public IHttpActionResult GetSpecialFormData(long formId)
        {
            return Ok("");
        }

        /// <summary>
        /// to get contactanalysis specialform data        
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/adhocreports/contactanalysis")]
        
        public IHttpActionResult GetContactAnalysisData()
        {
            /*var formId = "1000";
            SELECT Patient.PAT_ID, Patient.PAT_Forename1, Patient.PAT_Surname,Patient.PAT_DOB, Patient.PAT_Primary_Identifier, Patient.PAT_Secondary_Identifier, tblPCF_1000.CFC100013 AS 'Time Started', tblPCF_1000.CFC100028 AS 'Logged in User', tblPCF_1000.ID AS 'Contact ID',
                 tblPCF_1000.CFC100625 AS 'Cause 1', tblPCF_1000.CFC100630 AS 'Cause2', tblPCF_1000.CFC100631 AS 'Cause 3', tblPCF_1000.CFC100632 AS 'Cause 4', tblUDFLookupValue.Description AS 'Type', tblUDFLookupValue_1.Description AS 'Prompt', tblUDFLookupValue_2.Description as 'Service Type'
            FROM tblPCF_1000 LEFT OUTER JOIN
           tblUDFLookupValue AS tblUDFLookupValue_2 ON tblPCF_1000.CFC101357 = tblUDFLookupValue_2.ID LEFT OUTER JOIN
           tblUDFLookupValue AS tblUDFLookupValue_1 ON tblPCF_1000.CFC100015 = tblUDFLookupValue_1.ID LEFT OUTER JOIN
           tblUDFLookupValue ON tblPCF_1000.CFC100016 = tblUDFLookupValue.ID LEFT OUTER JOIN
           Patient ON tblPCF_1000.Patient_ID = Patient.PAT_ID
            where tblPCF_1000.isactive = 1 and Patient.isactive = 1*/


            /*SELECT App.[id]       ,App.[pat_id]    ,App.[startdatetime]    ,CLN.CLN_Fname    ,CLN.CLN_SName    ,l1.Description    ,P.PAT_Forename1    ,P.PAT_Surname    ,l2.lookupValue
            ,G.Pat_ID
            ,P2.Pat_forename1, P2.PAT_Surname
            FROM[AdhocReportsDB_SBHS_PROD].[dbo].[tblApptSchedule] as App
            LEFT OUTER JOIN[AdhocReportsDB_SBHS_PROD].[dbo].[Clinician] as CLN ON App.clinician_id = CLN.CLN_ID
            LEFT OUTER JOIN[AdhocReportsDB_SBHS_PROD].[dbo].tblUDFLookupValue as l1 ON App.clinic_id = l1.id
            LEFT OUTER JOIN[AdhocReportsDB_SBHS_PROD].[dbo].Patient as P ON App.pat_id = P.Pat_id
            LEFT OUTER JOIN[AdhocReportsDB_SBHS_PROD].[dbo].tbllookup as l2 ON App.attendance_code_slu = l2.id
            LEFT OUTER JOIN[AdhocReportsDB_SBHS_PROD].[dbo].tblApptGroupPatient as G ON App.id = G.Appt_ID
            LEFT OUTER JOIN[AdhocReportsDB_SBHS_PROD].[dbo].Patient as P2 ON G.pat_id = P2.Pat_id*/
            return Ok("");
        }

        /// <summary>
        /// to get appointmentscheduler information    
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/adhocreports/apptmntscheduler")]
        
        public IHttpActionResult ApptSchedulerInfo()
        {

            HttpClient client = new HttpClient();
            try
            {
                client.BaseAddress = new Uri("http://localhost:57573/");
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/adhocreports/apptmntschedulerInfo").Result;
                //HttpResponseMessage response = client.GetAsync("api/adhocreports/apptmntschedulerInfo/" + startindex + "/" + endindex).Result;
                if (response.IsSuccessStatusCode)
                {

                    JArray jsonArray = JArray.Parse(response.Content.ReadAsStringAsync().Result);
                    return Ok(jsonArray);
                }
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally { client = null; }

        }

        #endregion

        #region Healthboard
        /// <summary>
        /// to get healthboard confi daa
        /// </summary>  
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/healthboard")]
        public IHttpActionResult GetHealthBoardConfigData()
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/healthboard").Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }

            }
            catch (Exception ex) { throw ex; }
            finally { }

        }

        /// <summary>
        /// to get health board details for the given healthBoardId
        /// </summary>
        /// <param name="healthBoardId">mandatory</param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/healthboard/{healthBoardId}")]
        
        public IHttpActionResult GethealthBoardId(int healthBoardId)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/healthboard/" + healthBoardId).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }

            }
            catch (Exception ex) { throw ex; }
            finally { }

        }

        /// <summary>
        /// to save healhtboard details 
        /// </summary>
        /// <param name="request">mandatory</param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/healthboard")]
        public IHttpActionResult SaveHealthBoard([FromBody] object request)
        {
            string HealthBoardData = string.Empty;
            HttpClient client = null;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();            
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
     
                response = client.PostAsync("api/healthboard", new StringContent(JsonConvert.SerializeObject(request))).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                HealthBoardData = null;        
                client = null;
                response = null;        
            }
        }
        /// <summary>
        /// delete healtbord  for the given healthBoardId and user id
        /// </summary>
        /// <param name="healthBoardId">mandatory</param>
		/// <param name="userId">mandatory</param>
        /// <returns></returns>
        [HttpDelete]
        [Route("apigateway/healthboard/{healthBoardId}/{userId}")]
        
        
        public IHttpActionResult DeleteHealthBoard(int healthBoardId, int userId)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.DeleteAsync("api/healthboard/" + healthBoardId + "/" + userId).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }
        /// <summary>
        /// to reactivate healthboard
        /// </summary>
        /// <param name="healthBoardId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        [HttpPatch]
        [Route("apigateway/healthboard/{healthBoardId}/{userId}")]
        
        
        public IHttpActionResult ReactiveHealthBoard(int healthBoardId, int userId)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.SendAsync(new HttpRequestMessage(new HttpMethod("PATCH"), "api/healthboard/" + healthBoardId + "/" + userId)
                {
                    Content = null
                }).Result;

                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }
        #endregion

        #region SecurityGroup
        /// <summary>
        /// to get securitygroup details
        /// </summary>
        /// <param name="securityGroup_Id">mandatory</param>
        /// <param name="strType">mandatory</param>
        /// <param name="intParentModule_Id">mandatory</param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/SecurityGroup/{securityGroup_Id}/{strType}/{intParentModule_Id}")]
        
     
        
        public IHttpActionResult GetSecurityGroups(int securityGroup_Id, string strType, int intParentModule_Id)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/SecurityGroup/" + securityGroup_Id + "/" + strType + "/" + intParentModule_Id).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }

            }
            catch (Exception ex) { throw ex; }
            finally { }

        }

        /// <summary>
        /// save  SecurityGroup
        /// </summary>
        /// <param name="request">mandatory</param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/SecurityGroup")]
        
        
        public IHttpActionResult SaveSecurityGroups([FromBody] object request)
        {
            try
            {
                string securityGroupsData = string.Empty;
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage response = client.PostAsync("api/SecurityGroup", new StringContent(JsonConvert.SerializeObject(request))).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
           
        }



        /// <summary>
        /// delete SecurityGroup for the groupId and userId
        /// </summary>
        /// <param name="groupId">mandatory</param>
		/// <param name="userId">mandatory</param>
        /// <returns></returns>
        [HttpDelete]
        [Route("apigateway/SecurityGroup/{groupId}/{userId}")]
        
        
        public IHttpActionResult DeleteSecurityGroup(int groupId, int userId)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.DeleteAsync("api/SecurityGroup/" + groupId + "/" + userId).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }
        #endregion

        #region AclGroup
        /// <summary>
        /// getting acl group details
        /// </summary>
        /// <param name="groupId"></param>
        /// <returns></returns>

        [HttpGet]
        [Route("apigateway/aclGroup/{groupId}")]
        
     
        
        public IHttpActionResult GetAclGroupDetails(Int64 groupId)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/AclGroup/" + groupId).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }

            }
            catch (Exception ex) { throw ex; }
            finally { }

        }
        /// <summary>
        /// to validate acl group
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/validateaclgroup")]
        
     
        
        public IHttpActionResult ValidateACLGroup([FromBody] object request)
        { 
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                              HttpResponseMessage response = client.PostAsync("api/ValidateACLGroup", new StringContent(JsonConvert.SerializeObject(request))).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
             
            }

        }
        /// <summary>
        /// to delete ACL group
        /// </summary>
        /// <param name="groupId"></param>
        /// <returns></returns>
        [HttpDelete]
        [Route("apigateway/aclgroup/{groupId}")]
        
        
        public IHttpActionResult DeleteACLGroup(Int64 groupId)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.DeleteAsync("api/aclgroup/" + groupId).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }
        /// <summary>
        /// to save acl details
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/aclgroup")]
        
     
        
        public IHttpActionResult SaveAclDetails([FromBody] object request)
        {

            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

               
                HttpResponseMessage response = client.PostAsync("api/AclGroup", new StringContent(JsonConvert.SerializeObject(request))).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }
        /// <summary>
        /// to save acl staff
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>

        [HttpPost]
        [Route("apigateway/aclstaff")]
        
     
        
        public IHttpActionResult SaveAclStaffDetails([FromBody] object request)
        {

            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
               
                HttpResponseMessage response = client.PostAsync("api/AclStaff", new StringContent(JsonConvert.SerializeObject(request))).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { }

        }
        /// <summary>
        /// to save acl patient
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/aclpatient")]
        
     
        
        public IHttpActionResult SaveAclPatientDetails([FromBody] object request)
        {
  
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                // var myContent = JsonConvert.SerializeObject(request);
               
                HttpResponseMessage response = client.PostAsync("api/AclPatient", new StringContent(JsonConvert.SerializeObject(request))).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally {  }
        }

        #endregion AclGroup

        #region PatientMerge
        /// <summary>
        /// to merge patient  
        /// </summary>
        /// <param name="request">mandatory</param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/Merge")]
        
        
        public IHttpActionResult Merge([FromBody] object request)
        {
            try
            {
                HttpClient client = new HttpClient();      
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
               
                HttpResponseMessage response = client.PostAsync("api/Merge", new StringContent(JsonConvert.SerializeObject(request))).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(JObject.Parse(result));
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }

        /// <summary>
        /// to unmerge patient  
        /// </summary>
        /// <param name="request">mandatory</param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/Unmerge")]
        
        
        public IHttpActionResult Unmerge([FromBody] object request)
        {
            try
            {
                HttpClient client = new HttpClient();    
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
               
                HttpResponseMessage response = client.PostAsync("api/Unmerge", new StringContent(JsonConvert.SerializeObject(request))).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = JsonConvert.DeserializeObject(response.Content.ReadAsStringAsync().Result);
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }

        /// <summary>
        /// to get merge and unmerge data  
        /// </summary>   
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/mergeunmerge")]
        
        
        public IHttpActionResult GetMergeUnMergeData()
        {
            try
            {

                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/mergeunmerge").Result;
                if (response.IsSuccessStatusCode)
                {

                    //return Ok(response.Content.ReadAsStringAsync().Result);
                    var result = JsonConvert.DeserializeObject(response.Content.ReadAsStringAsync().Result);
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }
        /// <summary>
        /// to get identifier data
        /// </summary>
        /// <returns></returns>

        [HttpGet]
        [Route("apigateway/identifier")]
        
        
        public IHttpActionResult GetIdentifierData()
        {
            try
            {

                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/identifier").Result;
                if (response.IsSuccessStatusCode)
                {

                    var result = JsonConvert.DeserializeObject(response.Content.ReadAsStringAsync().Result);
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }
        #endregion

        #region CapabilityManagement
        /// <summary>
        /// to get Capability Based on id
        /// </summary>
        /// <param name="capability_id">mandatory</param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/capabilitymanagement/{capability_id}")]
        
        
        public IHttpActionResult ListofCapabilities(long capability_id)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(strApiUrl);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.GetAsync("api/capabilitymanagement/get/" + capability_id).Result;
            if (response.IsSuccessStatusCode)
            {
                return Ok(JObject.Parse(response.Content.ReadAsStringAsync().Result));
            }
            else
            {
                return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
        }

        /// <summary>
        /// to check duplicate prescribercode
        /// </summary>
        /// <param name="prescberCode"></param>
        /// <param name="userId"></param>
        /// <returns></returns>

        [HttpGet]
        [Route("apigateway/checkduplicateprescribercode/{prescberCode}/{userId}")]
        
        
        public IHttpActionResult GetCapabilities(long prescberCode, long userId)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(strApiUrl);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.GetAsync("api/usercapability/checkduplicateprescribercode/" + prescberCode + "/" + userId).Result;
            if (response.IsSuccessStatusCode)
            {
                return Ok(JObject.Parse(response.Content.ReadAsStringAsync().Result));
            }
            else
            {
                return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
        }


        /// <summary>
        /// to get capabilities
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/capabilitymanagement")]
        
        
        public IHttpActionResult GetCapabilities()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(strApiUrl);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.GetAsync("api/capabilitymanagement/get").Result;
            if (response.IsSuccessStatusCode)
            {

                return Ok(JObject.Parse(response.Content.ReadAsStringAsync().Result));
            }
            else
            {
                return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
        }

        /// <summary>
        /// to get user capabilities
        /// </summary>
        /// <param name="uId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/usercapability/{uId}")]
        
        
        public IHttpActionResult GetUserCapability(long uId)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(strApiUrl);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.GetAsync("api/capabilitymanagement/usercapability/" + uId).Result;
            if (response.IsSuccessStatusCode)
            {
                return Ok(JObject.Parse(response.Content.ReadAsStringAsync().Result));
            }
            else
            {
                return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }

        }

        /// <summary>
        /// to add capabilitymanagement
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/capabilitymanagementadd")]
        
        
        public IHttpActionResult SaveCapabilities([FromBody] object request)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage response = client.PostAsync("api/capabilitymanagement/add", new StringContent(JsonConvert.SerializeObject(request))).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { }         

        }

        /// <summary>
        /// to delete capability
        /// </summary>
        /// <param name="objDeleteInfo">mandatory</param>
        /// <returns></returns>
        [HttpDelete]
        [Route("apigateway/capabilitymanagementdelete")]
        
        public IHttpActionResult DeleteCapabilities([FromBody] object objDeleteInfo)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                
                HttpResponseMessage response = client.SendAsync(new HttpRequestMessage(new HttpMethod("DELETE"), "api/capabilitymanagement/delete")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(objDeleteInfo))
                }).Result;

                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(JObject.Parse(result));
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
       
            }
        }
        #endregion

        #region NHSTrust 

        /// <summary>
        /// to get configuration date for health board
        /// </summary>     
        /// <returns></returns>
        /// 
        [HttpGet]
        [Route("apigateway/nhstrust")]
        public IHttpActionResult GetNHSTrustConfigData()
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/nhstrust").Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }

            }
            catch (Exception ex) { throw ex; }
            finally { }

        }
        /// <summary>
        /// to get nhstrust details
        /// </summary>
        /// <param name="nhsId">mandatory</param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/nhstrust/{nhsId}")]
        public IHttpActionResult GetNHSTrustDetails(int nhsId)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/nhstrust/" + nhsId).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }

            }
            catch (Exception ex) { throw ex; }
            finally { }

        }
       /// <summary>
       /// to save nhstrust details
       /// </summary>
       /// <param name="request"></param>
       /// <returns></returns>
        [HttpPost]
        [Route("apigateway/nhstrust")]
        public IHttpActionResult SaveNHSTrustDetails([FromBody] object request)
        {
            string NHSTrustData = string.Empty;
            HttpClient client = null;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();          
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                
                response = client.PostAsync("api/nhstrust", new StringContent(JsonConvert.SerializeObject(request))).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                NHSTrustData = null;       
                client = null;
                response = null;      
            }
        }
        /// <summary>
        /// delete healtbord  for the given healthBoardId and user id
        /// </summary>
        /// <param name="nhsTrustId">mandatory</param>
		/// <param name="userId">mandatory</param>
        /// <returns></returns>
        [HttpDelete]
        [Route("apigateway/nhstrust/{nhsTrustId}/{userId}")]
        
        
        public IHttpActionResult DeleteNHSTrustDetails(int nhsTrustId, int userId)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.DeleteAsync("api/nhstrust/" + nhsTrustId + "/" + userId).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }
        /// <summary>
        /// to reactive nhstrust
        /// </summary>
        /// <param name="nhsTrustId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        [HttpPatch]
        [Route("apigateway/nhstrust/{nhsTrustId}/{userId}")]
        
        
        public IHttpActionResult ReactiveNHSTrustDetails(int nhsTrustId, int userId)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.SendAsync(new HttpRequestMessage(new HttpMethod("PATCH"), "api/nhstrust/" + nhsTrustId + "/" + userId)
                {
                    Content = null
                }).Result;

                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }
        #endregion

        #region DictioinaryManagement

        /// <summary>
        /// to get all dictionary details
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/dictionaries")]
        
        
        
     
        //[Throttle("GetListOfUsers", "", 20)]
        public IHttpActionResult GetListofDictionares()
        {
            HttpClient client;
            HttpResponseMessage response;
            JArray jsonArray;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/dictionaries").Result;
                if (response.IsSuccessStatusCode)
                {
                    jsonArray = JArray.Parse(response.Content.ReadAsStringAsync().Result);
                    return Ok(jsonArray);
                }
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
                jsonArray = null;
            }
        }

        /// <summary>
        /// to get dictionary editor information
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/dictionaryeditor/{dictID}")]
        
        
        
     
        //[Throttle("GetListOfUsers", "", 20)]
        public IHttpActionResult GetDictionaryInfo(int dictID)
        {
            HttpClient client;
            HttpResponseMessage response;
            //JArray jsonArray;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/dictionaryeditor/" + dictID).Result;
                if (response.IsSuccessStatusCode)
                {
                    // jsonArray = JArray.Parse(response.Content.ReadAsStringAsync().Result);
                    return Ok(response.Content.ReadAsStringAsync().Result);
                }
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
                //jsonArray = null;
            }
        }

        /// <summary>
        /// to save dictionary data
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/dictionaryeditor/{dictID}")]
        
        
        
     
        //[Throttle("GetListOfUsers", "", 20)]
        public IHttpActionResult SaveDictionaryData(int dictID, [FromBody] object objDictData)
        {
            HttpClient client;
            HttpResponseMessage response;
            StringContent DataContent = null;      
            string strDictData = "";
            try
            {
                client = new HttpClient();
                DataContent = new StringContent(strDictData, UnicodeEncoding.UTF8, "application/json");
                response = client.PostAsync("api/dictionaryeditor/" + dictID, DataContent).Result;
                if (response.IsSuccessStatusCode)
                {
                    //jsonArray = JArray.Parse(response.Content.ReadAsStringAsync().Result);
                    return Ok(response.Content.ReadAsStringAsync().Result);
                }
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }

        /// <summary>
        /// to inactivate/ reactivate dictionary data
        /// </summary>
        /// <param name="objDeleteInfo"></param>
        /// <returns></returns>
        [HttpDelete]
        [Route("apigateway/dictionary")]
        
        
        
        public IHttpActionResult DeleteorReactiveDictData([FromBody] object objDeleteInfo)
        {
            HttpClient client = null;
            HttpResponseMessage response;
            string deleteInfo = string.Empty;
            try
            {
                client = new HttpClient(); 
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
               
                response = client.SendAsync(new HttpRequestMessage(new HttpMethod("DELETE"), "api/dictionary")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(objDeleteInfo))
                }).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
                deleteInfo = null;            
 
            }
        }

        /// <summary>
        /// to get dictionary dependencies
        /// </summary>
        /// <param name="dictID"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/dictionarydependencies/{dictID}")]
        
        
        
     
        //[Throttle("GetListOfUsers", "", 20)]
        public IHttpActionResult GetDictionaryDependencies(int dictID)
        {
            HttpClient client;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/dictionarydependencies/" + dictID).Result;
                if (response.IsSuccessStatusCode)

                    return Ok(response.Content.ReadAsStringAsync().Result);

                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }

        #endregion

        #region Tasklist
        /// <summary>
        /// to fetch Task Management details
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/taskmanagement")]
        
        
        
     
        public IHttpActionResult GetTaskManagementDetails()
        {
            HttpClient client;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/taskmanagement").Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);

                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }

        /// <summary>
        /// to fetch Task Management config data
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/taskmanagementconfigdata")]
        
        
        
     
        public IHttpActionResult GetTaskManagementConfigData()
        {
            HttpClient client;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/taskmanagementconfigdata").Result;

                if (response.IsSuccessStatusCode)
                    return Ok(JObject.Parse(response.Content.ReadAsStringAsync().Result));

                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }

            finally
            {
                client = null;
                response = null;
            }
        }


        /// <summary>
        /// to create a new Task Management Details
        /// </summary>
        /// <param name="tasklistManagementDetails">mandatory</param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/taskmanagement")]
        
        
        public IHttpActionResult SaveTaskManagementDetails([FromBody] object tasklistManagementDetails)
        {
            HttpClient client;
            string TasklistManagementData = string.Empty;
            StringContent TasklistManagementDataContent = null;
            HttpResponseMessage response = null;
            try
            {

                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
               
                response = client.PostAsync("api/taskmanagement", TasklistManagementDataContent).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Content(HttpStatusCode.BadRequest, response.Content.ReadAsStringAsync().Result);

            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                TasklistManagementData = null;
                TasklistManagementDataContent = null;
                response = null;

            }

        }
        /// <summary>
        /// to inactivate Task Management
        /// </summary>
        /// <param name="objDeleteInfo">mandatory</param>
        /// <returns></returns>
        [HttpDelete]
        [Route("apigateway/taskmanagement")]
        
        
        public IHttpActionResult DeleteTaskManagementDetails([FromBody] object objDeleteInfo)
        {
            HttpClient client = null;
            HttpResponseMessage response;
            string deleteInfo = string.Empty;
            try
            {
                client = new HttpClient();        
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
               
                response = client.SendAsync(new HttpRequestMessage(new HttpMethod("DELETE"), "api/taskmanagement")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(objDeleteInfo))
                }).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
                deleteInfo = null;
     
            }
        }

        /// <summary>
        /// to get all the task list summary details
        /// </summary>
        /// <param name="userId">Login User Id</param> 
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/taskslist/{userId}")]
        
        
        
        public IHttpActionResult GetTasksList(long userId)
        {
            HttpClient client;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/taskslist/" + userId).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }

        /// <summary>
        /// to get all the Lookups and Config data for Task List
        /// </summary>
        /// <param name="userId">Login User Id</param>     
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/tasklistconfig/{userId}")]
        
        
        
        public IHttpActionResult GetTaskListConfigData(long userId)
        {
            HttpClient client;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/tasklistconfig/" + userId).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }

        /// <summary>
        /// to get the given task list id details
        /// </summary>
        /// <param name="taskListId">selected task list id</param>    
        /// <param name="userId">Login User Id</param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/tasklist/{taskListId}/{userId}")]
        
        
        
        public IHttpActionResult GetTaskListDetails(int taskListId, long userId)
        {
            HttpClient client;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/tasklist/" + taskListId + "/" + userId).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }

        /// <summary>
        /// to save the given Task List Details
        /// </summary>
        /// <param name="objTaskListDetails">Task List Details to save</param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/tasklist")]
        
        
        public IHttpActionResult SaveTaskListDetails([FromBody] object objTaskListDetails)
        {
            HttpClient client;
            HttpResponseMessage response; 
   
            try
            {                  
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.PostAsync("api/tasklist", new StringContent(JsonConvert.SerializeObject(objTaskListDetails))).Result;
                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;             
        
            }
        }

        /// <summary>
        /// to delete the given Task List Details
        /// </summary>
        /// <param name="objTaskListDelete">Task List Ids and Other Information to delete</param>
        /// <returns></returns>
        [HttpDelete]
        [Route("apigateway/tasklist")]
        
        
        
        public IHttpActionResult DeleteTaskListDetails([FromBody] object objTaskListDelete)
        {
            HttpClient client = null;
            HttpResponseMessage response;
            string deleteInfo = string.Empty; 
            try
            {
                               
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));               
                response = client.SendAsync(new HttpRequestMessage(new HttpMethod("DELETE"), "api/tasklist")
                {
                    Content = new StringContent(JsonConvert.SerializeObject(objTaskListDelete))
                }).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
                deleteInfo = null;           
            
            }
        }

        /// <summary>
        /// to update the Notes for selected Task List
        /// </summary>
        /// <param name="objTaskListNotes">Task List Notes Details to save</param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/tasklistnotes")]
        
        
        public IHttpActionResult UpdateTaskListNotes([FromBody] object objTaskListNotes)
        {
            HttpClient client;
            HttpResponseMessage response;  
            try
            {       
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
               
                response = client.PostAsync("api/tasklistnotes", new StringContent(JsonConvert.SerializeObject(objTaskListNotes))).Result;
                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
       
            }
        }

        /// <summary>
        /// to  update the Task List Status for the Selected Task Lists
        /// </summary>
        /// <param name="objTaskListStatus">Task List Status Detaisl to save</param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/taskliststatus")]
        
        
        public IHttpActionResult UpdateTaskListStatus([FromBody] object objTaskListStatus)
        {
            HttpClient client;
            HttpResponseMessage response;
            StringContent taskListStatusContent = null;
            string strTaskListStatus = "";
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                taskListStatusContent = new StringContent(strTaskListStatus, UnicodeEncoding.UTF8, "application/json");
                response = client.PostAsync("api/taskliststatus", new StringContent(JsonConvert.SerializeObject(objTaskListStatus))).Result;
                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
                taskListStatusContent = null;            
                strTaskListStatus = null;
            }
        }
        #endregion

        #region BTAPI
        /// <summary>
        /// to update SMS delivery status via BT API Webhook triggering event
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/btapi/response")]
       
        public IHttpActionResult UpdateBTMessageStatus(HttpRequestMessage request)
        {
            object _logBody;
            try
            {
                _logBody = JsonConvert.SerializeObject(new
                {
                    modulename = "UpdateBTMessageStatus",
                    sessionid = "",
                    patid = -1,
                    event_slu = 2798,
                    eventdetails = "BT message status started.",
                    moduleid = 152,
                    recordid = -1,
                    requestid = ""
                });
                SessionLogger(_logBody);
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var receivedBody = request.Content.ReadAsStringAsync().Result;
                _logBody = JsonConvert.SerializeObject(new
                {
                    modulename = "UpdateBTMessageStatus",
                    sessionid = "",
                    patid = -1,
                    event_slu = 2798,
                    eventdetails = $"Request body: {receivedBody}",
                    moduleid = 152,
                    recordid = -1,
                    requestid = ""
                });
                SessionLogger(_logBody);
                var stringContent = new StringContent(receivedBody, UnicodeEncoding.UTF8, "application/json");
                HttpResponseMessage response = client.PostAsync("api/messaging/smsstatus", stringContent).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    _logBody = JsonConvert.SerializeObject(new
                    {
                        modulename = "UpdateBTMessageStatus",
                        sessionid = "",
                        patid = -1,
                        event_slu = 2798,
                        eventdetails = $"Response body: {result}",
                        moduleid = 152,
                        recordid = -1,
                        requestid = ""
                    });
                    SessionLogger(_logBody);
                    return Ok(result);
                }
                else
                {
                    _logBody = JsonConvert.SerializeObject(new
                    {
                        modulename = "UpdateBTMessageStatus",
                        sessionid = "",
                        patid = -1,
                        event_slu = 2798,
                        eventdetails = "Facing an issue while getting response. Please contact administrator.",
                        moduleid = 152,
                        recordid = -1,
                        requestid = ""
                    });
                    SessionLogger(_logBody);
                    return Content(response.StatusCode, response.Content); // "Facing an issue while getting response. Please contact administrator.");
                }
            }
            catch (Exception ex)
            {
                _logBody = JsonConvert.SerializeObject(new
                {
                    modulename = "UpdateBTMessageStatus",
                    sessionid = "",
                    patid = -1,
                    event_slu = 2798,
                    eventdetails = $"{ex.Message}\n{ex.StackTrace}",
                    moduleid = 152,
                    recordid = -1,
                    requestid = ""
                });
                SessionLogger(_logBody);
                return Content(HttpStatusCode.InternalServerError, "Some thing went wrong. Please contact administrator.");
                //return InternalServerError(ex);
            }
            finally
            {

            }
        }
       
        #endregion

        #region Common 
        /// <summary>
        /// to fetch configuration date for health board
        /// </summary>       
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/print")]
           
        
        public IHttpActionResult GetSessionTokenData()
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                var accessToken = this.Request.Headers.GetValues("token").First();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("Token", accessToken);
                HttpResponseMessage response = client.GetAsync("api/common/print").Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }

            }
            catch (Exception ex) { throw ex; }
            finally { }

        }
        /// <summary>
        /// to sendFax
        /// </summary>
        /// <param name="moduleId"></param>
        /// <param name="recordIds"></param>
        /// <param name="convertToPdf"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/faxdocument/{recordIds}/{moduleId}/{convertToPdf}")]
        
        
        public IHttpActionResult sendFax(int moduleId, string recordIds, Boolean convertToPdf)
        {
            HttpClient client;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/faxdocument/" + recordIds + "/" + moduleId + "/" + convertToPdf).Result;

                if (response.IsSuccessStatusCode)
                {
                    return Ok(response.Content.ReadAsStringAsync().Result);
                }
                else
                {
                    return Content(HttpStatusCode.BadRequest, response.Content.ReadAsStringAsync().Result);
                }

            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null; ;
                response = null;
            }
        }
        /// <summary>
        /// to get dateFormats from tblsysLookup DB object
        /// created by: BRR
        /// created datetime: 21-Nov-2023 12:55PM
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/dateFormats")]
        public string getdateFormats()
        {
            try
            {
                //BizFramework objbizExcelicareFramework = new BizFramework();
                string strUpdatedValues = "";// objbizExcelicareFramework.getDateFormats();
                return "function ax_dtFrmt() { " + strUpdatedValues.ToString() + "}";
            }
            catch (Exception ex) { return ex.Message; }
            finally { }
        }

        /// <summary>
        /// to post errorlog details into log file
        /// created by: BRR
        /// created datetime: 21-Nov-2023 12:55PM
        /// </summary>
        ///<param name="objLogDetails">{"module": "Special Forms","sessionId": "violxrhodxgxpftjrdg2uur1","patId": -1,"userid": 2039,"logmessage": "onLoading..throwing exception"}</param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/log/errorlogger")]
        public void ErrorLogging([FromBody] object objLogDetails)
        {
            //log4net.Config.XmlConfigurator.Configure(new FileInfo(System.Web.HttpContext.Current.Server.MapPath("../../log4net.config")));
            JObject jLogInfo;
            try
            {
                jLogInfo = JObject.Parse(objLogDetails.ToString());
                //log.Error(jLogInfo.ToString());           
            }
            catch (Exception ex)
            {
          InternalServerError(ex);
            }
            finally
            {
                jLogInfo = null;
            }
        }
        /// <summary>
        /// to post information(trace) log details into log file
        /// created by: BRR
        /// created datetime: 21-Nov-2023 12:55PM
        /// </summary>     
        ///<param name="objLogDetails">{"module": "Special Forms","sessionId": "violxrhodxgxpftjrdg2uur1","patId": -1,"userid": 2039,"logmessage": "onLoading..throwing exception"}</param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/log/infologger")]
        public void InfoLogging([FromBody] object objLogDetails)
        {
            //log4net.Config.XmlConfigurator.Configure(new FileInfo(System.Web.HttpContext.Current.Server.MapPath("../../log4net.config")));
            JObject jLogInfo;
            try
            {
                jLogInfo = JObject.Parse(objLogDetails.ToString());
                //log.Info(jLogInfo.ToString());
            }
            catch (Exception ex)
            {
                InternalServerError(ex);
            }
            finally
            {
                jLogInfo = null;
            }
        }

        /// <summary>
        /// to post the debug statements into log file
        /// created by: BRR
        /// created datetime: 21-Nov-2023 12:55PM
        /// </summary>
        ///<param name="objLogDetails">{"module": "MCN Management","sessionId": "violxrhodxgxpftjrdg2uur1","patId": -1,"userid": 2039,"logmessage": "onLoading..throwing exception"}</param>
        /// <returns></returns>

        [HttpPost]
        [Route("apigateway/log/debuglogger")]
        public void DebugLogging([FromBody] object objLogDetails)
        {
            //log4net.Config.XmlConfigurator.Configure(new FileInfo(System.Web.HttpContext.Current.Server.MapPath("../../log4net.config")));
            JObject jLogInfo;
            try
            {

                jLogInfo = JObject.Parse(objLogDetails.ToString());
                //log.Debug(jLogInfo.ToString());
            }
            catch (Exception ex)
            {
                InternalServerError(ex);
            }
            finally
            {
                jLogInfo = null;
            }
        }
        /// <summary>
        /// to post client session log 
        /// </summary>
        /// <param name="objJson">{"ModuleName": "MCN Management","sessionId": "violxrhodxgxpftjrdg2uur1","patId": -1,"eventSLu": 2039,"eventDetails": "onLoading..","moduleId": 1009,"recordId": -1,"requestId": ""}</param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/log/sessionlogger")]
        public void SessionLogger([FromBody] object objJson)
        {
            JObject jLogInfo;
            try
            {
                jLogInfo = JObject.Parse(objJson.ToString());//JObject.FromObject((JObject)objJson);
                //clsECSession.LogWebSessionAction((string)jLogInfo["modulename"], (string)jLogInfo["sessionid"], (int)jLogInfo["patid"], (int)jLogInfo["event_slu"], (string)jLogInfo["eventdetails"], (int)jLogInfo["moduleid"], (int)jLogInfo["recordid"], (string)jLogInfo["requestid"]);
               
            }
            catch (Exception ex)
            {
                 InternalServerError(ex);
            }
            finally
            {
                jLogInfo = null;
            }
        }

        #endregion

        #region TokenGeneration

        /// <summary>
        ///  to register user into Excelicare
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>

        [HttpPost]
        [Route("apigateway/register")]
        public IHttpActionResult Register(UserDetails request)
        {    
            HttpClient client = null;
            HttpResponseMessage response;

            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var content = new StringContent(JsonConvert.SerializeObject(request).ToString(), Encoding.UTF8, "application/json");             
                response = client.PostAsync("api/register", content).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { return InternalServerError(ex); }
            finally { }
      

        }
        /// <summary>
        /// to get refreshtoken
        /// </summary>
        /// <param name="request">mandatory</param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/refreshtoken")]

        public IHttpActionResult RefreshToken(UserDetails request)
        {
            HttpClient client = null;
            HttpResponseMessage response;

            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var content = new StringContent(JsonConvert.SerializeObject(request).ToString(), Encoding.UTF8, "application/json");
                response = client.PostAsync("api/register", content).Result;           
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { return InternalServerError(ex); }
            finally { }
     

        }
        /// <summary>
        /// to check token expiry
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/istokenexpired")]
        public IHttpActionResult IsTokenExpired([FromBody] string token)
        {

            HttpClient client = null;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var content = new StringContent(JsonConvert.SerializeObject(token).ToString(), Encoding.UTF8, "application/json");
                response = client.PostAsync("api/istokenexpired", content).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { return InternalServerError(ex); }
            finally { }

        }

        #endregion
    }
}
