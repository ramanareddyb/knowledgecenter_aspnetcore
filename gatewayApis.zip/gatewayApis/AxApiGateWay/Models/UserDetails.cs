﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;

namespace AxApigateway.Models
{
    /// <summary>
    ///  UserDetails class
    /// </summary>
    public class UserDetails
    {
        /// <summary>
        /// Username
        /// </summary>
        public string Username { get; set; }
        /// <summary>
        /// Password
        /// </summary>
        public string Password { get; set; }
        /// <summary>
        /// resource
        /// </summary>
        public string resource { get; set; }
        /// <summary>
        /// EcKey
        /// </summary>
		public string EcKey { get; set; }
        
    }
}