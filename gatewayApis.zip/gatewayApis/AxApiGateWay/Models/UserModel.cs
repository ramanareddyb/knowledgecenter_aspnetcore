﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using Newtonsoft.Json.Linq;
using System.IO;

namespace AxApigateway.Models
{
    /// <summary>
    /// UserModel class to hold user object and required properties and methods as part of token generation
    /// Created By  : BRR
    /// Created Date: 2022-01-08
    /// </summary>
    public class UserModel
    {
        /// <summary>
        /// Username
        /// </summary>
        public string Username { get; set; }
        /// <summary>
        /// Password
        /// </summary>
        public string Password { get; set; }
        /// <summary>
        /// EmailAddress
        /// </summary>
        public string EmailAddress { get;set; }
        /// <summary>
        /// DateOfRegistered
        /// </summary>
        public DateTime DateOfRegistered { get; set; }


    }


}
