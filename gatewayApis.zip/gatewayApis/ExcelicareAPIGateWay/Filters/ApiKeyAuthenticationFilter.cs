﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace ExcelicareAPIGateWay.Filters
{
    /// <summary>
    /// Api Key checking as part of web api authentication
    /// Created By  : BRR
    /// Created Date: 01-07-2022
    /// </summary>
    public class ApiKeyAuthenticationFilter : ActionFilterAttribute
    {
        const string APIKEY = "Api_Key";
        /// <summary>
        /// Validating api_key token passing through request header
        /// </summary>
        /// <param name="actionContext">mandatory</param>
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            if (!actionContext.Request.Headers.TryGetValues(APIKEY, out
                var extractedApiKey))
            {
                actionContext.Response = actionContext.Request.CreateResponse(System.Net.HttpStatusCode.Unauthorized,"Invalid Authorization.");
                return;
            }

            var apiKey = ConfigurationManager.AppSettings["Api_Key"];

            if (!apiKey.Equals(extractedApiKey.ToArray()[0]))
            {
                actionContext.Response = actionContext.Request.CreateResponse(System.Net.HttpStatusCode.Unauthorized,"Invalid API Key.");
                return;
            }
            else
            {
                base.OnActionExecuting(actionContext);
            }
        }
    }
}