﻿using ExcelicareAPIGateWay.Filters;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace ExcelicareAPIGateWay.Filters
{
    /// <summary>
    /// request validation class
    /// </summary>
    public class RequestValidation : ActionFilterAttribute
    {
        /// <summary>
        /// Web Api Request Uri Query parameters and Body Parameter values checking as part of security
        /// Created By   : BRR
        /// Created Date : 2022-01-07
        /// </summary>
        /// <param name="actionContext"></param>
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            if (actionContext.ModelState.IsValid == false)
                actionContext.Response = actionContext.Request.CreateErrorResponse(HttpStatusCode.BadRequest, actionContext.ModelState);

           if(actionContext.Request.RequestUri.ToString()!="")
            {
                SecurityCheck objSecuritycheck = new SecurityCheck();

                // Request Uri Query parameters validation
                var blnValid = objSecuritycheck.SecurityValidations(actionContext.Request.RequestUri.PathAndQuery);

                // Request Body inputdata validation
                var requestBody = JsonConvert.SerializeObject(actionContext.ActionArguments);
                blnValid = objSecuritycheck.SecurityValidations(requestBody);


                if (blnValid)
                {
                    actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.BadRequest, "Invalid InputData");
                    return;
                }
                else
                {
                    base.OnActionExecuting(actionContext);
                }


                //var request = actionContext.Request;
                //var stream = new StreamReader(request.Content.);
                //var body = stream.ReadToEnd();

            }
        }

    }
}