﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http.Filters;

namespace ExcelicareAPIGateWay.Filters
{
    /// <summary>
    /// Handling Exceptions from single place for all controller endpoints
    /// Created By  : BRR
    /// Created Date: 2022-01-07
    /// </summary>
    public class ExceptionHandler : ExceptionFilterAttribute
    {
        /// <summary>
        /// OnException will verify for every call to controller endpoint
        /// </summary>
        /// <param name="actionContext"></param>
        public override void OnException(HttpActionExecutedContext actionContext)
        {
            actionContext.Response = actionContext.Request.CreateErrorResponse(HttpStatusCode.InternalServerError, actionContext.Exception.Message); // New HttpResponseMessage(HttpStatusCode.NotImplemented, actionContext.Exception.Message)
        }

    }
}