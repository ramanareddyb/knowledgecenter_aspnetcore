﻿using ExcelicareAPIGateWay.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace ExcelicareAPIGateWay.Filters
{
    /// <summary>
    /// Basic Authentication as part web api request
    /// Created By  : BRR
    /// Created Date: 2022-01-07
    /// </summary>
    public class BasicAuthenticationAttribute : AuthorizationFilterAttribute
    {
        /// <summary>
        /// Basic Authorization with user name and password.
        /// </summary>
        /// <param name="actionContext">mandatory</param>
        public override void OnAuthorization(HttpActionContext actionContext)
        {
           if(actionContext.Request.Headers.Authorization == null)
            {
                actionContext.Response = actionContext.Request.CreateResponse(System.Net.HttpStatusCode.Unauthorized,"Unauthorized");
                return;
            }
            else
            {
                string authenticationToken = actionContext.Request.Headers.Authorization.Parameter;
                string decodedAuthenticationToken=Encoding.UTF8.GetString(Convert.FromBase64String(authenticationToken));
                string username = decodedAuthenticationToken.Split(':')[0];
                string password = decodedAuthenticationToken.Split(':')[1];

                UserModel usermodelObj = new UserModel();
                if (usermodelObj.AuthenticateUser(username, password))
                {
                    Thread.CurrentPrincipal = new GenericPrincipal(new GenericIdentity(username),null); 
                }

                else
                {
                    usermodelObj = null;
                    actionContext.Response = actionContext.Request.CreateResponse(System.Net.HttpStatusCode.Unauthorized,"Invalid Authentication Details.");
                    return;
                }
            }
        }
    }
}