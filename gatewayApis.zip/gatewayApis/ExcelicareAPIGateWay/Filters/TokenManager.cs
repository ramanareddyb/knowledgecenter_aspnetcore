﻿using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Web.Http.Controllers;

namespace ExcelicareAPIGateWay.Filters
{
    /// <summary>
    /// Token Manager to generate and validate the token and its claims
    /// Created By  : BRR
    /// Created Date: 01-07-2022
    /// </summary>
    public class TokenManager
    {
        private static string Secret = "ERMN05OPLoDvbTTa/QkqLNMI7cPLguaRyHzyg7n5qNBVjQmtBhz4SzYh4NBVCXi3KJHlSXKP+oi2+bXr6CUYTR==";

        /// <summary>
        /// Generation of JWT Bearer Token
        /// Created By : BRR
        /// Created Date: 2022-01-05
        /// </summary>
        /// <param name="username">mandatory</param>
        /// <param name="resource">mandatory</param>
        /// <returns></returns>
        public static string GenerateToken(string username,string resource = "")
        {
            var printPath = "";
            byte[] key = Convert.FromBase64String(Secret);
            SymmetricSecurityKey securityKey = new SymmetricSecurityKey(key);
            if (resource.Contains("print,")) { printPath = resource.Split(':')[1]; }
            SecurityTokenDescriptor descriptor = new SecurityTokenDescriptor
            {
                
                Subject = new ClaimsIdentity(new[] {
                      new Claim(ClaimTypes.Name, username),
                      new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                      new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString("yyyy-MM-dd")),
                      printPath != "" ?new Claim("PrintUrl", printPath) : new Claim("Resources", "usermanagement,adhocreports,patientmerge,aclmanagement,capabilitymanagement,mcnmanagement"),
                      new Claim("Scope", "read,write"),
                      new Claim(ClaimTypes.Role, "Admin")}),

                Expires = DateTime.UtcNow.AddMinutes(60),
                SigningCredentials = new SigningCredentials(securityKey,
                SecurityAlgorithms.HmacSha256Signature)
            };

            JwtSecurityTokenHandler handler = new JwtSecurityTokenHandler();
            JwtSecurityToken token = handler.CreateJwtSecurityToken(descriptor);
            return handler.WriteToken(token);
        }
        /// <summary>
        /// Retrieval of principal and identity of given JWT Token
        /// </summary> 
        /// <param name="token">mandatory</param>
        /// <returns></returns>
        public static ClaimsPrincipal GetPrincipal(string token)
        {
            try
            {
                JwtSecurityTokenHandler tokenHandler = new JwtSecurityTokenHandler();
                JwtSecurityToken jwtToken = (JwtSecurityToken)tokenHandler.ReadToken(token);
                if (jwtToken == null)
                    return null;
                byte[] key = Convert.FromBase64String(Secret);
                TokenValidationParameters parameters = new TokenValidationParameters()
                {
                    RequireExpirationTime = true,
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    IssuerSigningKey = new SymmetricSecurityKey(key)
                };
                SecurityToken securityToken;
                ClaimsPrincipal principal = tokenHandler.ValidateToken(token,
                      parameters, out securityToken);
                return principal;
            }
            catch
            {
                return null;
            }
        }
        /// <summary>
        /// Validating the given JWT Token
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        public static string ValidateToken(string token)
        {
            string username = null;
            ClaimsPrincipal principal = GetPrincipal(token);
            if (principal == null)
                return null;
            ClaimsIdentity identity = null;
            try
            {
                identity = (ClaimsIdentity)principal.Identity;
            }
            catch (NullReferenceException)
            {
                return null;
            }
            Claim usernameClaim = identity.FindFirst(ClaimTypes.Name);
            username = usernameClaim.Value;
            return username;
        }
        /// <summary>
        /// GetTokenExpirationTime
        /// </summary>
        /// <param name="token">mandatory</param>
        /// <returns></returns>
        public static long GetTokenExpirationTime(string token)
        {
            var handler = new JwtSecurityTokenHandler();
            var jwtSecurityToken = handler.ReadJwtToken(token);
            var tokenExp = jwtSecurityToken.Claims.First(claim => claim.Type.Equals("exp")).Value;
            var ticks = long.Parse(tokenExp);
            return ticks;
        }
        /// <summary>
        /// Validating token expiry
        /// </summary>
        /// <param name="token">mandatory</param>
        /// <returns></returns>
        public static int IsTokenExpired(string token)
        {
            try
            {
                var tokenTicks = GetTokenExpirationTime(token);
                var tokenDate = DateTimeOffset.FromUnixTimeSeconds(tokenTicks).UtcDateTime;

                var now = DateTime.Now.ToUniversalTime();

                var valid = tokenDate >= now;
                if (valid)
                    return 1;
                else 
                   return 0;
            }
         
            catch (Exception ex) { throw ex; }
        }

        /// <summary>
        /// Refresh the token
        /// </summary>
        /// <param name="reftoken"></param>
        /// <returns></returns>
        public static string RefreshToken(string reftoken)
        {
            //var handler = new JwtSecurityTokenHandler();
            //var jsonToken = handler.ReadToken(reftoken);


            //// Gets name from claims. Generally it's an email address.
            //var Name = jsonToken.Claims.First(claim => claim.Type == "Name").Value;
            //var usernameClaim = jsonToken.Claims
            //    .Where(x => x.Type == ClaimTypes.Name)
            //    .FirstOrDefault();

            //byte[] key = Convert.FromBase64String(Secret);
            //SymmetricSecurityKey securityKey = new SymmetricSecurityKey(key);
            //SecurityTokenDescriptor descriptor = new SecurityTokenDescriptor
            //{
            //    //Subject = new ClaimsIdentity(new[] {
            //    //      new Claim(ClaimTypes.Name, username),
            //    //      new Claim(ClaimTypes.Role, "Admin")}),

            //    Subject = usernameClaim,
            //    Expires = DateTime.UtcNow.AddMinutes(30),
            //    SigningCredentials = new SigningCredentials(securityKey,
            //    SecurityAlgorithms.HmacSha256Signature)
            //};

            //JwtSecurityTokenHandler tokenHandler = new JwtSecurityTokenHandler();
            //JwtSecurityToken token = tokenHandler.CreateJwtSecurityToken(descriptor);
            //return tokenHandler.WriteToken(token);
            return "";
        }

        /// <summary>
        /// ValidateCurrentToken
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        public bool ValidateCurrentToken(string token)
        {
            byte[] key = Convert.FromBase64String(Secret);
            SymmetricSecurityKey mySecurityKey = new SymmetricSecurityKey(key);

            //var mySecurityKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(Secret));
            var myIssuer = "http://excelicare.com";
            var myAudience = "Excelicare_users";
            var tokenHandler = new JwtSecurityTokenHandler();
            try
            {
                tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidIssuer = myIssuer,
                    ValidAudience = myAudience,
                    IssuerSigningKey = mySecurityKey
                }, out SecurityToken validatedToken);
            }
            catch
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Retrieval of specified claimtype
        /// </summary>
        /// <param name="token"></param>
        /// <param name="claimType"></param>
        /// <returns></returns>
        public string GetClaim(string token, string claimType)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var securityToken = tokenHandler.ReadToken(token) as JwtSecurityToken;
            var stringClaimValue = securityToken.Claims.First(claim => claim.Type == claimType).Value;
            return stringClaimValue;
        }
    }
}