﻿using System;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Caching;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace ExcelicareAPIGateWay.Filters
{
    /// <summary>
    /// ThrottleAttribute
    /// </summary>
    public class ThrottleAttribute : ActionFilterAttribute
    {
        private const string HttpContext1 = "MS_HttpContext";
        private const string RemoteEndpointMessage = "System.ServiceModel.Channels.RemoteEndpointMessageProperty";
        private const string OwinContext = "MS_OwinContext";
        //private string v1;
        //private string v2;
        //private int v3;

        /// <summary>
        /// ThrottleAttribute
        /// </summary>
        /// <param name="v1"></param>
        /// <param name="v2"></param>
        /// <param name="v3"></param>
        public ThrottleAttribute(string v1, string v2, int v3)
        {
            this.Name = v1;
            this.Message = v2;
            this.Seconds = v3;
        }

        /// <summary>
        /// A unique name for this Throttle.
        /// </summary>
        /// <remarks>
        /// We'll be inserting a Cache record based on this name and client IP, e.g. "Name-192.168.0.1"
        /// </remarks>
        public string Name { get; set; }

        /// <summary>
        /// The number of seconds clients must wait before executing this decorated route again.
        /// </summary>
        public int Seconds { get; set; }

        /// <summary>
        /// A text message that will be sent to the client upon throttling.  You can include the token {n} to
        /// show this.Seconds in the message, e.g. "Wait {n} seconds before trying again".
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="actionContext"></param>
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            var key = string.Concat(Name, "-", GetClientIpAddress(actionContext.Request));
            var allowExecute = false;

            if (HttpRuntime.Cache[key] == null)
            {
                HttpRuntime.Cache.Add(key,
                    true, // is this the smallest data we can have?
                    null, // no dependencies
                    DateTime.Now.AddSeconds(Seconds), // absolute expiration
                    Cache.NoSlidingExpiration,
                    CacheItemPriority.Low,
                    null); // no callback

                allowExecute = true;
            }

            if (!allowExecute)
            {
                if (string.IsNullOrEmpty(Message))
                {
                    Message = "You may only perform this action every {n} seconds.";
                }

                actionContext.Response = actionContext.Request.CreateResponse(
                    HttpStatusCode.Conflict,
                    Message.Replace("{n}", Seconds.ToString())
                );
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public static string GetClientIpAddress(HttpRequestMessage request)
        {
            //Web-hosting
            if (request.Properties.ContainsKey("MS_HttpContext"))
            {
                dynamic ctx = request.Properties["MS_HttpContext"];
                if (ctx != null)
                {
                    return ctx.Request.UserHostAddress;
                }
            }

            //Self-hosting
            if (request.Properties.ContainsKey(RemoteEndpointMessage))
            {
                dynamic remoteEndpoint = request.Properties[RemoteEndpointMessage];
                if (remoteEndpoint != null)
                {
                    return remoteEndpoint.Address;
                }
            }

            //Owin-hosting
            if (request.Properties.ContainsKey(OwinContext))
            {
                dynamic ctx = request.Properties[OwinContext];
                if (ctx != null)
                {
                    return ctx.Request.RemoteIpAddress;
                }
            }
            return null;
        }
    }

    ///// <summary>
    ///// throrrle attribute class
    ///// </summary>
    //public class ThrottleAttribute : ActionFilterAttribute
    //{
    //    private int _API_RATEQUOTA = 60;

    //    // per x minute value
    //    private int _API_TIMELIMIT = 1;

    //    private int _API_BLOCKDURATION = 5;

    //    private readonly object syncLock = new object();

    //    /// <summary>
    //    /// 
    //    /// </summary>
    //    /// <param name="actionContext"></param>
    //    public override void OnActionExecuting(HttpActionContext actionContext)
    //    {
    //        // Extract access_token or id or ip address to uniquely identify an API call
    //        HttpRequestMessage request = actionContext.Request;
    //        AuthenticationHeaderValue authorization = request.Headers.Authorization;
    //        string[] tokenwithUser = null;

    //        tokenwithUser = authorization.Parameter.Split(':');
    //        string token = tokenwithUser[0];
    //        string userName = tokenwithUser[1];

    //        var access_token = token;

    //        if (access_token != null)
    //        {

    //            string throttleBaseKey = GetThrottleBaseKey(access_token);
    //            string throttleCounterKey = GetThrottleCounterKey(access_token);

    //            lock (syncLock)
    //            {
    //                //add a listner for new api request count
    //                if (HttpRuntime.Cache[throttleBaseKey] == null)
    //                {
    //                    // add api unique key.. this cache will get expire after _API_TIMELIMIT
    //                    HttpRuntime.Cache.Add(throttleBaseKey,
    //                        DateTime.UtcNow,
    //                        null,
    //                        DateTime.Now.AddMinutes(_API_TIMELIMIT),
    //                        Cache.NoSlidingExpiration,
    //                        CacheItemPriority.High,
    //                        null);

    //                    // add count as value for that api.. this cache will get expire after _API_TIMELIMIT
    //                    HttpRuntime.Cache.Add(throttleCounterKey,
    //                       1,
    //                       null,
    //                       DateTime.Now.AddMinutes(_API_TIMELIMIT),
    //                       Cache.NoSlidingExpiration,
    //                       CacheItemPriority.High,
    //                       null);
    //                }
    //                else
    //                {
    //                    //listener exists for api request count
    //                    var current_requests = (int)HttpRuntime.Cache[throttleCounterKey];

    //                    if (current_requests < _API_RATEQUOTA)
    //                    {
    //                        // increase api count
    //                        HttpRuntime.Cache.Insert(throttleCounterKey,
    //                        current_requests + 1,
    //                        null,
    //                        DateTime.Now.AddMinutes(_API_TIMELIMIT),
    //                        Cache.NoSlidingExpiration,
    //                        CacheItemPriority.High,
    //                        null);
    //                    }

    //                    //hit rate limit, wait for another 5 minutes (_API_BLOCKDURATION)
    //                    else
    //                    {
    //                        HttpRuntime.Cache.Insert(throttleBaseKey,
    //                       DateTime.UtcNow,
    //                       null,
    //                       DateTime.Now.AddMinutes(_API_BLOCKDURATION),
    //                       Cache.NoSlidingExpiration,
    //                       CacheItemPriority.High,
    //                       null);

    //                        HttpRuntime.Cache.Insert(throttleCounterKey,
    //                      current_requests + 1,
    //                      null,
    //                      DateTime.Now.AddMinutes(_API_BLOCKDURATION),
    //                      Cache.NoSlidingExpiration,
    //                      CacheItemPriority.High,
    //                      null);

    //                        Forbidden(actionContext);
    //                    }
    //                }
    //            }
    //        }
    //        else
    //        {
    //            BadRequest(actionContext);
    //        }

    //        base.OnActionExecuting(actionContext);
    //    }

    //    private string GetThrottleBaseKey(string app_id)
    //    {
    //        return Identifier.THROTTLE_BASE_IDENTIFIER + app_id;
    //    }

    //    private string GetThrottleCounterKey(string app_id)
    //    {
    //        return Identifier.THROTTLE_COUNTER_IDENTIFIER + app_id;
    //    }

    //    private void BadRequest(HttpActionContext actionContext)
    //    {
    //        actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.BadRequest);
    //    }

    //    private void Forbidden(HttpActionContext actionContext)
    //    {
    //        actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Forbidden, "Application Rate Limit Exceeded");
    //    }

    //}
    ///// <summary>
    ///// 
    ///// </summary>
    //public static class Identifier
    //{
    //    /// <summary>
    //    /// 
    //    /// </summary>
    //    public static readonly string THROTTLE_BASE_IDENTIFIER = "LA_THROTTLE_BASE_";

    //    /// <summary>
    //    /// 
    //    /// </summary>
    //    public static readonly string THROTTLE_COUNTER_IDENTIFIER = "LA_THROTTLE_COUNT_";
    //}
}


