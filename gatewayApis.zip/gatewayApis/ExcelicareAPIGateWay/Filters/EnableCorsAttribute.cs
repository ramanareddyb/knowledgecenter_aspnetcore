﻿using System.Linq;
using System.Web.Http.Filters;

namespace ExcelicareAPIGateWay.Filters
{
/// <summary>
/// Enable cors configurations
/// </summary>
    public class EnableCorsAttribute : ActionFilterAttribute
    {
        private const string origin = "Origin";
        private const string accessControlAllowOrigin = "Access-Control-Allow-Origin";

        /// <summary>
        /// 
        /// </summary>
        /// <param name="actionExecutedContext"></param>
        public override void OnActionExecuted(HttpActionExecutedContext actionExecutedContext)
        {
            if (actionExecutedContext.Request.Headers.Contains(origin))
            {
                var originHeader = actionExecutedContext.Request.Headers.GetValues(origin).FirstOrDefault();

                if (!string.IsNullOrEmpty(originHeader))
                {
                    actionExecutedContext.Response.Headers.Add(accessControlAllowOrigin, originHeader);
                }
            }
        }
    }
}