﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Principal;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.Filters;
using System.Web.Http.Results;

namespace ExcelicareAPIGateWay.Filters
{
    /// <summary>
    /// Custom Authentication as part of web api
    /// Created By  : BRR
    /// Created Date: 2022-01-07
    /// </summary>
    public class CustomAuthenticationFilter : AuthorizeAttribute, IAuthenticationFilter
    {
        ///// <summary>
        ///// AllowMultiple variable to configure token authentication
        ///// </summary>
        //public bool AllowMultiple
        //{
        //    get { return false; }
        //}

        /// <summary>
        /// AuthenticateAsync
        /// </summary>
        /// <param name="context"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task AuthenticateAsync(HttpAuthenticationContext context, CancellationToken cancellationToken)
        {
            string authParameter = string.Empty;
            HttpRequestMessage request = context.Request;
            string[] tokenwithUser = null;
            AuthenticationHeaderValue authorization = request.Headers.Authorization;
            if(authorization == null)
            {
                context.ErrorResult = new AuthenticationFailureResult("Missing Authorization Header",request);
                return;
            }
            if(authorization.Scheme != "Bearer")
            {
                context.ErrorResult = new AuthenticationFailureResult("Invalid Authorization Schema", request);
                return;

            }

           tokenwithUser = authorization.Parameter.Split(':');
            string token = tokenwithUser[0];
            string userName = tokenwithUser[1];

            if (String.IsNullOrEmpty(token))
            {
                context.ErrorResult = new AuthenticationFailureResult("Missing Token", request);
                return;
            }

            string validUserName = TokenManager.ValidateToken(token);

            if(validUserName != userName)
            {
                context.ErrorResult = new AuthenticationFailureResult("Invalid User", request);
                return;
            }
           
           context.Principal = TokenManager.GetPrincipal(token); 

        }
        /// <summary>
        /// ChallengeAsync
        /// </summary>
        /// <param name="context"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task ChallengeAsync(HttpAuthenticationChallengeContext context, CancellationToken cancellationToken)
        {

            var result = await context.Result.ExecuteAsync(cancellationToken);
            if (result.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                result.Headers.WwwAuthenticate.Add(new AuthenticationHeaderValue("Basic", "realm=localhost"));

            }
            context.Result = new ResponseMessageResult(result);
        }
    }

    /// <summary>
    /// AuthenticationFailureResult assigning to HttpContext to retun response
    /// Created By   : BRR
    /// Created Date : 202-01-07
    /// </summary>
    public class AuthenticationFailureResult : IHttpActionResult
    {
        /// <summary>
        /// ReasonPhrase
        /// </summary>
        public string ReasonPhrase;

        /// <summary>
        /// Request
        /// </summary>
        public HttpRequestMessage Request { get; set; }

        /// <summary>
        /// AuthenticationFailureResult
        /// </summary>
        /// <param name="responsePhrase"></param>
        /// <param name="request"></param>
        public AuthenticationFailureResult(string responsePhrase, HttpRequestMessage request)
        {
            this.ReasonPhrase = responsePhrase;
            Request = request;
        }
        /// <summary>
        /// ExecuteAsync
        /// </summary>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public Task<HttpResponseMessage> ExecuteAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult(Execute());

        }
        /// <summary>
        /// Execute
        /// </summary>
        /// <returns></returns>
        public HttpResponseMessage Execute()
        {
            HttpResponseMessage responseMessage = new HttpResponseMessage(System.Net.HttpStatusCode.Unauthorized);
            responseMessage.RequestMessage = Request;
            responseMessage.ReasonPhrase = ReasonPhrase;
            return responseMessage;
        }       
    }
}