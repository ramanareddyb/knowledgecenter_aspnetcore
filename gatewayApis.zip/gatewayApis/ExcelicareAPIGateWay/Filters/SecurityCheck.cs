﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Excelicare.Framework.AppSupport;

namespace ExcelicareAPIGateWay.Filters
{
    /// <summary>
    /// Security check of input data
    /// Created By  : BRR
    /// Created Date: 01-07-2022
    /// </summary>
    public class SecurityCheck
    {

        clsSecurity ObjClsSecurity = new clsSecurity();
        /// <summary>
        /// Validating input data provided by the user with request
        /// </summary>
        /// <param name="userData"></param>
        /// <returns></returns>
        public Boolean ValidateData(object userData)
        {
            JObject userMgt;
            string itemList = String.Empty;
            bool blnResult = false;
            try
            {
                userMgt = JObject.FromObject(userData);
                foreach (var property in userMgt)
                {
                    itemList += property.Value.ToString() + " ";
                }
                //blnResult = SecurityValidations(itemList);

                return blnResult;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                userMgt = null;
                itemList = null;
            }
        }

        /// <summary>
        /// Security validations via AxAppSupport dll
        /// </summary>
        /// <param name="strInputData"></param>
        /// <returns></returns>
        public Boolean SecurityValidations(string strInputData)
        {
            //Token Validation
            //XSS, Remote OS, SQL Injection validations
            bool blnFound;
            try
            {
                ObjClsSecurity = new clsSecurity();
                blnFound = ObjClsSecurity.fnValidateForXSS(strInputData);
                if (blnFound == false)
                    blnFound = ObjClsSecurity.ValidateOSandSQLCommandInjections(strInputData);
                //If Not HttpContext.Current.Session Is Nothing AndAlso Not HttpContext.Current.Session("SysDefault_2556") Is Nothing Then
                return blnFound;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                ObjClsSecurity = null;
            }
        }

        /// <summary>
        /// iswhitelisted ip method
        /// </summary>
        /// <param name="ValidIPAddress"></param>
        /// <returns></returns>
        public Boolean IsWhitelisted(string ValidIPAddress)
        {
            //IP Address validation
            bool blnFound=true;
            try
            {
                ObjClsSecurity = new clsSecurity();
               // blnFound = ObjClsSecurity.IsWhitelisted(ValidIPAddress);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                ObjClsSecurity = null;
            }
            return blnFound;
        }

    }
}