﻿using ExcelicareAPIGateWay.Controllers;
using ExcelicareAPIGateWay.Filters;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;
using System.Web.UI;
using System.Web.WebPages;
using System.Xml;
using System.Xml.Linq;

namespace ExcelicareAPIGateWay.Filters
{
    /// <summary>
    /// To validate whether the host is whitelisted.
    /// </summary>
    public class WhitelistIPValidation : ActionFilterAttribute
    {
        /// <summary>
        /// Web api requested host is validated for security reason.
        /// Created By   : K Srihari
        /// Created Date : 2023-11-01
        /// </summary>
        /// <param name="actionContext"></param>
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            ApigatewayController apigatewayController = new ApigatewayController();
            object _logBody = JsonConvert.SerializeObject(new { modulename = "WhitelistIPValidation", sessionid = "", patid = -1, event_slu = 2798,
                eventdetails = "White listing ip validation method started.", moduleid = 152, recordid = -1, requestid = "" });
            apigatewayController.SessionLogger(_logBody);
            if (actionContext.ModelState.IsValid == false)
                actionContext.Response = actionContext.Request.CreateErrorResponse(HttpStatusCode.BadRequest, actionContext.ModelState);
            if (actionContext.Request.RequestUri.ToString() != "")
            {
                dynamic reqProp = actionContext.Request.Properties["MS_HttpContext"];
                string hostAddress = reqProp.Request.UserHostAddress;
                _logBody = JsonConvert.SerializeObject(new { modulename = "WhitelistIPValidation", sessionid = "", patid = -1, event_slu = 2798,
                    eventdetails = $"Host address is {hostAddress}.", moduleid = 152, recordid = -1, requestid = "" });
                apigatewayController.SessionLogger(_logBody);
                SecurityCheck securityCheck = new SecurityCheck();
                bool valid = securityCheck.IsWhitelisted(hostAddress);
                _logBody = JsonConvert.SerializeObject(new { modulename = "WhitelistIPValidation", sessionid = "", patid = -1, event_slu = 2798,
                    eventdetails = $"Whitelisted: {valid}.", moduleid = 152, recordid = -1, requestid = "" });
                apigatewayController.SessionLogger(_logBody);
                if (valid)
                {
                    base.OnActionExecuting(actionContext);
                }
                else
                {
                    actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Unauthorized, "Unauthorized request.");
                    _logBody = JsonConvert.SerializeObject(new { modulename = "WhitelistIPValidation", sessionid = "", patid = -1, event_slu = 2798,
                        eventdetails = "Unauthorized request.", moduleid = 152, recordid = -1, requestid = "" });
                    apigatewayController.SessionLogger(_logBody);
                    return;
                }
            }
            else
            {
                actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Unauthorized, "Request uri not found.");
                _logBody = JsonConvert.SerializeObject(new { modulename = "WhitelistIPValidation", sessionid = "", patid = -1, event_slu = 2798,
                    eventdetails = "Request uri not found.", moduleid = 152, recordid = -1, requestid = "" });
                apigatewayController.SessionLogger(_logBody);
                return;
            }
        }
    }
}