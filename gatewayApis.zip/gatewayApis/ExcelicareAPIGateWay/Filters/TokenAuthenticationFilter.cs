﻿using Excelicare.Framework.AppSupport;
using ExcelicareAPIGateWay.Filters;
using Microsoft.Ajax.Utilities;
using Newtonsoft.Json;	  
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace ExcelicareAPIGateWay.Filters
{
    /// <summary>
    /// Bearer token validation for web api request comming from client
    /// Created By  : BRR
    /// Created Date: 2022-01-07
    /// </summary>
    public class TokenAuthenticationFilter : ActionFilterAttribute
    {
        /// <summary>
        /// OnActionExecuting
        /// </summary>
        /// <param name="actionContext"></param>
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            clsSecurity objclsSecurity = new clsSecurity(); 
            //string strToken = "";
            string authParameter = string.Empty;
            HttpRequestMessage request = actionContext.Request;
            string[] tokenwithUser = null;
            AuthenticationHeaderValue authorization = request.Headers.Authorization;

            if (authorization == null) {
                actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Unauthorized, "Invalid Authorization");
                return;
            }

            if (authorization.Scheme != "Bearer")
            {
                actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Unauthorized, "Invalid Token Authorization");
                return;
            }


            var Tokenheader = ((string[])request.Headers.GetValues("Authorization"))[0].ToString().Replace("Bearer","");
            var strDecodeString = objclsSecurity.ECDecode(Tokenheader);
            tokenwithUser = strDecodeString.Split(':');		   
            string token = tokenwithUser[0];
            string userName = tokenwithUser[1];

            if (String.IsNullOrEmpty(token))
            {
                actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Unauthorized, "Missing Token");
                return;
            }

            string validUserName = TokenManager.ValidateToken(token);

            if(validUserName == null)
            {
                actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Unauthorized, "Invalid Token");
                return;
            }

            else if (validUserName != userName)
            {
                actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Unauthorized, "Invalid User");
                return;
            }

            base.OnActionExecuting(actionContext);

        }

    }
}