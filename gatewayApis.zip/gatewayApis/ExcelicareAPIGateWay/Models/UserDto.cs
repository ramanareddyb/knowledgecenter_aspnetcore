﻿using Excelicare.Framework.AppDataSupport;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;

namespace ExcelicareAPIGateWay.Models
{
    /// <summary>
    ///  UserDto class
    /// </summary>
    public class UserDto
    {
        /// <summary>
        /// Username
        /// </summary>
        public string Username { get; set; }
        /// <summary>
        /// Password
        /// </summary>
        public string Password { get; set; }
        /// <summary>
        /// resource
        /// </summary>
        public string resource { get; set; }
        /// <summary>
        /// EcKey
        /// </summary>
		public string EcKey { get; set; }
        
    }
}