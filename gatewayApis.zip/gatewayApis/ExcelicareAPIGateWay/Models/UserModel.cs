﻿using Excelicare.Framework.AppDataSupport;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using Excelicare.Framework.AppSupport;
using Newtonsoft.Json.Linq;
using System.IO;

namespace ExcelicareAPIGateWay.Models
{
    /// <summary>
    /// UserModel class to hold user object and required properties and methods as part of token generation
    /// Created By  : BRR
    /// Created Date: 2022-01-08
    /// </summary>
    public class UserModel
    {
        /// <summary>
        /// properties for user object
        /// </summary>
        public clsDataAccess objClsDataAccess;

        /// <summary>
        /// Username
        /// </summary>
        public string Username { get; set; }
        /// <summary>
        /// Password
        /// </summary>
        public string Password { get; set; }
        /// <summary>
        /// EmailAddress
        /// </summary>
        public string EmailAddress { get;set; }
        /// <summary>
        /// DateOfRegistered
        /// </summary>
        public DateTime DateOfRegistered { get; set; }


        /// <summary>
        /// Authentication of given user and password 
        /// </summary>
        /// <param name="loginName"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public Boolean AuthenticateUser(string loginName, string password)
        {
            if (loginName == null || password == null)
            {
                return false;
            }
            else
            {
                ParamStruct[] param = new ParamStruct[2];
                try
                {
                    param[0].ParamName = "@USR_LoginName";
                    param[0].DataType = DbType.String;
                    param[0].direction = ParameterDirection.Input;
                    param[0].value = loginName;
                    param[1].ParamName = "@USRPWD";
                    param[1].DataType = DbType.String;
                    param[1].direction = ParameterDirection.Input;
                    param[1].value = password;

                    objClsDataAccess = new clsDataAccess();
                    DataSet dsAuthenticate;

                    string strConn = ConfigurationManager.AppSettings["ConnectionString"];
                    objClsDataAccess.GetConnectionStringforUser(ref strConn, EnumDataBaseUserType.AxAppUser);
                    objClsDataAccess.ConnectionString = strConn;
                    

                    dsAuthenticate = objClsDataAccess.ExecuteDataSet("[AxSp_AuthenticateUser]", CommandType.StoredProcedure, param);
                    if (dsAuthenticate.Tables[0].Rows.Count > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    param = null;
                    objClsDataAccess = null;                    
                }
            } 
        }

        /// <summary>
        /// ValidateToken
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        public string ValidateToken(string token)
        {

            ParamStruct[] prmValues = new ParamStruct[1];
         
            string ecSessionToken = String.Empty;
            DataSet dstokenData;
            try
            {
                dstokenData = new DataSet();
                objClsDataAccess = new clsDataAccess();

                prmValues[0].DataType = DbType.String;
                prmValues[0].direction = ParameterDirection.Input;
                prmValues[0].ParamName = "@guid";
                prmValues[0].value = token;

                dstokenData = objClsDataAccess.ExecuteDataSet("AxSP_GetValidToken", CommandType.StoredProcedure, prmValues);

                if (dstokenData != null)
                {
                    if (dstokenData.Tables.Count > 0)
                    {
                        ecSessionToken = dstokenData.Tables[0].Rows[0]["Token"].ToString();
                    }
                }
                return ecSessionToken;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                prmValues = null;
                objClsDataAccess = null;
            }
        }

        /// <summary>
        /// Saving of Token
        /// </summary>
        /// <param name="token"></param>
        public void SaveToken(string token)
        {

            ParamStruct[] prmValues = new ParamStruct[1];

            string ecSessionToken = String.Empty;
            DataSet dstokenData;
            try
            {
                dstokenData = new DataSet();
                objClsDataAccess = new clsDataAccess();

                prmValues[0].DataType = DbType.String;
                prmValues[0].direction = ParameterDirection.Input;
                prmValues[0].ParamName = "@Token";
                prmValues[0].value = token;

               objClsDataAccess.ExecuteNonQuery("AxSP_SaveSessionToken", CommandType.StoredProcedure, prmValues);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                prmValues = null;
                objClsDataAccess = null;
            }
        }

        /// <summary>
        /// To validate security content in the object
        /// </summary>
        /// <param name="Data"></param>
        /// <returns></returns>
        public string DecodeAndValidate(object Data)
        {
            //Token Validation
            //XSS, Remote OS, SQL Injection validations
            bool blnFound;
            string strDecodedValue = "";
            clsSecurity objClsSecurity;
            JValue Jobj;
            try
            {
                objClsSecurity = new clsSecurity();
                Jobj = (JValue)JObject.FromObject(Data)["data"];
                strDecodedValue = objClsSecurity.ECDecode(Jobj.Value.ToString());
                blnFound = objClsSecurity.fnValidateForXSS(strDecodedValue);
                if (blnFound == false)
                    blnFound = objClsSecurity.ValidateOSandSQLCommandInjections(strDecodedValue);

                if (blnFound == true)
                    return blnFound.ToString();
                else
                    return strDecodedValue;
            }
            catch (Exception ex)
            {
                WriteToLog($"{ex.Message}\n{ex.StackTrace}", "usermodel");
                throw ex;
            }
            finally
            {
                objClsSecurity = null;
                Jobj = null;
            }
        }

        private void WriteToLog(string strData, string strLogType)
        {
            System.IO.FileStream objFS = null;
            System.IO.StreamWriter objSW = null;
            try
            {
                if (System.IO.Directory.Exists(AppDomain.CurrentDomain.BaseDirectory) == false)
                {
                    Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory);
                }
                objFS = new FileStream($"{AppDomain.CurrentDomain.BaseDirectory}\\local_{strLogType}{DateTime.Now:yyyyMMdd}.txt", FileMode.Append);
                objSW = new StreamWriter(objFS);
                objSW.WriteLine($"{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff}\t{strData}");
            }
            catch { }
            finally
            {
                if (((objSW != null)))
                {
                    objSW.Close();
                    objSW.Dispose();
                }
                if (((objFS != null)))
                {
                    objFS.Close();
                    objFS.Dispose();
                }
            }
        }

    }


}
