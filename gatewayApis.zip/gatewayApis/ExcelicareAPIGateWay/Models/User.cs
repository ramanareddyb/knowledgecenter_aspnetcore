﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using Excelicare.Framework.AppDataSupport;
namespace ExcelicareAPIGateWay.Models
{
    /// <summary>
    ///  User model class
    /// </summary>
    public class User
    {
        /// <summary>
        /// Username
        /// </summary>
        public string Username { get; set; }
        /// <summary>
        /// PasswordHash
        /// </summary>
        public byte[] PasswordHash { get; set; }
        /// <summary>
        /// PasswordSalt
        /// </summary>
        public byte[] PasswordSalt { get; set; }    

        

       
    }
}