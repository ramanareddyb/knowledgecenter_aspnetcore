﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Web.Http;
using ExcelicareAPIGateWay.Filters;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Excelicare.Framework.AppSupport;
using ExcelicareAPIGateWay.Models;
using System.Reflection;
using System.Threading.Tasks;
using Swashbuckle.Swagger;

namespace ExcelicareAPIGateWay.Controllers
{
    /// <summary>
    /// apigateway for Excelicare api's
    /// created by: BRR
    /// created datetime: 25-June-2022 12:55PM
    /// </summary>
    //[EnableCors(origins: "*", headers: "*", methods: "*", exposedHeaders: "X-My-Header")]

    public class ApigatewayController : ApiController
    {

        #region Globalvariables
        //private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        string strApiUrl = ConfigurationManager.AppSettings["ECServiceURL"]; 
        /// <summary>
        /// usermodelObj
        /// </summary>
        public UserModel usermodelObj;

        #endregion

        #region StaffRegistration

        /// <summary>
        /// to get all staff details
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/user")]
        [TokenAuthenticationFilter]
        [EnableCors]
        [RequestValidation]
        //[ExceptionHandler]
        //[Throttle("GetListOfUsers", "", 20)]
        public IHttpActionResult GetListofUsers()
        {
            HttpClient client;
            HttpResponseMessage response;
            JArray jsonArray;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/user").Result;
                if (response.IsSuccessStatusCode)
                {
                    jsonArray = JArray.Parse(response.Content.ReadAsStringAsync().Result);
                    return Ok(jsonArray);
                }
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
                jsonArray = null;
            }
        }

        /// <summary>
        /// to get user details
        /// </summary>
        /// <param name="usertype">mandatory</param>
        /// <param name="userid">mandatory</param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/user/{usertype}/{userid}")]
        [TokenAuthenticationFilter]
        [EnableCors]
        [RequestValidation]
        //[ExceptionHandler]
        public IHttpActionResult GetUserDetails(int usertype, long userid)
        {
            HttpClient client;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/user/" + usertype + "/" + userid).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(JObject.Parse(response.Content.ReadAsStringAsync().Result));

                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }

        /// <summary>
        /// to register/ update staff
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/user/register")]
        [TokenAuthenticationFilter]
        [EnableCors]
        [RequestValidation]
        public IHttpActionResult SaveUser(object general)
        {
            string staffData = string.Empty;
            StringContent staffDataContent = null;
            HttpClient client = null;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();
                usermodelObj = new UserModel();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                staffData = usermodelObj.DecodeAndValidate(general);

                if (staffData == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");

                staffDataContent = new StringContent(staffData, UnicodeEncoding.UTF8, "application/json");
                response = client.PostAsync("api/user/register", staffDataContent).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                staffData = null;
                staffDataContent = null;
                client = null;
                response = null;
                usermodelObj = null;
            }
        }

        /// <summary>
        /// to inactivate/ reactivate staff
        /// </summary>
        /// <param name="objDeleteInfo"></param>
        /// <returns></returns>
        [HttpDelete]
        [Route("apigateway/user")]
        [TokenAuthenticationFilter]
        [EnableCors]
        [RequestValidation]
        public IHttpActionResult DeleteUser([FromBody] object objDeleteInfo)
        {
            HttpClient client = null;
            HttpResponseMessage response;
            string deleteInfo = string.Empty;
            StringContent deleteInfoContent = null;
            try
            {
                client = new HttpClient();
                usermodelObj = new UserModel();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                deleteInfo = usermodelObj.DecodeAndValidate(objDeleteInfo);

                if (deleteInfo == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");

                deleteInfoContent = new StringContent(deleteInfo, UnicodeEncoding.UTF8, "application/json");
                response = client.SendAsync(new HttpRequestMessage(new HttpMethod("DELETE"), "api/user")
                {
                    Content = deleteInfoContent
                }).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
                deleteInfo = null;
                deleteInfoContent = null;
                usermodelObj = null;
            }
        }

        /// <summary>
        /// to get given staff id user profile data
        /// </summary>
        /// <param name="userID">mandatory</param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/user/{userID}")]
        [TokenAuthenticationFilter]
        [EnableCors]
        [RequestValidation]
        public IHttpActionResult GetUserProfile(long userID)
        {
            HttpClient client = null;
            HttpResponseMessage response = null;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/user/" + userID).Result;

                if (response.IsSuccessStatusCode)

                    return Ok(JObject.Parse(response.Content.ReadAsStringAsync().Result));
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));

            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }

        /// <summary>
        /// to save user profile data
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/user/profile")]
        [TokenAuthenticationFilter]
        [EnableCors]
        [RequestValidation]
        public IHttpActionResult SaveUserProfile(object userProfiles)
        {
            string userData = string.Empty;
            StringContent userDataContent = null;
            HttpClient client = null;
            HttpResponseMessage response;

            try
            {
                client = new HttpClient();
                usermodelObj = new UserModel();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                userData = usermodelObj.DecodeAndValidate(userProfiles);

                if (userData == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");

                userDataContent = new StringContent(userData, UnicodeEncoding.UTF8, "application/json");
                response = client.PostAsync("api/user/profile/", userDataContent).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                userData = null;
                userDataContent = null;
                client = null;
                response = null;
                usermodelObj = null;
            }
        }

        /// <summary>
        /// Reset security questions for user
        /// </summary>
        /// <returns></returns>
        [HttpDelete]
        [Route("apigateway/user/resetsecurityquestions/{UserID}")]
        [TokenAuthenticationFilter]
        [EnableCors]
        [RequestValidation]
        public IHttpActionResult ResetSecurityQuestions(long userID)
        {
            HttpClient client = null;
            HttpResponseMessage response;

            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.SendAsync(new HttpRequestMessage(new HttpMethod("DELETE"), "api/user/resetsecurityquestions/" + userID)).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }

        /// <summary>
        /// to get given user id account information
        /// </summary>
        /// <param name="userID">mandatory</param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/manageaccount/{userID}")]
        [TokenAuthenticationFilter]
        [EnableCors]
        [RequestValidation]
        public IHttpActionResult GetUserAccountDetails(long userID)
        {
            HttpClient client = null;
            HttpResponseMessage response = null;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/manageaccount/" + userID).Result;

                if (response.IsSuccessStatusCode)

                    return Ok(JObject.Parse(response.Content.ReadAsStringAsync().Result));
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));

            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }

        /// <summary>
        /// to create/update user account
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/manageaccount")]
        [TokenAuthenticationFilter]
        [EnableCors]
        [RequestValidation]
        public IHttpActionResult AddUserAccount([FromBody] object manageAccount)
        {
            string userAccountData = string.Empty;
            StringContent userAccountContent = null;
            HttpClient client = null;
            HttpResponseMessage response;

            try
            {
                client = new HttpClient();
                usermodelObj = new UserModel();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                userAccountData = usermodelObj.DecodeAndValidate(manageAccount);

                if (userAccountData == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");

                userAccountContent = new StringContent(userAccountData, UnicodeEncoding.UTF8, "application/json");
                response = client.PostAsync("api/manageaccount/", userAccountContent).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(JObject.Parse(response.Content.ReadAsStringAsync().Result));
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                userAccountData = null;
                userAccountContent = null;
                client = null;
                response = null;
                usermodelObj = null;
            }
        }

        /// <summary>
        /// to inactivate/ reactivate user account
        /// </summary>
        /// <param name="objDeleteInfo">mandatory</param>
        /// <returns></returns>
        [HttpDelete]
        [Route("apigateway/manageaccount")]
        [TokenAuthenticationFilter]
        [EnableCors]
        [RequestValidation]
        public IHttpActionResult DeleteUserAccount([FromBody] object objDeleteInfo)
        {

            HttpClient client = null;
            HttpResponseMessage response;
            string deleteInfo = string.Empty;
            StringContent deleteInfoContent = null;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                deleteInfo = JObject.FromObject(objDeleteInfo).ToString();
                deleteInfoContent = new StringContent(deleteInfo, UnicodeEncoding.UTF8, "application/json");
                response = client.SendAsync(new HttpRequestMessage(new HttpMethod("DELETE"), "api/manageaccount")
                {
                    Content = deleteInfoContent
                }).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
                deleteInfo = null;
                deleteInfoContent = null;
            }
        }

        /// <summary>
        /// to get default configuration details of given userid
        /// </summary>
        /// <param name="userID">mandatory</param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/user/defaultconfiguration/{Userid}")]
        [TokenAuthenticationFilter]
        [EnableCors]
        [RequestValidation]
        public IHttpActionResult GetDefaultConfigurations(long userID)
        {
            HttpClient client = null;
            HttpResponseMessage response = null;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/user/defaultconfiguration/" + userID).Result;

                if (response.IsSuccessStatusCode)

                    return Ok(JObject.Parse(response.Content.ReadAsStringAsync().Result));
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));

            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }


        //Staff registration MCN tab end points

        /// <summary>
        /// to get user mcn data
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="staffType"></param>
        /// <param name="Mode"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/user/MCN/{userID}/{staffType}/{Mode}")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult GetUserMCN(long userID, int staffType, int Mode)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/user/MCN/" + userID + "/" + staffType + "/" + Mode).Result;
                if (response.IsSuccessStatusCode)
                {
                    return Ok(response.Content.ReadAsStringAsync().Result);
                }
                else
                {
                    return Content(HttpStatusCode.BadRequest, response.Content.ReadAsStringAsync().Result);
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }


        /// <summary>
        /// to save user mcn data
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/User/UserMCN")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult SaveUserMCN([FromBody] object request)
        {
            try
            {
                usermodelObj = new UserModel();
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //var content = JsonConvert.SerializeObject(request);
                var content = usermodelObj.DecodeAndValidate(request);
                if (content == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");

                var stringContent = new StringContent(content, UnicodeEncoding.UTF8, "application/json");
                HttpResponseMessage response = client.PostAsync("api/User/AddUserMCN", stringContent).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    //return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                    return Content(HttpStatusCode.BadRequest, response.Content.ReadAsStringAsync().Result);
                }
            }
            catch (Exception ex) { throw ex; }
            finally { usermodelObj = null; }
        }

        //Staff registration ACL tab end points

        /// <summary>
        ///  to get acl details
        /// </summary>
        /// <param name="Userid"></param>
        /// <param name="mode"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/user/ACLDetails/{Userid}/{mode}")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult GetACLDetails(long Userid, int mode)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/User/ACLDetails/" + Userid + "/" + mode).Result;
                if (response.IsSuccessStatusCode)
                {
                    return Ok(response.Content.ReadAsStringAsync().Result);
                }
                else
                {
                    return Content(HttpStatusCode.BadRequest, response.Content.ReadAsStringAsync().Result);
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }

        /// <summary>
        /// to save user acl details
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/user/ACLDetails")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult SaveUserACLDetails([FromBody] object request)
        {
            try
            {
                usermodelObj = new UserModel();
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //  var content = JsonConvert.SerializeObject(request);
                var content = usermodelObj.DecodeAndValidate(request);
                if (content == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");
                var stringContent = new StringContent(content, UnicodeEncoding.UTF8, "application/json");
                HttpResponseMessage response = client.PostAsync("api/user/ACLDetails", stringContent).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    //return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                    return Content(HttpStatusCode.BadRequest, response.Content.ReadAsStringAsync().Result);
                }
            }
            catch (Exception ex) { throw ex; }
            finally { usermodelObj = null; }
        }
        #endregion

        #region LocationRegistration

        /// <summary>
        /// to get location details of given locationid
        /// </summary>
        /// <param name="locationId">mandatory</param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/location/{locationId}")]
        [TokenAuthenticationFilter]
        [EnableCors]
        [RequestValidation]
        //[ExceptionHandler]
        public IHttpActionResult GetLocationDetails(int locationId)
        {
            HttpClient client;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/location/" + locationId).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(JObject.Parse(response.Content.ReadAsStringAsync().Result));

                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }

        /// <summary>
        /// to fetch location registration config data
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/location/LocationConfigData")]
        [TokenAuthenticationFilter]
        [EnableCors]
        [RequestValidation]
        //[ExceptionHandler]
        public IHttpActionResult GetLocationConfigData()
        {
            HttpClient client;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/location/LocationConfigData").Result;

                if (response.IsSuccessStatusCode)
                    return Ok(JObject.Parse(response.Content.ReadAsStringAsync().Result));

                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }

        /// <summary>
        /// to reactive location
        /// </summary>
        /// <param name="locationId">mandatory</param>
        /// <param name="userId">mandatory</param>
        /// <returns></returns>
		[HttpPatch]
        [Route("apigateway/locationreactive/{locationId}/{userId}")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        //[ExceptionHandler]
        public IHttpActionResult ReactiveLocation(int locationId, int userId)
        {
            HttpClient client;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.SendAsync(new HttpRequestMessage(new HttpMethod("PATCH"), "api/location/" + locationId + "/" + userId)).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));

            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }

        /// <summary>
        /// to create a new location
        /// </summary>
        /// <param name="locationDetails">mandatory</param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/location/Savelocation")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult SaveLocationDetails([FromBody] object locationDetails)
        {
            HttpClient client;
            string LocationData = string.Empty;
            StringContent LocationDataContent = null;
            HttpResponseMessage response = null;
            try
            {
                usermodelObj = new UserModel();
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                LocationData = usermodelObj.DecodeAndValidate(locationDetails);
                if (LocationData == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");
                LocationDataContent = new StringContent(LocationData, UnicodeEncoding.UTF8, "application/json");
                response = client.PostAsync("api/location", LocationDataContent).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Content(HttpStatusCode.BadRequest, response.Content.ReadAsStringAsync().Result);

            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                LocationData = null;
                LocationDataContent = null;
                response = null;
                usermodelObj = null;
            }

        }

        /// <summary>
        /// to inactivate location
        /// </summary>
        /// <param name="locationId">mandatory</param>
        /// <param name="userId">mandatory</param>
        /// <returns></returns>
        [HttpDelete]
        [Route("apigateway/location/{locationId}/{userId}")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult DeleteLocationDetails(int locationId, int userId)
        {
            HttpClient client;
            HttpResponseMessage response = null;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.DeleteAsync("api/location/" + locationId + "/" + userId).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Content(HttpStatusCode.BadRequest, response.Content.ReadAsStringAsync().Result);

            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }


        #endregion

        #region Locations
        /// <summary>
        /// to get locations
        /// </summary>
        /// <returns></returns>

        [HttpGet]
        [Route("apigateway/Locations")]
        [RequestValidation]
        public IHttpActionResult Locations()
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage response = client.GetAsync("api/v1.0/Locations").Result;
                if (response.IsSuccessStatusCode)
                {
                    //var data = response.Content.ReadAsAsync<IEnumerable<apigatewayController>>().Result;                    

                    JArray jsonArray = JArray.Parse(response.Content.ReadAsStringAsync().Result);

                    return Ok(jsonArray);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }
        #endregion

        #region Mcnmanagement
        /// <summary>
        /// to get mcn details
        /// </summary>
        /// <param name="mcnId">mandatory</param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/MCN/Details/{mcnId}")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult GetMcnManagementDetails(int mcnId)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/MCN/Details/" + mcnId).Result;
                if (response.IsSuccessStatusCode)
                {
                    return Ok(response.Content.ReadAsStringAsync().Result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex)
            {
                return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message));
            }
            finally { }
        }

        /// <summary>
        /// to delete MCN
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/MCN/InactivateMCN")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult DeleteMCN([FromBody] object request)
        {
            try
            {
                usermodelObj = new UserModel();
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var content = usermodelObj.DecodeAndValidate(request);
                if (content == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");
                //var content = JsonConvert.SerializeObject(request);
                var stringContent = new StringContent(content, UnicodeEncoding.UTF8, "application/json");
                HttpResponseMessage response = client.PostAsync("api/MCN/Delete", stringContent).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    //return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                    return Content(HttpStatusCode.BadRequest, response.Content.ReadAsStringAsync().Result);
                }
            }
            catch (Exception ex) { return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message)); }
            finally
            {
                usermodelObj = null;
            }
        }
        /// <summary>
        /// to add mcn details
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/MCN")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult AddMCN([FromBody] object request)
        {
            try
            {
                usermodelObj = new UserModel();
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var content = usermodelObj.DecodeAndValidate(request);
                if (content == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");
                var stringContent = new StringContent(content, UnicodeEncoding.UTF8, "application/json");
                HttpResponseMessage response = client.PostAsync("api/MCN/AddMCN", stringContent).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Content(HttpStatusCode.BadRequest, response.Content.ReadAsStringAsync().Result);
                }
            }
            catch (Exception ex) { return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message)); }
            finally
            {
                usermodelObj = null;
            }
        }
        /// <summary>
        /// to check mcn cachement have patient or not
        /// </summary>
        /// <param name="catchments"></param>
        /// <param name="Id"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/MCN/CatchPatCount/{catchments}/{Id}")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult MCNCatchmentHavePatients(string catchments, int Id)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/MCN/CatchPatCount/" + catchments + "/" + Id).Result;
                if (response.IsSuccessStatusCode)
                {
                    return Ok(response.Content.ReadAsStringAsync().Result);
                }
                else
                {
                    return Content(HttpStatusCode.BadRequest, response.Content.ReadAsStringAsync().Result);
                }
            }
            catch (Exception ex) { return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message)); }
            finally { }
        }

        /// <summary>
        ///  to check mcn rol have paitent or not
        /// </summary>
        /// <param name="roles"></param>
        /// <param name="StaffId"></param>
        /// <param name="staffType"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/MCN/RolePatCount/{roles}/{StaffId}/{staffType}")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult MCNRoleHavePatients(string roles, long StaffId, int staffType)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/MCN/RolePatCount/" + roles + "/" + StaffId + "/" + staffType).Result;
                if (response.IsSuccessStatusCode)
                {
                    return Ok(response.Content.ReadAsStringAsync().Result);
                }
                else
                {
                    return Content(HttpStatusCode.BadRequest, response.Content.ReadAsStringAsync().Result);
                }
            }
            catch (Exception ex) { return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message)); }
            finally { }
        }

        /// <summary>
        /// to get default mcn configuration details
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>

        [HttpGet]
        [Route("apigateway/mcn/defaultconfiguration/{Userid}")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult GetMCNDefaultConfigurations(long userID)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/mcn/defaultconfiguration/" + userID).Result;
                if (response.IsSuccessStatusCode)
                {
                    return Ok(response.Content.ReadAsStringAsync().Result);
                }
                else
                {
                    return Content(HttpStatusCode.BadRequest, response.Content.ReadAsStringAsync().Result);
                }
            }
            catch (Exception ex) { return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message)); }
            finally { }
        }

        #endregion "mcnmanagement"

        #region AdhocReports


        /// <summary>
        /// to active patient details
        /// </summary>       
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/adhocreports/patients")]
        [RequestValidation]
        public IHttpActionResult GetActivePatients()
        {

            HttpClient client = new HttpClient();
            try
            {
                client.BaseAddress = new Uri("http://localhost:57573/");
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/adhocreports/patient").Result;
                if (response.IsSuccessStatusCode)
                {

                    JArray jsonArray = JArray.Parse(response.Content.ReadAsStringAsync().Result);
                    return Ok(jsonArray);
                }
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally { client = null; }


        }

        /// <summary>
        /// to get all patient details
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/adhocreports/patients/{startindex}/{endindex}")]
        [RequestValidation]
        public IHttpActionResult GetAllPatients(int startindex, int endindex)
        {

            HttpClient client = new HttpClient();
            try
            {
                client.BaseAddress = new Uri("http://localhost:57573/");
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/adhocreports/patient/" + startindex + "/" + endindex).Result;
                if (response.IsSuccessStatusCode)
                {

                    JArray jsonArray = JArray.Parse(response.Content.ReadAsStringAsync().Result);
                    return Ok(jsonArray);
                }
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally { client = null; }


        }

        /// <summary>
        /// to get all mcn details
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/adhocreports/mcnlist")]
        [RequestValidation]
        public IHttpActionResult GetMCNList()
        {
            HttpClient client = new HttpClient();
            try
            {
                client.BaseAddress = new Uri("http://localhost:57573/");
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/adhocreports/mcnlist").Result;
                if (response.IsSuccessStatusCode)
                {

                    JArray jsonArray = JArray.Parse(response.Content.ReadAsStringAsync().Result);
                    return Ok(jsonArray);
                }
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally { client = null; }
        }

        /// <summary>
        /// to get all patient address details
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/adhocreports/patientaddress")]
        [RequestValidation]
        public IHttpActionResult GetAllPatientAddress()
        {
            HttpClient client = new HttpClient();
            try
            {
                client.BaseAddress = new Uri("http://localhost:57573/");
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/adhocreports/patientaddress").Result;
                if (response.IsSuccessStatusCode)
                {

                    JArray jsonArray = JArray.Parse(response.Content.ReadAsStringAsync().Result);
                    return Ok(jsonArray);
                }
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally { client = null; }
        }

        /// <summary>
        /// to get specialform data based on given customformid
        /// </summary>
        /// <param name="formId">mandatory</param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/adhocreports/specialform/{formid}")]
        [RequestValidation]
        public IHttpActionResult GetSpecialFormData(long formId)
        {
            return Ok("");
        }

        /// <summary>
        /// to get contactanalysis specialform data        
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/adhocreports/contactanalysis")]
        [RequestValidation]
        public IHttpActionResult GetContactAnalysisData()
        {
            /*var formId = "1000";
            SELECT Patient.PAT_ID, Patient.PAT_Forename1, Patient.PAT_Surname,Patient.PAT_DOB, Patient.PAT_Primary_Identifier, Patient.PAT_Secondary_Identifier, tblPCF_1000.CFC100013 AS 'Time Started', tblPCF_1000.CFC100028 AS 'Logged in User', tblPCF_1000.ID AS 'Contact ID',
                 tblPCF_1000.CFC100625 AS 'Cause 1', tblPCF_1000.CFC100630 AS 'Cause2', tblPCF_1000.CFC100631 AS 'Cause 3', tblPCF_1000.CFC100632 AS 'Cause 4', tblUDFLookupValue.Description AS 'Type', tblUDFLookupValue_1.Description AS 'Prompt', tblUDFLookupValue_2.Description as 'Service Type'
            FROM tblPCF_1000 LEFT OUTER JOIN
           tblUDFLookupValue AS tblUDFLookupValue_2 ON tblPCF_1000.CFC101357 = tblUDFLookupValue_2.ID LEFT OUTER JOIN
           tblUDFLookupValue AS tblUDFLookupValue_1 ON tblPCF_1000.CFC100015 = tblUDFLookupValue_1.ID LEFT OUTER JOIN
           tblUDFLookupValue ON tblPCF_1000.CFC100016 = tblUDFLookupValue.ID LEFT OUTER JOIN
           Patient ON tblPCF_1000.Patient_ID = Patient.PAT_ID
            where tblPCF_1000.isactive = 1 and Patient.isactive = 1*/


            /*SELECT App.[id]       ,App.[pat_id]    ,App.[startdatetime]    ,CLN.CLN_Fname    ,CLN.CLN_SName    ,l1.Description    ,P.PAT_Forename1    ,P.PAT_Surname    ,l2.lookupValue
            ,G.Pat_ID
            ,P2.Pat_forename1, P2.PAT_Surname
            FROM[AdhocReportsDB_SBHS_PROD].[dbo].[tblApptSchedule] as App
            LEFT OUTER JOIN[AdhocReportsDB_SBHS_PROD].[dbo].[Clinician] as CLN ON App.clinician_id = CLN.CLN_ID
            LEFT OUTER JOIN[AdhocReportsDB_SBHS_PROD].[dbo].tblUDFLookupValue as l1 ON App.clinic_id = l1.id
            LEFT OUTER JOIN[AdhocReportsDB_SBHS_PROD].[dbo].Patient as P ON App.pat_id = P.Pat_id
            LEFT OUTER JOIN[AdhocReportsDB_SBHS_PROD].[dbo].tbllookup as l2 ON App.attendance_code_slu = l2.id
            LEFT OUTER JOIN[AdhocReportsDB_SBHS_PROD].[dbo].tblApptGroupPatient as G ON App.id = G.Appt_ID
            LEFT OUTER JOIN[AdhocReportsDB_SBHS_PROD].[dbo].Patient as P2 ON G.pat_id = P2.Pat_id*/
            return Ok("");
        }

        /// <summary>
        /// to get appointmentscheduler information    
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/adhocreports/apptmntscheduler")]
        [RequestValidation]
        public IHttpActionResult ApptSchedulerInfo()
        {

            HttpClient client = new HttpClient();
            try
            {
                client.BaseAddress = new Uri("http://localhost:57573/");
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/adhocreports/apptmntschedulerInfo").Result;
                //HttpResponseMessage response = client.GetAsync("api/adhocreports/apptmntschedulerInfo/" + startindex + "/" + endindex).Result;
                if (response.IsSuccessStatusCode)
                {

                    JArray jsonArray = JArray.Parse(response.Content.ReadAsStringAsync().Result);
                    return Ok(jsonArray);
                }
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally { client = null; }

        }

        #endregion

        #region Healthboard
        /// <summary>
        /// to get healthboard confi daa
        /// </summary>  
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/healthboard")]
        [TokenAuthenticationFilter]
        //[ExceptionHandler]
        [RequestValidation]
        public IHttpActionResult GetHealthBoardConfigData()
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/healthboard").Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }

            }
            catch (Exception ex) { throw ex; }
            finally { }

        }

        /// <summary>
        /// to get health board details for the given healthBoardId
        /// </summary>
        /// <param name="healthBoardId">mandatory</param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/healthboard/{healthBoardId}")]
        [TokenAuthenticationFilter]
        //[ExceptionHandler]
        [RequestValidation]
        public IHttpActionResult GethealthBoardId(int healthBoardId)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/healthboard/" + healthBoardId).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }

            }
            catch (Exception ex) { throw ex; }
            finally { }

        }

        /// <summary>
        /// to save healhtboard details 
        /// </summary>
        /// <param name="request">mandatory</param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/healthboard")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult SaveHealthBoard([FromBody] object request)
        {
            string HealthBoardData = string.Empty;
            StringContent HealthBoardDataContent = null;
            HttpClient client = null;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();
                usermodelObj = new UserModel();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HealthBoardData = usermodelObj.DecodeAndValidate(request);
                if (HealthBoardData == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");
                HealthBoardDataContent = new StringContent(HealthBoardData, UnicodeEncoding.UTF8, "application/json");
                response = client.PostAsync("api/healthboard", HealthBoardDataContent).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                HealthBoardData = null;
                HealthBoardDataContent = null;
                client = null;
                response = null;
                usermodelObj = null;
            }
        }
        /// <summary>
        /// delete healtbord  for the given healthBoardId and user id
        /// </summary>
        /// <param name="healthBoardId">mandatory</param>
		/// <param name="userId">mandatory</param>
        /// <returns></returns>
        [HttpDelete]
        [Route("apigateway/healthboard/{healthBoardId}/{userId}")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult DeleteHealthBoard(int healthBoardId, int userId)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.DeleteAsync("api/healthboard/" + healthBoardId + "/" + userId).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }
        /// <summary>
        /// to reactivate healthboard
        /// </summary>
        /// <param name="healthBoardId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        [HttpPatch]
        [Route("apigateway/healthboard/{healthBoardId}/{userId}")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult ReactiveHealthBoard(int healthBoardId, int userId)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.SendAsync(new HttpRequestMessage(new HttpMethod("PATCH"), "api/healthboard/" + healthBoardId + "/" + userId)
                {
                    Content = null
                }).Result;

                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }
        #endregion

        #region SecurityGroup
        /// <summary>
        /// to get securitygroup details
        /// </summary>
        /// <param name="securityGroup_Id">mandatory</param>
        /// <param name="strType">mandatory</param>
        /// <param name="intParentModule_Id">mandatory</param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/SecurityGroup/{securityGroup_Id}/{strType}/{intParentModule_Id}")]
        [TokenAuthenticationFilter]
        //[ExceptionHandler]
        [RequestValidation]
        public IHttpActionResult GetSecurityGroups(int securityGroup_Id, string strType, int intParentModule_Id)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/SecurityGroup/" + securityGroup_Id + "/" + strType + "/" + intParentModule_Id).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }

            }
            catch (Exception ex) { throw ex; }
            finally { }

        }

        /// <summary>
        /// save  SecurityGroup
        /// </summary>
        /// <param name="request">mandatory</param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/SecurityGroup")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult SaveSecurityGroups([FromBody] object request)
        {
            UserModel usermodelObj;
            try
            {
                string securityGroupsData = string.Empty;
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                usermodelObj = new UserModel();
                securityGroupsData = usermodelObj.DecodeAndValidate(request);

                if (securityGroupsData == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");
                //var content = JsonConvert.SerializeObject(request);
                var stringContent = new StringContent(securityGroupsData, UnicodeEncoding.UTF8, "application/json");

                HttpResponseMessage response = client.PostAsync("api/SecurityGroup", stringContent).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                usermodelObj = null;
            }
        }



        /// <summary>
        /// delete SecurityGroup for the groupId and userId
        /// </summary>
        /// <param name="groupId">mandatory</param>
		/// <param name="userId">mandatory</param>
        /// <returns></returns>
        [HttpDelete]
        [Route("apigateway/SecurityGroup/{groupId}/{userId}")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult DeleteSecurityGroup(int groupId, int userId)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.DeleteAsync("api/SecurityGroup/" + groupId + "/" + userId).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }
        #endregion

        #region AclGroup
        /// <summary>
        /// getting acl group details
        /// </summary>
        /// <param name="groupId"></param>
        /// <returns></returns>

        [HttpGet]
        [Route("apigateway/aclGroup/{groupId}")]
        [TokenAuthenticationFilter]
        //[ExceptionHandler]
        [RequestValidation]
        public IHttpActionResult GetAclGroupDetails(Int64 groupId)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/AclGroup/" + groupId).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }

            }
            catch (Exception ex) { throw ex; }
            finally { }

        }
        /// <summary>
        /// to validate acl group
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/validateaclgroup")]
        [TokenAuthenticationFilter]
        //[ExceptionHandler]
        [RequestValidation]
        public IHttpActionResult ValidateACLGroup([FromBody] object request)
        {
            usermodelObj = new UserModel();
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var content = usermodelObj.DecodeAndValidate(request);
                if (content == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");
                var stringContent = new StringContent(content, UnicodeEncoding.UTF8, "application/json");
                HttpResponseMessage response = client.PostAsync("api/ValidateACLGroup", stringContent).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                usermodelObj = null;
            }

        }
        /// <summary>
        /// to delete ACL group
        /// </summary>
        /// <param name="groupId"></param>
        /// <returns></returns>
        [HttpDelete]
        [Route("apigateway/aclgroup/{groupId}")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult DeleteACLGroup(Int64 groupId)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.DeleteAsync("api/aclgroup/" + groupId).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }
        /// <summary>
        /// to save acl details
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/aclgroup")]
        [TokenAuthenticationFilter]
        //[ExceptionHandler]
        [RequestValidation]
        public IHttpActionResult SaveAclDetails([FromBody] object request)
        {
            usermodelObj = new UserModel();
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var content = usermodelObj.DecodeAndValidate(request);
                if (content == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");
                var stringContent = new StringContent(content, UnicodeEncoding.UTF8, "application/json");
                HttpResponseMessage response = client.PostAsync("api/AclGroup", stringContent).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally { usermodelObj = null; }
        }
        /// <summary>
        /// to save acl staff
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>

        [HttpPost]
        [Route("apigateway/aclstaff")]
        [TokenAuthenticationFilter]
        //[ExceptionHandler]
        [RequestValidation]
        public IHttpActionResult SaveAclStaffDetails([FromBody] object request)
        {
            usermodelObj = new UserModel();
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                // var myContent = JsonConvert.SerializeObject(request);
                var content = usermodelObj.DecodeAndValidate(request);
                if (content == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");
                var stringContent = new StringContent(content, UnicodeEncoding.UTF8, "application/json");
                HttpResponseMessage response = client.PostAsync("api/AclStaff", stringContent).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { usermodelObj = null; }

        }
        /// <summary>
        /// to save acl patient
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/aclpatient")]
        [TokenAuthenticationFilter]
        //[ExceptionHandler]
        [RequestValidation]
        public IHttpActionResult SaveAclPatientDetails([FromBody] object request)
        {
            usermodelObj = new UserModel();
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                // var myContent = JsonConvert.SerializeObject(request);
                var content = usermodelObj.DecodeAndValidate(request);
                if (content == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");
                var stringContent = new StringContent(content, UnicodeEncoding.UTF8, "application/json");
                HttpResponseMessage response = client.PostAsync("api/AclPatient", stringContent).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { usermodelObj = null; }
        }

        #endregion AclGroup

        #region PatientMerge
        /// <summary>
        /// to merge patient  
        /// </summary>
        /// <param name="request">mandatory</param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/Merge")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult Merge([FromBody] object request)
        {
            try
            {
                HttpClient client = new HttpClient();
                usermodelObj = new UserModel();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //var content = JsonConvert.SerializeObject(request);
                var content = usermodelObj.DecodeAndValidate(request);
                if (content == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");
                var stringContent = new StringContent(content, UnicodeEncoding.UTF8, "application/json");
                HttpResponseMessage response = client.PostAsync("api/Merge", stringContent).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(JObject.Parse(result));
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }

        /// <summary>
        /// to unmerge patient  
        /// </summary>
        /// <param name="request">mandatory</param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/Unmerge")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult Unmerge([FromBody] object request)
        {
            try
            {
                HttpClient client = new HttpClient();
                usermodelObj = new UserModel();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //var content = JsonConvert.SerializeObject(request);
                var content = usermodelObj.DecodeAndValidate(request);
                if (content == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");
                var stringContent = new StringContent(content, UnicodeEncoding.UTF8, "application/json");
                HttpResponseMessage response = client.PostAsync("api/Unmerge", stringContent).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = JsonConvert.DeserializeObject(response.Content.ReadAsStringAsync().Result);
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }

        /// <summary>
        /// to get merge and unmerge data  
        /// </summary>   
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/mergeunmerge")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult GetMergeUnMergeData()
        {
            try
            {

                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/mergeunmerge").Result;
                if (response.IsSuccessStatusCode)
                {

                    //return Ok(response.Content.ReadAsStringAsync().Result);
                    var result = JsonConvert.DeserializeObject(response.Content.ReadAsStringAsync().Result);
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }
        /// <summary>
        /// to get identifier data
        /// </summary>
        /// <returns></returns>

        [HttpGet]
        [Route("apigateway/identifier")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult GetIdentifierData()
        {
            try
            {

                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/identifier").Result;
                if (response.IsSuccessStatusCode)
                {

                    var result = JsonConvert.DeserializeObject(response.Content.ReadAsStringAsync().Result);
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }
        #endregion

        #region CapabilityManagement
        /// <summary>
        /// to get Capability Based on id
        /// </summary>
        /// <param name="capability_id">mandatory</param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/capabilitymanagement/{capability_id}")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult ListofCapabilities(long capability_id)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(strApiUrl);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.GetAsync("api/capabilitymanagement/get/" + capability_id).Result;
            if (response.IsSuccessStatusCode)
            {
                return Ok(JObject.Parse(response.Content.ReadAsStringAsync().Result));
            }
            else
            {
                return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
        }

        /// <summary>
        /// to check duplicate prescribercode
        /// </summary>
        /// <param name="prescberCode"></param>
        /// <param name="userId"></param>
        /// <returns></returns>

        [HttpGet]
        [Route("apigateway/checkduplicateprescribercode/{prescberCode}/{userId}")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult GetCapabilities(long prescberCode, long userId)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(strApiUrl);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.GetAsync("api/usercapability/checkduplicateprescribercode/" + prescberCode + "/" + userId).Result;
            if (response.IsSuccessStatusCode)
            {
                return Ok(JObject.Parse(response.Content.ReadAsStringAsync().Result));
            }
            else
            {
                return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
        }


        /// <summary>
        /// to get capabilities
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/capabilitymanagement")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult GetCapabilities()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(strApiUrl);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.GetAsync("api/capabilitymanagement/get").Result;
            if (response.IsSuccessStatusCode)
            {

                return Ok(JObject.Parse(response.Content.ReadAsStringAsync().Result));
            }
            else
            {
                return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
        }

        /// <summary>
        /// to get user capabilities
        /// </summary>
        /// <param name="uId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/usercapability/{uId}")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult GetUserCapability(long uId)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(strApiUrl);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.GetAsync("api/capabilitymanagement/usercapability/" + uId).Result;
            if (response.IsSuccessStatusCode)
            {
                return Ok(JObject.Parse(response.Content.ReadAsStringAsync().Result));
            }
            else
            {
                return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }

        }

        /// <summary>
        /// to add capabilitymanagement
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/capabilitymanagementadd")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult SaveCapabilities([FromBody] object request)
        {
            try
            {
                usermodelObj = new UserModel();
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //var content = JsonConvert.SerializeObject(request);
                var content = usermodelObj.DecodeAndValidate(request);
                if (content == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");
                var stringContent = new StringContent(content.ToString(), UnicodeEncoding.UTF8, "application/json");
                HttpResponseMessage response = client.PostAsync("api/capabilitymanagement/add", stringContent).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                usermodelObj = null;
            }

        }

        /// <summary>
        /// to delete capability
        /// </summary>
        /// <param name="objDeleteInfo">mandatory</param>
        /// <returns></returns>
        [HttpDelete]
        [Route("apigateway/capabilitymanagementdelete")]
        [RequestValidation]
        public IHttpActionResult DeleteCapabilities([FromBody] object objDeleteInfo)
        {
            try
            {
                usermodelObj = new UserModel();
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //var content = JsonConvert.SerializeObject(objDeleteInfo);
                var content = usermodelObj.DecodeAndValidate(objDeleteInfo);
                if (content == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");
                //var stringContent = new StringContent(content, UnicodeEncoding.UTF8, "application/json");
                var stringContent = new StringContent(content.ToString(), UnicodeEncoding.UTF8, "application/json");
                HttpResponseMessage response = client.SendAsync(new HttpRequestMessage(new HttpMethod("DELETE"), "api/capabilitymanagement/delete")
                {
                    Content = stringContent
                }).Result;

                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(JObject.Parse(result));
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                usermodelObj = null;
            }
        }
        #endregion

        #region NHSTrust 

        /// <summary>
        /// to get configuration date for health board
        /// </summary>     
        /// <returns></returns>
        /// 
        [HttpGet]
        [Route("apigateway/nhstrust")]
        [TokenAuthenticationFilter]
        //[ExceptionHandler]
        [RequestValidation]
        public IHttpActionResult GetNHSTrustConfigData()
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/nhstrust").Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }

            }
            catch (Exception ex) { throw ex; }
            finally { }

        }
        /// <summary>
        /// to get nhstrust details
        /// </summary>
        /// <param name="nhsId">mandatory</param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/nhstrust/{nhsId}")]
        [TokenAuthenticationFilter]
        //[ExceptionHandler]
        [RequestValidation]
        public IHttpActionResult GetNHSTrustDetails(int nhsId)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.GetAsync("api/nhstrust/" + nhsId).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }

            }
            catch (Exception ex) { throw ex; }
            finally { }

        }
       /// <summary>
       /// to save nhstrust details
       /// </summary>
       /// <param name="request"></param>
       /// <returns></returns>
        [HttpPost]
        [Route("apigateway/nhstrust")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult SaveNHSTrustDetails([FromBody] object request)
        {
            string NHSTrustData = string.Empty;
            StringContent NHSTrustDataContent = null;
            HttpClient client = null;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();
                usermodelObj = new UserModel();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                NHSTrustData = usermodelObj.DecodeAndValidate(request);
                if (NHSTrustData == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");
                NHSTrustDataContent = new StringContent(NHSTrustData, UnicodeEncoding.UTF8, "application/json");
                response = client.PostAsync("api/nhstrust", NHSTrustDataContent).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                NHSTrustData = null;
                NHSTrustDataContent = null;
                client = null;
                response = null;
                usermodelObj = null;
            }
        }
        /// <summary>
        /// delete healtbord  for the given healthBoardId and user id
        /// </summary>
        /// <param name="nhsTrustId">mandatory</param>
		/// <param name="userId">mandatory</param>
        /// <returns></returns>
        [HttpDelete]
        [Route("apigateway/nhstrust/{nhsTrustId}/{userId}")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult DeleteNHSTrustDetails(int nhsTrustId, int userId)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.DeleteAsync("api/nhstrust/" + nhsTrustId + "/" + userId).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }
        /// <summary>
        /// to reactive nhstrust
        /// </summary>
        /// <param name="nhsTrustId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        [HttpPatch]
        [Route("apigateway/nhstrust/{nhsTrustId}/{userId}")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult ReactiveNHSTrustDetails(int nhsTrustId, int userId)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = client.SendAsync(new HttpRequestMessage(new HttpMethod("PATCH"), "api/nhstrust/" + nhsTrustId + "/" + userId)
                {
                    Content = null
                }).Result;

                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }
        #endregion

        #region DictioinaryManagement

        /// <summary>
        /// to get all dictionary details
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/dictionaries")]
        [TokenAuthenticationFilter]
        [EnableCors]
        [RequestValidation]
        //[ExceptionHandler]
        //[Throttle("GetListOfUsers", "", 20)]
        public IHttpActionResult GetListofDictionares()
        {
            HttpClient client;
            HttpResponseMessage response;
            JArray jsonArray;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/dictionaries").Result;
                if (response.IsSuccessStatusCode)
                {
                    jsonArray = JArray.Parse(response.Content.ReadAsStringAsync().Result);
                    return Ok(jsonArray);
                }
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
                jsonArray = null;
            }
        }

        /// <summary>
        /// to get dictionary editor information
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/dictionaryeditor/{dictID}")]
        [TokenAuthenticationFilter]
        [EnableCors]
        [RequestValidation]
        //[ExceptionHandler]
        //[Throttle("GetListOfUsers", "", 20)]
        public IHttpActionResult GetDictionaryInfo(int dictID)
        {
            HttpClient client;
            HttpResponseMessage response;
            //JArray jsonArray;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/dictionaryeditor/" + dictID).Result;
                if (response.IsSuccessStatusCode)
                {
                    // jsonArray = JArray.Parse(response.Content.ReadAsStringAsync().Result);
                    return Ok(response.Content.ReadAsStringAsync().Result);
                }
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
                //jsonArray = null;
            }
        }

        /// <summary>
        /// to save dictionary data
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/dictionaryeditor/{dictID}")]
        [TokenAuthenticationFilter]
        [EnableCors]
        [RequestValidation]
        //[ExceptionHandler]
        //[Throttle("GetListOfUsers", "", 20)]
        public IHttpActionResult SaveDictionaryData(int dictID, [FromBody] object objDictData)
        {
            HttpClient client;
            HttpResponseMessage response;
            StringContent DataContent = null;
            usermodelObj = new UserModel();
            string strDictData = "";
            try
            {
                strDictData = usermodelObj.DecodeAndValidate(objDictData);

                if (strDictData == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");

                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                DataContent = new StringContent(strDictData, UnicodeEncoding.UTF8, "application/json");
                response = client.PostAsync("api/dictionaryeditor/" + dictID, DataContent).Result;
                if (response.IsSuccessStatusCode)
                {
                    //jsonArray = JArray.Parse(response.Content.ReadAsStringAsync().Result);
                    return Ok(response.Content.ReadAsStringAsync().Result);
                }
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }

        /// <summary>
        /// to inactivate/ reactivate dictionary data
        /// </summary>
        /// <param name="objDeleteInfo"></param>
        /// <returns></returns>
        [HttpDelete]
        [Route("apigateway/dictionary")]
        [TokenAuthenticationFilter]
        [EnableCors]
        [RequestValidation]
        public IHttpActionResult DeleteorReactiveDictData([FromBody] object objDeleteInfo)
        {
            HttpClient client = null;
            HttpResponseMessage response;
            string deleteInfo = string.Empty;
            StringContent deleteInfoContent = null;
            try
            {
                client = new HttpClient();
                usermodelObj = new UserModel();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                deleteInfo = usermodelObj.DecodeAndValidate(objDeleteInfo);

                if (deleteInfo == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");

                deleteInfoContent = new StringContent(deleteInfo, UnicodeEncoding.UTF8, "application/json");
                response = client.SendAsync(new HttpRequestMessage(new HttpMethod("DELETE"), "api/dictionary")
                {
                    Content = deleteInfoContent
                }).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
                deleteInfo = null;
                deleteInfoContent = null;
                usermodelObj = null;
            }
        }

        /// <summary>
        /// to get dictionary dependencies
        /// </summary>
        /// <param name="dictID"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/dictionarydependencies/{dictID}")]
        [TokenAuthenticationFilter]
        [EnableCors]
        [RequestValidation]
        //[ExceptionHandler]
        //[Throttle("GetListOfUsers", "", 20)]
        public IHttpActionResult GetDictionaryDependencies(int dictID)
        {
            HttpClient client;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/dictionarydependencies/" + dictID).Result;
                if (response.IsSuccessStatusCode)

                    return Ok(response.Content.ReadAsStringAsync().Result);

                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }

        #endregion

        #region Tasklist
        /// <summary>
        /// to fetch Task Management details
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/taskmanagement")]
        [TokenAuthenticationFilter]
        [EnableCors]
        [RequestValidation]
        //[ExceptionHandler]
        public IHttpActionResult GetTaskManagementDetails()
        {
            HttpClient client;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/taskmanagement").Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);

                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }

        /// <summary>
        /// to fetch Task Management config data
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/taskmanagementconfigdata")]
        [TokenAuthenticationFilter]
        [EnableCors]
        [RequestValidation]
        //[ExceptionHandler]
        public IHttpActionResult GetTaskManagementConfigData()
        {
            HttpClient client;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/taskmanagementconfigdata").Result;

                if (response.IsSuccessStatusCode)
                    return Ok(JObject.Parse(response.Content.ReadAsStringAsync().Result));

                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }

            finally
            {
                client = null;
                response = null;
            }
        }


        /// <summary>
        /// to create a new Task Management Details
        /// </summary>
        /// <param name="tasklistManagementDetails">mandatory</param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/taskmanagement")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult SaveTaskManagementDetails([FromBody] object tasklistManagementDetails)
        {
            HttpClient client;
            string TasklistManagementData = string.Empty;
            StringContent TasklistManagementDataContent = null;
            HttpResponseMessage response = null;
            try
            {
                usermodelObj = new UserModel();
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                TasklistManagementData = usermodelObj.DecodeAndValidate(tasklistManagementDetails);
                if (TasklistManagementData == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");
                TasklistManagementDataContent = new StringContent(TasklistManagementData, UnicodeEncoding.UTF8, "application/json");
                response = client.PostAsync("api/taskmanagement", TasklistManagementDataContent).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Content(HttpStatusCode.BadRequest, response.Content.ReadAsStringAsync().Result);

            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                TasklistManagementData = null;
                TasklistManagementDataContent = null;
                response = null;
                usermodelObj = null;
            }

        }
        /// <summary>
        /// to inactivate Task Management
        /// </summary>
        /// <param name="objDeleteInfo">mandatory</param>
        /// <returns></returns>
        [HttpDelete]
        [Route("apigateway/taskmanagement")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult DeleteTaskManagementDetails([FromBody] object objDeleteInfo)
        {
            HttpClient client = null;
            HttpResponseMessage response;
            string deleteInfo = string.Empty;
            StringContent deleteInfoContent = null;
            try
            {
                client = new HttpClient();
                usermodelObj = new UserModel();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                deleteInfo = usermodelObj.DecodeAndValidate(objDeleteInfo);

                if (deleteInfo == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");

                deleteInfoContent = new StringContent(deleteInfo, UnicodeEncoding.UTF8, "application/json");
                response = client.SendAsync(new HttpRequestMessage(new HttpMethod("DELETE"), "api/taskmanagement")
                {
                    Content = deleteInfoContent
                }).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
                deleteInfo = null;
                deleteInfoContent = null;
                usermodelObj = null;
            }
        }

        /// <summary>
        /// to get all the task list summary details
        /// </summary>
        /// <param name="userId">Login User Id</param> 
        /// <returns></returns>
        [HttpGet]
        [Route("~/apigateway/taskslist/{userId}")]
        [TokenAuthenticationFilter]
        [EnableCors]
        [RequestValidation]
        public IHttpActionResult GetTasksList(long userId)
        {
            HttpClient client;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/taskslist/" + userId).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }

        /// <summary>
        /// to get all the Lookups and Config data for Task List
        /// </summary>
        /// <param name="userId">Login User Id</param>     
        /// <returns></returns>
        [HttpGet]
        [Route("~/apigateway/tasklistconfig/{userId}")]
        [TokenAuthenticationFilter]
        [EnableCors]
        [RequestValidation]
        public IHttpActionResult GetTaskListConfigData(long userId)
        {
            HttpClient client;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/tasklistconfig/" + userId).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }

        /// <summary>
        /// to get the given task list id details
        /// </summary>
        /// <param name="taskListId">selected task list id</param>    
        /// <param name="userId">Login User Id</param>
        /// <returns></returns>
        [HttpGet]
        [Route("~/apigateway/tasklist/{taskListId}/{userId}")]
        [TokenAuthenticationFilter]
        [EnableCors]
        [RequestValidation]
        public IHttpActionResult GetTaskListDetails(int taskListId, long userId)
        {
            HttpClient client;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/tasklist/" + taskListId + "/" + userId).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
            }
        }

        /// <summary>
        /// to save the given Task List Details
        /// </summary>
        /// <param name="objTaskListDetails">Task List Details to save</param>
        /// <returns></returns>
        [HttpPost]
        [Route("~/apigateway/tasklist")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult SaveTaskListDetails([FromBody] object objTaskListDetails)
        {
            HttpClient client;
            HttpResponseMessage response;
            StringContent taskListDataContent = null;
            string strTaskListDetails = "";
            try
            {
                usermodelObj = new UserModel();
                strTaskListDetails = usermodelObj.DecodeAndValidate(objTaskListDetails);
                if (strTaskListDetails == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");

                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                taskListDataContent = new StringContent(strTaskListDetails, UnicodeEncoding.UTF8, "application/json");
                response = client.PostAsync("api/tasklist", taskListDataContent).Result;
                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
                taskListDataContent = null;
                usermodelObj = null;
                strTaskListDetails = null;
            }
        }

        /// <summary>
        /// to delete the given Task List Details
        /// </summary>
        /// <param name="objTaskListDelete">Task List Ids and Other Information to delete</param>
        /// <returns></returns>
        [HttpDelete]
        [Route("~/apigateway/tasklist")]
        [TokenAuthenticationFilter]
        [EnableCors]
        [RequestValidation]
        public IHttpActionResult DeleteTaskListDetails([FromBody] object objTaskListDelete)
        {
            HttpClient client = null;
            HttpResponseMessage response;
            string deleteInfo = string.Empty;
            StringContent deleteInfoContent = null;
            try
            {
                usermodelObj = new UserModel();
                deleteInfo = usermodelObj.DecodeAndValidate(objTaskListDelete);
                if (deleteInfo == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");

                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                deleteInfoContent = new StringContent(deleteInfo, UnicodeEncoding.UTF8, "application/json");
                response = client.SendAsync(new HttpRequestMessage(new HttpMethod("DELETE"), "api/tasklist")
                {
                    Content = deleteInfoContent
                }).Result;

                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
                deleteInfo = null;
                deleteInfoContent = null;
                usermodelObj = null;
            }
        }

        /// <summary>
        /// to update the Notes for selected Task List
        /// </summary>
        /// <param name="objTaskListNotes">Task List Notes Details to save</param>
        /// <returns></returns>
        [HttpPost]
        [Route("~/apigateway/tasklistnotes")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult UpdateTaskListNotes([FromBody] object objTaskListNotes)
        {
            HttpClient client;
            HttpResponseMessage response;
            StringContent taskListNotesContent = null;
            string strTaskListNotes = "";
            try
            {
                usermodelObj = new UserModel();
                strTaskListNotes = usermodelObj.DecodeAndValidate(objTaskListNotes);
                if (strTaskListNotes == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");

                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                taskListNotesContent = new StringContent(strTaskListNotes, UnicodeEncoding.UTF8, "application/json");
                response = client.PostAsync("api/tasklistnotes", taskListNotesContent).Result;
                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
                taskListNotesContent = null;
                usermodelObj = null;
                strTaskListNotes = null;
            }
        }

        /// <summary>
        /// to  update the Task List Status for the Selected Task Lists
        /// </summary>
        /// <param name="objTaskListStatus">Task List Status Detaisl to save</param>
        /// <returns></returns>
        [HttpPost]
        [Route("~/apigateway/taskliststatus")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult UpdateTaskListStatus([FromBody] object objTaskListStatus)
        {
            HttpClient client;
            HttpResponseMessage response;
            StringContent taskListStatusContent = null;
            string strTaskListStatus = "";
            try
            {
                usermodelObj = new UserModel();
                strTaskListStatus = usermodelObj.DecodeAndValidate(objTaskListStatus);
                if (strTaskListStatus == "True")
                    return Content(HttpStatusCode.ExpectationFailed, "422");

                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                taskListStatusContent = new StringContent(strTaskListStatus, UnicodeEncoding.UTF8, "application/json");
                response = client.PostAsync("api/taskliststatus", taskListStatusContent).Result;
                if (response.IsSuccessStatusCode)
                    return Ok(response.Content.ReadAsStringAsync().Result);
                else
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null;
                response = null;
                taskListStatusContent = null;
                usermodelObj = null;
                strTaskListStatus = null;
            }
        }
        #endregion

        #region BTAPI
        /// <summary>
        /// to update SMS delivery status via BT API Webhook triggering event
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("apigateway/btapi/response")]
        [WhitelistIPValidation]
        public IHttpActionResult UpdateBTMessageStatus(HttpRequestMessage request)
        {
            object _logBody;
            try
            {
                _logBody = JsonConvert.SerializeObject(new
                {
                    modulename = "UpdateBTMessageStatus",
                    sessionid = "",
                    patid = -1,
                    event_slu = 2798,
                    eventdetails = "BT message status started.",
                    moduleid = 152,
                    recordid = -1,
                    requestid = ""
                });
                SessionLogger(_logBody);
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var receivedBody = request.Content.ReadAsStringAsync().Result;
                _logBody = JsonConvert.SerializeObject(new
                {
                    modulename = "UpdateBTMessageStatus",
                    sessionid = "",
                    patid = -1,
                    event_slu = 2798,
                    eventdetails = $"Request body: {receivedBody}",
                    moduleid = 152,
                    recordid = -1,
                    requestid = ""
                });
                SessionLogger(_logBody);
                var stringContent = new StringContent(receivedBody, UnicodeEncoding.UTF8, "application/json");
                HttpResponseMessage response = client.PostAsync("api/messaging/smsstatus", stringContent).Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    _logBody = JsonConvert.SerializeObject(new
                    {
                        modulename = "UpdateBTMessageStatus",
                        sessionid = "",
                        patid = -1,
                        event_slu = 2798,
                        eventdetails = $"Response body: {result}",
                        moduleid = 152,
                        recordid = -1,
                        requestid = ""
                    });
                    SessionLogger(_logBody);
                    return Ok(result);
                }
                else
                {
                    _logBody = JsonConvert.SerializeObject(new
                    {
                        modulename = "UpdateBTMessageStatus",
                        sessionid = "",
                        patid = -1,
                        event_slu = 2798,
                        eventdetails = "Facing an issue while getting response. Please contact administrator.",
                        moduleid = 152,
                        recordid = -1,
                        requestid = ""
                    });
                    SessionLogger(_logBody);
                    return Content(response.StatusCode, response.Content); // "Facing an issue while getting response. Please contact administrator.");
                }
            }
            catch (Exception ex)
            {
                _logBody = JsonConvert.SerializeObject(new
                {
                    modulename = "UpdateBTMessageStatus",
                    sessionid = "",
                    patid = -1,
                    event_slu = 2798,
                    eventdetails = $"{ex.Message}\n{ex.StackTrace}",
                    moduleid = 152,
                    recordid = -1,
                    requestid = ""
                });
                SessionLogger(_logBody);
                return Content(HttpStatusCode.InternalServerError, "Some thing went wrong. Please contact administrator.");
                //return InternalServerError(ex);
            }
            finally
            {
                usermodelObj = null;
            }
        }
       
        #endregion

        #region Common 
        /// <summary>
        /// to fetch configuration date for health board
        /// </summary>       
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/print")]
        [TokenAuthenticationFilter]
        //[ExceptionHandler]
        [RequestValidation]
        public IHttpActionResult GetSessionTokenData()
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                var accessToken = this.Request.Headers.GetValues("token").First();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("Token", accessToken);
                HttpResponseMessage response = client.GetAsync("api/common/print").Result;
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
                else
                {
                    return Ok(Request.CreateResponse(HttpStatusCode.BadRequest, "Some thing went wrong. please contact administrator."));
                }

            }
            catch (Exception ex) { throw ex; }
            finally { }

        }
        /// <summary>
        /// to sendFax
        /// </summary>
        /// <param name="moduleId"></param>
        /// <param name="recordIds"></param>
        /// <param name="convertToPdf"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("apigateway/faxdocument/{recordIds}/{moduleId}/{convertToPdf}")]
        [TokenAuthenticationFilter]
        [RequestValidation]
        public IHttpActionResult sendFax(int moduleId, string recordIds, Boolean convertToPdf)
        {
            HttpClient client;
            HttpResponseMessage response;
            try
            {
                client = new HttpClient();
                client.BaseAddress = new Uri(strApiUrl);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                response = client.GetAsync("api/faxdocument/" + recordIds + "/" + moduleId + "/" + convertToPdf).Result;

                if (response.IsSuccessStatusCode)
                {
                    return Ok(response.Content.ReadAsStringAsync().Result);
                }
                else
                {
                    return Content(HttpStatusCode.BadRequest, response.Content.ReadAsStringAsync().Result);
                }

            }
            catch (Exception ex) { throw ex; }
            finally
            {
                client = null; ;
                response = null;
            }
        }
        /// <summary>
        /// to get dateFormats from tblsysLookup DB object
        /// created by: BRR
        /// created datetime: 07-Jan-2023 11:55PM
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("~/apigateway/dateFormats")]
        public async Task<string> getdateFormats()
        {
          
                try
                {
                using (var client = new HttpClient())
                {
                    //Passing service base url  
                    client.BaseAddress = new Uri("https://sandbox.api.service.nhs.uk/");

                    client.DefaultRequestHeaders.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //Sending request to find web api REST service resource GetDepartments using HttpClient  
                    HttpResponseMessage response = await client.GetAsync("personal-demographics/FHIR/R4/Patient");
                    if (response.IsSuccessStatusCode)
                    {
                        return response.Content.ReadAsStringAsync().Result;
                    }
                    else
                    {
                        return "Failured";
                    }
                }

              
            }
                catch (Exception ex) { throw ex; }
                finally { }
          }

        /// <summary>
        /// to post errorlog details into log file
        /// created by: BRR
        /// created datetime: 22-Sep-2022 11:55PM
        /// </summary>
        ///<param name="objLogDetails">{"module": "Special Forms","sessionId": "violxrhodxgxpftjrdg2uur1","patId": -1,"userid": 2039,"logmessage": "onLoading..throwing exception"}</param>
        /// <returns></returns>
        [HttpPost]
        [Route("~/apigateway/log/errorlogger")]
        public void ErrorLogging([FromBody] object objLogDetails)
        {
            //log4net.Config.XmlConfigurator.Configure(new FileInfo(System.Web.HttpContext.Current.Server.MapPath("../../log4net.config")));
            JObject jLogInfo;
            try
            {
                jLogInfo = JObject.Parse(objLogDetails.ToString());
                //log.Error(jLogInfo.ToString());           
            }
            catch (Exception ex)
            {
          InternalServerError(ex);
            }
            finally
            {
                jLogInfo = null;
            }
        }
        /// <summary>
        /// to post information(trace) log details into log file
        /// created by: BRR
        /// created datetime: 22-Sep-2022 11:55PM
        /// </summary>     
        ///<param name="objLogDetails">{"module": "Special Forms","sessionId": "violxrhodxgxpftjrdg2uur1","patId": -1,"userid": 2039,"logmessage": "onLoading..throwing exception"}</param>
        /// <returns></returns>
        [HttpPost]
        [Route("~/apigateway/log/infologger")]
        public void InfoLogging([FromBody] object objLogDetails)
        {
            //log4net.Config.XmlConfigurator.Configure(new FileInfo(System.Web.HttpContext.Current.Server.MapPath("../../log4net.config")));
            JObject jLogInfo;
            try
            {
                jLogInfo = JObject.Parse(objLogDetails.ToString());
                //log.Info(jLogInfo.ToString());
            }
            catch (Exception ex)
            {
                InternalServerError(ex);
            }
            finally
            {
                jLogInfo = null;
            }
        }

        /// <summary>
        /// to post the debug statements into log file
        /// created by: BRR
        /// created datetime: 22-Sep-2022 11:55PM
        /// </summary>
        ///<param name="objLogDetails">{"module": "MCN Management","sessionId": "violxrhodxgxpftjrdg2uur1","patId": -1,"userid": 2039,"logmessage": "onLoading..throwing exception"}</param>
        /// <returns></returns>

        [HttpPost]
        [Route("~/apigateway/log/debuglogger")]
        public void DebugLogging([FromBody] object objLogDetails)
        {
            //log4net.Config.XmlConfigurator.Configure(new FileInfo(System.Web.HttpContext.Current.Server.MapPath("../../log4net.config")));
            JObject jLogInfo;
            try
            {

                jLogInfo = JObject.Parse(objLogDetails.ToString());
                //log.Debug(jLogInfo.ToString());
            }
            catch (Exception ex)
            {
                InternalServerError(ex);
            }
            finally
            {
                jLogInfo = null;
            }
        }
        /// <summary>
        /// to post client session log 
        /// </summary>
        /// <param name="objJson">{"ModuleName": "MCN Management","sessionId": "violxrhodxgxpftjrdg2uur1","patId": -1,"eventSLu": 2039,"eventDetails": "onLoading..","moduleId": 1009,"recordId": -1,"requestId": ""}</param>
        /// <returns></returns>
        [HttpPost]
        [Route("~/api/log/sessionlogger")]
        public IHttpActionResult SessionLogger([FromBody] object objJson)
        {
            JObject jLogInfo;
            try
            {
                jLogInfo = JObject.Parse(objJson.ToString());//JObject.FromObject((JObject)objJson);
                clsECSession.LogWebSessionAction((string)jLogInfo["modulename"], (string)jLogInfo["sessionid"], (int)jLogInfo["patid"], (int)jLogInfo["event_slu"], (string)jLogInfo["eventdetails"], (int)jLogInfo["moduleid"], (int)jLogInfo["recordid"], (string)jLogInfo["requestid"]);
                return Ok(1);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
            finally
            {
                jLogInfo = null;
            }
        }

        #endregion

    }
}
