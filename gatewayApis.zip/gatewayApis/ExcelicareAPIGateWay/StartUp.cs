﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExcelicareAPIGateWay
{
    /// <summary>
    /// startup class
    /// </summary>
    public class StartUp
    {

    }
}