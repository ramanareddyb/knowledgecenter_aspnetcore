﻿using System;
using AxDALUserManagement;
using System.Data;
using Newtonsoft.Json.Linq;
using Excelicare.Framework.AppSupport;
using Excelicare.Framework.AppDataSupport;

namespace AxBIZUserManagement
{
    public class GeneralInfo
    {
        public UserManagementDAN ObjClsGeneralDAN;
        public UserManagementDAL ObjClsGeneralDAL;
        public clsResponse<string> ObjResponse;
        public clsDataAccess ObjClsDataAccess;

        public clsResponse<string> GetUserDetails(int userType, long userID)
        {
            DataSet userData;
            ObjClsGeneralDAN = new UserManagementDAN();
            ObjResponse = new clsResponse<string>();
            try
            {
                userData = ObjClsGeneralDAN.GetStaffDetails(userType, userID);

                if (userData.Tables.Count == 0 || userData.Tables[0].Rows[0][0] == System.DBNull.Value || userData.Tables[0].Rows[0][0].ToString() == "")
                {
                    ObjResponse.Status = "Failed";
                    ObjResponse.Reason = "User not exists";
                    return ObjResponse;
                }

                ObjResponse.Status = "Success";
                ObjResponse.data = userData.Tables[0].Rows[0][0].ToString();

                return ObjResponse;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                userData = null;
                ObjClsGeneralDAN = null;
                ObjResponse = null;
            }
        }

        public string DeleteorReactiveStaff(object objDeleteInfo)
        {
            ObjClsGeneralDAL = new UserManagementDAL();
            int? userType = 0, userID = 0, isActive = 0, LMU = 0;
            JObject jDeleteInfo;
            bool blnResult;
            try
            {
                if (objDeleteInfo == null)
                    return "Please enter proper delete information.";

                jDeleteInfo = JObject.FromObject(objDeleteInfo);
                userType = (int)jDeleteInfo["userType"];
                userID = (int)jDeleteInfo["staffID"];
                isActive = (int)jDeleteInfo["action"];
                LMU = (int)jDeleteInfo["LMU"];

                blnResult = ObjClsGeneralDAL.DeleteorReactiveStaff(userType, userID, isActive, LMU);

                if (blnResult && isActive == 0)
                    return "Staff inactivated successfully.";
                else if (blnResult && isActive == 1)
                    return "Staff activated successfully.";
                else
                    return "Staff not exists.";
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                ObjClsGeneralDAL = null;
                jDeleteInfo = null;
                userType = userID = isActive = LMU = null;
            }
        }

        public JArray GetListofUsers()
        {
            ObjClsGeneralDAN = new UserManagementDAN();
            DataSet staffData = null;
            try
            {
                staffData = ObjClsGeneralDAN.GetListofUsers();
                return JArray.FromObject(staffData.Tables[0]);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                ObjClsGeneralDAN = null;
                staffData = null;
            }
        }
        public string SaveUser(object _general)
        {
            bool isValidData = false;
            JObject generalInfo;
            long staffID;
            long staffClinicianCode;
            int result = -1;
            long retStaffID = 0;
            int? validationResult = 0;
            Validations clsValidations;

            try
            {
                clsValidations = new Validations();
                isValidData = clsValidations.ValidateData(_general);
                if (isValidData)
                {
                    clsECSession.LogWebSessionAction("User Management", "", -1, 2731, "Save Staff - Data not saved due to data validation failed.", 101, -1, "");

                    return "Data validation failed.";
                }

                generalInfo = JObject.FromObject(_general);
                ObjClsGeneralDAN = new UserManagementDAN();

                staffID = (long)generalInfo["Staff"]["ID"];
                staffClinicianCode = (long)generalInfo["Staff"]["ClinicianCode"];

                if (staffID != -1)
                    result = ObjClsGeneralDAN.CheckStaffIsActive(staffID, staffClinicianCode);

                if (result == 1 || result == -1)
                {
                    validationResult = ObjClsGeneralDAN.ValidateLookups(generalInfo.ToString(),"Staff");

                    if (validationResult != 0 && validationResult > 1)
                        return clsValidations.GetFailedValidationMessageforStaff(validationResult);

                    ObjClsGeneralDAL = new UserManagementDAL();
                    ObjClsDataAccess = new clsDataAccess();
                    ObjClsDataAccess.BeginTrans(IsolationLevel.ReadCommitted);

                    retStaffID = ObjClsGeneralDAL.SaveUser(generalInfo.ToString());

                    if (retStaffID > 0)
                    {
                        ObjClsDataAccess.CommitTrans();
                        return $"{retStaffID}";
                    }
                    else
                    {
                        ObjClsDataAccess.AbortTrans();
                        return "Error in registering user, Please contact excelicare support.";
                    }
                }
                else if (result == 2)
                    return "Staff not exists.";
                else
                    return "Staff is inactive.";
            }
            catch (Exception ex)
            {
                ObjClsDataAccess.AbortTrans();
                throw ex;
            }
            finally
            {
                generalInfo = null;
                ObjClsGeneralDAL = null;
                ObjClsGeneralDAN = null;
                ObjClsDataAccess = null;
                validationResult = null;
                clsValidations = null;
            }
        }

        public clsResponse<string> GetIdentifiers(int userType, long userID)
        {
            ObjClsGeneralDAN = new UserManagementDAN();
            string identifiersInfo = string.Empty;
            ObjResponse = new clsResponse<string>();
            try
            {
                identifiersInfo = ObjClsGeneralDAN.GetIdentifiers(userType, userID);
                if (identifiersInfo == "")
                {
                    ObjResponse.Status = "Failed";
                    ObjResponse.Reason = "User not exists.";
                    return ObjResponse;
                }

                ObjResponse.Status = "Success";
                ObjResponse.data = identifiersInfo;
                return ObjResponse;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                ObjClsGeneralDAN = null;
                identifiersInfo = null;
                ObjResponse = null;
            }
        }

        public static void LogException(Exception exception)
        {
            clsExceptionHandler objClsExceptionHandler;
            try
            {
                objClsExceptionHandler = new clsExceptionHandler(exception);
                objClsExceptionHandler.LogException();
            }
            catch (Exception ex)
            {
                objClsExceptionHandler = new clsExceptionHandler(ex);
                objClsExceptionHandler.LogException();
            }
            finally
            {
                objClsExceptionHandler = null;
            }
        }

        public clsResponse<string> GetDefaultConfigurations(long userID)
        {
            DataSet dsDefaultConfigurations;
            try
            {
                ObjClsGeneralDAN = new UserManagementDAN();
                ObjResponse = new clsResponse<string>();
                dsDefaultConfigurations = ObjClsGeneralDAN.GetDefaultConfigurations(userID);

                if (dsDefaultConfigurations.Tables.Count == 0 || dsDefaultConfigurations.Tables[0].Rows[0][0] == System.DBNull.Value || dsDefaultConfigurations.Tables[0].Rows[0][0].ToString() == "")
                {
                    ObjResponse.Status = "Failed";
                    ObjResponse.Reason = "User not exists";
                    return ObjResponse;
                }

                ObjResponse.Status = "Success";
                ObjResponse.data = dsDefaultConfigurations.Tables[0].Rows[0][0].ToString();

                return ObjResponse;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                ObjClsGeneralDAN = null;
                ObjResponse = null;
                dsDefaultConfigurations = null;
            }
        }
		public string  UpdateUserStatus(long  UserId, string Status)
            {
                ObjClsGeneralDAL = new UserManagementDAL();
                try
                {
                return ObjClsGeneralDAL.UpdateUserStatus(UserId, Status);
                }
                catch(Exception ex)
                {
                    throw ex;
                }
                finally
                {
                ObjClsGeneralDAL = null;
                }
            }
        public DataSet GetUserStatus(long UserId)
        {
            ObjClsGeneralDAN = new UserManagementDAN();
            try
            {
                return ObjClsGeneralDAN.GetUserStatus(UserId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                ObjClsGeneralDAL = null;
            }
        }
    }
}
