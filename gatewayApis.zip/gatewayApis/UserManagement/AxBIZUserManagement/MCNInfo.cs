﻿using System;
using Newtonsoft.Json.Linq;
using Excelicare.Framework.AppSupport;
using AxDALUserManagement;
using Newtonsoft.Json;
using System.Data;

namespace AxBIZUserManagement
{
    public class MCNInfo
    {
        private UserManagementDAL ObjClsMCNDAL;
        private UserManagementDAN _objClsDAN;
        public string SaveUserMCN(object objMcn)
        {
            bool isValidData = false;
            JObject jMCNInfo;
            long catchmentID;
            long mcnRoleID;
            long RetStaffID = 0;
            try
            {
                Validations clsValidations = new Validations();
                isValidData = clsValidations.ValidateData(objMcn);
                if (isValidData)
                {
                    clsECSession.LogWebSessionAction("User Management", "", -1, 2731, "Save MCN - Data not saved due to data validation failed.", 101, -1, "");

                    return "Data validation failed.";
                }

                jMCNInfo = JObject.FromObject(objMcn);

                foreach (JToken item in jMCNInfo["StaffMCNCatchmentandRole"])
                {
                    catchmentID = (long)item["CatchmentID"];
                    mcnRoleID = (long)item["MCNRoleID"];
                }
                ObjClsMCNDAL = new UserManagementDAL();
                RetStaffID = ObjClsMCNDAL.SaveUserManagementMCN(jMCNInfo.ToString(Formatting.None));

                //clsECSession.LogWebSessionAction("User Management", "", -1, 2732, "UseManagementMCN successfully Saved with ID: " + RetStaffID, 101, -1, "");

                if (RetStaffID > 0)
                    return $"UseManagementMCN saved/updated successfully with ID: {RetStaffID}";
                else
                    return "Error in registering UseManagementMCN, Please contact excelicare support.";
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                jMCNInfo = null;
                ObjClsMCNDAL = null;
            }
        }

        public clsResponse<string> GetUserManagementMCNDetails(long userID, int staffType, int Mode)
        {

            DataSet McnDatd;
           
            clsResponse<string> ObjResponse;
            try
            {
                ObjResponse = new clsResponse<string>();
                clsECSession.LogWebSessionAction("User Management", "", -1, 2729, "Get UserManagement MCN - Start", 101, -1, "");
                _objClsDAN=new UserManagementDAN();
                McnDatd = _objClsDAN.GetUserManagementMCNDetails(userID, staffType, Mode);
                if (McnDatd!=null && McnDatd.Tables.Count>0 && McnDatd.Tables[0].Rows[0][0] == System.DBNull.Value || McnDatd.Tables[0].Rows[0][0].ToString() == "")
                {
                    ObjResponse.Status = "Failed";
                    ObjResponse.Reason = "User not exists in MCN";
                    return ObjResponse;
                }
                ObjResponse.Status = "Success";
                ObjResponse.data = McnDatd.Tables[0].Rows[0][0].ToString();
                return ObjResponse;

            }
            catch (Exception ex)
            {
                // LogException(ex);
                throw ex;
            }
            finally
            {
                 McnDatd = null;
                _objClsDAN = null;
                ObjResponse = null;
            }
        }
    }
}
