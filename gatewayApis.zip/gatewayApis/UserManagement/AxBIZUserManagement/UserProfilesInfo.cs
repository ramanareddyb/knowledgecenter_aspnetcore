﻿using System;
using AxDALUserManagement;
using Newtonsoft.Json.Linq;
using System.Data;
using Newtonsoft.Json;
using Excelicare.Framework.AppSupport;
using Excelicare.Framework.AppDataSupport;
using System.Text.RegularExpressions;

namespace AxBIZUserManagement
{
    public class UserProfilesInfo
    {
        public UserManagementDAN ObjUserManagementDAN;
        public UserManagementDAL ObjUserManagementDAL;
        public Validations clsValidations;
        public clsResponse<string> ObjResponse;
        public clsDataAccess ObjClsDataAccess;

        public clsResponse<string> GetUserProfile(long userID)
        {
            ObjUserManagementDAN = new UserManagementDAN();
            DataSet _ProfileData;
            ObjResponse = new clsResponse<string>();
            try
            {
                _ProfileData = ObjUserManagementDAN.GetUserProfile(userID);

                if (_ProfileData.Tables.Count == 0 || _ProfileData.Tables[0].Rows[0][0] == System.DBNull.Value || _ProfileData.Tables[0].Rows[0][0].ToString() == "")
                {
                    ObjResponse.Status = "Failed";
                    ObjResponse.Reason = "User/ Profile data not exist";
                    return ObjResponse;
                }
                ObjResponse.Status = "Success";
                ObjResponse.data = _ProfileData.Tables[0].Rows[0][0].ToString();

                return ObjResponse;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _ProfileData = null;
                ObjUserManagementDAN = null;
                ObjResponse = null;
            }
        }

        public clsResponse<string> GetUserAccountDetails(long userID)
        {
            ObjUserManagementDAN = new UserManagementDAN();
            DataSet dsAccountInfo = null;
            try
            {
                dsAccountInfo = ObjUserManagementDAN.GetUserAccountDetails(userID);

                ObjResponse = new clsResponse<string>();

                if (dsAccountInfo.Tables.Count == 0 || dsAccountInfo.Tables[0].Rows[0][0] == System.DBNull.Value || dsAccountInfo.Tables[0].Rows[0][0].ToString() == "")
                {
                    ObjResponse.Status = "Failed";
                    ObjResponse.Reason = "User account details not exist";
                    return ObjResponse;
                }

                ObjResponse.Status = "Success";
                ObjResponse.data = dsAccountInfo.Tables[0].Rows[0][0].ToString();

                return ObjResponse;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                ObjUserManagementDAN = null;
                dsAccountInfo = null;
                ObjResponse = null;
            }
        }

        public string SaveUserProfile(object profileData)
        {
            bool isValidData = false;
            clsValidations = new Validations();
            JObject profileInfo;
            string loginName = string.Empty;
            long userID = 0;
            long returnUserID = 0;
            int? validationResult = 0;
            string password = string.Empty;
            string strPattern = @"^[a-f0-9]{64}$";
            bool blnFound;
            RegexOptions options;
            try
            {

                isValidData = clsValidations.ValidateData(profileData);
                if (isValidData)
                {
                    clsECSession.LogWebSessionAction("User Management", "", -1, 2731, "Save User Profiles - Data not saved due to data validation failed.", 112, -1, "");
                    return "Data validation missing.";

                }

                profileInfo = JObject.FromObject(profileData);
                loginName = (string)profileInfo["ProfileInfo"]["LoginName"];
                userID = (long)profileInfo["ProfileInfo"]["UserID"];
                isValidData = clsValidations.ValidateLoginName(userID, loginName);

                if (isValidData)
                {
                    return "A user with this name already exists.";
                }

                ObjUserManagementDAN = new UserManagementDAN();
                validationResult = ObjUserManagementDAN.ValidateLookups(profileInfo.ToString(), "User");

                if (validationResult != 0 && validationResult > 1)
                    return clsValidations.GetFailedValidationMessageforUser(validationResult);

                password = (string)profileInfo["ProfileInfo"]["Pswd"];
                password = password.Replace("#&Pound&#", "£");

                if (password != "" && password != null)
                {
                    options = RegexOptions.Multiline | RegexOptions.IgnoreCase;
                    blnFound = Regex.IsMatch(password, strPattern, options);
                    if (!blnFound)
                        profileInfo["ProfileInfo"]["Pswd"] = clsValidations.EncryptPassword(password);
                }
                ObjUserManagementDAL = new UserManagementDAL();
                ObjClsDataAccess = new clsDataAccess();
                ObjClsDataAccess.BeginTrans(IsolationLevel.ReadCommitted);

                returnUserID = ObjUserManagementDAL.SaveUserProfile(profileInfo.ToString(Formatting.None));

                if (returnUserID > 0)
                {
                    ObjClsDataAccess.CommitTrans();
                    return $"{returnUserID}";
                }
                else
                {
                    ObjClsDataAccess.AbortTrans();
                    return "Error in registering user, Please contact excelicare support.";
                }
            }
            catch (Exception ex)
            {
                ObjClsDataAccess.AbortTrans();
                throw ex;
            }
            finally
            {
                clsValidations = null;
                profileInfo = null;
                loginName = null;
                ObjClsDataAccess = null;
                ObjUserManagementDAL = null;
                ObjUserManagementDAN = null;
                strPattern = null;
            }
        }

        public clsResponse<string> AddUserAccount(object accountInfo)
        {
            JObject AccountInfo;
            long ReturnAccountID, _userID = 0;
            string endDate = string.Empty, startDate = string.Empty, mode = string.Empty;

            try
            {
                ObjResponse = new clsResponse<string>();
                ObjResponse.Status = "Failed";

                if (accountInfo == null)
                {
                    ObjResponse.Reason = "Please enter proper user account information.";
                    return ObjResponse;
                }

                AccountInfo = JObject.FromObject(accountInfo);
                //startDate = AccountInfo["AccountDetails"][0]["StartDate"].ToString();
                //endDate = AccountInfo["AccountDetails"][0]["EndDate"].ToString();
                //_userID = (long)AccountInfo["AccountDetails"][0]["UserID"];
                //mode = AccountInfo["AccountDetails"][0]["Mode"].ToString();

                //clsValidations = new Validations();
                //ObjResponse = clsValidations.ManageAccountValidations(_userID, startDate, endDate);
                //if (ObjResponse.Status == "Failed")
                //    return ObjResponse;

                ObjUserManagementDAL = new UserManagementDAL();
                ObjUserManagementDAL.AddUserAccount(AccountInfo.ToString(Formatting.None));
                //ReturnAccountID = ObjUserManagementDAL.AddUserAccount(AccountInfo.ToString(Formatting.None));
                //if (ReturnAccountID <= 0)
                //{
                //    ObjResponse.Status = "Failed";
                //    ObjResponse.Reason = "Error in User Account Registration/ Update, Please contact excelicare support.";
                //}

                //else
                ObjResponse.Reason = "User Account Created/ Updated Successfully.";
                ObjResponse.Status = "Success";

                return ObjResponse;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                AccountInfo = null;
                ObjUserManagementDAL = null;
                ObjResponse = null;
            }
        }

        public string DeleteUserAccount(object deleteInfo)
        {
            long id;
            int accountDetailID;
            bool status = false;
            string notes = string.Empty;
            int reasonforInactivationLU = 0;
            long LMU = 0;
            JObject DeleteInfo;
            try
            {

                if (deleteInfo == null)
                    return "Please enter proper delete information.";

                DeleteInfo = JObject.FromObject(deleteInfo);

                id = (long)DeleteInfo["userID"];
                accountDetailID = (int)DeleteInfo["accountDetailID"];
                status = (bool)DeleteInfo["status"];
                notes = (string)DeleteInfo["notes"];
                reasonforInactivationLU = (int)DeleteInfo["reasonforInactivationLU"];
                LMU = (long)DeleteInfo["LMU"];

                ObjUserManagementDAL = new UserManagementDAL();
                ObjUserManagementDAL.DeleteUserAccount(id, accountDetailID, status, notes, reasonforInactivationLU, LMU);
                return $"User account delete/ activate successfully for {id}";
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                DeleteInfo = null;
                ObjUserManagementDAL = null;
                notes = null;
            }
        }

        public bool ResetSecurityQuestions(long userID)
        {
            ObjUserManagementDAN = new UserManagementDAN();
            try
            {
                return ObjUserManagementDAN.ResetSecurityQuestions(userID);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
