﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AxDALUserManagement;
using Excelicare.Framework.AppSupport;
using Newtonsoft.Json.Linq;

namespace AxBIZUserManagement
{
    public class ACLInfo
    {
        public clsResponse<string> ObjResponse;
        public UserManagementDAL ObjClsACLDAL;
        public UserManagementDAN ObjClsACLDAN;
        public clsResponse<string> SaveUserACLDetails(object aclDetails)
        {
            ObjResponse = new clsResponse<string>();
            bool aclResponse = false;
            //int aclGroupID = 0;
            //long staffID = 0;
            //bool userACL = false;
            //string aclGroupsList = string.Empty;
            JObject jACLDetails = null;
            //string itemMode = string.Empty;
            try
            {
                jACLDetails = JObject.FromObject(aclDetails);
                ObjClsACLDAL = new UserManagementDAL();

                ObjResponse.Status = "Failed";

                //if (jACLDetails["ACLDetails"].Count() > 0)
                //{
                //    ObjClsACLDAN = new UserManagementDAN();
                //    foreach (JToken ACLItem in jACLDetails["ACLDetails"])
                //    {
                //        itemMode = (string)ACLItem["Mode"];
                //        if (itemMode.ToLower() == "update")
                //            continue;

                //        aclGroupID = (int)ACLItem["ACLGroupID"];
                //        staffID = (long)ACLItem["StaffID"];
                //        userACL = ObjClsACLDAN.CheckUserACL(staffID, aclGroupID);

                //        if (userACL)
                //            aclGroupsList += aclGroupID + ", ";
                //    }
                //}
                //if (aclGroupsList != string.Empty)
                //{
                //    ObjResponse.Reason = "User already exists in " + aclGroupsList.Substring(0, aclGroupsList.Length - 1) + "groups.";
                //    return ObjResponse;
                //}

                aclResponse = ObjClsACLDAL.SaveUserACLDetails(jACLDetails.ToString());
                if (!aclResponse)
                {
                    ObjResponse.Reason = "Adding user to acl groups failed.";
                    return ObjResponse;
                }
                ObjResponse.Status = "Success";
                ObjResponse.Reason = "User successfully added/ updated to ACL group(s).";
                return ObjResponse;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                ObjResponse = null;
                ObjClsACLDAL = null;
                ObjClsACLDAN = null;
            }
        }


        public clsResponse<string> GetACLDetails(long Userid, int mode)
        {
            ObjClsACLDAN = new UserManagementDAN();
            DataSet _ACLDetails;
            ObjResponse = new clsResponse<string>();
            try
            {
                _ACLDetails = ObjClsACLDAN.GetACLDetails(Userid, mode);

                if (_ACLDetails.Tables.Count == 0 || _ACLDetails.Tables[0].Rows[0][0] == System.DBNull.Value || _ACLDetails.Tables[0].Rows[0][0].ToString() == "")
                {
                    ObjResponse.Status = "Failed";
                    ObjResponse.Reason = "-100";
                    return ObjResponse;
                }
                ObjResponse.Status = "Success";
                ObjResponse.data = _ACLDetails.Tables[0].Rows[0][0].ToString();

                return ObjResponse;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _ACLDetails = null;
                ObjClsACLDAN = null;
                ObjResponse = null;
            }
        }
    }
}
