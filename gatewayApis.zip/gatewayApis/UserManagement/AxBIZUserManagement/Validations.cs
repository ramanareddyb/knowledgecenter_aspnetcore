﻿using System;
using Excelicare.Framework.AppSupport;
using Newtonsoft.Json.Linq;
using AxDALUserManagement;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;

namespace AxBIZUserManagement
{
    public enum StaffLookupValidations
    {
        [Display(Name = "Success")] Success = 1,
        [Display(Name = "Please enter proper clinician code.")] ClinicianCode = 2,
        [Display(Name = "Please enter proper Discipline.")] Discipline = 3,
        [Display(Name = "Please enter proper Speciality.")] Speciality = 4,
        [Display(Name = "Please enter proper Designation.")] Designation = 5,
        [Display(Name = "Please enter proper Department.")] Department = 6,
        [Display(Name = "Please enter proper Facilities.")] FacilityID = 7,
        [Display(Name = "Please enter proper Location ID under staff.")] LOC_ID = 8,
        [Display(Name = "Please enter proper Location ID.")] LocationID = 9,
        [Display(Name = "Please enter proper location's Last Modified User.")] LocationLMU = 10,
        [Display(Name = "At a time only one location is set to be primary.")] LocationIsPrimarycount = 11,
        [Display(Name = "Please enter proper Title.")] Title = 12,
        [Display(Name = "Please enter proper Last Modified User for staff.")] StaffdataLMU = 13,
        [Display(Name = "Please enter proper phone type.")] Phonetype = 14,
        [Display(Name = "At a time only one phone number is set to be as preferred.")] PhoneIsPreferredcount = 15,
        [Display(Name = "Please enter proper Last Modified User for phone's.")] PhoneLMU = 16,
        [Display(Name = "Please enter proper email type.")] EmailType = 17,
        [Display(Name = "At a time only one email is set to be as preferred.")] EmailIsPreferredcount = 18,
        [Display(Name = "Please enter proper Last Modified User for email's.")] EmailLMU = 19,
        [Display(Name = "Please enter proper Prescribing Role.")] PrescribingRoleLU = 20,
        [Display(Name = "Please enter proper staff language.")] Language = 21
    }


    public enum UserLookupValidations
    {
        [Display(Name = "Success")] Success = 1,
        [Display(Name = "Please enter proper User ID.")] UserID = 2,
        [Display(Name = "Clinician ID is already exists.")] UserClinicianID = 3,
        [Display(Name = "Please enter proper Discipline.")] Discipline = 4,
        [Display(Name = "Please enter proper Speciality.")] Speciality = 5,
        [Display(Name = "Please enter proper Authority.")] Authority = 6,
        [Display(Name = "Please enter proper Department.")] Department = 7,
        [Display(Name = "Please enter proper Designation.")] Designation = 8,
        [Display(Name = "Please enter proper Security Level.")] SecurityLevel = 9,
        [Display(Name = "Please enter proper Clinican ID")] ClinicanID = 10,
        [Display(Name = "Please enter proper Last Modified User in general section.")] UsergeneraldataLMU = 11,
        [Display(Name = "Please enter proper user id in Clinic Services.")] ClinicServiceUserID = 12,
        [Display(Name = "Please enter proper Clinic Type.")] ClinicServiceTypeLU = 13,
        [Display(Name = "Please enter proper Lab Department.")] LabDepartmentLU = 14,
        [Display(Name = "Please enter proper user ID in User Capability.")] UserCapabilityUserID = 15,
        [Display(Name = "Please enter proper User Capability ID.")] UserCapabilityID = 16,
        [Display(Name = "Please enter proper Last Modified User for User Capability.")] UserCapabilityLMU = 17,
        [Display(Name = "Please enter proper user ID in User Functions.")] UserFunctionUserID = 18,
        [Display(Name = "Please enter proper User Function.")] SysUserFunctionID = 19,
        [Display(Name = "Please enter proper Last Modified User for User Functions.")] UserFunctionLMU = 20,
        [Display(Name = "Please enter proper Last Modified User for Clinic Services.")] ClinicServiceLMU = 21,
        [Display(Name = "Staff not exists.")] UserFunctionID = 22,       
        [Display(Name = "Please enter proper Clinic Service ID.")] ClinicServiceID = 23,
        [Display(Name = "Please enter proper Lab Department ID.")] LabDepartmentID = 24,
    }

    public class Validations
    {
        public clsSecurity ObjClsSecurity;
        public UserManagementDAN ClsUserManagementDAN;
        clsResponse<string> ObjResponse;

        public Boolean ValidateData(object userData)
        {
            JObject userMgt;
            string itemList = String.Empty;
            bool blnResult = false;
            try
            {
                userMgt = JObject.FromObject(userData);
                foreach (var property in userMgt)
                {
                    itemList += property.Value.ToString() + " ";
                }
                //blnResult = SecurityValidations(itemList);

                return blnResult;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                userMgt = null;
                itemList = null;
            }
        }

        public Boolean SecurityValidations(string strInputData)
        {
            //Token Validation
            //XSS, Remote OS, SQL Injection validations
            bool blnFound;
            try
            {
                ObjClsSecurity = new clsSecurity();
               blnFound = ObjClsSecurity.fnValidateForXSS(strInputData);
                if (blnFound == false)
                    blnFound = ObjClsSecurity.ValidateOSandSQLCommandInjections(strInputData);
                return blnFound;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                ObjClsSecurity = null;
            }
        }

        public Boolean ValidateLoginName(long usrID, string loginName)
        {
            try
            {
                ClsUserManagementDAN = new UserManagementDAN();
                return ClsUserManagementDAN.ValidateLoginName(usrID, loginName);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                ClsUserManagementDAN = null;
            }
        }

        public clsResponse<string> ManageAccountValidations(long userID, string startDate, string endDate)
        {
            ClsUserManagementDAN = new UserManagementDAN();
            int? accountResult = null;
            ObjResponse = new clsResponse<string>();
            try
            {
                accountResult = ClsUserManagementDAN.CheckAccountState(userID, startDate, endDate);

                if (accountResult == 1)
                    ObjResponse.Status = "Success";
                else if (accountResult == 0)
                {
                    ObjResponse.Status = "Failed";
                    ObjResponse.Reason = "A user account has already been created for this user with in the selected time period.";
                }

                return ObjResponse;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                ClsUserManagementDAN = null;
                accountResult = null;
            }
        }

        public clsResponse<string> CheckUserACL(object aclDetails)
        {
            ObjResponse = new clsResponse<string>();
            JObject jACLDetails;
            try
            {
                jACLDetails = JObject.FromObject(aclDetails);
                return ObjResponse;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
            }
        }
        public string GetFailedValidationMessageforStaff(int? failedResult)
        {
            StaffLookupValidations? lookupValidations;
            try
            {
                lookupValidations = (StaffLookupValidations)Enum.Parse(typeof(StaffLookupValidations), Enum.GetName(typeof(StaffLookupValidations), failedResult));
                return lookupValidations.GetType()?.GetMember(lookupValidations.ToString())?.First()?.GetCustomAttribute<DisplayAttribute>()?.Name;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                lookupValidations = null;
            }
        }

        public string GetFailedValidationMessageforUser(int? failedResult)
        {
            UserLookupValidations? lookupValidations;
            try
            {
                lookupValidations = (UserLookupValidations)Enum.Parse(typeof(UserLookupValidations), Enum.GetName(typeof(UserLookupValidations), failedResult));
                return lookupValidations.GetType()?.GetMember(lookupValidations.ToString())?.First()?.GetCustomAttribute<DisplayAttribute>()?.Name;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                lookupValidations = null;
            }
        }

        public string EncryptPassword(string password)
        {
            try
            {
                ObjClsSecurity = new clsSecurity();
                return ObjClsSecurity.SHA256(password);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                ObjClsSecurity = null;
            }
        }

        //private Boolean DataValidation()
        //{
        //    Seperate SPs for General and User Profiles

        //    DB Validations
        //    ClinicianID - if id > -1 - General sp --Not required
        //    USR_ID, loginname is exists or not - User Profiles
        //    lookup, Linked lookup validations -- Not required Lookups and Linked Lookups service need to expose
        //    Phone number format as per excelicare

        //    Code Validations
        //    Required Validation - Handled in API
        //    Datatype validations (Email, string, int)
        //    DOB should not be greater than today's date

        //    return true;
        //}
    }
}
