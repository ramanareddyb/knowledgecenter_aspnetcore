using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("AxDALUserManagement|LOCAL-BUILD")]
[assembly: AssemblyDescription("Excelicare v7")]
[assembly: AssemblyCompany("Practive Health Inc. dba Excelicare.")]
[assembly: AssemblyProduct("Excelicare")]
[assembly: AssemblyCopyright("Copyright 2023 Practive Health Inc. dba Excelicare. All rights reserved.")]
[assembly: AssemblyTrademark("Excelicare")]

[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]

[assembly: AssemblyVersion("0.0.0.0")]
[assembly: AssemblyFileVersion("0.0.0.0")]
