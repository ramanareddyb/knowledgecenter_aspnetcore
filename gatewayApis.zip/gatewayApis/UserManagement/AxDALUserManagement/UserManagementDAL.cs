﻿using Excelicare.Framework.AppDataSupport;
using System;
using System.Data;
namespace AxDALUserManagement
{
    public class UserManagementDAL
    {
        public clsDataAccess ObjClsDataAccess;
        public Boolean DeleteorReactiveStaff(int? UserType, int? UserID, int? isActive, int? LMU)
        {
            ParamStruct[] param = new ParamStruct[5];
            ObjClsDataAccess = new clsDataAccess();
            try
            {
                param[0].ParamName = "@tintUserType";
                param[0].DataType = DbType.Int16;
                param[0].direction = ParameterDirection.Input;
                param[0].value = UserType;

                param[1].ParamName = "@intStaffID";
                param[1].DataType = DbType.Int32;
                param[1].direction = ParameterDirection.Input;
                param[1].value = UserID;

                param[2].ParamName = "@isActive";
                param[2].DataType = DbType.Int16;
                param[2].direction = ParameterDirection.Input;
                param[2].value = isActive;

                param[3].ParamName = "@LastModified_User_ID";
                param[3].DataType = DbType.Int64;
                param[3].direction = ParameterDirection.Input;
                param[3].value = LMU;

                param[4].ParamName = "@Resultvalue";
                param[4].DataType = DbType.Boolean;
                param[4].direction = ParameterDirection.Output;
                param[4].size = 10;

                ObjClsDataAccess = new clsDataAccess();
                return (bool)ObjClsDataAccess.ExecutePreparedSQL("AxSP_DeleteStaff", CommandType.StoredProcedure, param)[0];
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                param = null;
                ObjClsDataAccess = null;
            }
        }

        public long SaveUser(string GeneralInfo)
        {
            ParamStruct[] param = new ParamStruct[1];
            try
            {
                param[0].ParamName = "@strStaffDetails";
                param[0].DataType = DbType.String;
                param[0].direction = ParameterDirection.Input;
                param[0].value = GeneralInfo;

                ObjClsDataAccess = new clsDataAccess();
                return Convert.ToInt64(ObjClsDataAccess.ExecuteScalar("AxSp_SaveStaffDetails", CommandType.StoredProcedure, param));
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                param = null;
                ObjClsDataAccess = null;
            }
        }

        public long SaveUserProfile(string ProfileInfo)
        {
            ParamStruct[] param = new ParamStruct[1];
            try
            {
                param[0].ParamName = "@strUserDetails";
                param[0].DataType = DbType.String;
                param[0].direction = ParameterDirection.Input;
                param[0].value = ProfileInfo;

                ObjClsDataAccess = new clsDataAccess();
                return Convert.ToInt64(ObjClsDataAccess.ExecuteScalar("AxSp_SaveUserDetails", CommandType.StoredProcedure, param));
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                ObjClsDataAccess = null;
                param = null;
            }
        }

        public long AddUserAccount(string AccountInfo)
        {
            ParamStruct[] param = new ParamStruct[1];
            try
            {
                param[0].ParamName = "@strUserProfileAccountDetail";
                param[0].DataType = DbType.String;
                param[0].direction = ParameterDirection.Input;
                param[0].value = AccountInfo;

                ObjClsDataAccess = new clsDataAccess();
                return Convert.ToInt64(ObjClsDataAccess.ExecuteScalar("AxSp_SaveUserProfileAccount", CommandType.StoredProcedure, param));
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                param = null;
                ObjClsDataAccess = null;
            }
        }

        public void DeleteUserAccount(long id, int accountDetailID, bool status, string notes, int reasonforInactivationLU, long LMU)
        {
            ParamStruct[] param = new ParamStruct[6];
            try
            {
                param[0].ParamName = "@intUser_ID";
                param[0].DataType = DbType.Int64;
                param[0].direction = ParameterDirection.Input;
                param[0].value = id;

                param[1].ParamName = "@intUserAccountDetail_ID";
                param[1].DataType = DbType.Int64;
                param[1].direction = ParameterDirection.Input;
                param[1].value = accountDetailID;

                param[2].ParamName = "@IsActivate";
                param[2].DataType = DbType.Boolean;
                param[2].direction = ParameterDirection.Input;
                param[2].value = status;

                param[3].ParamName = "@strNotes";
                param[3].DataType = DbType.String;
                param[3].direction = ParameterDirection.Input;
                param[3].value = notes;

                param[4].ParamName = "@intReasonForInActivation";
                param[4].DataType = DbType.Int16;
                param[4].direction = ParameterDirection.Input;
                param[4].value = reasonforInactivationLU;

                param[5].ParamName = "@intLastModified_user_ID";
                param[5].DataType = DbType.Int64;
                param[5].direction = ParameterDirection.Input;
                param[5].value = LMU;

                ObjClsDataAccess = new clsDataAccess();

                ObjClsDataAccess.ExecuteNonQuery("AxSP_UserProfileActivateInactivateAccount", CommandType.StoredProcedure, param);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                param = null;
                ObjClsDataAccess = null;
            }
        }

        public Boolean SaveUserACLDetails(string aclDetails)
        {
            ParamStruct[] param = new ParamStruct[1];
            try
            {
                param[0].ParamName = "@strACLStaff";
                param[0].DataType = DbType.String;
                param[0].direction = ParameterDirection.Input;
                param[0].value = aclDetails;

                ObjClsDataAccess = new clsDataAccess();
                return (bool)ObjClsDataAccess.ExecuteScalar("AxSp_SaveAclStaffIntoGroup", CommandType.StoredProcedure, param);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                param = null;
                ObjClsDataAccess = null;
            }
        }

        public long SaveUserManagementMCN(string mcnInfo)
        {
            ParamStruct[] param = new ParamStruct[1];
            try
            {
                param[0].ParamName = "@StrStaffMCNDetails";
                param[0].DataType = DbType.String;
                param[0].direction = ParameterDirection.Input;
                param[0].value = mcnInfo;

                ObjClsDataAccess = new clsDataAccess();
                return Convert.ToInt64(ObjClsDataAccess.ExecuteScalar("AxSp_SaveStaffMCNDetails", CommandType.StoredProcedure, param));
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                ObjClsDataAccess = null;
                param = null;
            }
		}
		#region "UserStatus"
		  public string   UpdateUserStatus(long UserId ,string Status)
          {
            clsDataAccess objDataAccess;
            ParamStruct[] pmi = new ParamStruct[2];
            long intresult = 0;
            try
            {

                //Call update API/Update SP to update event status
                
                objDataAccess = new clsDataAccess();

                pmi[0].direction = ParameterDirection.Input;
                pmi[0].ParamName = "@intAvailabilityStatus_LU";
                pmi[0].DataType = DbType.Int64;
                pmi[0].value = Status;


                pmi[1].direction = ParameterDirection.Input;
                pmi[1].ParamName = "@intUser_ID";
                pmi[1].DataType = DbType.Int64;
                pmi[1].value = UserId;
                intresult = 1;
                 objDataAccess.ExecuteDataSet("Axsp_SaveUserAvailabilityStatus", CommandType.StoredProcedure, pmi);
                return intresult.ToString();
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
            finally
            {
                objDataAccess = null;
            }
        }
        #endregion
    }
}
