﻿using System;
using Excelicare.Framework.AppDataSupport;
using System.Data;
using System.Collections;

namespace AxDALUserManagement
{
    public class UserManagementDAN
    {
        public clsDataAccess ObjClsDataAccess;
        public DataSet GetStaffDetails(int UserType, long UserID)
        {
            ParamStruct[] param = new ParamStruct[2];
            try
            {
                param[0].ParamName = "@intStaffType";
                param[0].DataType = DbType.Int16;
                param[0].direction = ParameterDirection.Input;
                param[0].value = UserType;

                param[1].ParamName = "@intStaffID";
                param[1].DataType = DbType.Int64;
                param[1].direction = ParameterDirection.Input;
                param[1].value = UserID;

                ObjClsDataAccess = new clsDataAccess();
                return ObjClsDataAccess.ExecuteDataSet("AxSp_GetStaffGeneralData", CommandType.StoredProcedure, param);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                param = null;
                ObjClsDataAccess = null;
            }

        }

        public DataSet GetUserProfile(long UserID)
        {
            ParamStruct[] param = new ParamStruct[1];
            try
            {
                param[0].ParamName = "@intUserID";
                param[0].DataType = DbType.Int64;
                param[0].direction = ParameterDirection.Input;
                param[0].value = UserID;

                ObjClsDataAccess = new clsDataAccess();
                return ObjClsDataAccess.ExecuteDataSet("AxSp_GetUserProfiles", CommandType.StoredProcedure, param);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                param = null;
                ObjClsDataAccess = null;
            }
        }

        public DataSet GetListofUsers()
        {
            string strCommand = "Select * from AxView_WebStaffLOV";
            try
            {
                ObjClsDataAccess = new clsDataAccess();
                return ObjClsDataAccess.ExecuteDataSet(strCommand, CommandType.Text);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                ObjClsDataAccess = null;
                strCommand = null;
            }
        }

        public Boolean ValidateLoginName(long UserID, string LoginName)
        {
            ParamStruct[] param = new ParamStruct[2];
            int? _result = 0;
            try
            {
                param[0].ParamName = "@strUserLoginName";
                param[0].DataType = DbType.String;
                param[0].direction = ParameterDirection.Input;
                param[0].value = LoginName;

                param[1].ParamName = "@intUser_ID";
                param[1].DataType = DbType.String;
                param[1].direction = ParameterDirection.Input;
                param[1].value = UserID;

                ObjClsDataAccess = new clsDataAccess();
                _result = (int)ObjClsDataAccess.ExecuteScalar("AxSP_CheckUser", CommandType.StoredProcedure, param);
                if (_result == 1) return true;
                else return false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                param = null;
                ObjClsDataAccess = null;
                _result = null;
            }
        }

        public DataSet GetUserAccountDetails(long UserID)
        {
            ParamStruct[] param = new ParamStruct[1];
            try
            {
                param[0].ParamName = "@intUser_ID";
                param[0].DataType = DbType.Int64;
                param[0].direction = ParameterDirection.Input;
                param[0].value = UserID;

                ObjClsDataAccess = new clsDataAccess();

                return ObjClsDataAccess.ExecuteDataSet("AxSP_UserProfileAccountDetailOnLoad", CommandType.StoredProcedure, param);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                param = null;
                ObjClsDataAccess = null;
            }
        }

        public int CheckStaffIsActive(long StaffID, long StaffType)
        {
            ParamStruct[] param = new ParamStruct[2];
            try
            {
                param[0].ParamName = "@intStaffID";
                param[0].DataType = DbType.Int64;
                param[0].direction = ParameterDirection.Input;
                param[0].value = StaffID;

                param[1].ParamName = "@intStaffCode";
                param[1].DataType = DbType.Int64;
                param[1].direction = ParameterDirection.Input;
                param[1].value = StaffType;

                ObjClsDataAccess = new clsDataAccess();

                return (int)ObjClsDataAccess.ExecuteScalar("AxSP_CheckStaffStatus", CommandType.StoredProcedure, param);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                ObjClsDataAccess = null;
                param = null;
            }
        }

        public int ValidateLookups(string staffOrUserInfo, string calledFrom)
        {
            ParamStruct[] param = new ParamStruct[2];
            ArrayList arReturn;
            string spName = string.Empty;
            try
            {
                param[0].ParamName = "@strStaffDetails";
                param[0].DataType = DbType.String;
                param[0].direction = ParameterDirection.Input;
                param[0].value = staffOrUserInfo;

                param[1].ParamName = "@intSuccessMsg";
                param[1].DataType = DbType.Int16;
                param[1].direction = ParameterDirection.Output;
                param[1].size = 100;

                if (calledFrom.ToLower() == "user")
                {
                    param[0].ParamName = "@strUserDetails";
                    spName = "AxSP_ValidateUserDataBeforeSave";
                }
                else
                    spName = "AxSP_ValidateStaffDataBeforeSave";

                ObjClsDataAccess = new clsDataAccess();

                arReturn = ObjClsDataAccess.ExecutePreparedSQL(spName, CommandType.StoredProcedure, param);
                return Convert.ToInt16(arReturn[0]);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                param = null;
                arReturn = null;
                ObjClsDataAccess = null;
                spName = null;
            }
        }

        public int CheckAccountState(long userID, string startDate, string endDate)
        {
            ParamStruct[] param = new ParamStruct[3];
            try
            {
                param[0].ParamName = "@intUser_ID";
                param[0].DataType = DbType.Int64;
                param[0].direction = ParameterDirection.Input;
                param[0].value = userID;

                param[1].ParamName = "@dtStartDate ";
                param[1].DataType = DbType.String;
                param[1].direction = ParameterDirection.Input;
                param[1].value = startDate;

                param[2].ParamName = "@dtEndDate";
                param[2].DataType = DbType.String;
                param[2].direction = ParameterDirection.Input;
                param[2].value = endDate;

                ObjClsDataAccess = new clsDataAccess();

                return (int)ObjClsDataAccess.ExecuteScalar("AxSP_UserProfileCheckAccountDetail", CommandType.StoredProcedure, param);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public string GetIdentifiers(int UserType, long UserID)
        {
            ParamStruct[] param = new ParamStruct[2];
            DataSet dsIdentifierInfo;
            try
            {
                param[0].ParamName = "@intStaffType";
                param[0].DataType = DbType.Int16;
                param[0].direction = ParameterDirection.Input;
                param[0].value = UserType;

                param[1].ParamName = "@intStaffID";
                param[1].DataType = DbType.Int64;
                param[1].direction = ParameterDirection.Input;
                param[1].value = UserID;

                ObjClsDataAccess = new clsDataAccess();
                dsIdentifierInfo = ObjClsDataAccess.ExecuteDataSet("AxSp_GetStaffIdentifiers", CommandType.StoredProcedure, param);
                return dsIdentifierInfo.Tables[0].Rows[0][0].ToString();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                param = null;
                ObjClsDataAccess = null;
                dsIdentifierInfo = null;
            }
        }

        public Boolean CheckUserACL(long userID, int aclGroupID)
        {
            ParamStruct[] param = new ParamStruct[2];
            try
            {
                param[0].ParamName = "@intACLGroup_ID";
                param[0].DataType = DbType.Int16;
                param[0].direction = ParameterDirection.Input;
                param[0].value = aclGroupID;

                param[1].ParamName = "@intACLStaff_ID";
                param[1].DataType = DbType.Int64;
                param[1].direction = ParameterDirection.Input;
                param[1].value = userID;

                ObjClsDataAccess = new clsDataAccess();
                return (bool)ObjClsDataAccess.ExecuteScalar("AxSP_ValidateACLStaffDetails", CommandType.StoredProcedure, param);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

            }
        }

        public DataSet GetACLDetails(long Userid, int mode)
        {
            ParamStruct[] param = new ParamStruct[2];
            try
            {
                param[0].ParamName = "@intUser_id";
                param[0].DataType = DbType.Int64;
                param[0].direction = ParameterDirection.Input;
                param[0].value = Userid;

                param[1].ParamName = "@intDataRequested";
                param[1].DataType = DbType.Int16;
                param[1].direction = ParameterDirection.Input;
                param[1].value = mode;

                ObjClsDataAccess = new clsDataAccess();
                return ObjClsDataAccess.ExecuteDataSet("AxSP_GetUserACLStaffGroupDetails", CommandType.StoredProcedure, param);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                param = null;
                ObjClsDataAccess = null;
            }
        }

        public DataSet GetDefaultConfigurations(long Userid)
        {
            ParamStruct[] param = new ParamStruct[1];
            try
            {
                param[0].ParamName = "@intUserD";
                param[0].DataType = DbType.Int64;
                param[0].direction = ParameterDirection.Input;
                param[0].value = Userid;

                ObjClsDataAccess = new clsDataAccess();
                return ObjClsDataAccess.ExecuteDataSet("AxSp_GetStaffRegConfigInfo", CommandType.StoredProcedure, param);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                param = null;
                ObjClsDataAccess = null;
            }
        }

        public bool ResetSecurityQuestions(long Userid)
        {
            ParamStruct[] param = new ParamStruct[1];
            try
            {
                param[0].ParamName = "@intUser_ID";
                param[0].DataType = DbType.Int64;
                param[0].direction = ParameterDirection.Input;
                param[0].value = Userid;

                ObjClsDataAccess = new clsDataAccess();
                return (bool)ObjClsDataAccess.ExecuteScalar("AxSP_DeleteUserSecurityQuestions", CommandType.StoredProcedure, param);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                param = null;
                ObjClsDataAccess = null;
            }
        }
       #region "UserStatus"
		 public DataSet GetUserStatus( long UserID)
        {
            ParamStruct[] param = new ParamStruct[1];
            try
            {
                param[0].ParamName = "@lngUserID";
                param[0].DataType = DbType.Int64 ;
                param[0].direction = ParameterDirection.Input;
                param[0].value = UserID;

                
                ObjClsDataAccess = new clsDataAccess();
                return ObjClsDataAccess.ExecuteDataSet("AxSP_GetUserAvailabilityStatus", CommandType.StoredProcedure, param);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                param = null;
                ObjClsDataAccess = null;
            }

        }
		#endregion
		
        #region "UserManagementMCN"
        public DataSet GetUserManagementMCNDetails(long UserID, int staffType, int Mode)
        {
            ParamStruct[] param = new ParamStruct[3];
            DataSet dsUserMcn;
            try
            {
                param[0].ParamName = "@intStaffID";
                param[0].DataType = DbType.Int64;
                param[0].direction = ParameterDirection.Input;
                param[0].value = UserID;

                param[1].ParamName = "@intStaffType";
                param[1].DataType = DbType.Int64;
                param[1].direction = ParameterDirection.Input;
                param[1].value = staffType;

                param[2].ParamName = "@intMCNStatus";
                param[2].DataType = DbType.Int16;
                param[2].direction = ParameterDirection.Input;
                param[2].value = Mode;

                ObjClsDataAccess = new clsDataAccess();
                dsUserMcn = ObjClsDataAccess.ExecuteDataSet("AxSp_GetStaffMCNs", CommandType.StoredProcedure, param);
                return dsUserMcn;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                param = null;
                ObjClsDataAccess = null;
                dsUserMcn = null;
            }
        }
        #endregion
    }
}
