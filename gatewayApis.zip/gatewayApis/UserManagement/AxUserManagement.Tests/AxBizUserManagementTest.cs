﻿using System;
using NUnit.Framework;
using AxBIZUserManagement;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;

namespace AxUserManagement.Tests
{

    [TestFixture]
    public class AxBizUserManagementTest
    {

        [Test]
        public void Get_AllStaffs()
        {
            GeneralInfo objGeneral = new GeneralInfo();
            JArray result = null;
            try
            {
                result = objGeneral.GetListofUsers();
                Assert.IsNotNull(result);

            }
            catch (Exception Ex)
            {
                Assert.Fail(Ex.Message);
            }
            finally
            {
                objGeneral = null;
                result = null;
            }
        }

        [Test]
        [TestCase(5, 6059)]
        [TestCase(4, 10)]
        [TestCase(-1, 102)]
        [TestCase(5, -1)]
        public void Get_UserDetails_ByID(int StaffType, long StaffID)
        {
            GeneralInfo objGeneral = new GeneralInfo();
            clsResponse<string> result = null;
            try
            {
                result = objGeneral.GetUserDetails(StaffType, StaffID);
                Assert.IsNotNull(result);
            }
            catch (Exception Ex)
            {
                if (Ex.Message == "User not Exists.")
                    Assert.AreEqual(Ex.Message, "User not Exists.");
                else
                    Assert.Fail(Ex.Message);
            }
            finally
            {
                objGeneral = null;
                result = null;
            }

        }

        [Test]
        [TestCase("{\"Staff\":{\"ID\":-1,\"TitleCode\":588,\"SurName\":\"George3006\",\"ForeName\":\"Catlin3006\",\"DOB\":\"Feb  8 1975 12:00AM\",\"DisciplineCode\":null,\"SpecialityCode\":null,\"DesignationCode\":null,\"OSDesignation\":null,\"DepartmentCode\":9578028,\"JobTitle\":\"General Practitioner\",\"ClinicianCode\":272,\"NHSClinician\":1,\"LocID\":1,\"RCGPNumber\":\"12GMP\",\"CallNotes\":null,\"Nationality\":null,\"NINo\":null,\"IdentificationNumber\":null,\"SpProfessionalBodyNo\":null,\"PrescribingRefNo\":null,\"Role\":null,\"IsActive\":1,\"LastModifiedUserID\":102,\"Comments\":\"This is Main User\",\"PrescribingRoleLU\":6200,\"LicenseStateLU\":null,\"LicenseNumber\":null,\"UPIN\":null,\"DEA\":null,\"NPI\":null,\"Initials\":null,\"TinNumber\":null,\"MiddleName\":\"\",\"Mode\":\"New\",\"Language\":598},\"Locations\":[{\"StaffID\":-1,\"LocId\":1,\"LocName\":\"Acute Hospital\",\"LocAddr1\":\"455 LARKSPUR DR S, Weymouth\",\"LocAddr2\":\"London\",\"LocCity\":\"Springs\",\"LocCounty\":\"Alabama\",\"Country\":\"United States\",\"LocPCode\":\"W1G 8TL\",\"IsPrimary\":true,\"LastModifiedUserID\":10,\"LocationChain\":\"\",\"Mode\":\"New\"}],\"Phones\":[{\"ClnpId\":-1,\"StaffID\":-1,\"ClnpPhoneNo\":\"1234563210\",\"ClnpPhoneTypeCode\":501,\"ClnpProviderCode\":null,\"IsISDNBonded\":false,\"IsPreferred\":true,\"IsActive\":1,\"LastModifiedUserID\":10,\"Mode\":\"New\"}],\"Emails\":[{\"ClneID\":-1,\"StaffID\":-1,\"ClneEaddr\":\"ramakrishna.tunuguntla@excelicare.com\",\"IsPreferred\":true,\"IsActive\":1,\"MailAccountTypeSLU\":3552,\"LastModifiedUserID\":10,\"Mode\":\"New\"}],\"Facilities\":{\"StaffID\":-1,\"LastModifiedUserID\":\"10\",\"UserTypeLU\":5,\"FacilityLU\":[9575032,9575033,9575034,9575035]}}")]
        [TestCase("{\"Staff\":{\"ID\":52157,\"TitleCode\":588,\"SurName\":\"George3006\",\"ForeName\":\"Catlin3006\",\"DOB\":\"Feb  8 1975 12:00AM\",\"DisciplineCode\":null,\"SpecialityCode\":null,\"DesignationCode\":null,\"OSDesignation\":null,\"DepartmentCode\":9578028,\"JobTitle\":\"General Practitioner\",\"ClinicianCode\":272,\"NHSClinician\":1,\"LocID\":1,\"RCGPNumber\":\"12GMP\",\"CallNotes\":null,\"Nationality\":null,\"NINo\":null,\"IdentificationNumber\":null,\"SpProfessionalBodyNo\":null,\"PrescribingRefNo\":null,\"Role\":null,\"IsActive\":1,\"LastModifiedUserID\":102,\"Comments\":\"This is Main User\",\"PrescribingRoleLU\":6200,\"LicenseStateLU\":null,\"LicenseNumber\":null,\"UPIN\":null,\"DEA\":null,\"NPI\":null,\"Initials\":null,\"TinNumber\":null,\"MiddleName\":\"\",\"Mode\":\"Update\",\"Language\":598},\"Locations\":[{\"StaffID\":-1,\"LocId\":1,\"LocName\":\"Acute Hospital\",\"LocAddr1\":\"455 LARKSPUR DR S, Weymouth\",\"LocAddr2\":\"London\",\"LocCity\":\"Springs\",\"LocCounty\":\"Alabama\",\"Country\":\"United States\",\"LocPCode\":\"W1G 8TL\",\"IsPrimary\":true,\"LastModifiedUserID\":10,\"LocationChain\":\"\",\"Mode\":\"New\"}],\"Phones\":[{\"ClnpId\":-1,\"StaffID\":-1,\"ClnpPhoneNo\":\"1234563210\",\"ClnpPhoneTypeCode\":501,\"ClnpProviderCode\":null,\"IsISDNBonded\":false,\"IsPreferred\":true,\"IsActive\":1,\"LastModifiedUserID\":10,\"Mode\":\"New\"}],\"Emails\":[{\"ClneID\":-1,\"StaffID\":-1,\"ClneEaddr\":\"ramakrishna.tunuguntla@excelicare.com\",\"IsPreferred\":true,\"IsActive\":1,\"MailAccountTypeSLU\":3552,\"LastModifiedUserID\":10,\"Mode\":\"New\"}],\"Facilities\":{\"StaffID\":-1,\"LastModifiedUserID\":\"10\",\"UserTypeLU\":5,\"FacilityLU\":[9575032,9575033,9575034,9575035]}}")]
        public void Save_User(string inputJSON)
        {
            string result = null;
            AxAPIUserManagement.Models.General general;
            GeneralInfo objGeneral = new GeneralInfo();
            try
            {
                general = JsonConvert.DeserializeObject<AxAPIUserManagement.Models.General>(inputJSON);
                result = objGeneral.SaveUser(general);
                Assert.IsNotNull(result);
            }
            catch (Exception Ex)
            {
                Assert.Fail(Ex.Message);
            }
            finally
            {
                result = null;
                objGeneral = null;
                general = null;
            }
        }


        [Test]
        [TestCase("{\"userType\":5,\"staffID\":6059,\"action\":1,\"LMU\":102}")]
        [TestCase("{\"userType\":4,\"staffID\":10,\"action\":1,\"LMU\":102}")]
        [TestCase("{\"userType\":4,\"staffID\":10,\"action\":0,\"LMU\":102}")]
        [TestCase("{\"userType\":4,\"staffID\":-1,\"action\":0,\"LMU\":102}")]
        public void Delete_Staff(string strDeleteData)
        {
            GeneralInfo objGeneral = new GeneralInfo();
            string result = null;
            JObject DeleteObject;
            try
            {
                DeleteObject = JObject.Parse(strDeleteData);
                result = objGeneral.DeleteorReactiveStaff(DeleteObject);
                Assert.IsNotNull(result);
            }
            catch (Exception Ex)
            {
                Assert.Fail(Ex.Message);
            }
            finally
            {
                objGeneral = null;
                result = null;
                DeleteObject = null;
            }
        }


        [Test]
        [TestCase(5, 6059)]
        [TestCase(4, 10)]
        [TestCase(-1, 102)]
        [TestCase(5, -1)]
        public void Get_Identifiers(int userType, long userID)
        {
            GeneralInfo objGeneral = new GeneralInfo();
            clsResponse<string> result = null;
            try
            {
                result = objGeneral.GetIdentifiers(userType, userID);
                Assert.IsNotNull(result);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
            finally
            {
                objGeneral = null;
                result = null;
            }
        }

        [Test]
        [TestCase(-1)]
        [TestCase(102)]
        [TestCase(8253)]
        public void Get_User_Profile(long UserID)
        {
            UserProfilesInfo objUP = new UserProfilesInfo();
            clsResponse<string> result = null;
            try
            {
                result = objUP.GetUserProfile(UserID);
                Assert.IsNotNull(result);
            }
            catch (Exception Ex)
            {
                Assert.Fail(Ex.Message);
            }
            finally
            {
                objUP = null;
                result = null;
            }
        }

        [Test]
        [TestCase("{\"ProfileInfo\":{\"UserID\":-1,\"LoginName\":\"George3006_unit\",\"Pswd\":\"aa96c16d9c76acf0adb8a0940a05c779315bbcc65893d3e75ca9a838d3d9239b\",\"SurName\":\"George3006\",\"ForeName\":\"Catlin3006\",\"Speciality\":9578060,\"Authority\":5,\"Discipline\":348,\"Department\":9578028,\"Designation\":9581201,\"SecurityLevel\":2,\"Signature\":null,\"HospitalNo\":null,\"PreviousPswds\":null,\"PswdUpdtDate\":null,\"ClnID\":9359,\"MergedCopy\":\"N\",\"PatientFolderCopy\":\"N\",\"DraftCopy\":\"N\",\"DeletedCopy\":\"N\",\"PINCode\":null,\"SecondPINCode\":null,\"SystemVoiceID\":null,\"MessageRecipUserID\":null,\"PhoneticName\":null,\"SplFormPref\":null,\"SentCopy\":null,\"IsMessageEnabled\":true,\"IsTransferEnabled\":true,\"IsStraightToScript\":null,\"StartupObject\":null,\"StartupReminder\":null,\"ProfileActivated\":true,\"IsFormLibraryManager\":false,\"IsFormDesigner\":true,\"PrivilegedForms\":\"01001001000000010010111011100\",\"LabSecurityLevel\":5,\"OrderCommsSecurityLevel\":5,\"PersonalDiaryInterval\":null,\"PrescriberCode\":\"9847987\",\"AvailableOtherStoresSLU\":null,\"ViewAttachmentAfterVetting\":false,\"PatSearchCategory_ID\":5,\"IsActive\":1,\"LastModifiedUserID\":10,\"SessionTimeOut\":null,\"IsPwdPromptRequired\":0,\"Mode\":\"New\"},\"ClinicServices\":[{\"ClinicServicesID\":-1,\"UsrID\":-1,\"ServiceTypeLU\":100026,\"IsActive\":1,\"LastModifiedUserID\":10,\"IsReadOnly\":1,\"Mode\":\"New\"},{\"ClinicServicesID\":-1,\"UsrID\":-1,\"ServiceTypeLU\":13738,\"IsActive\":1,\"LastModifiedUserID\":10,\"IsReadOnly\":0,\"Mode\":\"New\"}],\"LabDepartmentAccessible\":{\"LastModifiedUserID\":\"10\",\"LabsDepartmentLU\":[5299,5300]},\"UserCapability\":null}")]
        [TestCase("{\"ProfileInfo\":{\"UserID\":52159,\"LoginName\":\"George3006_unit\",\"Pswd\":\"aa96c16d9c76acf0adb8a0940a05c779315bbcc65893d3e75ca9a838d3d9239b\",\"SurName\":\"George3006\",\"ForeName\":\"Catlin3006\",\"Speciality\":9578060,\"Authority\":5,\"Discipline\":348,\"Department\":9578028,\"Designation\":9581201,\"SecurityLevel\":2,\"Signature\":null,\"HospitalNo\":null,\"PreviousPswds\":null,\"PswdUpdtDate\":null,\"ClnID\":9359,\"MergedCopy\":\"N\",\"PatientFolderCopy\":\"N\",\"DraftCopy\":\"N\",\"DeletedCopy\":\"N\",\"PINCode\":null,\"SecondPINCode\":null,\"SystemVoiceID\":null,\"MessageRecipUserID\":null,\"PhoneticName\":null,\"SplFormPref\":null,\"SentCopy\":null,\"IsMessageEnabled\":true,\"IsTransferEnabled\":true,\"IsStraightToScript\":null,\"StartupObject\":null,\"StartupReminder\":null,\"ProfileActivated\":true,\"IsFormLibraryManager\":false,\"IsFormDesigner\":true,\"PrivilegedForms\":\"01001001000000010010111011100\",\"LabSecurityLevel\":5,\"OrderCommsSecurityLevel\":5,\"PersonalDiaryInterval\":null,\"PrescriberCode\":\"9847987\",\"AvailableOtherStoresSLU\":null,\"ViewAttachmentAfterVetting\":false,\"PatSearchCategory_ID\":5,\"IsActive\":1,\"LastModifiedUserID\":10,\"SessionTimeOut\":null,\"IsPwdPromptRequired\":0,\"Mode\":\"Update\"},\"ClinicServices\":[{\"ClinicServicesID\":-1,\"UsrID\":-1,\"ServiceTypeLU\":100026,\"IsActive\":1,\"LastModifiedUserID\":10,\"IsReadOnly\":1,\"Mode\":\"Idle\"},{\"ClinicServicesID\":-1,\"UsrID\":-1,\"ServiceTypeLU\":13738,\"IsActive\":1,\"LastModifiedUserID\":10,\"IsReadOnly\":0,\"Mode\":\"Idle\"}],\"LabDepartmentAccessible\":{\"LastModifiedUserID\":\"10\",\"LabsDepartmentLU\":[5299,5300]},\"UserCapability\":null}")]
        public void Save_User_Profile(string inputJSON)
        {
            string result = null;
            JObject input;
            UserProfilesInfo objUP;
            try
            {
                input = JObject.Parse(inputJSON);
                objUP = new UserProfilesInfo();
                result = objUP.SaveUserProfile(input);
                Assert.IsNotNull(result);
            }
            catch (Exception Ex)
            {
                Assert.Fail(Ex.Message);
            }
            finally
            {
                result = null;
                input = null;
                objUP = null;
            }
        }

        [Test]
        [TestCase(-1)]
        [TestCase(102)]
        [TestCase(8253)]
        public void Get_User_AccountDetails_ByID(long UserID)
        {
            UserProfilesInfo objUP = new UserProfilesInfo();
            clsResponse<string> result = null;
            try
            {
                result = objUP.GetUserAccountDetails(UserID);
                Assert.IsNotNull(result);
            }
            catch (Exception Ex)
            {
                Assert.Fail(Ex.Message);
            }
            finally
            {
                objUP = null;
                result = null;
            }
        }

        [Test]
        [TestCase("{\"AccountDetails\":[{\"ID\":-1,\"UserID\":103,\"IsActive\":1,\"StartDate\":\"Jul  27 2022 07:02PM\",\"EndDate\":\"Jul  28 2022 12:00AM\",\"Notes\":\"1 day user profile 1\",\"LastModifiedUser\":10,\"Mode\":\"New\",\"AccountDetailStatus\":null}]}")]
        [TestCase("{\"AccountDetails\":[{\"ID\":7101,\"UserID\":7001,\"IsActive\":1,\"StartDate\":\"Jul  27 2022 07:02PM\",\"EndDate\":\"Jul  28 2022 12:00AM\",\"Notes\":\"1 day user profile 1\",\"LastModifiedUser\":10,\"Mode\":\"Update\",\"AccountDetailStatus\":null}]}")]
        public void Add_User_Account(string inputJSON)
        {
            UserProfilesInfo objUP = new UserProfilesInfo();
            clsResponse<string> result = null;
            try
            {
                result = objUP.AddUserAccount(JObject.Parse(inputJSON));
                Assert.IsNotNull(result);
            }
            catch (Exception Ex)
            {
                Assert.Fail(Ex.Message);
            }
            finally
            {
                objUP = null;
                result = null;
            }
        }

        [Test]
        [TestCase("{\"userID\":102,\"accountDetailID\":8397,\"status\":1,\"notes\":\"\",\"reasonforInactivationLU\":0,\"LMU\":102}")]
        [TestCase("{\"userID\":7102,\"accountDetailID\":7002,\"status\":0,\"notes\":\"\",\"reasonforInactivationLU\":13737,\"LMU\":102}")]
        public void Delete_User_Account(string inputJSON)
        {
            UserProfilesInfo objUP = new UserProfilesInfo();
            string result = null;
            try
            {
                result = objUP.DeleteUserAccount(JObject.Parse(inputJSON));
                Assert.IsNotNull(result);
            }
            catch (Exception Ex)
            {
                Assert.Fail(Ex.Message);
            }
            finally
            {
                objUP = null;
                result = null;
            }
        }

        [Test]
        [TestCase(102, "TestAdmin")]
        [TestCase(-1, "George")]
        [TestCase(-1, "TestAdmin1")]
        public void Validate_LoginName(long UserID, string UserName)
        {
            bool? isValidName;
            Validations objValidation = new Validations();
            try
            {
                isValidName = objValidation.ValidateLoginName(UserID, UserName);
                Assert.IsNotNull(isValidName);
            }
            catch (Exception Ex)
            {
                Assert.Fail(Ex.Message);
            }
            finally
            {
                objValidation = null;
                isValidName = null;
            }
        }

        [Test]
        [TestCase(-1)]
        [TestCase(102)]
        [TestCase(52159)]
        public void Get_User_ACLDetails(long userID)
        {
            ACLInfo objUC = new ACLInfo();
            clsResponse<string> result = null;
            try
            {
                result = objUC.GetACLDetails(userID);
                Assert.IsNotNull(result);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
            finally
            {
                objUC = null;
                result = null;
            }
        }

        [Test]
        [TestCase("{\"ACLDetails\":[{\"ACLGroupID\":1051,\"GroupName\":\"exacluser9\",\"ACLGroupTypeSLU\":null,\"ACLGroupType\":null,\"StaffID\":102,\"StartDate\":\"2022-06-30T00:00:00\",\"EndDate\":null,\"SetByUserID\":10,\"StoppedByUserID\":0,\"RestrictionLevel\":0,\"LastModifiedUserID\":10,\"Mode\":\"New\"},{\"ACLGroupID\":1050,\"GroupName\":\"exacluser8\",\"ACLGroupTypeSLU\":null,\"ACLGroupType\":null,\"StaffID\":102,\"StartDate\":\"2022-06-30T00:00:00\",\"EndDate\":\"2022-06-30T00:00:00\",\"SetByUserID\":10,\"StoppedByUserID\":0,\"RestrictionLevel\":0,\"LastModifiedUserID\":10,\"Mode\":\"New\"}]}")]
        [TestCase("{\"ACLDetails\":[{\"ACLGroupID\":1051,\"GroupName\":\"exacluser9\",\"ACLGroupTypeSLU\":null,\"ACLGroupType\":null,\"StaffID\":102,\"StartDate\":\"2022-06-30T00:00:00\",\"EndDate\":null,\"SetByUserID\":10,\"StoppedByUserID\":0,\"RestrictionLevel\":0,\"LastModifiedUserID\":10,\"Mode\":\"Update\"},{\"ACLGroupID\":1050,\"GroupName\":\"exacluser8\",\"ACLGroupTypeSLU\":null,\"ACLGroupType\":null,\"StaffID\":102,\"StartDate\":\"2022-06-30T00:00:00\",\"EndDate\":\"2022-06-30T00:00:00\",\"SetByUserID\":10,\"StoppedByUserID\":0,\"RestrictionLevel\":0,\"LastModifiedUserID\":10,\"Mode\":\"Update\"}]}")]
        public void Save_User_ACLDetails(string inputJSON)
        {
            clsResponse<string> result = null;
            ACLInfo objACL = new ACLInfo();
            try
            {
                JObject input = JObject.Parse(inputJSON);
                result = objACL.SaveUserACLDetails(input);
                Assert.IsNotNull(result);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
            finally
            {
                result = null;
                objACL = null;
            }
        }

        [Test]
        [TestCase(-1)]
        [TestCase(102)]
        [TestCase(8253)]
        public void Get_User_ManagementMCNDetails(long UserID)
        {
            MCNInfo objUC = new MCNInfo();
            clsResponse<string> result = null;
            try
            {
                result = objUC.GetUserManagementMCNDetails(UserID);
                Assert.IsNotNull(result);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
            finally
            {
                objUC = null;
                result = null;
            }
        }

        [Test]
        [TestCase("{\"StaffMCNCatchmentandRole\":[{\"MCNRoleAssignID\":-1,\"MCNID\":8,\"MCNName\":\"TestMCN14062022\",\"CatchmentID\":11,\"CatchmentName\":\"A1 healthboard\",\"StaffID\":30,\"Stafftype\":4,\"MCNRoleID\":11,\"MCNRoleName\":\"Role1\",\"StartDate\":\"2022-06-14T00:00:00\",\"StopDate\":null,\"IsActive\":1,\"LastModifiedUserID\":10,\"Mode\":\"New\"}]}")]
        [TestCase("{\"StaffMCNCatchmentandRole\":[{\"MCNRoleAssignID\":1057,\"MCNID\":8,\"MCNName\":\"TestMCN14062022\",\"CatchmentID\":11,\"CatchmentName\":\"A1 healthboard\",\"StaffID\":8010,\"Stafftype\":4,\"MCNRoleID\":11,\"MCNRoleName\":\"Role1\",\"StartDate\":\"2022-06-14T00:00:00\",\"StopDate\":null,\"IsActive\":1,\"LastModifiedUserID\":10,\"Mode\":\"Update\"}]}")]
        public void Save_User_MCNTest(string inputJSON)
        {
            string result = null;
            AxAPIUserManagement.Models.MCN general;
            MCNInfo objGeneral;
            try
            {
                general = JsonConvert.DeserializeObject<AxAPIUserManagement.Models.MCN>(inputJSON);
                objGeneral = new MCNInfo();
                result = objGeneral.SaveUserMCN(general);
                Assert.IsNotNull(result);
            }
            catch (Exception Ex)
            {
                Assert.Fail(Ex.Message);
            }
            finally
            {
                result=null;
                general = null;
                objGeneral = null;
            }
        }
    }
}
