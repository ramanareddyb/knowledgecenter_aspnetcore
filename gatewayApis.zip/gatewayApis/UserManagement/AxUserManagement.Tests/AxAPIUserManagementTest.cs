﻿using System;
using System.Web.Http;
using AxAPIUserManagement.Controllers;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NUnit.Framework;

namespace AxUserManagement.Tests
{
    [TestFixture]
    public class AxAPIUserManagementTest
    {
        IHttpActionResult result = null;
        #region General User Management
        [Test]
        public void Get_AllStaffs()
        {
            UserController objUC = new UserController();
            try
            {
                result = objUC.GetListofUsers();
                Assert.IsNotNull(result);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
            finally
            {
                objUC = null;
                result = null;
            }
        }

        [Test]
        [TestCase(5, 6059)]
        [TestCase(4, 10)]
        [TestCase(-1, 102)]
        [TestCase(5, -1)]
        public void Get_UserDetails_ByID(int StaffType, long StaffID)
        {
            UserController objUC = new UserController();
            try
            {
                result = objUC.GetUserDetails(StaffType, StaffID);
                Assert.IsNotNull(result);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
            finally
            {
                objUC = null;
                result = null;
            }
        }

        [Test]
        [TestCase("{\"Staff\":{\"ID\":-1,\"TitleCode\":588,\"SurName\":\"George3006\",\"ForeName\":\"Catlin3006\",\"DOB\":\"Feb  8 1975 12:00AM\",\"DisciplineCode\":null,\"SpecialityCode\":null,\"DesignationCode\":null,\"OSDesignation\":null,\"DepartmentCode\":9578028,\"JobTitle\":\"General Practitioner\",\"ClinicianCode\":272,\"NHSClinician\":1,\"LocID\":1,\"RCGPNumber\":\"12GMP\",\"CallNotes\":null,\"Nationality\":null,\"NINo\":null,\"IdentificationNumber\":null,\"SpProfessionalBodyNo\":null,\"PrescribingRefNo\":null,\"Role\":null,\"IsActive\":1,\"LastModifiedUserID\":102,\"Comments\":\"This is Main User\",\"PrescribingRoleLU\":6200,\"LicenseStateLU\":null,\"LicenseNumber\":null,\"UPIN\":null,\"DEA\":null,\"NPI\":null,\"Initials\":null,\"TinNumber\":null,\"MiddleName\":\"\",\"Mode\":\"New\",\"Language\":598},\"Locations\":[{\"StaffID\":-1,\"LocId\":1,\"LocName\":\"Acute Hospital\",\"LocAddr1\":\"455 LARKSPUR DR S, Weymouth\",\"LocAddr2\":\"London\",\"LocCity\":\"Springs\",\"LocCounty\":\"Alabama\",\"Country\":\"United States\",\"LocPCode\":\"W1G 8TL\",\"IsPrimary\":true,\"LastModifiedUserID\":10,\"LocationChain\":\"\",\"Mode\":\"New\"}],\"Phones\":[{\"ClnpId\":-1,\"StaffID\":-1,\"ClnpPhoneNo\":\"1234563210\",\"ClnpPhoneTypeCode\":501,\"ClnpProviderCode\":null,\"IsISDNBonded\":false,\"IsPreferred\":true,\"IsActive\":1,\"LastModifiedUserID\":10,\"Mode\":\"New\"}],\"Emails\":[{\"ClneID\":-1,\"StaffID\":-1,\"ClneEaddr\":\"ramakrishna.tunuguntla@excelicare.com\",\"IsPreferred\":true,\"IsActive\":1,\"MailAccountTypeSLU\":3552,\"LastModifiedUserID\":10,\"Mode\":\"New\"}],\"Facilities\":{\"StaffID\":-1,\"LastModifiedUserID\":\"10\",\"UserTypeLU\":5,\"FacilityLU\":[9575032,9575033,9575034,9575035]}}")]
        [TestCase("{\"Staff\":{\"ID\":52157,\"TitleCode\":588,\"SurName\":\"George3006\",\"ForeName\":\"Catlin3006\",\"DOB\":\"Feb  8 1975 12:00AM\",\"DisciplineCode\":null,\"SpecialityCode\":null,\"DesignationCode\":null,\"OSDesignation\":null,\"DepartmentCode\":9578028,\"JobTitle\":\"General Practitioner\",\"ClinicianCode\":272,\"NHSClinician\":1,\"LocID\":1,\"RCGPNumber\":\"12GMP\",\"CallNotes\":null,\"Nationality\":null,\"NINo\":null,\"IdentificationNumber\":null,\"SpProfessionalBodyNo\":null,\"PrescribingRefNo\":null,\"Role\":null,\"IsActive\":1,\"LastModifiedUserID\":102,\"Comments\":\"This is Main User\",\"PrescribingRoleLU\":6200,\"LicenseStateLU\":null,\"LicenseNumber\":null,\"UPIN\":null,\"DEA\":null,\"NPI\":null,\"Initials\":null,\"TinNumber\":null,\"MiddleName\":\"\",\"Mode\":\"Update\",\"Language\":598},\"Locations\":[{\"StaffID\":-1,\"LocId\":1,\"LocName\":\"Acute Hospital\",\"LocAddr1\":\"455 LARKSPUR DR S, Weymouth\",\"LocAddr2\":\"London\",\"LocCity\":\"Springs\",\"LocCounty\":\"Alabama\",\"Country\":\"United States\",\"LocPCode\":\"W1G 8TL\",\"IsPrimary\":true,\"LastModifiedUserID\":10,\"LocationChain\":\"\",\"Mode\":\"New\"}],\"Phones\":[{\"ClnpId\":-1,\"StaffID\":-1,\"ClnpPhoneNo\":\"1234563210\",\"ClnpPhoneTypeCode\":501,\"ClnpProviderCode\":null,\"IsISDNBonded\":false,\"IsPreferred\":true,\"IsActive\":1,\"LastModifiedUserID\":10,\"Mode\":\"New\"}],\"Emails\":[{\"ClneID\":-1,\"StaffID\":-1,\"ClneEaddr\":\"ramakrishna.tunuguntla@excelicare.com\",\"IsPreferred\":true,\"IsActive\":1,\"MailAccountTypeSLU\":3552,\"LastModifiedUserID\":10,\"Mode\":\"New\"}],\"Facilities\":{\"StaffID\":-1,\"LastModifiedUserID\":\"10\",\"UserTypeLU\":5,\"FacilityLU\":[9575032,9575033,9575034,9575035]}}")]
        public void Save_User(string inputJSON)
        {
            UserController objUC = new UserController();
            AxAPIUserManagement.Models.General general;
            try
            {
                general = JsonConvert.DeserializeObject<AxAPIUserManagement.Models.General>(inputJSON);
                result = objUC.SaveUser(general);
                Assert.IsNotNull(result);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
            finally
            {
                objUC = null;
                result = null;
                general = null;
            }
        }

        [Test]
        [TestCase("{\"userType\":5,\"staffID\":6059,\"action\":0,\"LMU\":102}")]
        [TestCase("{\"userType\":5,\"staffID\":6059,\"action\":1,\"LMU\":102}")]
        public void Delete_Staff(string inputJSON)
        {
            UserController objUC = new UserController();
            JObject jDeleteInfo = new JObject();
            try
            {
                jDeleteInfo = JObject.Parse(inputJSON);
                result = objUC.DeleteUser(jDeleteInfo);
                Assert.IsNotNull(result);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
            finally
            {
                objUC = null;
                jDeleteInfo = null;
                result = null;
            }
        }

        [Test]
        [TestCase(5, 6059)]
        [TestCase(4, 10)]
        [TestCase(-1, 102)]
        [TestCase(5, -1)]
        public void Get_Identifiers(int userType, long userID)
        {
            UserController objUC = new UserController();
            try
            {
                result = objUC.GetIdentifiers(userType, userID);
                Assert.IsNotNull(result);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
            finally
            {
                objUC = null;
                result = null;
            }
        }
        #endregion

        #region User Profile
        [Test]
        [TestCase(-1)]
        [TestCase(102)]
        [TestCase(8253)]


        public void Get_User_Profile(long UserID)
        {
            UserController objUC = new UserController();
            try
            {
                result = objUC.GetUserProfile(UserID);
                Assert.IsNotNull(result);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
            finally
            {
                objUC = null;
                result = null;
            }
        }

        [Test]
        [TestCase("{\"ProfileInfo\":{\"UserID\":-1,\"LoginName\":\"George3006_unit\",\"Pswd\":\"aa96c16d9c76acf0adb8a0940a05c779315bbcc65893d3e75ca9a838d3d9239b\",\"SurName\":\"George3006\",\"ForeName\":\"Catlin3006\",\"Speciality\":9578060,\"Authority\":5,\"Discipline\":348,\"Department\":9578028,\"Designation\":9581201,\"SecurityLevel\":2,\"Signature\":null,\"HospitalNo\":null,\"PreviousPswds\":null,\"PswdUpdtDate\":null,\"ClnID\":9359,\"MergedCopy\":\"N\",\"PatientFolderCopy\":\"N\",\"DraftCopy\":\"N\",\"DeletedCopy\":\"N\",\"PINCode\":null,\"SecondPINCode\":null,\"SystemVoiceID\":null,\"MessageRecipUserID\":null,\"PhoneticName\":null,\"SplFormPref\":null,\"SentCopy\":null,\"IsMessageEnabled\":true,\"IsTransferEnabled\":true,\"IsStraightToScript\":null,\"StartupObject\":null,\"StartupReminder\":null,\"ProfileActivated\":true,\"IsFormLibraryManager\":false,\"IsFormDesigner\":true,\"PrivilegedForms\":\"01001001000000010010111011100\",\"LabSecurityLevel\":5,\"OrderCommsSecurityLevel\":5,\"PersonalDiaryInterval\":null,\"PrescriberCode\":\"9847987\",\"AvailableOtherStoresSLU\":null,\"ViewAttachmentAfterVetting\":false,\"PatSearchCategory_ID\":5,\"IsActive\":1,\"LastModifiedUserID\":10,\"SessionTimeOut\":null,\"IsPwdPromptRequired\":0,\"Mode\":\"New\"},\"ClinicServices\":[{\"ClinicServicesID\":-1,\"UsrID\":-1,\"ServiceTypeLU\":100026,\"IsActive\":1,\"LastModifiedUserID\":10,\"IsReadOnly\":1,\"Mode\":\"New\"},{\"ClinicServicesID\":-1,\"UsrID\":-1,\"ServiceTypeLU\":13738,\"IsActive\":1,\"LastModifiedUserID\":10,\"IsReadOnly\":0,\"Mode\":\"New\"}],\"LabDepartmentAccessible\":{\"LastModifiedUserID\":\"10\",\"LabsDepartmentLU\":[5299,5300]},\"UserCapability\":null}")]
        [TestCase("{\"ProfileInfo\":{\"UserID\":52159,\"LoginName\":\"George3006_unit\",\"Pswd\":\"aa96c16d9c76acf0adb8a0940a05c779315bbcc65893d3e75ca9a838d3d9239b\",\"SurName\":\"George3006\",\"ForeName\":\"Catlin3006\",\"Speciality\":9578060,\"Authority\":5,\"Discipline\":348,\"Department\":9578028,\"Designation\":9581201,\"SecurityLevel\":2,\"Signature\":null,\"HospitalNo\":null,\"PreviousPswds\":null,\"PswdUpdtDate\":null,\"ClnID\":9359,\"MergedCopy\":\"N\",\"PatientFolderCopy\":\"N\",\"DraftCopy\":\"N\",\"DeletedCopy\":\"N\",\"PINCode\":null,\"SecondPINCode\":null,\"SystemVoiceID\":null,\"MessageRecipUserID\":null,\"PhoneticName\":null,\"SplFormPref\":null,\"SentCopy\":null,\"IsMessageEnabled\":true,\"IsTransferEnabled\":true,\"IsStraightToScript\":null,\"StartupObject\":null,\"StartupReminder\":null,\"ProfileActivated\":true,\"IsFormLibraryManager\":false,\"IsFormDesigner\":true,\"PrivilegedForms\":\"01001001000000010010111011100\",\"LabSecurityLevel\":5,\"OrderCommsSecurityLevel\":5,\"PersonalDiaryInterval\":null,\"PrescriberCode\":\"9847987\",\"AvailableOtherStoresSLU\":null,\"ViewAttachmentAfterVetting\":false,\"PatSearchCategory_ID\":5,\"IsActive\":1,\"LastModifiedUserID\":10,\"SessionTimeOut\":null,\"IsPwdPromptRequired\":0,\"Mode\":\"Update\"},\"ClinicServices\":[{\"ClinicServicesID\":-1,\"UsrID\":-1,\"ServiceTypeLU\":100026,\"IsActive\":1,\"LastModifiedUserID\":10,\"IsReadOnly\":1,\"Mode\":\"Idle\"},{\"ClinicServicesID\":-1,\"UsrID\":-1,\"ServiceTypeLU\":13738,\"IsActive\":1,\"LastModifiedUserID\":10,\"IsReadOnly\":0,\"Mode\":\"Idle\"}],\"LabDepartmentAccessible\":{\"LastModifiedUserID\":\"10\",\"LabsDepartmentLU\":[5299,5300]},\"UserCapability\":null}")]
        public void Save_User_Profile(string inputJSON)
        {
            UserController objUC = new UserController();
            AxAPIUserManagement.Models.UserProfiles userprofiles;
            try
            {
                userprofiles = JsonConvert.DeserializeObject<AxAPIUserManagement.Models.UserProfiles>(inputJSON);
                result = objUC.SaveUserProfile(userprofiles);
                Assert.IsNotNull(result);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
            finally
            {
                objUC = null;
                result = null;
                userprofiles = null;
            }
        }



        [Test]
        [TestCase(-1)]
        [TestCase(102)]
        [TestCase(8253)]
        public void Get_User_AccountDetails_ByID(long UserID)
        {
            ManageAccountController objUC = new ManageAccountController();
            try
            {
                result = objUC.GetUserAccountDetails(UserID);
                Assert.IsNotNull(result);
            }
            catch (Exception Ex)
            {
                Assert.Fail(Ex.Message);
            }
            finally
            {
                objUC = null;
                result = null;
            }
        }

        [Test]
        [TestCase("{\"AccountDetails\":[{\"ID\":-1,\"UserID\":103,\"IsActive\":1,\"StartDate\":\"Jul  27 2022 07:02PM\",\"EndDate\":\"Jul  28 2022 12:00AM\",\"Notes\":\"1 day user profile 1\",\"LastModifiedUser\":10,\"Mode\":\"New\",\"AccountDetailStatus\":null}]}")]
        [TestCase("{\"AccountDetails\":[{\"ID\":7101,\"UserID\":7001,\"IsActive\":1,\"StartDate\":\"Jul  27 2022 07:02PM\",\"EndDate\":\"Jul  28 2022 12:00AM\",\"Notes\":\"1 day user profile 1\",\"LastModifiedUser\":10,\"Mode\":\"Update\",\"AccountDetailStatus\":null}]}")]
        public void Add_User_Account(string inputJSON)
        {
            ManageAccountController objUC = new ManageAccountController();
            AxAPIUserManagement.Models.ManageAccount manageAccount;
            try
            {
                manageAccount = JsonConvert.DeserializeObject<AxAPIUserManagement.Models.ManageAccount>(inputJSON);
                result = objUC.AddUserAccount(manageAccount);
                Assert.IsNotNull(result);
            }
            catch (Exception Ex)
            {
                Assert.Fail(Ex.Message);
            }
            finally
            {
                objUC = null;
                result = null;
                manageAccount = null;
            }
        }

        [Test]
        [TestCase("{\"userID\":102,\"accountDetailID\":8397,\"status\":1,\"notes\":\"\",\"reasonforInactivationLU\":0,\"LMU\":102}")]
        [TestCase("{\"userID\":7102,\"accountDetailID\":7002,\"status\":0,\"notes\":\"\",\"reasonforInactivationLU\":13737,\"LMU\":102}")]
        public void Delete_User_Account(string inputJSON)
        {
            ManageAccountController objUC = new ManageAccountController();
            try
            {
                result = objUC.DeleteUserAccount(JObject.Parse(inputJSON));
                Assert.IsNotNull(result);
            }
            catch (Exception Ex)
            {
                Assert.Fail(Ex.Message);
            }
            finally
            {
                objUC = null;
                result = null;
            }
        }

        #endregion

        #region User ACL

        [Test]
        [TestCase(-1)]
        [TestCase(102)]
        [TestCase(52159)]
        public void Get_User_ACLDetails(long userID)
        {
            UserController objUC = new UserController();
            try
            {
                result = objUC.GetACLDetails(userID);
                Assert.IsNotNull(result);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
            finally
            {
                objUC = null;
                result = null;
            }
        }


        [Test]
        [TestCase("{\"ACLDetails\":[{\"ACLGroupID\":1051,\"GroupName\":\"exacluser9\",\"ACLGroupTypeSLU\":null,\"ACLGroupType\":null,\"StaffID\":102,\"StartDate\":\"2022-06-30T00:00:00\",\"EndDate\":null,\"SetByUserID\":10,\"StoppedByUserID\":0,\"RestrictionLevel\":0,\"LastModifiedUserID\":10,\"Mode\":\"New\"},{\"ACLGroupID\":1050,\"GroupName\":\"exacluser8\",\"ACLGroupTypeSLU\":null,\"ACLGroupType\":null,\"StaffID\":102,\"StartDate\":\"2022-06-30T00:00:00\",\"EndDate\":\"2022-06-30T00:00:00\",\"SetByUserID\":10,\"StoppedByUserID\":0,\"RestrictionLevel\":0,\"LastModifiedUserID\":10,\"Mode\":\"New\"}]}")]
        [TestCase("{\"ACLDetails\":[{\"ACLGroupID\":1051,\"GroupName\":\"exacluser9\",\"ACLGroupTypeSLU\":null,\"ACLGroupType\":null,\"StaffID\":102,\"StartDate\":\"2022-06-30T00:00:00\",\"EndDate\":null,\"SetByUserID\":10,\"StoppedByUserID\":0,\"RestrictionLevel\":0,\"LastModifiedUserID\":10,\"Mode\":\"Update\"},{\"ACLGroupID\":1050,\"GroupName\":\"exacluser8\",\"ACLGroupTypeSLU\":null,\"ACLGroupType\":null,\"StaffID\":102,\"StartDate\":\"2022-06-30T00:00:00\",\"EndDate\":\"2022-06-30T00:00:00\",\"SetByUserID\":10,\"StoppedByUserID\":0,\"RestrictionLevel\":0,\"LastModifiedUserID\":10,\"Mode\":\"Update\"}]}")]
        public void Save_User_ACLDetails(string inputJSON)
        {
            UserController objUC = new UserController();
            AxAPIUserManagement.Models.ACL ACLDetails;
            try
            {
                ACLDetails = JsonConvert.DeserializeObject<AxAPIUserManagement.Models.ACL>(inputJSON);
                result = objUC.SaveUserACLDetails(ACLDetails);
                Assert.IsNotNull(result);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
            finally
            {
                ACLDetails = null;
                objUC = null;
                result = null;
            }
        }

        #endregion

        #region User MCN

        [Test]
        [TestCase("{\"StaffMCNCatchmentandRole\":[{\"MCNRoleAssignID\":-1,\"MCNID\":8,\"MCNName\":\"TestMCN14062022\",\"CatchmentID\":11,\"CatchmentName\":\"A1 healthboard\",\"StaffID\":30,\"Stafftype\":4,\"MCNRoleID\":11,\"MCNRoleName\":\"Role1\",\"StartDate\":\"2022-06-14T00:00:00\",\"StopDate\":null,\"IsActive\":1,\"LastModifiedUserID\":10,\"Mode\":\"New\"}]}")]
        [TestCase("{\"StaffMCNCatchmentandRole\":[{\"MCNRoleAssignID\":1057,\"MCNID\":8,\"MCNName\":\"TestMCN14062022\",\"CatchmentID\":11,\"CatchmentName\":\"A1 healthboard\",\"StaffID\":8010,\"Stafftype\":4,\"MCNRoleID\":11,\"MCNRoleName\":\"Role1\",\"StartDate\":\"2022-06-14T00:00:00\",\"StopDate\":null,\"IsActive\":1,\"LastModifiedUserID\":10,\"Mode\":\"Update\"}]}")]
        public void Save_User_MCN(string inputJSON)
        {
            UserController objUC = new UserController();
            AxAPIUserManagement.Models.MCN MCNDetails;
            try
            {
                MCNDetails = JsonConvert.DeserializeObject<AxAPIUserManagement.Models.MCN>(inputJSON);
                result = objUC.SaveUserMCN(MCNDetails);
                Assert.IsNotNull(result);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
            finally
            {
                MCNDetails = null;
                objUC = null;
                result = null;
            }

        }

        [Test]
        [TestCase(-1)]
        [TestCase(102)]
        [TestCase(8253)]
        public void Get_User_MCN(long UserID)
        {
            UserController objUC = new UserController();
            try
            {
                result = objUC.GetUserMCN(UserID);
                Assert.IsNotNull(result);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
            finally
            {
                objUC = null;
                result = null;
            }
        }

        #endregion
    }
}
