﻿using System;
using System.Linq;
using System.Net;
using System.Web.Http;
using AxAPIUserManagement.Models;
using AxBIZUserManagement;
using Excelicare.Framework.AppSupport;
using Newtonsoft.Json.Linq;
using System.Data;

namespace AxAPIUserManagement.Controllers
{
    public class UserController : ApiController
    {
        public GeneralInfo ObjClsGeneralBIZ;
        public UserProfilesInfo ObjClsUserProfilesBIZ;
        public clsResponse<string> ObjResponse;

        #region General

        /// <summary>
        /// To get the list of all staff details both clinician and otherstaff.
        /// </summary>
        /// <returns></returns>

        [HttpGet]
        [Route("~/api/user")]
        public IHttpActionResult GetListofUsers()
        {
            ObjClsGeneralBIZ = new GeneralInfo();
            JArray staffData;
            try
            {
                clsECSession.LogWebSessionAction("User Management", "", -1, 2729, "Get List of Staff - Start", 101, -1, "");

                staffData = ObjClsGeneralBIZ.GetListofUsers();
                if (staffData.Count == 0)
                {
                    clsECSession.LogWebSessionAction("User Management", "", -1, 2730, "Get List of Staff - No records found - End", 101, -1, "");
                    return Content(HttpStatusCode.NotFound, "No records found.");
                }

                clsECSession.LogWebSessionAction("User Management", "", -1, 2730, "Get List of Staff - End", 101, -1, "");
                return Ok(staffData);
            }
            catch (Exception ex)
            {
                GeneralInfo.LogException(ex);
                throw ex;
            }
            finally
            {
                ObjClsGeneralBIZ = null;
                staffData = null;
            }
        }

        /// <summary>
        /// To get individual staff details.
        /// </summary>
        /// <param name="userType"></param>
        /// <param name="userID"></param>
        /// <returns></returns>

        [HttpGet]
        [Route("~/api/user/{userType}/{userID}")]
        public IHttpActionResult GetUserDetails(int userType, long userID)
        {
            General _general;
            ObjResponse = new clsResponse<string>();
            try
            {
                if (userType < 4 || userType > 6 || userID <= 0)
                    return Content(HttpStatusCode.NotFound, $"Invalid user type or user ID: {userType} / {userID}");

                clsECSession.LogWebSessionAction("User Management", "", -1, 2729, "Get User Details for User Type:" + userType + ", Staff ID:" + userID + " - Start", 101, -1, "");

                ObjClsGeneralBIZ = new GeneralInfo();
                ObjResponse = ObjClsGeneralBIZ.GetUserDetails(userType, userID);

                if (ObjResponse.Status == "Failed")
                    return Content(HttpStatusCode.NotFound, ObjResponse.Reason);

                _general = JObject.Parse(ObjResponse.data).ToObject<General>();

                clsECSession.LogWebSessionAction("User Management", "", -1, 2730, "Get User Details - End", 101, -1, "");
                return Ok(_general);
            }
            catch (Exception ex)
            {
                GeneralInfo.LogException(ex);
                throw ex;
            }
            finally
            {
                ObjClsGeneralBIZ = null;
                _general = null;
                ObjResponse = null;
            }
        }

        /// <summary>
        /// To register new clinician/ other staff.
        /// </summary>
        /// <param name="general"></param>
        /// <returns></returns>

        [HttpPost]
        [Route("~/api/user/register")]
        public IHttpActionResult SaveUser(General general)
        {
            ObjClsGeneralBIZ = new GeneralInfo();
            string errorMessage = string.Empty;
            try
            {
                clsECSession.LogWebSessionAction("User Management", "", -1, 2731, "Save Staff - Start", 101, -1, "");

                if (!ModelState.IsValid)
                {
                    errorMessage = string.Join($",", ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                    clsECSession.LogWebSessionAction("User Management", "", -1, 2731, "Save Staff - Model validation failed" + JObject.FromObject(general).ToString(), 101, -1, "");
                    return Content(HttpStatusCode.PreconditionFailed, errorMessage);
                }

                clsECSession.LogWebSessionAction("User Management", "", -1, 2732, "Staff successfully registered", 101, -1, "");
                return Ok(ObjClsGeneralBIZ.SaveUser(general));
            }
            catch (Exception ex)
            {
                GeneralInfo.LogException(ex);
                throw ex;
            }
            finally
            {
                errorMessage = null;
                ObjClsGeneralBIZ = null;
            }
        }

        /// <summary>
        /// To inactivate or activate clinician/ other staff.
        /// </summary>
        /// <param name="objDeleteInfo"></param>
        /// <returns></returns>

        [HttpDelete]
        [Route("~/api/user")]
        public IHttpActionResult DeleteUser([FromBody] object objDeleteInfo)
        {
            ObjClsGeneralBIZ = new GeneralInfo();
            string result = string.Empty;
            try
            {
                clsECSession.LogWebSessionAction("User Management", "", -1, 2032, "Delete or Reactive Staff - Start", 101, -1, "");

                result = ObjClsGeneralBIZ.DeleteorReactiveStaff(objDeleteInfo);

                clsECSession.LogWebSessionAction("User Management", "", -1, 2796, "Delete or Reactive Staff - End", 101, -1, "");
                return Ok(result);
            }
            catch (Exception ex)
            {
                GeneralInfo.LogException(ex);
                throw ex;
            }
            finally
            {
                ObjClsGeneralBIZ = null;
                result = null;
            }
        }

        /// <summary>
        /// To get identifiers for individual staff.
        /// </summary>
        /// <param name="userType"></param>
        /// <param name="userID"></param>
        /// <returns></returns>

        [HttpGet]
        [Route("~/api/user/identifiers/{userType}/{UserID}")]
        public IHttpActionResult GetIdentifiers(int userType, long userID)
        {
            ObjClsGeneralBIZ = new GeneralInfo();
            ObjResponse = new clsResponse<string>();
            try
            {
                if (userType < 4 || userType > 6 || userID <= 0)
                    return Content(HttpStatusCode.NotFound, $"Invalid user type or user ID: {userType} / {userID}");

                clsECSession.LogWebSessionAction("User Management", "", -1, 2729, "Get staff identifier details for User Type:" + userType + ", Staff ID:" + userID + " - Start", 101, -1, "");

                ObjResponse = ObjClsGeneralBIZ.GetIdentifiers(userType, userID);

                if (ObjResponse.Status == "Failed")
                    return Content(HttpStatusCode.NotFound, ObjResponse.Reason);

                clsECSession.LogWebSessionAction("User Management", "", -1, 2730, "Get staff identifier details - End", 101, -1, "");
                return Ok(JObject.Parse(ObjResponse.data));
            }
            catch (Exception ex)
            {
                GeneralInfo.LogException(ex);
                throw ex;
            }
            finally
            {
                ObjClsGeneralBIZ = null;
                ObjResponse = null;
            }
        }

        #endregion

        #region UserProfiles

        /// <summary>
        /// To get user profile details for selected user.
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>

        [HttpGet]
        [Route("~/api/user/{userID}")]
        public IHttpActionResult GetUserProfile(long userID)
        {
            UserProfiles userProfiles;
            ObjResponse = new clsResponse<string>();
            try
            {
                if (userID <= 0)
                    return Content(HttpStatusCode.NotFound, $"User/ Profile data not exist with: {userID}");

                clsECSession.LogWebSessionAction("User Management", "", -1, 2729, "Get user profile details for User ID:" + userID + " - Start", 101, -1, "");

                ObjClsUserProfilesBIZ = new UserProfilesInfo();
                ObjResponse = ObjClsUserProfilesBIZ.GetUserProfile(userID);

                if (ObjResponse.Status == "Failed")
                    return Content(HttpStatusCode.NotFound, $"{ObjResponse.Reason} with: {userID}");

                userProfiles = JObject.Parse(ObjResponse.data).ToObject<UserProfiles>();

                clsECSession.LogWebSessionAction("User Management", "", -1, 2730, "Get user profile details - End", 101, -1, "");
                return Ok(userProfiles);
            }
            catch (Exception ex)
            {
                GeneralInfo.LogException(ex);
                throw ex;
            }
            finally
            {
                ObjClsUserProfilesBIZ = null;
                userProfiles = null;
                ObjResponse = null;
            }
        }

        /// <summary>
        /// To register new user profile and update an existing user profile.
        /// </summary>
        /// <param name="userProfiles"></param>
        /// <returns></returns>

        [HttpPost]
        [Route("~/api/user/profile")]
        public IHttpActionResult SaveUserProfile(UserProfiles userProfiles)
        {
            string errorMessage = string.Empty;
            ObjClsUserProfilesBIZ = new UserProfilesInfo();
            try
            {
                clsECSession.LogWebSessionAction("User Management", "", -1, 2731, "Save user profiles - Start", 101, -1, "");

                if (!ModelState.IsValid)
                {
                    errorMessage = string.Join(", ", ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                    clsECSession.LogWebSessionAction("User Management", "", -1, 2731, "Save user profiles - Model validation failed" + JObject.FromObject(userProfiles).ToString(), 101, -1, "");
                    return Content(HttpStatusCode.PreconditionFailed, errorMessage);
                }

                clsECSession.LogWebSessionAction("User Management", "", -1, 2732, "User profile successfully created", 101, -1, "");
                return Ok(ObjClsUserProfilesBIZ.SaveUserProfile(userProfiles));
            }
            catch (Exception ex)
            {
                GeneralInfo.LogException(ex);
                throw ex;
            }
            finally
            {
                errorMessage = null;
                ObjClsUserProfilesBIZ = null;
            }
        }

        [HttpDelete]
        [Route("~/api/user/resetsecurityquestions/{UserID}")]
        public IHttpActionResult ResetSecurityQuestions(long userID)
        {
            ObjClsUserProfilesBIZ = new UserProfilesInfo();
            bool blnSecurityQuestions = false;
            try
            {
                if (userID <= 0)
                    return Content(HttpStatusCode.NotFound, $"Invalid user ID: {userID}");

                clsECSession.LogWebSessionAction("User Management", "", -1, 2032, "Reset Security Questions - Start", 101, -1, "");

                blnSecurityQuestions = ObjClsUserProfilesBIZ.ResetSecurityQuestions(userID);

                clsECSession.LogWebSessionAction("User Management", "", -1, 2796, "Reset Security Questions - End", 101, -1, "");
                return Ok(blnSecurityQuestions);
            }
            catch (Exception ex)
            {
                GeneralInfo.LogException(ex);
                throw ex;
            }
            finally
            {
                ObjClsUserProfilesBIZ = null;
            }
        }

        #endregion

        #region UserACL

        /// <summary>
        /// Adding staff to ACL group
        /// </summary>
        /// <returns></returns>

        [HttpPost]
        [Route("~/api/user/ACLDetails")]
        public IHttpActionResult SaveUserACLDetails(ACL aclDetails)
        {
            ACLInfo ObjClsACLBIZ;
            string errorMessage = string.Empty;
            try
            {
                clsECSession.LogWebSessionAction("User Management", "", -1, 2731, "Save ACL details - Start", 101, -1, "");

                if (aclDetails == null) return Content(HttpStatusCode.NotFound, "Please provide ACL data.");

                if (!ModelState.IsValid)
                {
                    errorMessage = string.Join(", ", ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                    clsECSession.LogWebSessionAction("User Management", "", -1, 2731, "Save ACL Details - Model validation failed" + JObject.FromObject(aclDetails).ToString(), 101, -1, "");
                    return Content(HttpStatusCode.PreconditionFailed, errorMessage);
                }

                ObjClsACLBIZ = new ACLInfo();
                return Ok(ObjClsACLBIZ.SaveUserACLDetails(aclDetails));
            }
            catch (Exception ex)
            {
                GeneralInfo.LogException(ex);
                throw ex;
            }
            finally
            {
                errorMessage = null;
                ObjClsACLBIZ = null;
            }
        }

        [HttpGet]
        [Route("~/api/User/ACLDetails/{Userid}/{mode}")]
        public IHttpActionResult GetACLDetails(long Userid, int mode)
        {
            ACLInfo ObjClsACLBIZ;
            ObjResponse = new clsResponse<string>();
            try
            {
                clsECSession.LogWebSessionAction("User Management", "", -1, 2729, "Get ACL Details for userId" + Userid + " - Start", 112, -1, "");

                if (Userid <= 0)
                    return Content(HttpStatusCode.NotFound, $"ACL Details does not exist with: {Userid}");

                ObjClsACLBIZ = new ACLInfo();
                ObjResponse = ObjClsACLBIZ.GetACLDetails(Userid, mode);

                if (ObjResponse.Status == "Failed")
                    //return Content(HttpStatusCode.NotFound, $"{ObjResponse.Reason} with: {Userid}");
                    return Ok(ObjResponse.Reason);

                clsECSession.LogWebSessionAction("User Management", "", -1, 2730, "Get ACL Details - End", 112, -1, "");

                //_jResponseData = JArray.Parse(ObjResponse.data);

                return Ok(JObject.Parse(ObjResponse.data).ToObject<ACL>());
            }
            catch (Exception ex)
            {
                GeneralInfo.LogException(ex);
                throw ex;
            }
            finally
            {
                ObjClsACLBIZ = null;
                ObjResponse = null;
            }
        }

        #endregion

        #region MCN

        [HttpGet]

        [Route("~/api/user/MCN/{userID}/{staffType}/{Mode}")]
        public IHttpActionResult GetUserMCN(long userID, int staffType, int Mode)
        {
            MCN _general;
            MCNInfo ObjClsMCNBIZ;
            try
            {
                if (userID <= 0)
                    return Content(HttpStatusCode.NotFound, $"User MCN data not exist with: {userID}");

                clsECSession.LogWebSessionAction("User Management", "", -1, 2729, "Get UserMcn Details for Staff ID:" + userID + " - Start", 101, -1, "");

                ObjResponse = new clsResponse<string>();
                ObjClsMCNBIZ = new MCNInfo();

                ObjResponse = ObjClsMCNBIZ.GetUserManagementMCNDetails(userID, staffType, Mode);

                if (ObjResponse.Status == "Failed")
                    return Content(HttpStatusCode.NotFound, ObjResponse.Reason);

                _general = JObject.Parse(ObjResponse.data.ToString()).ToObject<MCN>();
                clsECSession.LogWebSessionAction("User Management", "", -1, 2730, "Get UserMcn Details - End", 101, -1, "");

                return Ok(_general);
            }
            catch (Exception ex)
            {
                GeneralInfo.LogException(ex);
                throw ex;
            }
            finally
            {
                ObjClsGeneralBIZ = null;
                _general = null;
                ObjResponse = null;
            }
        }

        [HttpPost]
        [Route("~/api/User/AddUserMCN")]
        public IHttpActionResult SaveUserMCN(MCN objMCN)
        {
            string ItemList = string.Empty;
            MCNInfo ObjClsMCNBIZ;
            try
            {
                clsECSession.LogWebSessionAction("User Management", "", -1, 2731, "Save MCN - Start", 101, -1, "");

                if (!ModelState.IsValid)
                {
                    var keys = from item in ModelState
                               where item.Value.Errors.Any()
                               select item.Key;

                    foreach (string item in keys.ToList())
                        ItemList += item.Split('.').Last() + ",";

                    return Content(HttpStatusCode.PreconditionFailed, $"Please enter proper data: {ItemList}");
                }
                ObjClsMCNBIZ = new MCNInfo();
                return Ok(ObjClsMCNBIZ.SaveUserMCN(objMCN));
            }
            catch (Exception ex)
            {
                GeneralInfo.LogException(ex);
                throw ex;
            }
            finally
            {
                ItemList = null;
                ObjClsMCNBIZ = null;
            }
        }

        #endregion

        #region DefaultConfigurations

        [HttpGet]
        [Route("~/api/user/defaultconfiguration/{Userid}")]
        public IHttpActionResult GetDefaultConfigurations(long userID)
        {
            try
            {
                clsECSession.LogWebSessionAction("User Management", "", -1, 2729, "Get default configurations - Start", 101, -1, "");

                ObjClsGeneralBIZ = new GeneralInfo();
                ObjResponse = new clsResponse<string>();

                ObjResponse = ObjClsGeneralBIZ.GetDefaultConfigurations(userID);

                if (ObjResponse.Status == "Failed")
                    return Content(HttpStatusCode.NotFound, ObjResponse.Reason);

                clsECSession.LogWebSessionAction("User Management", "", -1, 2730, "Getdefault configurations - End", 101, -1, "");
                return Ok(JObject.Parse(ObjResponse.data));
            }
            catch (Exception ex)
            {
                GeneralInfo.LogException(ex);
                throw ex;
            }
        }
        #endregion
		
        #region UserStatus
        [HttpPost]
        [Route("~/api/userstatus")]
        public string UpdateUserStatus([FromBody] object objUserDetails)
        {
            ObjClsGeneralBIZ = new GeneralInfo();
            long intUserID = 0;
            string Status = "";
            JObject JUserDetails;
            string result = string.Empty;
            try
            {
                JUserDetails = JObject.FromObject(objUserDetails);
                intUserID = (int)JUserDetails["userId"];
                Status = JUserDetails["status"].ToString();
                clsECSession.LogWebSessionAction("User Management", "", -1, 2731, "Get User Availability Status:" + intUserID + " - Start", 101, -1, "");
                result = ObjClsGeneralBIZ.UpdateUserStatus(intUserID, Status);
                clsECSession.LogWebSessionAction("User Management", "", -1, 2732, "Get User Availability Status:" + intUserID + " - Start", 101, -1, "");
                return result;
            }


            catch (Exception ex)
            {
                GeneralInfo.LogException(ex);
                throw ex;
            }
            finally
            {
                ObjClsGeneralBIZ = null;
            }
        }
        [HttpGet]
        [Route("~/api/userstatus/{userID}")]
        public string GetUserStatus(long userID)
        {
            DataSet ds = new DataSet();
            try
            {
                if (userID <= 0)
                    return "User ID is not correct";

                clsECSession.LogWebSessionAction("User Management", "", -1, 2729, "Get User Availability Status:" + userID + " - Start", 101, -1, "");
                ObjClsGeneralBIZ = new GeneralInfo();
                ds = ObjClsGeneralBIZ.GetUserStatus(userID);
                //if (ObjResponse.Status == "Failed")
                //    return Content(HttpStatusCode.NotFound, ObjResponse.Reason);
                clsECSession.LogWebSessionAction("User Management", "", -1, 2730, "Get User Availability Status:" + userID + " - End", 101, -1, "");
                return ds.Tables[0].Rows[0][0].ToString();
               
            }
            catch (Exception ex)
            {
                GeneralInfo.LogException(ex);
                throw ex;
            }
            finally
            {
                ObjClsGeneralBIZ = null;
                ObjResponse = null;
            }
        }
        #endregion
    
    }
}
