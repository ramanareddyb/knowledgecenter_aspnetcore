﻿using System;
using System.Linq;
using System.Net;
using System.Web.Http;
using AxAPIUserManagement.Models;
using AxBIZUserManagement;
using Newtonsoft.Json.Linq;
using Excelicare.Framework.AppSupport;

namespace AxAPIUserManagement.Controllers
{
    public class ManageAccountController : ApiController
    {
        public UserProfilesInfo UserProfilesInfo;
        public clsResponse<string> ObjResponse;

        /// <summary>
        /// To get the user account details and it's status.
        /// </summary>
        /// <param name="userid"></param>
        /// <returns></returns>

        [HttpGet]
        [Route("~/api/manageaccount/{userid}")]
        public IHttpActionResult GetUserAccountDetails(long userid)
        {
            ManageAccount manageAccount;
            ObjResponse = new clsResponse<string>();
            try
            {
                if (userid < 0)
                    return Content(HttpStatusCode.BadRequest, "Please enter a valid User ID.");

                clsECSession.LogWebSessionAction("User Management", "", -1, 2729, "Get User Account Details for User ID:" + userid + " - Start", 112, -1, "");

                UserProfilesInfo = new UserProfilesInfo();
                ObjResponse = UserProfilesInfo.GetUserAccountDetails(userid);

                if (ObjResponse.Status == "Failed")
                    return Content(HttpStatusCode.NotFound, $"{ObjResponse.Reason} with: {userid}");


                manageAccount = JObject.Parse(ObjResponse.data).ToObject<ManageAccount>();

                clsECSession.LogWebSessionAction("User Management", "", -1, 2730, "Get User Account Details for User ID:" + userid + " - End", 112, -1, "");
                return Ok(manageAccount);
            }
            catch (Exception ex)
            {
                GeneralInfo.LogException(ex);
                throw ex;
            }
            finally
            {
                manageAccount = null;
                UserProfilesInfo = null;
                ObjResponse = null;
            }
        }

        /// <summary>
        /// To create/ update user account.
        /// </summary>
        /// <param name="manageAccount"></param>
        /// <returns></returns>

        [HttpPost]
        [Route("~/api/manageaccount")]
        public IHttpActionResult AddUserAccount([FromBody] ManageAccount manageAccount)
        {
            string errorMessage = string.Empty;
            clsResponse<string> result = null;
            try
            {
                clsECSession.LogWebSessionAction("User Management", "", -1, 2731, "Save User Account - Start", 112, -1, "");

                if (!ModelState.IsValid)
                {
                    errorMessage = string.Join(", ", ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                    clsECSession.LogWebSessionAction("User Management", "", -1, 2731, "Save User Account - Model validation failed" + JObject.FromObject(manageAccount).ToString(), 101, -1, "");
                    return Content(HttpStatusCode.PreconditionFailed, errorMessage);
                }
                UserProfilesInfo = new UserProfilesInfo();
                clsECSession.LogWebSessionAction("User Management", "", -1, 2732, "Save User Account - End", 112, -1, "");
                result = UserProfilesInfo.AddUserAccount(manageAccount);

                if (result.Status == "Failed")
                    return Content(HttpStatusCode.PreconditionFailed, result);

                return Ok(result);
            }
            catch (Exception ex)
            {
                GeneralInfo.LogException(ex);
                throw ex;
            }
            finally
            {
                result = null;
                errorMessage = null;
                UserProfilesInfo = null;
            }
        }

        /// <summary>
        /// To inactivate/ activate user account.
        /// </summary>
        /// <param name="objDeleteInfo"></param>
        /// <returns></returns>

        [HttpDelete]
        [Route("~/api/manageaccount")]
        public IHttpActionResult DeleteUserAccount([FromBody] object objDeleteInfo)
        {
            try
            {
                clsECSession.LogWebSessionAction("User Management", "", -1, 2032, "Activate or Inactive User Account - Start", 112, -1, "");

                UserProfilesInfo = new UserProfilesInfo();
                if (objDeleteInfo == null)
                    return Content(HttpStatusCode.NoContent, "Enter proper data for delete/ reactivate user account.");

                clsECSession.LogWebSessionAction("User Management", "", -1, 2796, "Activate or Inactive User Account - End", 112, -1, "");
                return Ok(UserProfilesInfo.DeleteUserAccount(objDeleteInfo));
            }
            catch (Exception ex)
            {
                GeneralInfo.LogException(ex);
                throw ex;
            }
            finally
            {
                UserProfilesInfo = null;
            }
        }
    }
}
