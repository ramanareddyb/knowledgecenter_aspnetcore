﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace AxAPIUserManagement.Models
{
    public class ACL
    {
        public Acldetail[] ACLDetails { get; set; }
    }
    public class Acldetail
    {
        [Required(ErrorMessage = "Please enter ACLGroupID.")]
        public int ACLGroupID { get; set; }
        public string GroupName { get; set; }
        public int? ACLGroupType_SLU { get; set; }
        public string ACLGroupType { get; set; }
        [Required(ErrorMessage = "Please enter StaffID.")]
        public long StaffID { get; set; }
        [Required(ErrorMessage = "Please enter StartDate.")]
        public DateTime? StartDate { get; set; }
        //[DateCompareAttriute("StartDate",">",ErrorMessage = "The EndDate for staff member cannot be earlier than the start date.")]
        public DateTime? StopDate { get; set; }
        public int? SetBy_User_ID { get; set; }
        public int? StoppedBy_User_ID { get; set; }
        public int RestrictionLevel { get; set; }
        [Required(ErrorMessage = "Please enter LastModifiedUserID.")]
        public int? LastModified_User_ID { get; set; }
        public string Mode { get; set; }

        public DateTime? ACLGroupStartDate { get; set; }
        public DateTime? ACLGroupEndDate { get; set; }
    }
}