﻿using System;
using System.ComponentModel.DataAnnotations;

namespace AxAPIUserManagement.Models
{
    public class FutureDateValidationAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            if (value == "" || value == null) return true;

            DateTime date = Convert.ToDateTime(value);
            return date <= DateTime.Now.Date; //Dates less than or equal to today are valid (true)

        }
    }

    public class PastDateValidationAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            if (value == null)
                return true;

            DateTime date = Convert.ToDateTime(value);
            return date >= DateTime.Now.Date; //Dates greater than or equal to today are valid (true)
        }
    }

    public class DateCompareAttriute : ValidationAttribute
    {
        public string DependentProperty { get; set; }
        public object TargetValue { get; set; }
        public object DependentValue { get; set; }
        public bool Result { get; set; }

        public DateCompareAttriute(string dependentProperty, object targetValue)
        {
            this.DependentProperty = dependentProperty;
            this.TargetValue = targetValue;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var field = validationContext.ObjectType.GetProperty(DependentProperty);
            if (field != null)
            {
                DependentValue = field.GetValue(validationContext.ObjectInstance, null);
                if (DependentValue != null && TargetValue != null && value != null)
                {
                    DateTime sourceValue = Convert.ToDateTime(value);
                    DateTime targetValue = Convert.ToDateTime(DependentValue);

                    if (TargetValue.ToString() == ">")
                    {
                        Result = sourceValue >= targetValue;
                        if (Result)
                            return ValidationResult.Success;
                        else
                            return new ValidationResult(FormatErrorMessage("Please enter proper dates."));
                    }
                    else if (TargetValue.ToString() == "<")
                    {
                        Result = sourceValue <= targetValue;
                        if (Result)
                            return ValidationResult.Success;
                        else
                            return new ValidationResult(FormatErrorMessage("Please enter proper dates."));
                    }
                }
                return ValidationResult.Success;
            }
            else
            {
                return new ValidationResult(FormatErrorMessage(DependentProperty));
            }
        }
    }

    public class RequiredIfAttribute : ValidationAttribute
    {
        RequiredAttribute _innerAttribute = new RequiredAttribute();
        public string DependentProperty { get; set; }
        public object TargetValue { get; set; }
        public string Notation { get; set; }

        public RequiredIfAttribute(string dependentProperty, object targetValue, string notation)
        {
            this.DependentProperty = dependentProperty;
            this.TargetValue = targetValue;
            this.Notation = notation;
        }
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var field = validationContext.ObjectType.GetProperty(DependentProperty);
            if (field != null)
            {
                var dependentValue = field.GetValue(validationContext.ObjectInstance, null);
                if (((dependentValue == null && TargetValue == null) || (dependentValue.Equals(TargetValue)) && Notation == "")|| (!dependentValue.Equals(TargetValue) && Notation.ToLower() == "not"))
                {
                    if (!_innerAttribute.IsValid(value))
                        return new ValidationResult(FormatErrorMessage("Please enter proper data."));
                }
                return ValidationResult.Success;
            }
            else
                return new ValidationResult(FormatErrorMessage(DependentProperty));
        }
    }
}