﻿using System;
using System.ComponentModel.DataAnnotations;

namespace AxAPIUserManagement.Models
{
    public class UserProfiles
    {
        public ProfileInfo ProfileInfo { get; set; }
        public Clinicservice[] ClinicServices { get; set; }
        public Labdepartmentaccessible LabDepartmentAccessible { get; set; }
        public UserCapabilities[] UserCapabilities { get; set; }
        public UserFunctions[] UserFunctions { get; set; }
    }

    public class ProfileInfo
    {
        [Required(ErrorMessage = "Please enter UserID.")]
        public long UserID { get; set; }
        [Required(ErrorMessage = "Please enter LoginName.")]
        public string LoginName { get; set; }
        public string Pswd { get; set; }
        public string SurName { get; set; }
        public string ForeName { get; set; }
        public int? Speciality { get; set; }
        public int Authority { get; set; }
        public int? Discipline { get; set; }
        public int Department { get; set; }
        public int? Designation { get; set; }
        [Required(ErrorMessage = "Please enter SecurityLevel.")]
        public int SecurityLevel { get; set; }
        public string Signature { get; set; }
        public string HospitalNo { get; set; }
        public string PreviousPswds { get; set; }
        public DateTime? PswdUpdtDate { get; set; }
        [Required(ErrorMessage = "Please enter ClnID.")]
        public int ClnID { get; set; }
        public string MergedCopy { get; set; }
        public string PatientFolderCopy { get; set; }
        public string DraftCopy { get; set; }
        public string DeletedCopy { get; set; }
        public string PINCode { get; set; }
        public string SecondPINCode { get; set; }
        public int? SystemVoiceID { get; set; }
        public int? MessageRecipUserID { get; set; }
        public string PhoneticName { get; set; }
        public string SplFormPref { get; set; }
        public string SentCopy { get; set; }
        public bool? IsMessageEnabled { get; set; }
        public bool? IsTransferEnabled { get; set; }
        public bool? IsStraightToScript { get; set; }
        public int? StartupObject { get; set; }
        public int? StartupReminder { get; set; }
        [Required(ErrorMessage = "Please enter ProfileActivated.")]
        public bool? ProfileActivated { get; set; }
        public bool? IsFormLibraryManager { get; set; }
        public bool? IsFormDesigner { get; set; }
        public string PrivilegedForms { get; set; }
        public int? LabSecurityLevel { get; set; }
        public int? OrderCommsSecurityLevel { get; set; }
        public int? PersonalDiaryInterval { get; set; }
        public string PrescriberCode { get; set; }
        public int? PrescriberRoleLU { get; set; }
        public string AvailableOtherStoresSLU { get; set; }
        public bool? ViewAttachmentAfterVetting { get; set; }
        public int PatSearchCategory_ID { get; set; }
        [Required(ErrorMessage = "Please enter IsActive.")]
        public int? IsActive { get; set; }
        public int LastModifiedUserID { get; set; }
        public int? SessionTimeOut { get; set; }
        public int IsPwdPromptRequired { get; set; }
        public int? IsUserSecQuestions { get; set; }
        public int? IsPwdModified { get; set; }
        public bool? UserAccountDetailStatus { get; set; }
        public string Mode { get; set; }
    }

    public class Labdepartmentaccessible
    {
        public string LastModifiedUserID { get; set; }
        public int[] LabsDepartmentLU { get; set; }
    }

    public class UserCapabilities
    {
        public int ID { get; set; }
        public int UserID { get; set; }
        public int CapabilityID { get; set; }
        public int IsActive { get; set; }
        public int LastModifiedUserID { get; set; }
        public string Mode { get; set; }
    }

    public class UserFunctions
    {
        public int ID { get; set; }
        public int UserID { get; set; }
        public int FunctionID { get; set; }
        public int IsActive { get; set; }
        public int LastModifiedUserID { get; set; }
        public string Mode { get; set; }
    }

    public class Functions
    {
    }

    public class Clinicservice
    {
        public int ClinicServicesID { get; set; }
        public long UsrID { get; set; }
        public int? ServiceTypeLU { get; set; }
        public int? IsActive { get; set; }
        public int LastModifiedUserID { get; set; }
        public int IsReadOnly { get; set; }
        public string Mode { get; set; }
    }
}