﻿using System;
using System.ComponentModel.DataAnnotations;

namespace AxAPIUserManagement.Models
{
    public class MCN
    {
        public StaffMCNCatchmentandRole[] StaffMCNCatchmentandRole { get; set; }
    }
    public class StaffMCNCatchmentandRole
    {
        [Required]
        public long MCNRoleAssignID { get; set; }
        [Required]
        public long MCNID { get; set; }
        public string MCNName { get; set; }

        [Required]
        public long CatchmentID { get; set; }
        public string CatchmentName { get; set; }
        public long StaffID { get; set; }
        public int Stafftype { get; set; }
        [Required]
        public long MCNRoleID { get; set; }
        public string MCNRoleName { get; set; }
        [Required]
        public DateTime StartDate { get; set; }
        public DateTime? StopDate { get; set; }
        public DateTime? MCNStartDate { get; set; }
        public DateTime? MCNEndDate { get; set; }
        public int IsActive { get; set; }
        public long LastModifiedUserID { get; set; }    
        public string Mode { get; set; }
    }
}