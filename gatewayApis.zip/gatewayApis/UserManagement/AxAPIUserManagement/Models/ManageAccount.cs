﻿using AxAPIUserManagement.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace AxAPIUserManagement.Models
{
    public class ManageAccount
    {
        public Accountdetail[] AccountDetails { get; set; }
    }

    public class Accountdetail
    {
        [Required(ErrorMessage = "Please enter ID.")]
        public int? ID { get; set; }
        [Required(ErrorMessage = "Please enter UserID.")]
        public long? UserID { get; set; }
        public int? IsActive { get; set; }
        [Required(ErrorMessage = "Please enter StartDate.")]
        //[PastDateValidation(ErrorMessage = "The start date cannot be past date.")]
        public DateTime? StartDate { get; set; }
        //[PastDateValidation(ErrorMessage = "The end date cannot be past date.")]
        //[DateCompareAttriute("StartDate", ">", ErrorMessage = "The End Date must be equal to or greater than the Start Date.")]
        public DateTime? EndDate { get; set; }
        public string Notes { get; set; }
        [Required(ErrorMessage = "Please enter LastModifiedUser.")]
        public int? LastModifiedUser { get; set; }
        public int? ProfileActivated { get; set; }
        public string LMUName { get; set; }
        public DateTime? LastModifiedDate { get; set; }
        public string Mode { get; set; }
        public Accountdetailstatus[] AccountDetailStatus { get; set; }

    }

    public class Accountdetailstatus
    {
        [Required(ErrorMessage = "Please enter statusID.")]
        public int? StatusID { get; set; }
        [Required(ErrorMessage = "Please enter UserAccountDetailID.")]
        public int? UserAccountDetailID { get; set; }
        [Required(ErrorMessage = "Please enter DateActivated.")]
        public DateTime? DateActivated { get; set; }
        public DateTime? DateInactivated { get; set; }
        public int? ReasonforInactivation { get; set; }
        public string ReasonforInactivationName { get; set; }
        [Required(ErrorMessage = "Please enter isActive.")]
        public int? IsActive { get; set; }
        [Required(ErrorMessage = "Please enter LastModified_User_ID.")]
        public int? LastModified_User_ID { get; set; }
        public string LMUName { get; set; }
        public DateTime? LastModifiedDate { get; set; }
        public int Parentlevel { get; set; }
        public string Mode { get; set; }

    }
}