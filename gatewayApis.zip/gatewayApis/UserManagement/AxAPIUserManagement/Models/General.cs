﻿using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace AxAPIUserManagement.Models
{
    public class General
    {
        public Staff Staff { get; set; }
        public Location[] Locations { get; set; }
        public Phone[] Phones { get; set; }
        public Email[] Emails { get; set; }
        [Required(ErrorMessage = "Please enter the staff's Facilities.")]
        public Facilities Facilities { get; set; }
        //public Staffidentfiers StaffIdentfiers { get; set; }
        public UserDetails UserDetails { get; set; }
        public ClinicianNHSdetails ClinicianNHSDetails { get; set; }
    }

    public class Staff
    {
        //[JsonProperty(propertyName: "cln_id")]
        [Required]
        public long ID { get; set; }
        public int? TitleCode { get; set; }
        [Required(ErrorMessage = "Please enter SurName.")]
        public string SurName { get; set; }
        [Required(ErrorMessage = "Please enter ForeName.")]
        public string ForeName { get; set; }
        [FutureDateValidation(ErrorMessage = "The staff's date of birth cannot be a future date.")]
        public string DOB { get; set; }
        [RequiredIf("ClinicianCode", 16365, "Not", ErrorMessage = "Please enter DisciplineCode.")]
        public int? DisciplineCode { get; set; }
        [RequiredIf("ClinicianCode", 16365, "Not", ErrorMessage = "Please enter SpecialityCode.")]
        public int? SpecialityCode { get; set; }
        [RequiredIf("ClinicianCode", 16365, "Not", ErrorMessage = "Please enter DesignationCode.")]
        public int? DesignationCode { get; set; }
        [RequiredIf("ClinicianCode", 16365, "", ErrorMessage = "Please enter OSDesignation.")]
        public string OSDesignation { get; set; }
        [Required(ErrorMessage = "Please enter DepartmentCode.")]
        public int? DepartmentCode { get; set; }
        public string JobTitle { get; set; }
        [Required(ErrorMessage = "Please enter ClinicianCode.")]
        public int ClinicianCode { get; set; }
        public int? NHSClinician { get; set; }
        [Required(ErrorMessage = "Please enter staff's Location.")]
        public int LocID { get; set; }
        public string CallNotes { get; set; }
        public string Nationality { get; set; }
        public string PrescribingRefNo { get; set; }
        public string Role { get; set; }
        public int? IsActive { get; set; }
        public int LastModifiedUserID { get; set; }
        public string Comments { get; set; }
        public int? PrescribingRoleLU { get; set; }
        public int? LicenseStateLU { get; set; }
        public string Initials { get; set; }
        public string MiddleName { get; set; }
        public int? ChangeAssociatedPatientsLocation { get; set; }
        public int? PLLocID { get; set; }
        public string RCGPNumber { get; set; }
        public string NINo { get; set; }
        public string IdentificationNumber { get; set; }
        public string SpProfessionalBodyNo { get; set; }
        public string LicenseNumber { get; set; }
        public string UPIN { get; set; }
        public string DEA { get; set; }
        public string NPI { get; set; }
        public string TinNumber { get; set; }
        public string Mode { get; set; }
        public string Language { get; set; }
    }

    public class Facilities
    {
        public long StaffID { get; set; }
        public string LastModifiedUserID { get; set; }
        public int UserTypeLU { get; set; }
        [Required(ErrorMessage = "Please enter the staff's Facilities.")]
        public int[] FacilityLU { get; set; }
    }

    /*public class Staffidentfiers
    {
        [JsonProperty(propertyName: "NHSC ID")]
        public int NHSCID { get; set; }
        public long CLNID { get; set; }
        [JsonProperty(propertyName: "NHSC GMC TempRegistration No.")]
        public string NHSCGMCTempRegistrationNo { get; set; }
        [JsonProperty(propertyName: "NHSC GMC TempRegistration Date")]
        public string NHSCGMCTempRegistrationDate { get; set; }
        [JsonProperty(propertyName: "NHSC GMC PermRegistration No.")]
        public string NHSCGMCPermRegistrationNo { get; set; }
        [JsonProperty(propertyName: "NHSC GMC Perm Registration Date")]
        public string NHSCGMCPermRegistrationDate { get; set; }
        [JsonProperty(propertyName: "RCGP Number")]
        public string RCGPNumber { get; set; }
        [JsonProperty(propertyName: "NI No.")]
        public string NINo { get; set; }
        [JsonProperty(propertyName: "Identification Number")]
        public string IdentificationNumber { get; set; }
        [JsonProperty(propertyName: "Sp Professional Body No.")]
        public string SpProfessionalBodyNo { get; set; }
        [JsonProperty(propertyName: "License Number")]
        public string LicenseNumber { get; set; }
        public string UPIN { get; set; }
        public string DEA { get; set; }
        public string NPI { get; set; }
        [JsonProperty(propertyName: "Tin Number")]
        public string TinNumber { get; set; }
    }*/

    public class Location
    {
        public long StaffID { get; set; }
        [Required(ErrorMessage = "Please enter staff's Location.")]
        public int LocId { get; set; }
        public string LocName { get; set; }
        public string LocAddr1 { get; set; }
        public string LocAddr2 { get; set; }
        public string LocCity { get; set; }
        public string LocCounty { get; set; }
        public string Country { get; set; }
        public string LocPCode { get; set; }
        public string Address { get; set; }
        public bool IsPrimary { get; set; }
        public int LastModifiedUserID { get; set; }
        public string LocationChain { get; set; }
        public string Mode { get; set; }
		public int RoleLU { get; set; }
    }
    public class Phone
    {
        public int ClnpId { get; set; }
        public long StaffID { get; set; }
        public string ClnpPhoneNo { get; set; }
        public int ClnpPhoneTypeCode { get; set; }
        public object ClnpProviderCode { get; set; }
        public bool IsISDNBonded { get; set; }
        public bool IsPreferred { get; set; }
        public int IsActive { get; set; }
        public int LastModifiedUserID { get; set; }
        public string Mode { get; set; }
    }

    public class Email
    {

        public int ClneID { get; set; }
        public long StaffID { get; set; }

        public string ClneEaddr { get; set; }
        public bool IsPreferred { get; set; }
        public int IsActive { get; set; }
        [Required(ErrorMessage = "Please enter Mail Account Type.")]
        public int MailAccountTypeSLU { get; set; }
        public int LastModifiedUserID { get; set; }
        public string Mode { get; set; }
    }

    public class UserDetails
    {
        public long? UsrID { get; set; }
        public int? StaffType { get; set; }
    }

    public class ClinicianNHSdetails
    {
        public int? NHSC_ID { get; set; }
        public string NHSC_GMC_Temp_Registration_No { get; set; }
        public string NHSC_GMC_Temp_Registration_Dt { get; set; }
        public string NHSC_GMC_Perm_Registration_No { get; set; }
        public string NHSC_GMC_Perm_Registration_Dt { get; set; }
    }
}