﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AxAPIUserManagement.Models
{
    public class UserManagement
    {
        public General General { get; set; }
        public UserProfiles UserProfiles { get; set; }
    }
}