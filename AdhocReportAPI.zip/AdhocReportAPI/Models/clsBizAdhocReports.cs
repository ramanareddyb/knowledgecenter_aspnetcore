﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;


namespace AxAPIAdhocReports.Models
{
     /// <summary>
     /// 
     /// </summary>
    public class clsBizAdhocReports
    {
       /// <summary>
       /// getting active patient details
       /// </summary>
       /// <param name="startIndex">optional</param>
       /// <param name="endIndex">optional</param>
       /// <returns></returns>
        public string GetActivePatientDetails(string conn,int startIndex=1,int endIndex=100)
        {
            clsDalAdhocReports _objAdhocReports = new clsDalAdhocReports();
            DataTable _patientData;           
            try
            {
                
                _patientData = _objAdhocReports.GetActivePatientDetails(conn,startIndex, endIndex);
                if (_patientData.Rows[0][0].ToString() == "")
                    throw new Exception("Patients are not exists.");

                //_JGeneralObject = JObject.Parse(_patientData.Tables[0].Rows[0][0].ToString().Replace("[", "{").Replace("]", "}"));               
                return _patientData.Rows[0][0].ToString();
              
            }
            catch (Exception ex){ throw ex;}
            finally
            {
                _patientData = null;
                _patientData = null;               
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="startIndex"></param>
        /// <param name="endIndex"></param>
        /// <returns></returns>
        public string GetPatientAddressDetails(string conn, int startIndex = 1, int endIndex = 100)
        {
            clsDalAdhocReports _objAdhocReports = new clsDalAdhocReports();
            DataTable _patientData;
            try
            {

                _patientData = _objAdhocReports.GetPatientAddressDetails(conn, startIndex, endIndex);
                if (_patientData.Rows[0][0].ToString() == "")
                    throw new Exception("Patients are not exists.");

                //_JGeneralObject = JObject.Parse(_patientData.Tables[0].Rows[0][0].ToString().Replace("[", "{").Replace("]", "}"));               
                return _patientData.Rows[0][0].ToString();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _patientData = null;
                _patientData = null;

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="startIndex"></param>
        /// <param name="endIndex"></param>
        /// <returns></returns>
        public string GetApptmntSchedulerDetails(string conn, int startIndex = 1, int endIndex = 100)
        {
            clsDalAdhocReports _objAdhocReports = new clsDalAdhocReports();
            DataTable _patientData;
            try
            {

                _patientData = _objAdhocReports.GetAppmentSchedulerInfo(conn, startIndex, endIndex);
                if (_patientData.Rows[0][0].ToString() == "")
                    throw new Exception("Appointment details are not exists.");

                //_JGeneralObject = JObject.Parse(_patientData.Tables[0].Rows[0][0].ToString().Replace("[", "{").Replace("]", "}"));               
                return _patientData.Rows[0][0].ToString();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _patientData = null;
                _patientData = null;

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="startIndex"></param>
        /// <param name="endIndex"></param>
        /// <returns></returns>
        public string GetMcnList(string conn, int startIndex = 1, int endIndex = 100)
        {
            clsDalAdhocReports _objAdhocReports = new clsDalAdhocReports();
            DataTable _patientData;
            try
            {

                _patientData = _objAdhocReports.GetMCNListDetails(conn, startIndex, endIndex);
                if (_patientData.Rows[0][0].ToString() == "")
                    throw new Exception("MCN details are not exists.");

                //_JGeneralObject = JObject.Parse(_patientData.Tables[0].Rows[0][0].ToString().Replace("[", "{").Replace("]", "}"));               
                return _patientData.Rows[0][0].ToString();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _patientData = null;
                _patientData = null;

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsondata"></param>
        /// <returns></returns>
        public JObject GetJsonObjectfromString(params string[] jsondata)
        {
            JObject jObjMain;
            try
            {
                jObjMain = new JObject
                {
                    {"General", JObject.Parse(jsondata[0])},
                    {"UserProfiles", JObject.Parse(jsondata[1])}
                };
                return jObjMain;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                jObjMain = null;
            }
        }
    }
}