﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excelicare.Framework.AppDataSupport;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
namespace AxAPIAdhocReports.Models
{
    public class clsDalAdhocReports
    {
      

        public clsDataAccess objClsDataAccess;

        /// <summary>
        /// Get Active Patients
        /// </summary>
        /// <param name="StartIndex"></param>
        /// <param name="EndIndex"></param>
        /// <returns></returns>
        public DataTable GetActivePatientDetails(string conn,int StartIndex, int EndIndex)
        {
            //ParamStruct[] param = new ParamStruct[2];
            SqlParameter[] param = new SqlParameter[2];
            try
            {
                //param[0].ParamName = "@StartIndex";
                //param[0].DataType = DbType.Int16;
                //param[0].direction = ParameterDirection.Input;
                //param[0].value = StartIndex;

                //param[1].ParamName = "@EndIndex";
                //param[1].DataType = DbType.Int64;
                //param[1].direction = ParameterDirection.Input;
                //param[1].value = EndIndex;



                param[0] = new SqlParameter("@StartIndex", SqlDbType.Int);
                param[0].Value = StartIndex;
                param[0].Direction = ParameterDirection.Input;

                param[1] = new SqlParameter("@EndIndex", SqlDbType.Int);
                param[1].Value = EndIndex;
                param[1].Direction = ParameterDirection.Input;


                objClsDataAccess = new clsDataAccess();
                string strConn = conn;//System.Configuration.ConfigurationManager.AppSettings["AdhocConnectionString"];
                objClsDataAccess.GetConnectionStringforUser(ref strConn, EnumDataBaseUserType.AxAppUser);
                SqlConnection cn=new SqlConnection(strConn);
                SqlCommand cmd = cn.CreateCommand();
                cmd.CommandText = "axadhocsp_getPatients";
                //cmd.Parameters.Add("@StartIndex", SqlDbType.Int).Value = StartIndex;
                //cmd.Parameters.Add("@EndIndex", SqlDbType.Int).Value = EndIndex;
                //cmd = new SqlCommand("submitrecord", cn);
                //cmd.CommandType = CommandType.StoredProcedure;
                cn.Open();
                DataSet getDataSet = new DataSet();
                SqlDataAdapter getDapt = new SqlDataAdapter();
                getDapt.SelectCommand = new SqlCommand(cmd.CommandText, cn);
                getDapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                getDapt.SelectCommand.Parameters.AddRange(param);
                getDapt.Fill(getDataSet);
                cn = null;
                getDapt = null;
                strConn = null;
                return getDataSet.Tables[0];

                //string strConn = ConfigurationManager.AppSettings["AdhocConnectionString"];
            
                //objClsDataAccess.ConnectionString = strConn;
                
                //return objClsDataAccess.ExecuteDataSet("axadhocsp_getPatients", CommandType.StoredProcedure, param).Tables[0];

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                param = null;
                objClsDataAccess = null;
            }

        }

        /// <summary>
        /// Get Patient Address Details
        /// </summary>
        /// <param name="StartIndex"></param>
        /// <param name="EndIndex"></param>
        /// <returns></returns>
        public DataTable GetPatientAddressDetails(string conn, int StartIndex, int EndIndex)
        {
            //ParamStruct[] param = new ParamStruct[2];
            SqlParameter[] param = new SqlParameter[2];
            try
            {
                //    param[0].ParamName = "@StartIndex";
                //    param[0].DataType = DbType.Int16;
                //    param[0].direction = ParameterDirection.Input;
                //    param[0].value = StartIndex;

                //    param[1].ParamName = "@EndIndex";
                //    param[1].DataType = DbType.Int64;
                //    param[1].direction = ParameterDirection.Input;
                //    param[1].value = EndIndex;


                //    objClsDataAccess = new clsDataAccess();


                //    string strConn = ConfigurationManager.AppSettings["AdhocConnectionString"];
                //    objClsDataAccess.GetConnectionStringforUser(ref strConn, EnumDataBaseUserType.AxAppUser);
                //    objClsDataAccess.ConnectionString = strConn;
                //    return objClsDataAccess.ExecuteDataSet("axadhocsp_getpatientAddress", CommandType.StoredProcedure, param).Tables[0];

                param[0] = new SqlParameter("@StartIndex", SqlDbType.Int);
                param[0].Value = StartIndex;
                param[0].Direction = ParameterDirection.Input;

                param[1] = new SqlParameter("@EndIndex", SqlDbType.Int);
                param[1].Value = EndIndex;
                param[1].Direction = ParameterDirection.Input;


                objClsDataAccess = new clsDataAccess();
                string strConn = conn;//System.Configuration.ConfigurationManager.AppSettings["AdhocConnectionString"];
                objClsDataAccess.GetConnectionStringforUser(ref strConn, EnumDataBaseUserType.AxAppUser);
                SqlConnection cn = new SqlConnection(strConn);
                SqlCommand cmd = cn.CreateCommand();
                cmd.CommandText = "axadhocsp_getpatientAddress";
                //cmd.Parameters.Add("@StartIndex", SqlDbType.Int).Value = StartIndex;
                //cmd.Parameters.Add("@EndIndex", SqlDbType.Int).Value = EndIndex;
                //cmd = new SqlCommand("submitrecord", cn);
                //cmd.CommandType = CommandType.StoredProcedure;
                cn.Open();
                DataSet getDataSet = new DataSet();
                SqlDataAdapter getDapt = new SqlDataAdapter();
                getDapt.SelectCommand = new SqlCommand(cmd.CommandText, cn);
                getDapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                getDapt.SelectCommand.Parameters.AddRange(param);
                getDapt.Fill(getDataSet);
                cn = null;
                getDapt = null;
                strConn = null;
                return getDataSet.Tables[0];

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                //param = null;
                objClsDataAccess = null;
            }

        }

        /// <summary>
        /// Get MCN List
        /// </summary>
        /// <param name="StartIndex"></param>
        /// <param name="EndIndex"></param>
        /// <returns></returns>
        public DataTable GetMCNListDetails(string conn, int StartIndex, int EndIndex)
        {
            // ParamStruct[] param = new ParamStruct[2];
            SqlParameter[] param = new SqlParameter[2];
            try
            {
                //param[0].ParamName = "@StartIndex";
                //param[0].DataType = DbType.Int16;
                //param[0].direction = ParameterDirection.Input;
                //param[0].value = StartIndex;

                //param[1].ParamName = "@EndIndex";
                //param[1].DataType = DbType.Int64;
                //param[1].direction = ParameterDirection.Input;
                //param[1].value = EndIndex;


                //objClsDataAccess = new clsDataAccess();


                //string strConn = ConfigurationManager.AppSettings["AdhocConnectionString"];
                //objClsDataAccess.GetConnectionStringforUser(ref strConn, EnumDataBaseUserType.AxAppUser);
                //objClsDataAccess.ConnectionString = strConn;
                //return objClsDataAccess.ExecuteDataSet("axadhocsp_getMcnList", CommandType.StoredProcedure, param).Tables[0];
                param[0] = new SqlParameter("@StartIndex", SqlDbType.Int);
                param[0].Value = StartIndex;
                param[0].Direction = ParameterDirection.Input;

                param[1] = new SqlParameter("@EndIndex", SqlDbType.Int);
                param[1].Value = EndIndex;
                param[1].Direction = ParameterDirection.Input;


                objClsDataAccess = new clsDataAccess();
                string strConn = conn;//System.Configuration.ConfigurationManager.AppSettings["AdhocConnectionString"];
                objClsDataAccess.GetConnectionStringforUser(ref strConn, EnumDataBaseUserType.AxAppUser);
                SqlConnection cn = new SqlConnection(strConn);
                SqlCommand cmd = cn.CreateCommand();
                cmd.CommandText = "axadhocsp_getMcnList";
                //cmd.Parameters.Add("@StartIndex", SqlDbType.Int).Value = StartIndex;
                //cmd.Parameters.Add("@EndIndex", SqlDbType.Int).Value = EndIndex;
                //cmd = new SqlCommand("submitrecord", cn);
                //cmd.CommandType = CommandType.StoredProcedure;
                cn.Open();
                DataSet getDataSet = new DataSet();
                SqlDataAdapter getDapt = new SqlDataAdapter();
                getDapt.SelectCommand = new SqlCommand(cmd.CommandText, cn);
                getDapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                getDapt.SelectCommand.Parameters.AddRange(param);
                getDapt.Fill(getDataSet);
                cn = null;
                getDapt = null;
                strConn = null;
                return getDataSet.Tables[0];

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                //param = null;
                objClsDataAccess = null;
            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="StartIndex"></param>
        /// <param name="EndIndex"></param>
        /// <returns></returns>
        public DataTable GetContactanalysisDetails(string conn, int StartIndex, int EndIndex)
        {
            //ParamStruct[] param = new ParamStruct[2];
            SqlParameter[] param = new SqlParameter[2];
            try
            {
                //param[0].ParamName = "@StartIndex";
                //param[0].DataType = DbType.Int16;
                //param[0].direction = ParameterDirection.Input;
                //param[0].value = StartIndex;

                //param[1].ParamName = "@EndIndex";
                //param[1].DataType = DbType.Int64;
                //param[1].direction = ParameterDirection.Input;
                //param[1].value = EndIndex;


                //objClsDataAccess = new clsDataAccess();


                //string strConn = ConfigurationManager.AppSettings["AdhocConnectionString"];
                //objClsDataAccess.GetConnectionStringforUser(ref strConn, EnumDataBaseUserType.AxAppUser);
                //objClsDataAccess.ConnectionString = strConn;
                //return objClsDataAccess.ExecuteDataSet("axadhocsp_getPatients", CommandType.StoredProcedure, param).Tables[0];

                param[0] = new SqlParameter("@StartIndex", SqlDbType.Int);
                param[0].Value = StartIndex;
                param[0].Direction = ParameterDirection.Input;

                param[1] = new SqlParameter("@EndIndex", SqlDbType.Int);
                param[1].Value = EndIndex;
                param[1].Direction = ParameterDirection.Input;


                objClsDataAccess = new clsDataAccess();
                string strConn = conn;//System.Configuration.ConfigurationManager.AppSettings["AdhocConnectionString"];
                objClsDataAccess.GetConnectionStringforUser(ref strConn, EnumDataBaseUserType.AxAppUser);
                SqlConnection cn = new SqlConnection(strConn);
                SqlCommand cmd = cn.CreateCommand();
                cmd.CommandText = "axadhocsp_getPatients";
                //cmd.Parameters.Add("@StartIndex", SqlDbType.Int).Value = StartIndex;
                //cmd.Parameters.Add("@EndIndex", SqlDbType.Int).Value = EndIndex;
                //cmd = new SqlCommand("submitrecord", cn);
                //cmd.CommandType = CommandType.StoredProcedure;
                cn.Open();
                DataSet getDataSet = new DataSet();
                SqlDataAdapter getDapt = new SqlDataAdapter();
                getDapt.SelectCommand = new SqlCommand(cmd.CommandText, cn);
                getDapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                getDapt.SelectCommand.Parameters.AddRange(param);
                getDapt.Fill(getDataSet);
                cn = null;
                getDapt = null;
                strConn = null;
                return getDataSet.Tables[0];


            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
               // param = null;
                objClsDataAccess = null;
            }

        }
        /// <summary>
        /// Get Appointment scheduler information details
        /// </summary>
        /// <param name="StartIndex"></param>
        /// <param name="EndIndex"></param>
        /// <returns></returns>
        public DataTable GetAppmentSchedulerInfo(string conn, int StartIndex, int EndIndex)
        {
            //ParamStruct[] param = new ParamStruct[2];
            SqlParameter[] param = new SqlParameter[2];
            DataSet getDataSet = new DataSet();
            
           
            try
            {
                //param[0].ParamName = "@StartIndex";
                //param[0].DataType = DbType.Int16;
                //param[0].direction = ParameterDirection.Input;
                //param[0].value = StartIndex;

                //param[1].ParamName = "@EndIndex";
                //param[1].DataType = DbType.Int64;
                //param[1].direction = ParameterDirection.Input;
                //param[1].value = EndIndex;


                //objClsDataAccess = new clsDataAccess();


                //string strConn = ConfigurationManager.AppSettings["AdhocConnectionString"];
                //objClsDataAccess.GetConnectionStringforUser(ref strConn, EnumDataBaseUserType.AxAppUser);
                //objClsDataAccess.ConnectionString = strConn;
                //return objClsDataAccess.ExecuteDataSet("[axadhocsp_getApptSchedulerInfo]", CommandType.StoredProcedure, param).Tables[0];

                param[0] = new SqlParameter("@StartIndex", SqlDbType.Int);
                param[0].Value = StartIndex;
                param[0].Direction = ParameterDirection.Input;

                param[1] = new SqlParameter("@EndIndex", SqlDbType.Int);
                param[1].Value = EndIndex;
                param[1].Direction = ParameterDirection.Input;


                objClsDataAccess = new clsDataAccess();
                string strConn = conn;//System.Configuration.ConfigurationManager.AppSettings["AdhocConnectionString"];
                objClsDataAccess.GetConnectionStringforUser(ref strConn, EnumDataBaseUserType.AxAppUser);
                SqlConnection cn = new SqlConnection(strConn);
                
                SqlCommand cmd = cn.CreateCommand();
                cmd.CommandText = "axadhocsp_getApptSchedulerInfo";               
                cn.Open();
               
                SqlDataAdapter getDapt = new SqlDataAdapter();
                getDapt.SelectCommand = new SqlCommand(cmd.CommandText, cn);
                getDapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                getDapt.SelectCommand.Parameters.AddRange(param);
                getDapt.Fill(getDataSet);
                cn = null;
                getDapt = null;
                strConn = null;
                return getDataSet.Tables[0];

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                param = null;
                objClsDataAccess = null;
            }

        }
    }
}
