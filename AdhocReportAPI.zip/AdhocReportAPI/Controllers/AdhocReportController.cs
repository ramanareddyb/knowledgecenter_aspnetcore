﻿using AxAPIAdhocReports.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
namespace AdhocReportAPI.Controllers
{
    public class AdhocReportController : ControllerBase
    {

        IConfiguration _iconfiguration;
        public AdhocReportController(IConfiguration iconfiguration)
        {
            _iconfiguration = iconfiguration;
        }
        /// <summary>
        /// all active patients details
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/adhocreports/patients")]
        public IActionResult AllActivePatients()
        {
            string _jResponseData;
            try
            {
                clsBizAdhocReports _objAdhocReports = new clsBizAdhocReports();
                _jResponseData = _objAdhocReports.GetActivePatientDetails(_iconfiguration["AdhocConnectionString"]);

                JArray jsonArray = JArray.Parse(_jResponseData);

                //dynamic data = JObject.Parse(jsonArray[0].ToString());

                return Ok(_jResponseData);
                //return Json(new JavaScriptSerializer().Serialize(_jResponseData));
            }
            catch (Exception ex) { return Ok(ex.Message); }
            finally { _jResponseData = null; }
        }

        /// <summary>
        /// all active patients details
        /// </summary>
        /// <param name="startIndex">optional</param>
        /// <param name="endIndex">optional</param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/adhocreports/patient/{startIndex}/{endIndex}")]
        public IActionResult  AllActivePatients(int startIndex, int endIndex)
        {
            string _jResponseData;
            try
            {
                clsBizAdhocReports _objAdhocReports = new clsBizAdhocReports();
                _jResponseData = _objAdhocReports.GetActivePatientDetails(_iconfiguration["AdhocConnectionString"],startIndex, endIndex);

                JArray jsonArray = JArray.Parse(_jResponseData);

                return Ok(_jResponseData);
            }
            catch (Exception ex) { throw ex; }
            finally { _jResponseData = null; }

        }

        /// <summary>
        /// patient address details
        /// </summary>
        /// <param name="startIndex"></param>
        /// <param name="endIndex"></param>
        /// <returns></returns>

        [HttpGet]
        [Route("api/adhocreports/patientaddress")]
        [Route("api/adhocreports/patientaddressdetails/{startIndex}/{endIndex}")]
        public IActionResult PatientAddressDetails(int startIndex = 1, int endIndex = 10)
        {
            string _jResponseData;
            try
            {
                clsBizAdhocReports _objAdhocReports = new clsBizAdhocReports();
                _jResponseData = _objAdhocReports.GetPatientAddressDetails(_iconfiguration["AdhocConnectionString"],startIndex, endIndex);

                JArray jsonArray = JArray.Parse(_jResponseData);

                return Ok(_jResponseData);
            }
            catch (Exception ex) { throw ex; }
            finally { _jResponseData = null; }

        }


        /// <summary>
        /// mcn details list
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/adhocreports/mcnlist")]
        [Route("api/adhocreports/mcndetails/{startIndex}/{endIndex}")]
        public IActionResult MCNlist(int startIndex = 1, int endIndex = 10)
        {
            string _jResponseData;
            try
            {
                clsBizAdhocReports _objAdhocReports = new clsBizAdhocReports();
                _jResponseData = _objAdhocReports.GetMcnList(_iconfiguration["AdhocConnectionString"], startIndex, endIndex);

                JArray jsonArray = JArray.Parse(_jResponseData);

                return Ok(_jResponseData);
            }
            catch (Exception ex) { throw ex; }
            finally { _jResponseData = null; }
        }

        /// <summary>
        /// contact analysis special form data
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/adhocreports/contactanalysis")]
        public IActionResult ContactAnalysis()
        {
            try
            {

                return Ok();
            }
            catch (Exception ex) { throw ex; }
            finally { }
        }

        /// <summary>
        /// patient appointment scheduled details
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/adhocreports/apptmntschedulerInfo")]
        public IActionResult ApptSchedulerInfo()
        {
            string _jResponseData;
            try
            {
                clsBizAdhocReports _objAdhocReports = new clsBizAdhocReports();
                _jResponseData = _objAdhocReports.GetApptmntSchedulerDetails(_iconfiguration["AdhocConnectionString"]);

                JArray jsonArray = JArray.Parse(_jResponseData);

                return Ok(_jResponseData);
            }
            catch (Exception ex) { throw ex; }
            finally { _jResponseData = null; }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="startIndex"></param>
        /// <param name="endIndex"></param>
        /// <returns></returns>

        [HttpGet]
        [Route("api/adhocreports/apptmntscheduler/{startIndex}/{endIndex}")]
        public IActionResult ApptSchedulerInfo(int startIndex, int endIndex)
        {
            string _jResponseData;
            try
            {
                clsBizAdhocReports _objAdhocReports = new clsBizAdhocReports();
                _jResponseData = _objAdhocReports.GetApptmntSchedulerDetails(_iconfiguration["AdhocConnectionString"],startIndex, endIndex);

                JArray jsonArray = JArray.Parse(_jResponseData);

                return Ok(_jResponseData);
            }
            catch (Exception ex) { throw ex; }
            finally { _jResponseData = null; }
        }

    }

}

