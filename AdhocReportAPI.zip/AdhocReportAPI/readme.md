# Project Title

ADHOCREPORTS API

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes. See deployment for notes on how to deploy the project on a live system.

### Prerequisites

.NET6.0 SDK

DOCKER


### Installing

https://www.docker.com/products/docker-desktop/

After installing Docker Desktop for Mac or  Windows, try to follow below command execution steps to get build and run the ADHOCREPORTS API Docker

Go to the Project Folder from command prompt i.e /ADHOCREPORTSAPI

Run docker build -t docker3387/adhocreportapi .

Run docker run -p 8080:80 docker3387/adhocreporapi

Browse below urls from browser

i/p : 

    ADHOCDB - ActivePatient Details
	  http://localhost:8080/api/adhocreports/patients

    ADHOCDB - ActivePatient Details Based on Pagination like start and end positions
      http://localhost:8080/api/adhocreports/patient/1/10
    
    ADHOCDB - PatientAddress Details
      http://localhost:8080/api/adhocreports/patientaddress

    ADHOCDB - PatientAddress Details Based on Pagination like start and end positions
      http://localhost:8080/api/adhocreports/patientaddressdetails/1/10

    ADHOCDB - MCN List
      http://localhost:8080/api/adhocreports/mcnlist

    ADHOCDB - MCN Details Based on Pagination like start and end position
      http://localhost:8080/api/adhocreports/mcndetials/1/10
    
    ADHOCDB - AppointmentSchedulerInformation Details
      http://localhost:8080/api/adhocreports/apptmntschedulerInfo

    ADHOCDB - AppointmentSchedulerInformation Details Baesd on Pagination like start and end positions
      http://localhost:8080/api/adhocreports/apptmntscheduler/1/10
	  
	
o/p : 

	Sample Example
	---------
	[{"PAT_Forename1":"tedt","PAT_Surname":"testq","PAT_Sex_Code":547,"PAT_DOB":"2022-06-08T00:00:00","PAT_Optional2":"0","PAT_Reg_Date":"2022-06-08T00:00:00","PAT_Secondary_Identifier":"HIE00196762","IsActive":1,"LookupCategory_SLU":132,"LookupValue":"Male"},{"PAT_Forename1":"Happy","PAT_Surname":"Mark's","PAT_Sex_Code":547,"PAT_DOB":"1982-05-13T00:00:00","PAT_Optional2":"0","PAT_Reg_Date":"2022-05-13T00:00:00","PAT_Secondary_Identifier":"HIE00196754","IsActive":1,"LookupCategory_SLU":132,"LookupValue":"Male"}]

    [{"Patient_Id":19675,"PPA_City":"Sector  - NOIDA CITY","PPA_IsCurrent":true,"PPA_PCode":"M11AA","PPA_HB_ID":null,"HB_Name":null},{"Patient_Id":19662,"PPA_City":"CITY","PPA_IsCurrent":true,"PPA_PCode":"M11AA","PPA_HB_ID":null,"HB_Name":null},{"Patient_Id":19661,"PPA_City":null,"PPA_IsCurrent":true,"PPA_PCode":null,"PPA_HB_ID":null,"HB_Name":null},{"Patient_Id":19660,"PPA_City":null,"PPA_IsCurrent":true,"PPA_PCode":null,"PPA_HB_ID":null,"HB_Name":null},{"Patient_Id":19659,"PPA_City":null,"PPA_IsCurrent":true,"PPA_PCode":null,"PPA_HB_ID":null,"HB_Name":null}]

    [{"Id":6002,"Pat_Id":122,"Mcn_Id":9002,"Stop_Date":null,"Mcn_Name":"MCN-Anthony"},{"Id":6001,"Pat_Id":122,"Mcn_Id":9001,"Stop_Date":null,"Mcn_Name":"MCN-Retinopathy"},{"Id":6000,"Pat_Id":110,"Mcn_Id":9675006,"Stop_Date":null,"Mcn_Name":"local"},{"Id":5999,"Pat_Id":110,"Mcn_Id":9875118,"Stop_Date":null,"Mcn_Name":"test MCN 111"},{"Id":5998,"Pat_Id":114,"Mcn_Id":9675008,"Stop_Date":null,"Mcn_Name":"TestMCN2"},{"Id":5997,"Pat_Id":113,"Mcn_Id":9675008,"Stop_Date":null,"Mcn_Name":"TestMCN2"},{"Id":4997,"Pat_Id":111,"Mcn_Id":9675008,"Stop_Date":null,"Mcn_Name":"TestMCN2"},{"Id":4996,"Pat_Id":109,"Mcn_Id":9675006,"Stop_Date":null,"Mcn_Name":"local"}]

    [{"Appt_id":10006280,"pat_id":null,"startdatetime":"2022-05-17T05:00:00","Cln_Fname":null,"Cln_Sname":null,"Description":"CARE HOSPITALS , HYDERABAD (Vijay's Clinic - Testing)","Pat_ForeName":"Happy","Pat_Surname":null,"Lookupvalue":"Booked","Pat_ID":null,"Pat_forename1":null,"Pat_surname":null},{"Appt_id":10006281,"pat_id":null,"startdatetime":"2022-05-17T09:00:00","Cln_Fname":null,"Cln_Sname":null,"Description":"CARE HOSPITALS , HYDERABAD (Vijay's Clinic - Testing)","Pat_ForeName":"Happy","Pat_Surname":null,"Lookupvalue":"Booked","Pat_ID":null,"Pat_forename1":null,"Pat_surname":null},{"Appt_id":10006282,"pat_id":null,"startdatetime":"2022-05-17T06:30:00","Cln_Fname":null,"Cln_Sname":null,"Description":"CARE HOSPITALS , HYDERABAD (Vijay's Clinic - Testing)","Pat_ForeName":"Happy","Pat_Surname":null,"Lookupvalue":"Booked","Pat_ID":null,"Pat_forename1":null,"Pat_surname":null},{"Appt_id":10006283,"pat_id":null,"startdatetime":"2022-05-31T09:30:00","Cln_Fname":null,"Cln_Sname":null,"Description":"CARE HOSPITALS , HYDERABAD (Vijay's Clinic - Testing)","Pat_ForeName":"Happy","Pat_Surname":null,"Lookupvalue":"Booked","Pat_ID":null,"Pat_forename1":null,"Pat_surname":null},{"Appt_id":10006284,"pat_id":null,"startdatetime":"2022-05-31T21:30:00","Cln_Fname":null,"Cln_Sname":null,"Description":"\"OZONE HOSPITALS\" , @HYDERABAD - INDIA","Pat_ForeName":"Happy","Pat_Surname":null,"Lookupvalue":"Booked","Pat_ID":null,"Pat_forename1":null,"Pat_surname":null}]


### Running the tests
### Break down into end to end tests
### And coding style tests

### Deployment
     Make sure the appsettings.json file must have AdhocDB connection string key value with expected DataBase server details as like below
    
     {
         "Logging": {
            "LogLevel": {
            "Default": "Information",
            "Microsoft.AspNetCore": "Warning"
            }
        },
        "AllowedHosts": "*",
        "AdhocConnectionString": "Data Source=10.3.0.116;Initial Catalog=AdhocReportsDB_v74UK_DEV;Current Language=British",
        "ConnectionString": "Data Source=10.3.0.115;Initial Catalog=ExceliDB_v74UK_DEV;Current Language=British"
    }   
