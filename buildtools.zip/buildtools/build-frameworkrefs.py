#!/usr/bin/python
'''
Created on Dec 28, 2016

@author: greg
'''

import os

from fnmatch import fnmatch

import json

import collections
import hashlib
import time
import shutil 


refasmPath = 'Reference Assemblies/Microsoft/Framework/NETFramework'


try:
    if os.getenv('programfiles(x86)') is None: 
        frmroot = os.path.join(os.environ['PROGRAMFILES'],refasmPath)
    else:     
        frmroot = os.path.join(os.environ['PROGRAMFILES(X86)'],refasmPath)
except:
    frmroot = None

if frmroot is None:
    print('ERROR: no framesworks found, exiting!')
    exit()

vers = ['v3.5', 'v4.5.1', 'v4.6', 'v4.7.2', 'v4.8']


#==============================================================================


for v in vers:
    print ('.NETFramework Reference Assemblies',v)
        
    dlls = {}

    frmdir = os.path.join(frmroot,v)
    print('Scanning framework directory', frmdir)

    for path, subdirs, files in os.walk(frmdir):
        print(path)
        for name in files:
    
            if fnmatch(name, '*.dll'):
                fname = os.path.join(path, name)
                lname = name.lower().split('.dll')[0]
                
                if lname not in dlls:
                    dlls[lname] = {}
    
                s = os.stat(fname)
                h = hashlib.md5(open(fname, 'rb').read()).hexdigest()
    
                x = { 
                'md5': h,
                'size': s.st_size
                }
    
                dlls[lname] = x
    with open('./netframework-%s.json'%(v.replace('.','')), 'w') as fp:
        files=list(dlls.keys())
        files.sort()
        fp.write(json.dumps(files, indent=2))
        fp.close()