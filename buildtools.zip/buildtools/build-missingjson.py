#!/usr/bin/python
import os
from fnmatch import fnmatch
import xmltodict
import json
import collections
from _socket import SOL_IP
from collections import OrderedDict

rootpath = os.path.abspath('..')
with open(os.path.join(rootpath,'build.cfg')) as fp:
    cfg = json.load(fp)
    
#-------------------------------------------------------------------------------
#  Main
#-------------------------------------------------------------------------------
with open('./projects.json', 'r') as fp:
    projects = json.load(fp, object_pairs_hook=OrderedDict)
    fp.close() 
    
#-------------------------------------------------------------------------------
#  build the reference list
#-------------------------------------------------------------------------------
print ('='*100)
print ('    Pre-Build: Create missing.json ')
print ('='*100)
print ('')

missing = []
ref = []
for p in projects:
    if projects[p]['type'].lower() == 'library' or projects[p]['type'].lower() == 'winexe':
        for r in projects[p]['reference']:
            ref.append(r)


for r in ref:
    if r in missing:
        continue
    
    if r in projects.keys():
        continue
    
    missing.append(r)

missing.sort()                      # Sort the output


with open('./missing.json', 'w') as fp:
    fp.write(json.dumps(missing, indent=2))
    fp.close()


