#!/usr/bin/python
#==============================================================================
#  Build the deployment structure out of the source tree.
#
#    by: Greg Bodine
#    date: Feb 2, 2017
#
#==============================================================================
__all__ = []
__author__ = "Greg Bodine"
__copyright__ = "Copyright 2017, Excelicare. All rights reserved"
__version__ = "1.0.0"
__date__ = '2017-03-31'
__updated__ = '2017-08-03'

import os
import sys
from fnmatch import fnmatch
import shutil

extensions = (
    '*.sln',
    '*.vbproj.user', 
    '*.csproj.user', 
    '*.suo', 
    '*.scc', 
    '*.vspscc', 
    '*.pdb',  
    '*.exe.manifest',
    '*.cache',
    'upgradelog*.*',
    'infragistics35*.dll'
    )

def cleanup(argv):
    loc = os.path.abspath(argv)
    
    print ('='*100)
    print ('    Cleaning up deploy directory trees at', loc)
    print ('='*100)
    print ('')
    
    for path, subdirs, files in os.walk(loc):
    
        for name in files:
            for e in extensions:
                if fnmatch(name.lower(), e):
                    f = os.path.join(path, name)
                    print ('INFO:  Removing file', f)
                    os.remove(f)
                    
    print ('    Completed ')
    
    
if __name__ == "__main__":
    if len(sys.argv) < 2:
        cleanup('../deploy')
    else:
        cleanup(sys.argv[1])
