#!/usr/bin/python
'''
Created on Dec 28, 2016

@author: greg
'''

import os
from fnmatch import fnmatch
import json
import collections
import hashlib
import time
import win32api

rootpath = os.path.abspath('..')
with open(os.path.join(rootpath,'build.cfg')) as fp:
    cfg = json.load(fp)

#==============================================================================
def getFileProperties(fname):
    """
    Read all properties of the given file return them as a dictionary.
    """
    propNames = (
        'Comments', 
        'InternalName', 
        'ProductName',
        'CompanyName', 
        'LegalCopyright', 
        'ProductVersion',
        'FileDescription', 
        'LegalTrademarks', 
        'PrivateBuild',
        'FileVersion', 
        'OriginalFilename', 
        'SpecialBuild'
        )

    props = {'StringFileInfo': None, 'FileVersion': None, 'ProductVersion': None, 'FileDate': None}

    try:
        # backslash as parm returns dictionary of numeric info corresponding to VS_FIXEDFILEINFO struc
        fixedInfo = win32api.GetFileVersionInfo(fname, '\\')
                
        props['FileVersion'] = "%d.%d.%d.%d" % (fixedInfo['FileVersionMS'] / 65536,
                fixedInfo['FileVersionMS'] % 65536, fixedInfo['FileVersionLS'] / 65536,
                fixedInfo['FileVersionLS'] % 65536)
        
        props['ProductVersion'] = "%d.%d.%d.%d" % (fixedInfo['ProductVersionMS'] / 65536,
                fixedInfo['ProductVersionMS'] % 65536, fixedInfo['ProductVersionLS'] / 65536,
                fixedInfo['ProductVersionLS'] % 65536)


        # \VarFileInfo\Translation returns list of available (language, codepage)
        # pairs that can be used to retreive string info. We are using only the first pair.
        lang, codepage = win32api.GetFileVersionInfo(fname, '\\VarFileInfo\\Translation')[0]

        # any other must be of the form \StringfileInfo\%04X%04X\parm_name, middle
        # two are language/codepage pair returned from above

        strInfo = {}
        for propName in propNames:
            strInfoPath = u'\\StringFileInfo\\%04X%04X\\%s' % (lang, codepage, propName)
            ## print str_info
            strInfo[propName] = win32api.GetFileVersionInfo(fname, strInfoPath)

        props['StringFileInfo'] = strInfo
    except:
        pass
 
    return props

#==============================================================================
#
#==============================================================================
axsys = {}

deploypath = os.path.join(rootpath,'DeployStucture')

for path, subdirs, files in os.walk(deploypath):
    
    # ignore the .git directory.
    if '.git' in path:
        continue
    
    for name in files:
        fname = os.path.join(path, name)
        lname = name.lower()
        if lname not in axsys:
            axsys[lname] = []
            
        s = os.stat(fname)
        h = hashlib.md5(open(fname, 'rb').read()).hexdigest()
        x = {}
        
        prop = getFileProperties(fname)
        
        x['fpath'] = fname.replace(deploypath,'.')
        
        x['md5'] = h
        x['size'] = s.st_size
        x['ctime'] = s.st_ctime
        x['mtime'] = s.st_mtime
        
        if prop['FileVersion'] is not None:
            x['fileversion'] = prop['FileVersion']
        
        if prop['ProductVersion'] is not None:    
            x['productversion'] = prop['ProductVersion']
            
        if prop['FileDate'] is not None:    
            x['filedate'] = prop['FileDate']
        
        if prop['StringFileInfo'] is not None:
            if prop['StringFileInfo']['ProductName'] is not None:
                x['productname'] = prop['StringFileInfo']['ProductName']
            if prop['StringFileInfo']['CompanyName'] is not None:    
                x['companyname'] = prop['StringFileInfo']['CompanyName']
            if prop['StringFileInfo']['LegalCopyright'] is not None:
                x['legalcopyright'] = prop['StringFileInfo']['LegalCopyright']

        axsys[lname].append(x)

        

with open(os.path.join(deploypath, 'manifest.json'), 'w') as fp:
    fp.write(json.dumps(axsys, indent=2))
    fp.close()

exit()

