#!/usr/bin/python
#==============================================================================
#  Build the deployment structure out of the source tree.
#
#    by: Greg Bodine
#    date: Feb 2, 2017
#
# Note:
#   2019-09-26: Updated for v7.1.0.1
#
#==============================================================================
__all__ = []
__author__ = "Greg Bodine"
__copyright__ = "Copyright 2021, Excelicare. All rights reserved"
__version__ = "7.1.0.1"
__date__ = '2021-06-03'
__updated__ = '2021-06-03'

import os
import sys
import json
import xmltodict
import datetime

rootpath = os.path.abspath('..')
with open(os.path.join(rootpath, 'build.cfg')) as fp:
    cfg = json.load(fp)


#------------------------------------------------------------------------------
#  Build the Version XML in WEB Root
#------------------------------------------------------------------------------
def updateVersionXML(deployPath):
    major = int(cfg['version'].split('.')[0])
    minor = int(cfg['version'].split('.')[1])
    maintinance = 0
    patch = 0
    versionstr = '{:d}.{:04d}.{:04d}.{:04d}'.format(major, minor*1000, maintinance, patch)
    
    verionfile = os.path.realpath(os.path.join(deployPath, 'Excelicare', 'VersionInfo.xml'))
    with open(verionfile,'rb') as _file:    
        data = xmltodict.parse(_file)
        _file.close()
    
    data['ExcelicareWeb']['Release']['Date'] = datetime.datetime.today().strftime('%Y/%m/%d')
    data['ExcelicareWeb']['Release']['MainVersion'] = versionstr
    data['ExcelicareWeb']['Release']['Comments'] = ''
    data['ExcelicareWeb']['Release']['URLRewrite'] = 0
    modules = data['ExcelicareWeb']['Release']['Modules']['Module']
    for module in modules:
        module['V'] = versionstr
        
    xml = xmltodict.unparse(data, pretty=True, newl = '\n', indent='   ')
    with open(verionfile, 'w') as _file:
        _file.write(xml)
        _file.close()
    
    return

#-------------------------------------------------------------------------------
#  Main
#-------------------------------------------------------------------------------
if __name__ == "__main__":
    if len(sys.argv) < 2:
        updateVersionXML('../deploy')
    else:
        updateVersionXML(sys.argv[1])
