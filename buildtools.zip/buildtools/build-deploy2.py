#!/usr/bin/python

'''
build-deploy2 -- shortdesc

manifest is a description

It defines classes_and_methods

@author:     greg bodine
@copyright:  2023 Excelciare. All rights reserved.
@license:    Copyright 2023 Excelicare. All rights reserved.
@contact:    greg.bodine@excelicare.com
@deffield    updated: Updated
'''

import argparse
import glob
import json
import os
import shutil
import sys
import yaml
from argparse import ArgumentParser, RawDescriptionHelpFormatter
from fnmatch import fnmatch


__all__ = []
__version__ = 0.1
__date__ = '2021-05-04'
__updated__ = '2023-11-01'

program = {
    'name': os.path.basename(sys.argv[0]),
    'version': 'v%s'%__version__,
    'build_date': __updated__,
    'license': 'Copyright 2023 Excelicare. All rights reserved.'
}

projects = dict()
frameworkrefs = dict()
knownlibs = dict()

rootpath = os.path.abspath('..')
with open(os.path.join(rootpath,'build.cfg')) as fp:
# with open(os.path.join(rootpath,'build.cfg')) as fp:
    cfg = json.load(fp)

frmver = (cfg['.NETFramework']['version']).lower()

with open(os.path.abspath('./netframework-%s.json'%(frmver.replace('.',''))), 'r') as stream:
    frameworkrefs = json.load(stream)
    stream.close()

with open(os.path.abspath('./knownlibs.json'), 'r') as stream:
    knownlibs = json.load(stream)
    stream.close()

with open(os.path.abspath('./projects.json'), 'r') as stream:
    projects = json.load(stream)
    stream.close()

class DeployTasks():
    
    def __init__(self, projects, frameworkrefs, knownlibs):
        self.projects = projects
        self.frameworkrefs = frameworkrefs
        self.knownlibs = knownlibs

        p = []    
        for project in projects: 
            p.append(projects[project]['path'])
    
        self.root = os.path.realpath(os.path.commonprefix(p))
        self.targetdir = os.path.join(self.root, 'Deploy')
        
    def __copyfile(self, f, t):
        if os.path.isdir(f):
            return
        
        print('copyfile: ' + f.replace(self.root,'.') + ' to ' + t.replace(self.root,'.'))

        if not os.path.exists(f):
            print('ERROR: source file missing', f)
            return

        if not os.path.isdir(os.path.dirname(t)):
            os.makedirs(os.path.dirname(t))            
        
        try:
            shutil.copy2(f, t)
        except shutil.SameFileError:
            pass
        
    def __removefile(self, t):
        print('removefile: ' + t )

        if not os.path.exists(t):
            print('ERROR: target file missing', f)
            return

        os.remove(t)

    def __findrefs(self, project, references):
        
        if project not in references:
            if project not in frameworkrefs:
                references.append(project)
                
                if project not in knownlibs:           
                    for ar in projects[project]['reference']:
                        self.__findrefs(ar, references)


    def SetEnvironment(self, cfgroot, env):
        for key in env:

            value = env[key]
            if '${' in value and '}' in value:
                print ('get env for', value)
                value = os.path.expandvars(value)

            os.environ[key.upper()] = value
    
    def CopyFiles(self, cfgroot, cfg):

        if 'display' in cfg:
            print ('# %s'%os.path.expandvars(cfg['display']))

        if 'inputs' in cfg:
            inputs = cfg['inputs']

            flatten = False

            if 'sourceFolder' in inputs:
                source = os.path.join(cfgroot, inputs['sourceFolder']).replace('\\','/')
                source = os.path.expandvars(source)
                source = os.path.normpath(source)
            else:
                source = os.path.normpath('.')

            if 'targetFolder' in inputs:
                target = os.path.join(self.targetdir, inputs['targetFolder']).replace('\\','/')                
                target = os.path.expandvars(target)
                target = os.path.normpath(target)


            if 'flattenFolders' in inputs:
                flatten = inputs['flattenFolders']

            excludefns = []
            if 'excludes' in inputs:
                excludes = inputs['excludes'].strip('\n').split('\n')
                for exclude in excludes:
                    fn = exclude.strip('\'').replace('\\','/').strip('/')
                    fn = os.path.expandvars(fn)
                    fn = os.path.normpath(fn)
                    excludefns.append(os.path.join(source,fn))

            print('  sourceFolder: %s'%source)
            print('  targetFolder: %s'%target)
            print('  flattenFolders: %s'%flatten)
            print('  excludes: %s'%excludefns)

            if 'contents' in inputs:
                contents = inputs['contents'].strip('\n').split('\n')
                for content in contents:
                    fn = content.strip('\'').replace('\\','/').strip('/')
                    fn = os.path.expandvars(fn)
                    fn = os.path.normpath(fn)

                    for sourcefn in glob.glob( os.path.join(source,fn), recursive=True ):
                        
                        excludeit = False
                        for excludefn in excludefns:
                            if fnmatch(sourcefn, excludefn):
                                print('  excluding: %s'%sourcefn)
                                excludeit = True
                        
                        if not excludeit:
                            if flatten:
                                targetfn = os.path.join(target,os.path.basename(sourcefn))
                            else:
                                tfn = sourcefn.replace(source,'').strip(os.path.sep)
                                targetfn = os.path.join(target, tfn)
                                
                            if '_x86' in targetfn:
                                targetfn = targetfn.replace('_x86','')

                            self.__copyfile(sourcefn, targetfn)

        else:
            print('*CopyFiles*: nothing to do,  inputs empty')
    
    def CopyAssemblies(self, cfgroot, cfg):

        if 'display' in cfg:
            print ('# %s'%os.path.expandvars(cfg['display']))

        source = os.path.join(self.root, 'Build', 'Bin', 'Release')

        if 'inputs' in cfg:
            inputs = cfg['inputs']

            if 'targetFolder' in inputs:
                target = os.path.join(self.targetdir, inputs['targetFolder']).replace('\\','/')                
                target = os.path.expandvars(target)
                target = os.path.normpath(target)

        print('  sourceFolder: %s'%source)
        print('  targetFolder: %s'%target)
            
        
        references = []
        if 'project' in inputs:
            project = os.path.expandvars(inputs['project']).lower()
            self.__findrefs(project, references)               
            references.sort()

        for reference in references:
            assembly = reference
            extype = '.dll'

            if reference in self.projects:
                assembly = self.projects[reference]['assembly']

                if self.projects[reference]['type'] in ['exe', 'winexe']:
                    extype = '.exe'


            s = os.path.realpath(os.path.join(source,assembly+extype))
            t = os.path.join(target,os.path.basename(s))
            self.__copyfile(s, t)

            # copy the .*.config file also.
            s = os.path.realpath(os.path.join(source,assembly+extype+'.config'))
            t = os.path.join(target,os.path.basename(s))
            if os.path.exists(s):
                self.__copyfile(s, t)

            # copy the .resources.dll file also.
            for lang in ['en-Us', 'en-GB', 'en-CA', 'fr-CA']:
                s = os.path.realpath(os.path.join(source,lang,assembly+'.resources'+extype))
                t = os.path.join(target,lang,os.path.basename(s))
                if os.path.exists(s):
                    self.__copyfile(s, t)

            # This is a very special case.  if the reference is ePDFCreator then also copy the epengine dll
            if reference == 'epdfcreator':
                s = os.path.realpath(os.path.join(source,'epengine.dll'))
                t = os.path.join(target,os.path.basename(s))
                self.__copyfile(s, t)
                
            # This is an another special case.  if the reference is Restsharp then also copy the below dll's
            if reference == 'restsharp':
                s = os.path.realpath(os.path.join(source,'system.text.json.dll'))
                t = os.path.join(target,os.path.basename(s))
                self.__copyfile(s, t)
                s = os.path.realpath(os.path.join(source,'system.threading.tasks.extensions.dll'))
                t = os.path.join(target,os.path.basename(s))
                self.__copyfile(s, t)

        return 

    def RemoveFiles(self, cfgroot, cfg):

        if 'display' in cfg:
            print ('# %s'%os.path.expandvars(cfg['display']))

        if 'inputs' in cfg:
            inputs = cfg['inputs']

            if 'targetFolder' in inputs:
                target = os.path.join(self.targetdir, inputs['targetFolder']).replace('\\','/')                
                target = os.path.expandvars(target)
                target = os.path.normpath(target)

            print('  targetFolder: %s'%target)

            if 'contents' in inputs:
                contents = inputs['contents'].strip('\n').split('\n')
                for content in contents:
                    fn = content.strip('\'').replace('\\','/').strip('/')
                    fn = os.path.expandvars(fn)
                    fn = os.path.normpath(fn)

                    for targetfn in glob.glob( os.path.join(target,fn), recursive=True ):
                        self.__removefile(targetfn)

        else:
            print('*RemoveFiles*: nothing to do,  inputs empty')

    def WebConfig(self, cfgroot, cfg):

        if 'display' in cfg:
            print ('# %s'%os.path.expandvars(cfg['display']))

        return

    def CreateFile(self, cfgroot, cfg):

        if 'display' in cfg:
            print ('# %s'%os.path.expandvars(cfg['display']))

        if 'inputs' in cfg:
            inputs = cfg['inputs']

            if 'targetFolder' in inputs:
                target = os.path.join(self.targetdir, inputs['targetFolder']).replace('\\','/')                
                target = os.path.expandvars(target)
                target = os.path.normpath(target)

            if 'fileName' in inputs:
                fileName = os.path.join(self.targetdir, inputs['fileName']).replace('\\','/')                
                fileName = os.path.expandvars(fileName)
                fileName = os.path.normpath(fileName)

            print('  targetFolder: %s'%target)
            print('  fileName: %s'%fileName)

            if 'contents' in inputs:
                contents = inputs['contents'].strip('\n')
                contents = os.path.expandvars(contents)

            with open(os.path.join(target,fileName), 'w') as stream:
                stream.write(contents)
                stream.close()

        return    
    
# -----------------------------------------------------------------------------
#   
# -----------------------------------------------------------------------------
dt = DeployTasks(projects, frameworkrefs, knownlibs)
skip = None

# -----------------------------------------------------------------------------
#    Run through all of the project looking for deploy2.yml files and executing
#    there instructions. 
# -----------------------------------------------------------------------------
if __name__ == "__main__":
        
    try:
        # Setup argument parser
        parser = ArgumentParser(description=program['license'], formatter_class=RawDescriptionHelpFormatter)
        parser.add_argument(
            "-v", 
            "--verbose", 
            dest="verbose", 
            action="count", 
            help="set verbosity level [default: %(default)s]"
            )

        parser.add_argument(
            '-V', 
            '--version', 
            action='version', 
            version='%%(prog)s %s (%s)' % (program['version'], program['build_date'])
            )

        parser.add_argument(
            '--rootdir', 
            type=str, 
            required=False
            )

        parser.add_argument(
            '--targetdir', 
            type=str, 
            required=False
            )


        # Process arguments
        args = parser.parse_args()

        if args.targetdir is not None:
            targetdir = os.path.realpath(args.targetdir)
            dt.targetdir = targetdir
            print('target directory path:', targetdir)

        if args.rootdir is not None:
            rootpath = os.path.realpath(args.rootdir)

        for path, subdirs, files in os.walk(rootpath):
            #print path
            
            if skip is not None and skip in path:
                print ('skipping', path)
                continue
            
            if os.path.exists(os.path.join(path,'.nobuild')):
                print ('skipping', path)
                skip = path
                continue

            for name in files:

                if fnmatch(name, 'deploy2.yml'):
                    cfgpath = os.path.join(path, name)
                    print ("Processing:", cfgpath  )

                    with open(cfgpath, 'r') as stream:
                        try: 
                            deploycfg = yaml.load(stream, Loader=yaml.FullLoader)
                        except yaml.YAMLError as exc:
                            print('ERROR: loading deploy2 configuration file', cgfpath)
                            raise CLIError(exc)
                        stream.close()

                    if 'enabled' in deploycfg:
                        if not deploycfg['enabled']:
                            continue

                    if 'environment' in deploycfg:
                        dt.SetEnvironment(path,deploycfg['environment'])

                    if 'tasks' in deploycfg:
                        for task in deploycfg['tasks']:
                            getattr(dt, task['task'])(path,task)

    except KeyboardInterrupt:
        ### handle keyboard interrupt ###
        exit(0)
    
    except Exception as e:
        indent = len(program['name']) * " "
        sys.stderr.write(program['name'] + ": " + repr(e) + "\n")
        sys.stderr.write(indent + "  for help use --help")
        exit(2)

    exit(0)
