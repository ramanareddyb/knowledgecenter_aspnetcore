import smtplib, ssl, os

smtp_server = 'smtp.office365.com'
port = 587  # For starttls
sender_email = 'no-reply@excelicare.com'
password = 'practive$123'
receiver_email = 'rds.team@excelicare.com;rajshaker.koppada@excelicare.com;ramana.bhumpalli@excelicare.com;abdul.quiser@excelicare.com;surendra.vankayala@excelicare.com'

jobname = os.getenv('AGENT_JOBNAME')
jobstatus = os.getenv('AGENT_JOBSTATUS')
definitionname = os.getenv('BUILD_DEFINITIONNAME')
buildnumber = os.getenv('BUILD_BUILDNUMBER')

message = f"""\
Subject: [Build {jobstatus}] {definitionname} - {buildnumber}

{jobname}
{definitionname} - {buildnumber} - {jobstatus}

This is an automated mail from Azure DevOps, pl. check Azure Deveops for latest builds details.

Thanks
Devops Teams
"""

# Create a secure SSL context
context = ssl.create_default_context()

# Try to log in to server and send email
try:
    server = smtplib.SMTP(smtp_server,port)
    server.ehlo() # Can be omitted
    server.starttls(context=context) # Secure the connection
    server.ehlo() # Can be omitted
    server.login(sender_email, password)
    server.sendmail(sender_email, receiver_email, message)

except Exception as e:
    # Print any error messages to stdout
    print(e)
finally:
    server.quit()
