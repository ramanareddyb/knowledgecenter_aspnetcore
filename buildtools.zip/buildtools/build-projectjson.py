#!/usr/bin/python
import os
from fnmatch import fnmatch
import xmltodict
import json
import re
from collections import OrderedDict

rootpath = os.path.abspath('..')
with open(os.path.join(rootpath,'build.cfg')) as fp:
    cfg = json.load(fp)
    
projects = OrderedDict()
with open('./projects.json', 'r') as fp:
    projects = json.load(fp, object_pairs_hook=OrderedDict)
    fp.close()

references = []

def propertyGroupCond(cond, property, data):
    if 'PropertyGroup' in data['Project']:
        group = data['Project']['PropertyGroup']
        
        if type(group) is list:
            for items in group:
                if '@Condition' in items and items['@Condition'].strip() == "'$(Configuration)|$(Platform)' == '%s|AnyCPU'"%(cond):
                    if items is not None and property in items:
                        return items[property]
        else:
            if property in group:
                return group[property]
            
def propertyGroup(property, data):
    if 'PropertyGroup' in data['Project']:
        group = data['Project']['PropertyGroup']
        
        if type(group) is list:
            for items in group:
                if items is not None and property in items:
                    return items[property]
        else:
            if property in group:
                return group[property]

def itemGroup(property, data):
    if 'ItemGroup' in data['Project']:
        group = data['Project']['ItemGroup']
        
        if type(group) is list:
            for items in group:
                if items is not None and property in items:
                    return items[property] 
        else:
            if property in group:
                return group[property]
        
        return None

def Compile(data):
    source = []
    if 'ItemGroup' in data['Project']:
        group = data['Project']['ItemGroup']
        
        if type(group) is list:
            for items in group:
                    if items is not None and 'Compile' in items:
                        if type(items['Compile']) is list:
                            for i in items['Compile']:
                                #print json.dumps(items, indent=2)
                                source.append(i['@Include'])
                                #print i['@Include']
                        else:
                            source.append(items['Compile']['@Include'])
                            #print items['Compile']['@Include']
        else:
            if property in group:
                print ('group level')
                print (group['Compile'])
                
        return source     

def Content(data):
    source = []
    if 'ItemGroup' in data['Project']:
        group = data['Project']['ItemGroup']
        
        if type(group) is list:
            for items in group:
                    if items is not None and 'Content' in items:
                        if type(items['Content']) is list:
                            for i in items['Content']:
                                #print json.dumps(items, indent=2)
                                source.append(i['@Include'])
                                #print i['@Include']
                        else:
                            source.append(items['Content']['@Include'])
                            #print items['Compile']['@Include']
        else:
            if property in group:
                print ('group level')
                print (group['Content'])
                
        return source

    
def COMRef(data):
    source = []
    if 'ItemGroup' in data['Project']:
        group = itemGroup('COMReference', data)
        
        if group is not None:
            if type(group) is list:
                for item in group:
                    source.append(item['@Include'])    
            else:
                source.append(group['@Include'])
    
    return source
        
                
def Reference(project, data):
    
    itemgroup = data['Project']['ItemGroup']
    
    for item in itemgroup:
        if item is not None:
            if 'Reference' in item:
                if type(item['Reference']) is list:
                    for include in item['Reference']:
                        if '@Include' in include:
                            i = include['@Include'].split(',')[0].lower()
                            if project != i:
                                projects[project]['reference'].append(i)
                            else:
                                print ("WARNING!!! "+project+" has a recursive reference.")
                else:
                    i = item['Reference']['@Include'].split(',')[0].lower()
                    if project != i:
                        projects[project]['reference'].append(i)
                    else:
                        print ("WARNING!!! "+project+" has a recursive reference.")

            if 'ProjectReference' in item:
                print ('WARNING!!! ProjectReference found in '+project)
                if type(item['ProjectReference']) is list:
                    for pr in item['ProjectReference']:
                        i = pr['Name'].lower()
                        if project != i:
                            projects[project]['reference'].append(i)
                        else:
                            print ("WARNING!!! "+project+" has a recursive reference.")

                else:
                    i = item['ProjectReference']['Name'].lower()
                    if project != i:
                        projects[project]['reference'].append(i)
                    else:
                        print ("WARNING!!! "+project+" has a recursive reference."  )
        
print ('='*100)
print ('    Pre-Build: building out project.json information')
print ('='*100)
print ('')

for project in projects:
    try:
        projectfile = projects[project]['path']
        (path,name) = os.path.split(projectfile)
        #print path, name
                
        with open(projectfile,'rb') as data_file:    
            data = xmltodict.parse(data_file)
            data_file.close()
    
        if 'PropertyGroup' in data['Project']:
            aname = propertyGroup('AssemblyName', data) 
            project = aname.lower()
            
            otype = propertyGroup('OutputType', data).lower()
            prjguid =  propertyGroup('ProjectGuid', data).upper().strip('{}')
            
            framework = propertyGroup('TargetFrameworkVersion', data)
            namespace = propertyGroup('RootNamespace', data)
            op_release = propertyGroupCond('Release', 'OutputPath', data)
            op_debug = propertyGroupCond('Debug', 'OutputPath', data)
        
        if 'ItemGroup' in data['Project']:
            source = Compile(data)
            content = Content(data)
            comref = COMRef(data)
            
            svctype = False
            
            if len(content) > 0:
                for c in content:
                    if '.svc' in c:
                        svctype = True
                        
            if len(comref) > 0:
                print ("WARNING!!  Found COM Reference in", projectfile)
    
        
        projects[project].update( {
            'type': otype,
            'projectguid': prjguid,
            'svc': svctype, 
            'framework': framework, 
            'namespace': namespace,
            'reference':[],
            'source': source,
            'content': content,
            'outputpath.release': os.path.abspath(path+'/'+op_release.replace("\\","/")),
            'outputpath.debug': os.path.abspath(path+'/'+op_debug.replace("\\","/")),
            'comrefs': comref
            } )
            
        Reference(project, data)
    
        if project not in references:
            references.append(project)
        
        for reference in projects[project]['reference']:
            if reference not in references:
                references.insert(references.index(project),reference)
    except Exception as err:
        print ('exception why processing', projects[project]['path'])
        print (err)
        exit()    

with open('./projects.json', 'w') as fp:
    fp.write(json.dumps(projects, indent=2))
    fp.close()
exit()
