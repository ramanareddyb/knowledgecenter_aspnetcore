#!/usr/bin/python
import os
from fnmatch import fnmatch
import xmltodict
import json
import collections
import shutil

root = os.path.abspath('..')

with open(os.path.join(root,'build.cfg')) as fp:
    cfg = json.load(fp)

buildorder = cfg['BuildOrder']

directories = (
    'obj',
    'lib',
    'bin'
    )
extensions = (
    '*.sln',
    '*.vbproj.user', 
    '*.csproj.user', 
    '*.suo', 
    '*.scc', 
    '*.vspscc',
    '*.pdb',
    '*.exe.manifest',
    '*.cache',
    'updatelog*.*'
    )

print ('='*100)
print ('    Pre-Build: Cleaning up solution directory trees ')
print ('='*100)
print ('')

for sol in buildorder:
    for path, subdirs, files in os.walk(os.path.join(root,sol)):
        print ('INFO:  cleaning project:', path)
    
        for name in subdirs:
            for d in directories:
                if fnmatch(name.lower(), d):    
                    shutil.rmtree(os.path.join(path, name))
    
        for name in files:
            for e in extensions:
                if fnmatch(name.lower(), e):
                    os.remove(os.path.join(path, name))
                    
print ('    Pre-Build: Completed ')
