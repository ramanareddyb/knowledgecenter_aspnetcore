#!/usr/bin/python
import os
from fnmatch import fnmatch
import xmltodict
import json
import re
from collections import OrderedDict
import uuid

guid = str(uuid.uuid4()).upper()

projects = OrderedDict()
with open('./projects.json', 'r') as fp:
    projects = json.load(fp, object_pairs_hook=OrderedDict)
    fp.close()


#-------------------------------------------------------------------------------
#  Edit Compile
#-------------------------------------------------------------------------------
def editAssemblyInfo(data, outpath, outname):
    if 'ItemGroup' in data['Project']:
        group = data['Project']['ItemGroup']
        
        if type(group) is list:
            for items in group:
                    if items is not None and 'Compile' in items:
                        if type(items['Compile']) is list:
                            for item in items['Compile']:
                                c = item['@Include'].lower()
                                if 'assemblyinfo' in c:
                                    item['@Include'] = outpath+'\\'+outname   
                        else:
                            c  = items['Compile']['@Include'].lower()
                            if 'assemblyinfo' in c:
                                    items['Compile']['@Include'] = outpath+'\\'+outname  
        else:
            if property in group:
                print ('group level')
                print (group['Compile'])
                                    
#-------------------------------------------------------------------------------
#  Main
#-------------------------------------------------------------------------------
print ('='*100)
print ('    Pre-Build: building assembly info files')
print ('='*100)
print ('')

for project in projects:
    projectfile = projects[project]['path']
    assemblyname = projects[project]['assembly']
    projtype = projects[project]['projtype']
        
    (path,name) = os.path.split(projectfile)
    print (path, name)
    
    if projtype == 'VB':
        outpath = 'My Project'
        outname = 'AssemblyInfo.vb'
            
        assemblyinfo  = \
'''Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("%s|LOCAL-BUILD")>
<Assembly: AssemblyDescription("Excelicare v7")>
<Assembly: AssemblyCompany("Practive Health Inc. dba Excelicare")>
<Assembly: AssemblyProduct("Excelicare")>
<Assembly: AssemblyCopyright("Copyright 2023 Practive Health Inc. dba Excelicare. All rights reserved.")>
<Assembly: AssemblyTrademark("Excelicare")>

<Assembly: ComVisible(False)>
<Assembly: CLSCompliant(True)>

<Assembly: AssemblyVersion("0.0.0.0")>
<Assembly: AssemblyFileVersion("0.0.0.0")>
'''%(assemblyname)

    else:
        outpath = 'Properties' 
        outname = 'AssemblyInfo.cs'
        assemblyinfo  = \
'''using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("%s|LOCAL-BUILD")]
[assembly: AssemblyDescription("Excelicare v7")]
[assembly: AssemblyCompany("Practive Health Inc. dba Excelicare.")]
[assembly: AssemblyProduct("Excelicare")]
[assembly: AssemblyCopyright("Copyright 2023 Practive Health Inc. dba Excelicare. All rights reserved.")]
[assembly: AssemblyTrademark("Excelicare")]

[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]

[assembly: AssemblyVersion("0.0.0.0")]
[assembly: AssemblyFileVersion("0.0.0.0")]
'''%(assemblyname)

    # see if the outpath exists and if not create it.
    myproj = os.path.join(path, outpath)
    if not os.path.isdir(myproj):
        os.makedirs(myproj)

    with open(os.path.join(path,outpath, outname), 'w') as fp:
        fp.write(assemblyinfo)
        fp.close()      
            
    with open(projectfile,'rb') as fp:    
        data = xmltodict.parse(fp, xml_attribs=True)
        fp.close()
        
    editAssemblyInfo(data, outpath, outname)
    
    xml = xmltodict.unparse(data, short_empty_elements=True, pretty=True, newl = '\n', indent='   ')

    with open(projectfile, 'w') as data_file:
        data_file.write(xml)
        data_file.close()
        
exit()