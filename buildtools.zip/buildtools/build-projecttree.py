#!/usr/bin/python
import os
from fnmatch import fnmatch
import xmltodict
import json
import re
from collections import OrderedDict

rootpath = os.path.abspath('..')
with open(os.path.join(rootpath,'build.cfg')) as fp:
    cfg = json.load(fp)

buildorder = cfg['BuildOrder']
projects = OrderedDict()
references = []

            
def propertyGroup(property, data):
    if 'PropertyGroup' in data['Project']:
        group = data['Project']['PropertyGroup']
        
        if type(group) is list:
            for items in group:
                if items is not None and property in items:
                    return items[property]
        else:
            if property in group:
                return group[property]


print ('='*100)
print ('    Pre-Build: Create init tree in project.json ')
print ('        build order:', buildorder)
print ('='*100)
print ('')

for sol in buildorder:

    skip = None
    for path, subdirs, files in os.walk(os.path.join(rootpath,sol)):
        #print path
        
        if skip is not None and skip in path:
            print ('skipping', path)
            continue
        
        if os.path.exists(os.path.join(path,'.nobuild')):
            print ('skipping', path)
            skip = path
            continue

        for name in files:

            if fnmatch(name, '*.vbproj') or fnmatch(name, '*.csproj'):
                 
                if fnmatch(name, '*.vbproj'):
                    projecttype = 'VB'
                if fnmatch(name, '*.csproj'):
                    projecttype = 'CS'
                
                file = os.path.join(path, name)
                print( 'processing file: %s'%file)
                
                with open(file,'rb') as data_file:    
                    data = xmltodict.parse(data_file)
                    data_file.close()

                if 'PropertyGroup' in data['Project']:
                    aname = propertyGroup('AssemblyName', data) 
                    project = aname.lower()
                    
                if project in projects:
                    print ("ERROR!!!  project %s already in projects files"%project)
                    print (file)
                    print (projects[project]['path'])

                
                projects[project] = {
                    'solution': sol.lower(),
                    'projtype': projecttype,
                    'assembly': aname,
                    'path': file
                    }

with open('./projects.json', 'w') as fp:
    fp.write(json.dumps(projects, indent=2))
    fp.close()
exit()
