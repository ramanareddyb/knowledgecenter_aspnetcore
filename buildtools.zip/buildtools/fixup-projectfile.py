#!/usr/bin/python
import os
from fnmatch import fnmatch
import xmltodict
import json
import collections
from collections import OrderedDict


rootpath = os.path.abspath('..')
with open(os.path.join(rootpath,'build.cfg')) as fp:
# with open(os.path.join(rootpath,'build.cfg')) as fp:
    cfg = json.load(fp)

frmver = (cfg['.NETFramework']['version']).lower()

with open('./projects.json', 'r') as fp:
    projects = json.load(fp)
    fp.close()
    
with open('./netframework-%s.json'%(frmver.replace('.','')), 'r') as fp:
    frameworkrefs = json.load(fp)
    fp.close()


def deleteProperty(data, property):
    if 'PropertyGroup' in data['Project']:
        group = data['Project']['PropertyGroup']
        
        if type(group) is list:
            for items in group:
                if items is not None and property in items:
                    del(items[property])
        else:
            if property in group:
                del(group[property])    

def editProperty(data, property, value):
    if 'PropertyGroup' in data['Project']:
        group = data['Project']['PropertyGroup']
        
        if type(group) is list:
            for items in group:
                if items is not None and property in items:
                    items[property] = value
        else:
            if property in group:
                group[property] = value

                                
#-------------------------------------------------------------------------------
#  Edit Imports
#-------------------------------------------------------------------------------
def editImport(data, toolsdir, projtype):
    #i = data['Project']['Import']

    #data['Project']['Import'] = i
    
    if 'Import' in data['Project']:
        del(data['Project']['Import'])
    
    if projtype == 'CS':
        doc = xmltodict.parse("""
          <Project>
            <Import Project="$(MSBuildBinPath)\Microsoft.CSharp.targets"/>
            <Import Project="$(MSBuildExtensionsPath)\MSBuildCommunityTasks\MSBuild.Community.Tasks.Targets"/>
            <Import Project="%s\AxBuildCommon.Targets"/>
          </Project>
        """%(toolsdir))
    elif projtype == 'VB':
        doc = xmltodict.parse("""
          <Project>
            <Import Project="$(MSBuildBinPath)\Microsoft.VisualBasic.targets"/>
            <Import Project="$(MSBuildExtensionsPath)\MSBuildCommunityTasks\MSBuild.Community.Tasks.Targets"/>
            <Import Project="%s\AxBuildCommon.Targets"/>
          </Project>
        """%(toolsdir))
    else:
        doc = xmltodict.parse("""
          <Project>
            <Import Project="$(MSBuildExtensionsPath)\MSBuildCommunityTasks\MSBuild.Community.Tasks.Targets"/>
          </Project>
        """)
    
    data['Project']['Import'] = doc['Project']['Import']
                        

#-------------------------------------------------------------------------------
#  Edit Reference
#-------------------------------------------------------------------------------
def editReference(ref, refpath):
    files=list(ref.items())
    lib = files[0][1].split(',')[0]
    
    if lib.lower() in frameworkrefs:
        if 'HintPath' in ref:
            del ref['HintPath']
    else:
        ref['HintPath'] = os.path.join(refpath,lib+'.dll')
        ref['Name'] = str(lib)
        ref['SpecificVersion'] = 'False'
        ref['Private'] = 'False'
    
            
def editHintpath(data, bin):
    if 'ItemGroup' not in data['Project']:
        return
    
    itemgroup = data['Project']['ItemGroup']

    if 'Reference' in itemgroup:
        ref = itemgroup['Reference']
        editReference(ref, bin)
       
    else :
        for prop in itemgroup:
            if prop is not None:
                if 'Reference' in prop:
                    if type(prop['Reference']) is list:
                        for ref in prop['Reference']:
                            editReference(ref, bin)
                    else:
                        ref = prop['Reference']
                        editReference(ref, bin)

#-------------------------------------------------------------------------------
#  Edit Post Build Event
#-------------------------------------------------------------------------------
def editPostBuildEvent(data, bin):
    if 'PropertyGroup' not in data['Project']:
        return
    
    propgroup = data['Project']['PropertyGroup']

    if 'PostBuildEvent' in propgroup:
        propgroup['PostBuildEvent'] = None
        propgroup['PreBuildEvent'] = None
        
    else :
        for prop in propgroup: 
            if prop is not None:
                if type(prop.items()) is list:
                    if 'PostBuildEvent' in prop:
                        prop['PreBuildEvent'] = None
                        prop['PostBuildEvent'] = None

#-------------------------------------------------------------------------------
#  Edit Target
#-------------------------------------------------------------------------------
def editTarget(data, projtype):
    if 'Target' in data['Project']:
        del(data['Project']['Target'])
        

def deleteReference(data, reference):
    if 'ItemGroup' in data['Project']:
        group = data['Project']['ItemGroup']
        
        if type(group) is list:
            for items in group:
                if items is not None and 'Reference' in items:
                    for i, r in enumerate(items['Reference']):
                        if r['@Include'].lower() == reference:
                            print ('removing', i, reference)
                            del(items['Reference'][i])
        else:
            if 'Reference' in group:
                for i, r in enumerate(group['Reference']):
                    if r['@Include'].lower() == reference:
                        print ('removing', i, reference)
                        del(group['Reference'][i])
                    
#-------------------------------------------------------------------------------
#  Main
#-------------------------------------------------------------------------------
print ('='*100)
print ('    Pre-Build: Fixup project level project files ')
print ('='*100)
print ('')
    
for project in projects:
    projectfile = projects[project]['path']
    projtype = projects[project]['projtype']
                        
    dotdot = ('..'+os.sep)*(len(os.path.dirname(projectfile).split(os.sep)) - len(rootpath.split(os.sep)))
    destdir = os.path.join(dotdot, 'Build', 'Bin','$(Configuration)')
    toolsdir = os.path.join(dotdot, 'buildtools')

    with open(projectfile,'rb') as fp:    
        data = xmltodict.parse(fp, xml_attribs=True)
        fp.close()
    
    print (projectfile)
    editImport(data, toolsdir, projtype)
    editHintpath(data, destdir)
    
    editProperty(data, 'OutputPath', destdir)

    deleteProperty(data, 'SccProjectName')
    deleteProperty(data, 'SccLocalPath')
    deleteProperty(data, 'SccProvider')
    deleteProperty(data, 'SccAuxPath')
    deleteProperty(data, 'OldToolsVersion')
    
    editProperty(data, 'PreBuildEvent', None)
    editProperty(data, 'PostBuildEvent', None)
    editProperty(data, 'TargetFrameworkVersion', frmver)

    editTarget(data, projtype)

    xml = xmltodict.unparse(data, short_empty_elements=True, pretty=True, newl = '\n', indent='   ')

    with open(projectfile, 'w') as data_file:
        data_file.write(xml)
        data_file.close()

exit()