#!/usr/bin/python
'''
Created on Aug 9, 2016

@author: greg
'''
import sys
import os
import json
from collections import OrderedDict

rootpath = os.path.abspath('..')

with open(os.path.join(rootpath,'build.cfg')) as fp:
    cfg = json.load(fp)

#-------------------------------------------------------------------------------
#  Open up the json files and bring them into memory
#-------------------------------------------------------------------------------
with open('./projects.json', 'r') as fp:
    projects = json.load(fp)
    fp.close()
   
with open('./missing.json', 'r') as fp:
    missing = json.load(fp)
    fp.close() 


#-------------------------------------------------------------------------------
#  Main
#-------------------------------------------------------------------------------
def recursive(r, a):
    global ref
    if r in a:
        a.append(r)
        print (a, '(recursive)')

        print ('\nReport: recursive check failed\n')
        sys.exit(1)
    
    a.append(r)
    if len(ref[r]) == 0:
        #print a
        return 
        
    for l in ref[r]:
        recursive( l, list(a) )

    #print a

#-------------------------------------------------------------------------------
#  Build the reference list for all the libraries
#------------------------------------------------------------------------------- 
print ('='*100)
print ('    Report: Recursive assembly reference')
print ('='*100)
print ('')
   
ref = OrderedDict()

for p in projects:
    if projects[p]['type'] == 'library':
        ref[p] = list()
        for r in projects[p]['reference']:
            if r not in missing:
                ref[p].append(r)

#print ref

for r in ref:   
    a = []
    recursive(r, a)
    
print ('\nReport: completed successfully\n')


