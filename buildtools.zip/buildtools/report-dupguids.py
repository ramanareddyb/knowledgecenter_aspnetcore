#!/usr/bin/python
'''
Created on Aug 9, 2016

@author: greg
'''
import sys
import os
import json
from collections import OrderedDict

rootpath = os.path.abspath('..')
    
isError = False
isWarning = False

#-------------------------------------------------------------------------------
#  Open up the json files and bring them into memory
#-------------------------------------------------------------------------------
with open('./projects.json', 'r') as fp:
    projects = json.load(fp, object_pairs_hook=OrderedDict)
    fp.close()

#-------------------------------------------------------------------------------
#  
#-------------------------------------------------------------------------------
print ('\n\n')
print ('='*100)
print ('    Report: Project GUID is already used')
print ('='*100)
print ('')
guids = []
for p in projects:
    guid = projects[p]['projectguid']
    if guid not in guids:
        guids.append(guid)
    else:
        print ("project guid already used", guid, projects[p]['path'])
  
exit(0)

