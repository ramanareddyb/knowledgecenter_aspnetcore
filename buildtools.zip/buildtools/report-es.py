#!/usr/bin/python
#==============================================================================
#  Build the deployment structure out of the source tree.
#
#    by: Greg Bodine
#    date: Feb 2, 2017
#
#==============================================================================
__all__ = []
__author__ = "Greg Bodine"
__copyright__ = "Copyright 2017, Excelicare. All rights reserved"
__version__ = "1.0.0"
__date__ = '2017-03-31'
__updated__ = '2017-08-03'

DEBUG = 0
TESTRUN = 0
PROFILE = 0

import os
import sys
import getopt
import glob
import shutil
from fnmatch import fnmatch
import json
import collections
import xmltodict
import datetime
from collections import OrderedDict

rootpath = os.path.abspath('..')

ewlist = [
    'AxFXDialog',
    'AxFXWebCusCtrlLOV',
    'AxFXWebUICusSplFrmControls',
    'AxFXWebUICharts',
    'AxFXWebUIConflictManager',
    'AxFXWebUICusAppControls',
    'AxFXWebCusCtrlDictionary',
    'AxFXWebUIFieldSelector',
    'AxFXWebUIFormsLibrary',
    'AxFXWebUIHTMLDocuments',
    'AxFXWebUILayoutContainer',
    'AxFXWebUISharedUtilities',
    'AxFXWebUISignOff',
    'AxFXWebUISummaryPanel',
    'AxFXWebUIUserSecondaryToolBar',
    'AxWebUIAppointmentScheduler',
    'AxWebUIAssessmentNavigation',
    'AxWebUICarePlanTemplate',
    'AxWebUICusDrugSearchControl',
    'AxWebUIDisplaySpecialForm',
    'AxWebUIExportPatientRecord',
    'AxWebUILab',
    'AxWebUILogin',
    'AxWebUIMDI',
    'AxWebUIMailBasket',
    'AxWebUIMediastore',
    'AxWebUIMedicationReconciliation',
    'AxWebUIMessenger',
    'AxWebUIOrderComms',
    'AxWebUIPRISM',
    'AxWebUIPRISMMigrationTool',
    'AxWebUIPatientMcn',
    'AxWebUIPatientReferralDashboard',
    'Excelicare.AxWebUIPatientSearch',
    'AxWebUIPresAccountRegistration',
    'AxWebUIPrescription',
    'AxWebUIQAS',
    'AxWebUIReportManager',
    'AxWebUIStaticSpecialForms',
    'AxWebUserManager',
    'AxWebUIUserPreferences',
    'AxWebUIPatientRegistration',
    'AxWebUILOV',
    
    'AxFXGridControl',
    
    'AxWebUIDisplaySpecialForm',
    'AxWebUIePrescription',
    
    # Web Tools
    'AxCompilerService',
    'AxPDFCreator',
    'AxWinSplFrmWebTool',
    'ECWebConfigTool',
    
    # New for 6.6.1
    'AxWebUIDashboardDesigner',
    'AxWebUIDataCardDesigner',
    'AxWebUIMailOptions',
    'AxWebUIMenuDesigner',
    
    # New for 6.6.2
    'AxWebUIPersonRegistration',
    
    # New for 6.8
    'AxWebUIeDocViewer',
    
    # New for 7.0.0.5
    'AxFXWebUISchedulerControl',
    
    #FX4 List
    'Ax.Excelicare.Services',
    'Ax.Excelicare.Commons.UI',
    'Ax.Excelicare.Framework',
    'Ax.Excelicare.Web',
    'Ax.Excelicare.ClinicalNotes.UI',
    'AxPDFCreator'
]

eslist = [
    'AxRSAppointmentManager',
    'AxRSCarePlanTemplate',
    'AxRSClinicalNotes',
    'AxRSDocumentManager',
    'AxRSExportPatientRecord',
    'AxRSLabsService',
    'Excelicare.LOV.RS',
    'AxRSMediaService',
    'AxRSMedicationReconciliation',
    'AxRSMessenger',
    'AxRSOrderCommunications',
    'AxRSExportPatientData',
    'AxRSPatientManager',
    'Excelicare.RS.PatientSearch',
    'AxRSPrescriptionSupport',
    'AxRSSecurityService',
    'AxRSSpecialFormManager',
    'AxRSSummaryPanel',
    
    #FX3 List
    'AxRSUserManager',
    'AxRSReportManager',
    
    #
    'AxLibBizExportPatientRecord',
    'AxExportRecordPatient',
    #'AxWinSplFrmWebTool',
    'ECServiceConfigTool',
    'AxCertificateImport',
    
    # New for 6.6.1
    'AxRSCharts',
    'AxRSDashboardDesigner',
    'AxRSDataCardDesigner',
    'AxRSMenuDesigner',
    
    # New for 6.6.2
    'AxRSContentStorage',
    'AxRSExternalLinkAccount',
    'AxRSPersonRegistration',
	'AxRSAppSupport',
	'AxEPRSEBMeDSResponse',
	'AxRSGeolocation',
	'AxRSScriptManager',
	'AxRSMyCircleService',
	'AxRSPatientDataItemLink',
    
    # New for 6.8
    'AxRSAppSupport',
    'AxRSGeolocation',
    'AxRSMyCircleService',
    'AxRSPatientDataItemLink',
    
    'SpecialFormServiceCompiler',
    'DataEntryCardServiceCompiler',
    
    # New for 6.9
    'AxRSReportManager',
    'AxRSLibBizReportManager',
    'AxRSDiabetesMgtService',
    'AxRSPatientDetails',
    'AxRSSSO',
    'AxRSCCDManager',
    'SocialEventsExtractor',
    'AxRSLibDalDiabetesMgt',
    'AxRSLibBizDiabetesMgt',
    'AxEPMedClickBiz',
    'AxRSSplFrmWebTool',
    'AxEPDirectMessages',
    
    # New for 6.10
    'AxRsCarePlanExport',
    'AxRSPrescription'

]

fxlist = []

dblist = [
    # database
    'AxFN_ApptIsDateExistsInSeries',
    'AxAdhocContSyncDeploy',
    'AxAdHocContDataSync'
]

wslist = [
    #windows service
    'MailSender',
    'PushNotificationService',
    'ExtractSocialEventsService',
    'AxFXEmailProcessor'
]

#------------------------------------------------------------------------------
#  Intialize the projects and solutions dictionaries
#------------------------------------------------------------------------------  
projects = OrderedDict()
with open('./projects.json', 'r') as fp:
    projects = json.load(fp, object_pairs_hook=OrderedDict)
    fp.close()

def findRefs(project, references):
    
    if project in references:
        return
    
    if project in projects:
        references.append(project) 
        
        for ar in projects[project]['reference']:
            findRefs(ar, references)
    
    return

#-------------------------------------------------------------------------------
#  Main
#-------------------------------------------------------------------------------
if __name__ == "__main__":
         
    esreferences = []  # excelicare service list
    ewreferences = []  # excelicare service list
    fxreferences = []  # fx service list
    dbreferences = []  # db tools list
    wsreferences = []  # windows service list
    
    for p in projects:
        if projects[p]['solution'] == 'excelicarefx':
            fxlist.append(p)
    
    fxlist.sort()
    
    for project in fxlist:
        findRefs(project.lower(), fxreferences)
    fxreferences.sort()
     
    for project in eslist:
        findRefs(project.lower(), esreferences)
                        
    esreferences.sort()
    
    
    for project in ewlist:
        findRefs(project.lower(), ewreferences)
                        
    ewreferences.sort()
    
    print ("Assemblies in both Service and Web")
    for r in esreferences:    
        if r in ewreferences:
            print (r, projects[r]["solution"], projects[r]["type"])
    
    print ('')
    print ("FXAssemblies not in FX")
    for r in fxreferences:
        if projects[r]["solution"] != 'excelicarefx':
            print (r, projects[r]["solution"], projects[r]["type"])
            
            
    print ('')
    print ("FXAssemblies not referenced in Web")
    for r in fxlist:    
        if r not in ewreferences:
            print (r)
            
    print ('')
    print ("FXAssemblies not referenced in Service")
    for r in fxlist:    
        if r not in esreferences:
            print (r)
            
    print ('')
    print ("List all projects that are not references by any EW or ES projects")
    for p in projects:
        if p not in esreferences and p not in ewreferences:
            if projects[p]['type'] != 'winexe':
                print (p)
            
    print ('')
    print ("List all projects that are not references by any other project")
    for p in projects:
        x = 0    
        for r in projects:
            if p.lower() in projects[r]['reference']:
                x = x + 1
        
        if x == 0:
            if projects[p]['type'] != 'winexe':
                if projects[p]['solution'] == 'excelicare':
                    if projects[p]['assembly'] not in ewlist:
                        print (p, x)
    
    print ('')
    print ("List all RestService SVC files")            
    for path, subdirs, files in os.walk(os.path.join('..','RestService')):
        for name in files:
            if fnmatch(name, '*.svc'):
                print (name)
    
    print ('')
    print ("List all projects that have an SVC in there content")
    x = []
    for p in projects:
        if projects[p]['solution'] == 'restservice':
            for c in projects[p]['content']:
                if os.path.splitext(c)[1].lower() == '.svc':        
                    if projects[p]['assembly'] not in x:
                        x.append(projects[p]['assembly'])
    x.sort()
    print ('   project not in eslist')
    for a in x:
        if a not in eslist:
            print ('     ',a)
            
    print ('   eslist not in project')
    for a in eslist:
        if a not in x and projects[a.lower()]['type'] == 'library':
            print ('     ',a)
    
    print ('\n\nEND...')
