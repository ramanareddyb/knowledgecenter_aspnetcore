#!/usr/bin/python
# encoding: utf-8
'''
mdiff -- Manifest differences

mdiff is a description

It defines classes_and_methods

@author:     Greg Bodine

@copyright:  2017 Excelicare. All rights reserved.

@license:    2017 Excelicare. All rights reserved.

@contact:    greg.bodine@excelicare.com
@deffield    updated: Updated
'''

import sys
import os
import json

from argparse import ArgumentParser
from argparse import RawDescriptionHelpFormatter

__all__ = []
__version__ = 0.1
__date__ = '2017-03-31'
__updated__ = '2017-03-31'

DEBUG = 0
TESTRUN = 0
PROFILE = 0

ignore = [
    '.ds_store',
    '.gitkeep',
    '.project',
    '.pydevproject',
    'database'
    'demos',
    'dojoback',
    'excelicarecc',
    'excelicareservicecc',
    'excelicareservicefx4',
    'powertools',
    'samples',
    'thumbs.db',
]


#==============================================================================
def in_ignore(s):
    for i in ignore:
        if i.lower() in s.lower():
            return True
    return False

#==============================================================================
class CLIError(Exception):
    '''Generic exception to raise and log different fatal errors.'''
    def __init__(self, msg):
        super(CLIError).__init__(type(self))
        self.msg = "E: %s" % msg
    def __str__(self):
        return self.msg
    def __unicode__(self):
        return self.msg

#==============================================================================
def manifest_diff(m1, m2):
    print ('comparing:', m1, 'to', m2)
    
    with open(m1, 'rb') as fp:
        m1json = json.loads(fp.read())
        fp.close()
        
    m1files = []
    for m in m1json:
        for f in m1json[m]:
            if not in_ignore(f['fpath']):
                m1files.append(f['fpath'].lower())

    with open(m2, 'rb') as fp:
        m2json = json.loads(fp.read())
        fp.close()
    
    m2files = []
    for m in m2json:
        for f in m2json[m]:
            if not in_ignore(f['fpath']):
                m2files.append(f['fpath'].lower())
    
    m1set = set(m1files)
    m2set = set(m2files)
    
    x1 = None
    x2 = None
    print ('files in',  m2, 'but not in', m1  )
    for s in sorted(m2set-m1set):
        l = s.split('/')

        if x1 != l[1]:
            print ('\n\n', l[1])
            x1 = l[1]
            x2 = None
            
        if len(l) > 2:
            if x2 != l[2]:
                if x2 is not None:
                    print ('')
                x2 = l[2]
                    
        print ('  ', s  )
    
    return 0

#==============================================================================
def main(argv=None): # IGNORE:C0111
    '''Command line options.'''

    if argv is None:
        argv = sys.argv
    else:
        sys.argv.extend(argv)

    program_name = os.path.basename(sys.argv[0])
    program_version = "v%s" % __version__
    program_build_date = str(__updated__)
    program_version_message = '%%(prog)s %s (%s)' % (program_version, program_build_date)
    program_shortdesc = __import__('__main__').__doc__.split("\n")[1]
    program_license = '''%s

  Created by Greg Bodine on %s.
  Copyright 2017 Excelicare. All rights reserved.

USAGE
''' % (program_shortdesc, str(__date__))

    try:
        # Setup argument parser
        parser = ArgumentParser(description=program_license, formatter_class=RawDescriptionHelpFormatter)
        parser.add_argument("-v", "--verbose", dest="verbose", action="count", help="set verbosity level [default: %(default)s]")
        parser.add_argument('-V', '--version', action='version', version=program_version_message)
        parser.add_argument(dest="paths", help="paths to folder(s) with source file(s) [default: %(default)s]", metavar="path", nargs='+')

        # Process arguments
        args = parser.parse_args()

        paths = args.paths
        verbose = args.verbose

        if len(paths) != 2:
            raise CLIError("error: need two files to compare.")
            
        manifest_diff(paths[0], paths[1])
        
        return 0
    
    except KeyboardInterrupt:
        ### handle keyboard interrupt ###
        return 0
    
    except Exception as e:
        if DEBUG or TESTRUN:
            raise(e)
        indent = len(program_name) * " "
        sys.stderr.write(program_name + ": " + repr(e) + "\n")
        sys.stderr.write(indent + "  for help use --help")
        return 2

#==============================================================================
if __name__ == "__main__":
    if DEBUG:
        sys.argv.append("-h")
        sys.argv.append("-v")
        sys.argv.append("-r")
    if TESTRUN:
        import doctest
        doctest.testmod()
    if PROFILE:
        import cProfile
        import pstats
        profile_filename = 'mdiff_profile.txt'
        cProfile.run('main()', profile_filename)
        statsfile = open("profile_stats.txt", "wb")
        p = pstats.Stats(profile_filename, stream=statsfile)
        stats = p.strip_dirs().sort_stats('cumulative')
        stats.print_stats()
        statsfile.close()
        sys.exit(0)
    sys.exit(main())