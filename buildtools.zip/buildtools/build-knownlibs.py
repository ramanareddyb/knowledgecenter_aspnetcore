#!/usr/bin/python
'''
Created on Dec 28, 2016

@author: greg
'''

import os

from fnmatch import fnmatch

import json

import collections
import hashlib
import time
import shutil 

root = os.path.abspath('..')

with open(os.path.join(root,'build.cfg')) as fp:
# with open(os.path.join(rootpath,'build.cfg')) as fp:
    cfg = json.load(fp)

frmver = (cfg['.NETFramework']['version']).lower()

with open(os.path.abspath('./netframework-%s.json'%(frmver.replace('.',''))), 'r') as stream:
    frameworkrefs = json.load(stream)
    stream.close()

pkg = os.path.abspath(os.path.join('..', 'Packages', 'Libraries'))
print ('Reference Assemblies', pkg)

#==============================================================================


dlls = {}

for path, subdirs, files in os.walk(pkg):
    for name in files:

        if fnmatch(name, '*.dll'):
            fname = os.path.join(path, name)
            lname = name.lower().split('.dll')[0]
            
            if lname not in dlls:
                dlls[lname] = {}

            s = os.stat(fname)
            h = hashlib.md5(open(fname, 'rb').read()).hexdigest()

            x = { 
             'md5': h,
             'size': s.st_size
            }

            dlls[lname] = x
    
with open('./knownlibs.json', 'w') as fp:
    files=list(set(dlls.keys()).union(set(frameworkrefs)))
    files.sort()
    fp.write(json.dumps(files, indent=2))
    fp.close()

exit()




