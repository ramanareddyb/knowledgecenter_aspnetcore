#!/usr/bin/python

'''
manifest -- shortdesc

manifest is a description

It defines classes_and_methods

@author:     greg bodine
@copyright:  2017 Excelciare. All rights reserved.
@license:    license
@contact:    greg.bodine@excelicare.com
@deffield    updated: Updated
'''

import os
import sys

from fnmatch import fnmatch
import json
import collections
import hashlib
import time

try:
    import win32api
    __windows__ = 1
except ImportError:
    __windows__ = 0

from argparse import ArgumentParser
from argparse import RawDescriptionHelpFormatter

__all__ = []
__version__ = 0.1
__date__ = '2017-03-31'
__updated__ = '2017-03-31'

DEBUG = 0
TESTRUN = 0
PROFILE = 0

#==============================================================================
class CLIError(Exception):
    '''Generic exception to raise and log different fatal errors.'''
    
    def __init__(self, msg):
        super(CLIError).__init__(type(self))
        self.msg = "E: %s" % msg
    def __str__(self):
        return self.msg
    def __unicode__(self):
        return self.msg
    
#==============================================================================
def getFileProperties(fname):
    '''Read all properties of the given file return them as a dictionary.'''
    
    propNames = (
        'Comments', 
        'InternalName', 
        'ProductName',
        'CompanyName', 
        'LegalCopyright', 
        'ProductVersion',
        'FileDescription', 
        'LegalTrademarks', 
        'PrivateBuild',
        'FileVersion', 
        'OriginalFilename', 
        'SpecialBuild'
        )

    props = {'StringFileInfo': None, 'FileVersion': None, 'ProductVersion': None, 'FileDate': None}

    try:
        # backslash as parm returns dictionary of numeric info corresponding to VS_FIXEDFILEINFO struc
        fixedInfo = win32api.GetFileVersionInfo(fname, '\\')
                
        props['FileVersion'] = "%d.%d.%d.%d" % (fixedInfo['FileVersionMS'] / 65536,
                fixedInfo['FileVersionMS'] % 65536, fixedInfo['FileVersionLS'] / 65536,
                fixedInfo['FileVersionLS'] % 65536)
        
        props['ProductVersion'] = "%d.%d.%d.%d" % (fixedInfo['ProductVersionMS'] / 65536,
                fixedInfo['ProductVersionMS'] % 65536, fixedInfo['ProductVersionLS'] / 65536,
                fixedInfo['ProductVersionLS'] % 65536)


        # \VarFileInfo\Translation returns list of available (language, codepage)
        # pairs that can be used to retreive string info. We are using only the first pair.
        lang, codepage = win32api.GetFileVersionInfo(fname, '\\VarFileInfo\\Translation')[0]

        # any other must be of the form \StringfileInfo\%04X%04X\parm_name, middle
        # two are language/codepage pair returned from above

        strInfo = {}
        for propName in propNames:
            strInfoPath = u'\\StringFileInfo\\%04X%04X\\%s' % (lang, codepage, propName)
            ## print str_info
            strInfo[propName] = win32api.GetFileVersionInfo(fname, strInfoPath)

        props['StringFileInfo'] = strInfo
    except:
        pass

    return props

#==============================================================================
def build_manifest(scanpath):
    '''Read all properties of the given file return them as a dictionary.'''
    
    axsys = {}
    
    for sp in scanpath:
        #print 'scanning', sp
        for path, subdirs, files in os.walk(sp):
            
            # ignore the .git directory.
            if '.git' in path:
                continue
            
            for name in files:
                fname = os.path.join(path, name)
                #print fname
                lname = name.lower()
                if lname not in axsys:
                    axsys[lname] = []
                    
                s = os.stat(fname)
                h = hashlib.md5(open(fname, 'rb').read()).hexdigest()
                
                x = {}
                x['fpath'] = fname.replace(sp,'.').replace('\\','/')

                x['md5'] = h
                x['size'] = s.st_size
                x['ctime'] = s.st_ctime
                x['mtime'] = s.st_mtime
                
                if __windows__:
                    prop = getFileProperties(fname)
                    
                    if prop['FileVersion'] is not None:
                        x['fileversion'] = prop['FileVersion']
                    
                    if prop['ProductVersion'] is not None:    
                        x['productversion'] = prop['ProductVersion']
                        
                    if prop['FileDate'] is not None:    
                        x['filedate'] = prop['FileDate']
                    
                    if prop['StringFileInfo'] is not None:
                        if prop['StringFileInfo']['ProductName'] is not None:
                            x['productname'] = prop['StringFileInfo']['ProductName']
                        if prop['StringFileInfo']['CompanyName'] is not None:    
                            x['companyname'] = prop['StringFileInfo']['CompanyName']
                        if prop['StringFileInfo']['LegalCopyright'] is not None:
                            x['legalcopyright'] = prop['StringFileInfo']['LegalCopyright']
                        if prop['StringFileInfo']['FileDescription'] is not None:
                            x['filedescription'] = prop['StringFileInfo']['FileDescription']
                        if prop['StringFileInfo']['Comments'] is not None:
                            x['comments'] = prop['StringFileInfo']['Comments']
                
                axsys[lname].append(x)
    
            
    print (json.dumps(axsys, indent=2))
    #with open(os.path.join('.', 'manifest.json'), 'w') as fp:
    #    fp.write(json.dumps(axsys, indent=2))
    #    fp.close()
        
    return 0

#==============================================================================    
def main(argv=None): # IGNORE:C0111
    '''Command line options.'''

    if argv is None:
        argv = sys.argv
    else:
        sys.argv.extend(argv)

    program_name = os.path.basename(sys.argv[0])
    program_version = "v%s" % __version__
    program_build_date = str(__updated__)
    program_version_message = '%%(prog)s %s (%s)' % (program_version, program_build_date)
    program_shortdesc = __import__('__main__').__doc__.split("\n")[1]
    program_license = '''%s

  Created by Greg Bodine on %s.
  Copyright 2017 Excelicare. All rights reserved.

USAGE
''' % (program_shortdesc, str(__date__))

    try:
        # Setup argument parser
        parser = ArgumentParser(description=program_license, formatter_class=RawDescriptionHelpFormatter)
        parser.add_argument("-r", "--recursive", dest="recurse", action="store_true", help="recurse into subfolders [default: %(default)s]")
        parser.add_argument("-v", "--verbose", dest="verbose", action="count", help="set verbosity level [default: %(default)s]")
        parser.add_argument("-i", "--include", dest="include", help="only include paths matching this regex pattern. Note: exclude is given preference over include. [default: %(default)s]", metavar="RE" )
        parser.add_argument("-e", "--exclude", dest="exclude", help="exclude paths matching this regex pattern. [default: %(default)s]", metavar="RE" )
        parser.add_argument('-V', '--version', action='version', version=program_version_message)
        parser.add_argument(dest="paths", help="paths to folder(s) with source file(s) [default: %(default)s]", metavar="path", nargs='+')

        # Process arguments
        args = parser.parse_args()

        paths = args.paths
        verbose = args.verbose
        recurse = args.recurse
        inpat = args.include
        expat = args.exclude

        if inpat and expat and inpat == expat:
            raise CLIError("include and exclude pattern are equal! Nothing will be processed.")

        return build_manifest(paths)


    except KeyboardInterrupt:
        ### handle keyboard interrupt ###
        return 0
    
    except Exception as e:
        if DEBUG or TESTRUN:
            raise(e)
        indent = len(program_name) * " "
        sys.stderr.write(program_name + ": " + repr(e) + "\n")
        sys.stderr.write(indent + "  for help use --help\n")
        return 2

#==============================================================================
if __name__ == "__main__":
    if DEBUG:
        sys.argv.append("-h")
        sys.argv.append("-v")
        sys.argv.append("-r")
        
    if TESTRUN:
        import doctest
        doctest.manifestmod()
        
    if PROFILE:
        import cProfile
        import pstats
        profile_filename = 'manifest_profile.txt'
        cProfile.run('main()', profile_filename)
        statsfile = open("profile_stats.txt", "wb")
        p = pstats.Stats(profile_filename, stream=statsfile)
        stats = p.strip_dirs().sort_stats('cumulative')
        stats.print_stats()
        statsfile.close()
        sys.exit(0)
        
    sys.exit(main())

