#!/usr/bin/python
'''
Created on Aug 9, 2016

@author: greg
'''
import sys
import os
import json
from collections import OrderedDict

rootpath = os.path.abspath('..')
    
isError = False
isWarning = False

#-------------------------------------------------------------------------------
#  Open up the json files and bring them into memory
#-------------------------------------------------------------------------------
with open('./projects.json', 'r') as fp:
    projects = json.load(fp, object_pairs_hook=OrderedDict)
    fp.close()


#-------------------------------------------------------------------------------
#  
#-------------------------------------------------------------------------------
print ('\n\n')
print ('='*100)
print ('    Report: project file names that do to match the assembly name')
print ('='*100)
print ('')

for p in projects:
    path = projects[p]['path']
    assembly = projects[p]['assembly']
    prjpath = os.path.split(projects[p]['path'])[0]
    prjparent =  os.path.split(prjpath)[1]
    prjfile = os.path.splitext(os.path.split(projects[p]['path'])[1])[0]
    prjext = os.path.splitext(os.path.split(projects[p]['path'])[1])[1]
    
    if assembly != prjfile:
        print ('mv', path.replace(rootpath, '..'), os.path.join(prjpath, assembly+prjext).replace(rootpath, '..'))

print ('\n\n')
print ('='*100)
print ('    Report: solution project direcotry names that do to match the assembly name')
print ('='*100)
print ('' )
for p in projects:
    assembly = projects[p]['assembly']
    prjpath = os.path.split(projects[p]['path'])[0]
    prjparent =  os.path.split(prjpath)[1]
    prjpparent =  os.path.split(prjpath)[0]
    prjfile = os.path.splitext(os.path.split(projects[p]['path'])[1])[0]

    if assembly != prjparent:
        #print 'Solution Prject Name Missamatch:', assembly, 'NE', prjparent, '-->', prjpath
        print ('mv', prjpath.replace(rootpath, '..'), os.path.join(prjpparent, assembly).replace(rootpath, '..'))
           
exit(0)

