#!/usr/bin/python
import os
from fnmatch import fnmatch
import xmltodict
import json
from collections import OrderedDict

rootpath = os.path.abspath('..')
with open(os.path.join(rootpath,'build.cfg')) as fp:
    cfg = json.load(fp)

projects = OrderedDict()
with open('./projects.json', 'r') as fp:
    projects = json.load(fp, object_pairs_hook=OrderedDict)
    fp.close()
    
def cleanPropertyGroups(data):
    if 'PropertyGroup' in data['Project']:
        group = data['Project']['PropertyGroup']
        
        if type(group) is list:
            for idx, items in enumerate(group):
                if group[idx] is not None:
                    if len(items) == 0:
                        group.pop(idx)

def delPropertyGroup(data, keyname):
    if 'PropertyGroup' in data['Project']:
        group = data['Project']['PropertyGroup']
        
        if type(group) is list:
            for idx, items in enumerate(group):
                if group[idx] is not None:
                    files=list(group[idx].keys())
                          
                    if files[0] == keyname:
                        del group[idx][keyname]
                        if len(group[idx]) == 0:
                            group.pop(idx)
                                         
def getProjectReferences(data):
    refnames = []
    if 'ItemGroup' in data['Project']:
        group = data['Project']['ItemGroup']
        
        if type(group) is list:
            for items in group:
                if items is not None and 'ProjectReference' in items:
                    names = items['ProjectReference']
                    
                    if type(names) is list:
                        for name in names:
                            refnames.append(name['Name'])
                    else:
                        refnames.append(names['Name'])
                    
        else:
            if 'ProjectReference' in group:
                refnames.append(group['ProjectReference']['Name'])
    
    return refnames

def getCOMReferences(data):
    refnames = []
    if 'ItemGroup' in data['Project']:
        group = data['Project']['ItemGroup']
        
        if type(group) is list:
            for items in group:
                if items is not None and 'COMReference' in items:
                    comrefs = items['COMReference']
                    
                    if type(comrefs) is list:
                        for comref in comrefs:
                            refnames.append('Interop.'+comref['@Include'])
                    else:
                        refnames.append('Interop.'+comrefs['@Include'])
                    
        else:
            if 'COMReference' in group:
                refnames.append('Interop.'+group['COMReference']['@Include'])
    
    return refnames

def getReferences(data):
    refnames = []
    if 'ItemGroup' in data['Project']:
        group = data['Project']['ItemGroup']
        
        if type(group) is list:
            for items in group:
                if items is not None and 'Reference' in items:
                    names = items['Reference']
                    
                    if type(names) is list:
                        for name in names:
                            refnames.append(name['@Include'])
                    else:
                        refnames.append(names['@Include'])
    
    return refnames
    
def cleanItemGroups(data):
    if 'ItemGroup' in data['Project']:
        group = data['Project']['ItemGroup']
        
        if type(group) is list:
            for idx, items in enumerate(group):
                if group[idx] is not None:
                    if len(items) == 0:
                        group.pop(idx)                 

def delItemGroup(data, keyname):
    if 'ItemGroup' in data['Project']:
        group = data['Project']['ItemGroup']
        
        if type(group) is list:
            for idx, items in enumerate(group):
                if group[idx] is not None:
                    files=list(group[idx].keys())
                          
                    if files[0] == keyname:
                        del group[idx][keyname]
                        if len(group[idx]) == 0:
                            group.pop(idx)

def addReferences(data, refnames):
    if 'ItemGroup' in data['Project']:
        group = data['Project']['ItemGroup']
        
        if type(refnames) is list:
            r = []
            for refname in refnames:
                r.append({'@Include': refname.split(',')[0]})
        else:
            r={'@Include': refnames.split(',')[0]}

        group.insert(0, {'Reference': r})

             
#-------------------------------------------------------------------------------
#  Main
#-------------------------------------------------------------------------------
print ('='*100)
print ('    Pre-Build: cleanup references.')
print ('='*100)
print ('')
for project in projects:
    projectfile = projects[project]['path']
    projtype = projects[project]['projtype']                
    
    with open(projectfile,'rb') as fp:    
        data = xmltodict.parse(fp, xml_attribs=True)
        fp.close()
    
    refnames1 = getReferences(data)    
    refnames2 = getProjectReferences(data)
    refnames3 = getCOMReferences(data)

    refnames = refnames1+refnames2+refnames3
    refnames.sort()
    
    
    delItemGroup(data, 'Reference')
    delItemGroup(data, 'ProjectReference')
    delItemGroup(data, 'BootstrapperPackage')
    delItemGroup(data, 'COMReference')
    cleanItemGroups(data)
    
    delPropertyGroup(data, 'PreBuildEvent')
    delPropertyGroup(data, 'PostBuildEvent')
    cleanPropertyGroups(data)
        
    addReferences(data, refnames)
    
    xml = xmltodict.unparse(data, short_empty_elements=True, pretty=True, newl = '\n', indent='   ')

    with open(projectfile, 'w') as fp:
        fp.write(xml)
        fp.close()
    
exit()


