#!/usr/bin/python
'''
Created on Aug 9, 2016

@author: greg
'''
import sys
import os
import json
from collections import OrderedDict

rootpath = os.path.abspath('..')
with open(os.path.join(rootpath,'build.cfg')) as fp:
    cfg = json.load(fp)

frmver = (cfg['.NETFramework']['version']).lower().replace('.','')

isError = False
isWarning = False

#-------------------------------------------------------------------------------
#  Open up the json files and bring them into memory
#-------------------------------------------------------------------------------
with open('./projects.json', 'r') as stream:
    projects = json.load(stream)
    stream.close()
    
with open('./missing.json', 'r') as stream:
    missing = json.load(stream)
    stream.close()

with open('./knownlibs.json', 'r') as stream:
    knownlibs = json.load(stream)
    stream.close()

with open('./netframework-%s.json'%(frmver), 'r') as stream:
    frameworkrefs = json.load(stream)
    stream.close()

knownlibs.extend(frameworkrefs)


#-------------------------------------------------------------------------------
#  
#-------------------------------------------------------------------------------
print ('\n\n'        )
print ('='*100)
print ('    Report: Missing assembly references')
print ('='*100)
print ('')

diff = set(missing) - set(knownlibs)

for d in diff:
    print ('Missing Assembly Reference:', d)
    isError = True

    for p in projects:
        if d in projects[p]['reference']:
            print ('    referenced in', projects[p]['assembly'], '-->', os.path.split(projects[p]['path'])[0])
            
    print ('')


#-------------------------------------------------------------------------------
#  
#-------------------------------------------------------------------------------
print ('\n\n')
print ('='*100)
print ('    Report: Assembly framework is not',  cfg['.NETFramework']['version'])
print ('='*100)
print ('')
for p in projects:
    if projects[p]['framework'] != cfg['.NETFramework']['version']:
        isWarning = True
        print ('Framwork Missmatch:', '(', projects[p]['framework'],')', projects[p]['assembly'], '-->', os.path.split(projects[p]['path'])[0])

#-------------------------------------------------------------------------------
#  
#-------------------------------------------------------------------------------
print ('\n\n')
print ('='*100)
print ('    Report: Project File names that do to match the assembly name')
print ('='*100)
print ('')

for p in projects:
    prjpath = os.path.split(projects[p]['path'])[0]
    prjname, prjext = os.path.splitext(os.path.split(projects[p]['path'])[1])
    asmname = projects[p]['assembly']
    
    if asmname != prjname:
        isWarning = True
        #print 'Project Filename Missamatch:', projects[p]['assembly'], '-->', prjname, 'in', prjpath.replace(rootpath, '.')
        print ('mv', projects[p]['path'].replace(rootpath, '.').replace(' ','\ '), os.path.join(prjpath,asmname+prjext).replace(rootpath, '.').replace(' ', '\ '))

#-------------------------------------------------------------------------------
#  
#-------------------------------------------------------------------------------
print ('\n\n')
print ('='*100)
print ('    Report: Project Tree names that do to match the assembly name')
print ('='*100)
print ('')

for p in projects:
    prjpath, prjname = os.path.split(projects[p]['path'])
    treepath, prjtree = os.path.split(prjpath)
    prjname = os.path.splitext(prjname)[0]
    asmname = projects[p]['assembly']
    
    if asmname != prjtree:
        isWarning = True
        print ('Tree Name Missamatch:', projects[p]['assembly'], '-->', prjtree, 'in', prjpath)
        #print 'mv', prjpath, os.path.join(treepath, asmname)

#-------------------------------------------------------------------------------
#  
#-------------------------------------------------------------------------------
print ('\n\n'        )
print ('='*100)
print ('    Report: find missing source')
print ('='*100)

for p in projects:
    if projects[p]['source'] != None:
        sourcefiles = projects[p]['source']
        for sf in sourcefiles:
            if 'assemblyinfo' in sf.lower():
                continue

            x = os.path.split(projects[p]['path'])[0]+os.sep+sf.replace('\\', os.sep)
            if not os.path.exists(x):
                print ('ERROR!!!  source file missing:', x)
                isError = True
            if 'assemblyinfo' not in sf:
                x = os.path.split(projects[p]['path'])[0]+os.sep+sf.replace('\\', os.sep)
                if not os.path.exists(x):
                    print ('ERROR!!!  source file missing:', x)
                    isError = True


#-------------------------------------------------------------------------------
#  
#-------------------------------------------------------------------------------                             
if isError is True:
    print ('\nReport: Failed\n')
    exit(1)

if isWarning is True:
    print ('\nReport: Warning\n')
else:    
    print ('\nReport: completed successfully\n')
    
exit(0)

