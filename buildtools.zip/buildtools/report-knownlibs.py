#!/usr/bin/python
'''
Created on Dec 28, 2016

@author: greg

'''



import os

from fnmatch import fnmatch

import json

import collections
import hashlib
import time
import shutil 

from collections import OrderedDict

pkg = os.path.abspath('../Packages/Libraries')

with open('./missing.json', 'r') as fp:
    missing = json.load(fp)
    fp.close()

#==============================================================================


dlls = OrderedDict()


for path, subdirs, files in os.walk(pkg):
    for name in files:

        if fnmatch(name, '*.dll'):
            fname = os.path.join(path, name)
            lname = name.lower().split('.dll')[0]
            
            if lname not in dlls:
                dlls[lname] = {}

            s = os.stat(fname)
            h = hashlib.md5(open(fname, 'rb').read()).hexdigest()

            x = { 
             'md5': h,
             'size': s.st_size
            }

            dlls[lname] = x
            
for x in sorted(set(dlls.keys()) - set(missing)):
    print (x) 


exit()




