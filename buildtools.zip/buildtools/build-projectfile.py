#!/usr/bin/python
'''
Created on Aug 9, 2016

@author: greg
'''
import os
import json
import time
from collections import OrderedDict

rootpath = os.path.abspath('..')
with open(os.path.join(rootpath,'build.cfg')) as fp:
    cfg = json.load(fp)

with open('./projects.json', 'r') as fp:
    projects = json.load(fp)
    fp.close()

with open('./missing.json', 'r') as fp:
    missing = json.load(fp)
    fp.close()  

#==============================================================================
#
#==============================================================================
def dep(arg):
    '''
        Dependency resolver

    "arg" is a dependency dictionary in which
    the values are the dependencies of their respective keys.
    '''
    d=dict((k, set(arg[k])) for k in arg)
    r=[]
    while d:
        # values not in keys (items without dep)
        t=set(i for v in d.values() for i in v)-set(d.keys())
        # and keys without value (items without dep)
        t.update(k for k, v in d.items() if not v)
        # can be done right away
        r.append(t)
        # and cleaned up
        d=dict(((k, v-t) for k, v in d.items() if v))
    return r

def checkRecursive(r, a):
    if r in a:
        a.append(r)
        print (a, '(recursive)')
        return
    
    a.append(r)
    if len(ref[r]) == 0:
        #print a
        return 
        
    for l in ref[r]:
        checkRecursive( l, list(a) )
        
#==============================================================================
#
#==============================================================================
print ('='*100)
print ('    Pre-Build: Build Solution level project file ')
print ('='*100)
print ('')

ref = OrderedDict()
for p in projects:
    if projects[p]['type'] == 'library' or projects[p]['type'] == 'winexe': 
        ref[p] = list()
        for r in projects[p]['reference']:
            if r not in missing:
                ref[p].append(r) 
                
for r in ref:
    a = []
    checkRecursive(r, a)

order = []    
for d in dep(ref):
    for x in d:
        order.append(x)
        
#print order

with open('./excelicare.proj', 'w') as fp:    
    fp.write( '<Project DefaultTargets="BuildAll" ToolsVersion="14.0" xmlns="http://schemas.microsoft.com/developer/msbuild/2003">\n' )
    fp.write( '  <Import Project="$(MSBuildExtensionsPath)\MSBuildCommunityTasks\MSBuild.Community.Tasks.Targets"/>\n' )
    fp.write( '  <PropertyGroup>\n' )
    fp.write( '    <RootDir>%s</RootDir>\n'%(rootpath) )
    fp.write( '    <DestinationDir Condition=" \'$(DESTINATIONDIR)\' == \'\' ">%s\\%s</DestinationDir>\n'%(rootpath,"build") )
    fp.write( '    <SolutionDir>%s</SolutionDir>\n'%(rootpath) )
    fp.write( '    <Configuration Condition=" \'$(Configuration)\' == \'\' ">Release</Configuration>\n' )
    fp.write( '    <Platform>AnyCPU</Platform>\n' )
    fp.write( '  </PropertyGroup>\n' )
    
    fp.write( '  <PropertyGroup><BuildAllDependsOn>\n' )
    fp.write( '    PreBuild;\n' )
    for o in order:
        fp.write( "    Project_%s;\n"%(o.replace('.','_').upper()) )
    fp.write( '    PostBuild;\n' )
    fp.write( '  </BuildAllDependsOn></PropertyGroup>\n' )
    
    fp.write( '  <Target Name="BuildAll" DependsOnTargets="$(BuildAllDependsOn)"/>\n\n' )
    
    fp.write( '  <Target Name="PreBuild">\n' )
    
    fp.write( '  <PropertyGroup>\n' )
    fp.write( '    <BuildNumber>$([System.DateTime]::UtcNow.ToString(yy))$([System.DateTime]::UtcNow.DayOfYear.ToString("D3"))$([System.DateTime]::UtcNow.ToString(.HHmm))</BuildNumber>\n')
    fp.write( '    <VersionNumber>%s</VersionNumber>\n'%(cfg['version']))
    fp.write( '  </PropertyGroup>\n' )
    
    fp.write( '    <Message Text="=============================================================================" />\n' )
    fp.write( '    <Message Text="  Version: $(VersionNumber), Build: $(BuildNumber)"/>\n' )
    fp.write( '    <Message Text="  MSBuild Path = $(MSBuildBinPath)" />\n' )
    fp.write( '    <Message Text="  MSBuild Tool Version = $(MSBuildToolsVersion)" />\n' )
      
    fp.write( '    <Message Text="  Project Root = $(MSBuildProjectDirectory)" />\n' )
    fp.write( '    <Message Text="  Project File = $(MSBuildProjectFile)" />\n' )
      
    fp.write( '    <Message Text="  Root Folder = $(RootDir)" />\n' )
    fp.write( '    <Message Text="  Solution Folder = $(SolutionDir)" />\n' )
    fp.write( '    <Message Text="  Destination Folder = $(DestinationDir)" />\n' )
    fp.write( '    <Message Text="  MSBuild ThisFileDirectory  = $(MSBuildThisFileDirectory)" />\n' )
    fp.write( '    <Message Text="=============================================================================" />\n' )
    
    fp.write( '    <ItemGroup>\n' )
    fp.write( '      <SourceFiles Include="$(RootDir)\\Packages\\Libraries\\*.*" />\n' )
    fp.write( '      <BuildtagFile Include="../buildtag.txt"/>\n' )
    fp.write( '    </ItemGroup>\n' )
    fp.write( '    <Copy SourceFiles="@(SourceFiles)" DestinationFolder="$(RootDir)\\build\\bin\\$(Configuration)" OverwriteReadOnlyFiles="true" SkipUnchangedFiles="false"></Copy> \n')
    fp.write( '    <WriteLinesToFile File="@(BuildtagFile)" Lines="$(VersionNumber).$(BuildNumber)" Overwrite="true" />\n')
 
    
    fp.write( '  </Target>\n' )
    
    fp.write( '  <Target Name="PostBuild">\n' )
    fp.write( '    <Message Text="=============================================================================" />\n' )
    fp.write( '    <Message Text="  Build Completed." /> \n' )
    fp.write( '    <Message Text="=============================================================================" />\n' ) 
    fp.write( '  </Target>\n' )
    
    for o in order:
        fp.write( '  <Target Name="Project_%s">\n'%(o.replace('.','_').upper() ))
        fp.write( '    <MSBuild Projects ="%s"\n'%(projects[o.lower()]['path']  ))
        fp.write( '             ContinueOnError ="false"\n'  )
        fp.write( '             Properties="Configuration=$(Configuration);Platform=$(Platform);DestinationDir=$(DestinationDir);SolutionDir=$(SolutionDir);VersionNumber=$(VersionNumber);BuildNumber=$(BuildNumber)">\n' )
        fp.write( '      <Output ItemName="OutputFiles" TaskParameter="TargetOutputs"/>\n' )
        fp.write( '    </MSBuild>\n' )
        fp.write( '  </Target>\n' )
    
    fp.write( '</Project>' ) 
    

